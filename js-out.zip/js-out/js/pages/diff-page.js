/**
 * diff-page.js — entry for /diff/index.html.
 *
 * Loads ALL parsed sessions and lets the user pick two to compare.
 * Renders the diff using lib/diff.js. Mirrors components/DiffClient.tsx
 * and components/DiffView.tsx.
 *
 * Note: this script lives at js/pages/ but the HTML loads it via
 * "../../js/pages/diff-page.js" — so all relative imports here use
 * "../lib/..." and "../ui/...".
 */

import { loadAllSessions } from "../lib/session-loader.js";
import { diffSessions } from "../lib/diff.js";
import { card, pill } from "../ui/primitives.js";

const root = document.getElementById("diff-root");
const SESSIONS_PATH = "../sessions/";

boot().catch((err) => {
  console.error("[diff] boot failed", err);
  root.replaceChildren(stateError(`Failed to load: ${err.message}`));
});

async function boot() {
  const { sessions, errors } = await loadAllSessions(SESSIONS_PATH);
  if (errors.length > 0) {
    for (const e of errors) console.warn(`[diff] parse failed for ${e.file}: ${e.message}`);
  }

  root.replaceChildren();
  if (sessions.length < 2) {
    root.appendChild(stateEmpty(
      "At least two sessions are required for diff. Drop more XML files into /sessions/ and refresh.",
    ));
    return;
  }

  // ── Picker card ──────────────────────────────────────────────────
  const pickerCard = card({ title: "Pick two sessions" });
  const pickers = document.createElement("div");
  pickers.className = "diff-pickers";

  const leftWrap = document.createElement("div");
  const leftLabel = document.createElement("label");
  leftLabel.className = "stat__label";
  leftLabel.textContent = "Left";
  leftWrap.appendChild(leftLabel);
  const leftSelect = makeSessionSelect(sessions);
  leftWrap.appendChild(leftSelect);
  pickers.appendChild(leftWrap);

  const rightWrap = document.createElement("div");
  const rightLabel = document.createElement("label");
  rightLabel.className = "stat__label";
  rightLabel.textContent = "Right";
  rightWrap.appendChild(rightLabel);
  const rightSelect = makeSessionSelect(sessions);
  // Default Right to the second session if available.
  if (sessions.length > 1) rightSelect.selectedIndex = 1;
  rightWrap.appendChild(rightSelect);
  pickers.appendChild(rightWrap);

  pickerCard.body.appendChild(pickers);
  root.appendChild(pickerCard);

  // ── Result host ──────────────────────────────────────────────────
  const resultHost = document.createElement("div");
  resultHost.style.display = "grid";
  resultHost.style.gap = "var(--gap-md)";
  resultHost.style.marginTop = "var(--gap-md)";
  root.appendChild(resultHost);

  const renderDiff = () => {
    const li = Number(leftSelect.value);
    const ri = Number(rightSelect.value);
    const left = sessions[li];
    const right = sessions[ri];
    resultHost.replaceChildren();
    if (!left || !right) return;
    renderDiffResult(resultHost, diffSessions(left, right));
  };

  leftSelect.addEventListener("change", renderDiff);
  rightSelect.addEventListener("change", renderDiff);
  renderDiff();
}

function makeSessionSelect(sessions) {
  const sel = document.createElement("select");
  sessions.forEach((s, i) => {
    const o = document.createElement("option");
    o.value = String(i);
    o.textContent = `${s.fileName} :: ${s.name}`;
    sel.appendChild(o);
  });
  return sel;
}

function renderDiffResult(host, diff) {
  // Totals strip
  const totals = card({
    title: "Diff summary",
    subtitle: `${diff.leftLabel}   ↔   ${diff.rightLabel}`,
  });
  const strip = document.createElement("div");
  strip.className = "diff-totals";
  strip.appendChild(pill(`+${diff.totals.added} added`, "ok"));
  strip.appendChild(pill(`-${diff.totals.removed} removed`, "bad"));
  strip.appendChild(pill(`~${diff.totals.changed} changed`, "warn"));
  strip.appendChild(pill(`= ${diff.totals.same} same`));
  totals.body.appendChild(strip);
  host.appendChild(totals);

  // Show "added/removed/changed only" toggle
  const opts = card({ title: "Filter" });
  const toggle = document.createElement("label");
  toggle.style.display = "flex";
  toggle.style.alignItems = "center";
  toggle.style.gap = "0.5rem";
  toggle.style.fontSize = "13px";
  const chk = document.createElement("input");
  chk.type = "checkbox";
  chk.checked = true;
  toggle.appendChild(chk);
  const txt = document.createTextNode("Hide unchanged rows");
  toggle.appendChild(txt);
  opts.body.appendChild(toggle);
  host.appendChild(opts);

  // Sections — render each as its own card
  const sectionsHost = document.createElement("div");
  sectionsHost.style.display = "grid";
  sectionsHost.style.gap = "var(--gap-md)";
  host.appendChild(sectionsHost);

  const renderSections = () => {
    sectionsHost.replaceChildren();
    const hideSame = chk.checked;
    for (const sec of diff.sections) {
      const visible = hideSame
        ? sec.pairs.filter((p) => p.status !== "same")
        : sec.pairs;
      const sectionCard = card({
        title: sec.title,
        subtitle: `+${sec.summary.added}  -${sec.summary.removed}  ~${sec.summary.changed}  =${sec.summary.same}`,
      });
      if (visible.length === 0) {
        const p = document.createElement("p");
        p.style.color = "var(--ink-500)";
        p.style.fontSize = "13px";
        p.textContent = hideSame ? "No differences in this section." : "No entries.";
        sectionCard.body.appendChild(p);
        sectionsHost.appendChild(sectionCard);
        continue;
      }
      const wrap = document.createElement("div");
      wrap.className = "data-table-wrap";
      wrap.style.maxHeight = "480px";
      const table = document.createElement("table");
      table.className = "diff-table";
      const thead = document.createElement("thead");
      const tr = document.createElement("tr");
      for (const h of ["Status", "Key", "Left", "Right"]) {
        const th = document.createElement("th");
        th.textContent = h;
        tr.appendChild(th);
      }
      thead.appendChild(tr);
      table.appendChild(thead);
      const tbody = document.createElement("tbody");
      for (const pr of visible) {
        const row = document.createElement("tr");
        row.className = `diff-row--${pr.status}`;
        const st = document.createElement("td");
        const stSpan = document.createElement("span");
        stSpan.className = `diff-status diff-status--${pr.status}`;
        stSpan.textContent = pr.status;
        st.appendChild(stSpan);
        row.appendChild(st);
        appendTd(row, pr.key);
        appendTd(row, pr.left ?? "");
        appendTd(row, pr.right ?? "");
        tbody.appendChild(row);
      }
      table.appendChild(tbody);
      wrap.appendChild(table);
      sectionCard.body.appendChild(wrap);
      sectionsHost.appendChild(sectionCard);
    }
  };
  chk.addEventListener("change", renderSections);
  renderSections();
}

function appendTd(tr, text) {
  const td = document.createElement("td");
  td.textContent = text;
  tr.appendChild(td);
}

function stateEmpty(text) {
  const el = document.createElement("div");
  el.className = "state-panel";
  el.textContent = text;
  return el;
}
function stateError(text) {
  const el = document.createElement("div");
  el.className = "state-panel state-panel--error";
  el.textContent = text;
  return el;
}
