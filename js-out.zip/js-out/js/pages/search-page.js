/**
 * search-page.js — entry for /search/index.html.
 *
 * Loads ALL parsed sessions once, then runs in-memory substring matching
 * via lib/search-index.js. Mirrors components/SearchClient.tsx.
 */

import { loadAllSessions } from "../lib/session-loader.js";
import { searchSessions } from "../lib/search-index.js";
import { card } from "../ui/primitives.js";

const root = document.getElementById("search-root");
const SESSIONS_PATH = "../sessions/";

boot().catch((err) => {
  console.error("[search] boot failed", err);
  root.replaceChildren(stateError(`Failed to load: ${err.message}`));
});

async function boot() {
  const { sessions, errors } = await loadAllSessions(SESSIONS_PATH);
  for (const e of errors) console.warn(`[search] parse failed for ${e.file}: ${e.message}`);

  root.replaceChildren();

  // ── Form card ──────────────────────────────────────────────────────
  const formCard = card({ title: `Search ${sessions.length} session${sessions.length === 1 ? "" : "s"}` });
  const form = document.createElement("form");
  form.style.display = "flex";
  form.style.gap = "0.75rem";
  form.style.alignItems = "center";
  const input = document.createElement("input");
  input.type = "search";
  input.placeholder = "Connection name, target table, parameter, expression, SQL keyword…";
  input.className = "diag-controls__input";
  input.style.flex = "1 1 auto";
  form.appendChild(input);
  const submit = document.createElement("button");
  submit.type = "submit";
  submit.className = "btn-primary";
  submit.textContent = "Search";
  form.appendChild(submit);
  formCard.body.appendChild(form);

  const info = document.createElement("div");
  info.style.marginTop = "0.5rem";
  info.style.fontSize = "12px";
  info.style.color = "var(--ink-500)";
  formCard.body.appendChild(info);

  root.appendChild(formCard);

  // ── Results host ──────────────────────────────────────────────────
  const resultsHost = document.createElement("div");
  resultsHost.style.display = "grid";
  resultsHost.style.gap = "var(--gap-md)";
  resultsHost.style.marginTop = "var(--gap-md)";
  root.appendChild(resultsHost);

  // Pre-populate from #q=… hash if present.
  const hash = new URLSearchParams(window.location.hash.slice(1));
  if (hash.get("q")) {
    input.value = hash.get("q");
    runSearch(input.value);
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const v = input.value.trim();
    window.location.hash = v ? `#q=${encodeURIComponent(v)}` : "";
    runSearch(v);
  });

  function runSearch(q) {
    resultsHost.replaceChildren();
    if (!q) {
      info.textContent = "";
      resultsHost.appendChild(emptyState(
        "Search across every session in /sessions/ — by file name, session name, mapping, connection, source/target table, lookup, parameter, SQL/expression content, or session attribute value.",
      ));
      return;
    }
    const hits = searchSessions(q, sessions);
    info.textContent = `${hits.length} match${hits.length === 1 ? "" : "es"} for "${q}"`;
    if (hits.length === 0) {
      resultsHost.appendChild(emptyState("No matches."));
      return;
    }
    for (const hit of hits) {
      const link = document.createElement("a");
      link.href = `../index.html#file=${encodeURIComponent(hit.fileName)}&session=${encodeURIComponent(hit.sessionName)}`;
      link.style.textDecoration = "none";
      link.style.color = "inherit";

      const wrap = document.createElement("div");
      wrap.className = "card";
      wrap.style.display = "block";
      wrap.style.padding = "0";

      const head = document.createElement("div");
      head.className = "card__header";
      const left = document.createElement("div");
      const h = document.createElement("h3");
      h.className = "card__title";
      h.textContent = hit.sessionName;
      left.appendChild(h);
      const right = document.createElement("div");
      right.className = "card__subtitle";
      right.textContent = hit.fileName + (hit.mappingName ? ` · ${hit.mappingName}` : "");
      head.appendChild(left);
      head.appendChild(right);
      wrap.appendChild(head);

      const body = document.createElement("div");
      body.className = "card__body";
      if (hit.matches.length > 0) {
        const ul = document.createElement("ul");
        ul.style.margin = "0";
        ul.style.padding = "0 0 0 1rem";
        ul.style.display = "grid";
        ul.style.gap = "0.25rem";
        ul.style.fontSize = "12px";
        ul.style.color = "var(--ink-700)";
        for (const m of hit.matches) {
          const li = document.createElement("li");
          const cat = document.createElement("span");
          cat.style.fontWeight = "600";
          cat.textContent = m.category + ": ";
          li.appendChild(cat);
          const sample = document.createElement("span");
          sample.style.fontFamily = "var(--font-mono)";
          sample.textContent = m.sample;
          li.appendChild(sample);
          ul.appendChild(li);
        }
        body.appendChild(ul);
      }
      wrap.appendChild(body);
      link.appendChild(wrap);
      resultsHost.appendChild(link);
    }
  }
}

function emptyState(text) {
  const el = document.createElement("div");
  el.className = "state-panel";
  el.textContent = text;
  return el;
}
function stateError(text) {
  const el = document.createElement("div");
  el.className = "state-panel state-panel--error";
  el.textContent = text;
  return el;
}
