/**
 * app.js — application entry / orchestrator.
 *
 * The only file in /js that does I/O (fetch). Everything else is either
 * pure logic (lib/*) or DOM rendering (ui/*).
 *
 * Lifecycle:
 *   1. Mount the TopBar (search + Diff + Download all) into #top-bar
 *   2. List XML files under /sessions/
 *   3. Fetch + parse each file → ParsedSession[]
 *   4. Mount the SessionPicker card into #picker-card
 *   5. When a session is picked, mount the SessionView into #session-view-root
 *
 * SECURITY: We treat /sessions/ files as the only trusted input. Even so,
 * the rendering layer (ui/*) uses textContent throughout — see those
 * modules' SECURITY notes — so a hostile XML file can't inject DOM.
 */

import { parseSessionsFromXml } from "./lib/sessions-parser.js";
import { mountTopBar } from "./ui/top-bar.js";
import { mountSessionPicker } from "./ui/session-picker.js";
import { mountSessionView } from "./ui/session-view.js";

// Where on disk we look for XML files. Relative to the page so the
// dashboard works under any URL prefix (e.g. http://host/dashboard/).
const SESSIONS_PATH = "./sessions/";

// ── Boot ────────────────────────────────────────────────────────────────

boot().catch((err) => {
  console.error("[app] boot failed", err);
  toast(`Failed to start: ${err.message}`, "error");
});

async function boot() {
  // Mount the TopBar first — it doesn't need session data and gives users
  // immediate feedback that the app is alive even while sessions load.
  mountTopBar(document.getElementById("top-bar"), {
    onSearch: (q) => {
      window.location.href = `./search/index.html#q=${encodeURIComponent(q)}`;
    },
    onOpenDiff: () => {
      window.location.href = "./diff/index.html";
    },
    onDownloadAll: async () => {
      toast("Download-all (.zip) coming soon.", "info");
    },
  });

  setStatus("Listing /sessions/…");
  const fileNames = await listSessionFiles();
  const pickerRoot = document.getElementById("picker-card");
  const viewRoot = document.getElementById("session-view-root");

  if (fileNames.length === 0) {
    setStatus("No sessions");
    pickerRoot.replaceChildren(emptyPickerCard());
    viewRoot.replaceChildren(stateEmpty("Drop XML files into /sessions/ and refresh."));
    return;
  }

  setStatus(`Fetching ${fileNames.length} file${fileNames.length === 1 ? "" : "s"}…`);
  const parsed = [];
  for (const file of fileNames) {
    try {
      const xml = await fetchText(SESSIONS_PATH + file);
      const sessions = parseSessionsFromXml(file, xml);
      parsed.push(...sessions);
    } catch (err) {
      console.error(`[app] failed to parse ${file}`, err);
      toast(`Could not parse ${file}: ${err.message}`, "error");
    }
  }

  setStatus(`${parsed.length} session${parsed.length === 1 ? "" : "s"} loaded`);

  const picker = mountSessionPicker(pickerRoot, parsed, (session) => {
    picker.setActive(session);
    mountSessionView(viewRoot, session, toast);
  });

  if (parsed.length > 0) {
    picker.setActive(parsed[0]);
    mountSessionView(viewRoot, parsed[0], toast);
  } else {
    viewRoot.replaceChildren(stateEmpty("No sessions parsed."));
  }
}

// ── /sessions/ discovery ────────────────────────────────────────────────

/**
 * List XML files under /sessions/. Tries (in order):
 *
 *   1. /sessions/index.json   — static manifest
 *   2. /sessions/             — JSON {files: [...]} (our serve.py)
 *   3. /sessions/             — HTML directory index (most servers)
 *
 * @returns {Promise<string[]>}
 */
async function listSessionFiles() {
  const manifest = await tryJson(SESSIONS_PATH + "index.json");
  if (manifest?.files && Array.isArray(manifest.files)) {
    return manifest.files.filter((f) => f.toLowerCase().endsWith(".xml"));
  }
  const listing = await tryJson(SESSIONS_PATH);
  if (listing?.files && Array.isArray(listing.files)) {
    return listing.files.filter((f) => f.toLowerCase().endsWith(".xml"));
  }

  const html = await tryText(SESSIONS_PATH);
  if (html) {
    const out = [];
    const re = /href\s*=\s*["']([^"']+\.xml)["']/gi;
    for (const m of html.matchAll(re)) {
      const name = decodeURIComponent(m[1].split("/").pop() ?? "");
      if (name && !out.includes(name)) out.push(name);
    }
    return out;
  }
  return [];
}

async function tryJson(url) {
  try {
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return null;
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("json")) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function tryText(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} for ${url}`);
  return await res.text();
}

// ── UI feedback helpers ─────────────────────────────────────────────────

function setStatus(_msg) {
  // The redesigned header no longer has a status text element — left here
  // so future Phase work has a single hook to drop progress text into.
  // For now, statuses surface via toast() if they matter.
}

let toastTimer = 0;
/**
 * Show a transient message at the bottom-right.
 *
 * @param {string} msg
 * @param {"info"|"success"|"error"} [kind]
 */
function toast(msg, kind = "info") {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.remove("toast--success", "toast--error");
  if (kind === "success") el.classList.add("toast--success");
  if (kind === "error")   el.classList.add("toast--error");
  el.classList.add("toast--visible");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("toast--visible"), 3500);
}

function stateEmpty(text) {
  const el = document.createElement("div");
  el.className = "state-panel";
  el.textContent = text;
  return el;
}

function emptyPickerCard() {
  const el = document.createElement("div");
  el.style.flex = "1 1 auto";
  el.style.color = "var(--ink-500)";
  el.style.fontSize = "13px";
  el.textContent = "No XML files found in /sessions/.";
  return el;
}
