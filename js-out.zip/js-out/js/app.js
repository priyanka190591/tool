/**
 * app.js — application entry / orchestrator.
 *
 * The only file in /js that does I/O (fetch). Everything else is either
 * pure logic (lib/*) or DOM rendering (ui/*).
 *
 * Lifecycle:
 *   1. List XML files under /sessions/  (server returns JSON or HTML index)
 *   2. Fetch each file
 *   3. Parse all files → flat ParsedSession[]
 *   4. Mount the session-list (left pane)
 *   5. When a session is picked, mount the session-view (right pane)
 *
 * SECURITY: We treat /sessions/ files as the only trusted input. Even so,
 * the rendering layer (ui/*) uses textContent throughout — see those
 * modules' SECURITY notes — so a hostile XML file can't inject DOM.
 */

import { parseSessionsFromXml } from "./lib/sessions-parser.js";
import { mountSessionList } from "./ui/session-list.js";
import { mountSessionView } from "./ui/session-view.js";

// Where on disk we look for XML files. Relative to the page so the
// dashboard works under any URL prefix (e.g. http://host/dashboard/).
const SESSIONS_PATH = "./sessions/";

// ── Boot ────────────────────────────────────────────────────────────────
boot().catch((err) => {
  console.error("[app] boot failed", err);
  toast(`Failed to start: ${err.message}`, "error");
});

async function boot() {
  setStatus("Listing /sessions/…");
  const fileNames = await listSessionFiles();
  if (fileNames.length === 0) {
    setStatus("No sessions");
    document.getElementById("session-list").textContent =
      "No XML files in /sessions/. Drop some and refresh.";
    return;
  }

  setStatus(`Fetching ${fileNames.length} file${fileNames.length === 1 ? "" : "s"}…`);
  const parsed = [];
  for (const file of fileNames) {
    try {
      const xml = await fetchText(SESSIONS_PATH + file);
      const sessions = parseSessionsFromXml(file, xml);
      parsed.push(...sessions);
    } catch (err) {
      console.error(`[app] failed to parse ${file}`, err);
      toast(`Could not parse ${file}: ${err.message}`, "error");
    }
  }

  setStatus(`${parsed.length} session${parsed.length === 1 ? "" : "s"} loaded`);

  const listRoot = document.getElementById("session-list");
  const viewRoot = document.getElementById("session-view");

  const api = mountSessionList(listRoot, parsed, (session) => {
    api.setActive(session);
    mountSessionView(viewRoot, session, toast);
  });

  // Auto-select the first session so the right pane isn't empty on first load.
  if (parsed.length > 0) {
    api.setActive(parsed[0]);
    mountSessionView(viewRoot, parsed[0], toast);
  }
}

// ── /sessions/ discovery ─────────────────────────────────────────────────

/**
 * List XML files under /sessions/. Tries (in order):
 *
 *   1. /sessions/index.json   — if the host serves a static manifest
 *   2. /sessions/             — if the host returns a JSON {files: [...]}
 *      (this is what bundled serve.py / serve.ps1 produce)
 *   3. /sessions/             — if the host returns HTML directory index,
 *      scrape href="*.xml" links.
 *
 * Returns an array of filenames (no path prefix).
 *
 * @returns {Promise<string[]>}
 */
async function listSessionFiles() {
  // Strategy 1 / 2 — try a JSON manifest first.
  const manifest = await tryJson(SESSIONS_PATH + "index.json");
  if (manifest?.files && Array.isArray(manifest.files)) {
    return manifest.files.filter((f) => f.toLowerCase().endsWith(".xml"));
  }
  const listing = await tryJson(SESSIONS_PATH);
  if (listing?.files && Array.isArray(listing.files)) {
    return listing.files.filter((f) => f.toLowerCase().endsWith(".xml"));
  }

  // Strategy 3 — HTML index. Most servers (Apache, nginx, python -m
  // http.server) emit one. Scrape href="…xml" anchors.
  const html = await tryText(SESSIONS_PATH);
  if (html) {
    const out = [];
    const re = /href\s*=\s*["']([^"']+\.xml)["']/gi;
    for (const m of html.matchAll(re)) {
      // Strip any leading path and decode percent-encodings (' ' etc.).
      const name = decodeURIComponent(m[1].split("/").pop() ?? "");
      if (name && !out.includes(name)) out.push(name);
    }
    return out;
  }
  return [];
}

async function tryJson(url) {
  try {
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return null;
    const ct = res.headers.get("content-type") || "";
    if (!ct.includes("json")) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function tryText(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

/**
 * Fetch a file and return text, throwing on HTTP failure.
 * @param {string} url
 * @returns {Promise<string>}
 */
async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`${res.status} ${res.statusText} for ${url}`);
  }
  return await res.text();
}

// ── UI feedback helpers ─────────────────────────────────────────────────

function setStatus(msg) {
  const el = document.getElementById("status-text");
  if (el) el.textContent = msg;
}

let toastTimer = 0;
/**
 * Show a transient message at the bottom-right.
 * @param {string} msg
 * @param {"info"|"success"|"error"} [kind]
 */
function toast(msg, kind = "info") {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.remove("toast--success", "toast--error");
  if (kind === "success") el.classList.add("toast--success");
  if (kind === "error") el.classList.add("toast--error");
  el.classList.add("toast--visible");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("toast--visible"), 3500);
}
