/**
 * top-bar.js — header right-side action group.
 *
 * Mirrors components/TopBar.tsx:
 *   [ Search field ] [ Diff link ] [ Download all (.zip) ]
 *
 * The search field navigates to /search with ?q=… (in this build the
 * fragment goes to the hash). Diff link navigates to /diff. Download-all
 * bundles every parsed session into one workbook — wired through the
 * caller-supplied `onDownloadAll` so we don't reach into business logic
 * from the UI layer.
 *
 * SECURITY: textContent only; no innerHTML; query value is read from a
 * form input and never inserted into HTML.
 */

import { icon, ICON_SEARCH } from "./primitives.js";

/**
 * Mount the top bar into `root`.
 *
 * @param {HTMLElement} root
 * @param {{
 *   onSearch: (query: string) => void,
 *   onOpenDiff: () => void,
 *   onDownloadAll: () => Promise<void>,
 * }} handlers
 */
export function mountTopBar(root, handlers) {
  root.replaceChildren();
  const bar = document.createElement("div");
  bar.className = "top-bar";

  // ── Search ────────────────────────────────────────────────────────
  const form = document.createElement("form");
  form.className = "top-bar__search";

  const input = document.createElement("input");
  input.type = "search";
  input.placeholder = "Search across all sessions…";
  input.className = "top-bar__search-input";
  form.appendChild(input);

  const search = icon(ICON_SEARCH, { className: "top-bar__search-icon" });
  form.appendChild(search);

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (q) handlers.onSearch(q);
  });
  bar.appendChild(form);

  // ── Diff ──────────────────────────────────────────────────────────
  const diff = document.createElement("button");
  diff.type = "button";
  diff.className = "btn-secondary";
  diff.textContent = "Diff";
  diff.addEventListener("click", handlers.onOpenDiff);
  bar.appendChild(diff);

  // ── Download all ──────────────────────────────────────────────────
  const downloadAll = document.createElement("button");
  downloadAll.type = "button";
  downloadAll.className = "btn-primary";
  downloadAll.textContent = "Download all (.zip)";
  downloadAll.addEventListener("click", async () => {
    if (downloadAll.disabled) return;
    downloadAll.disabled = true;
    downloadAll.textContent = "Bundling…";
    try {
      await handlers.onDownloadAll();
    } finally {
      downloadAll.disabled = false;
      downloadAll.textContent = "Download all (.zip)";
    }
  });
  bar.appendChild(downloadAll);

  root.appendChild(bar);
}
