/**
 * session-sidebar.js — sidebar nav for the SessionView.
 *
 * Mirrors the Sidebar component inside components/SessionView.tsx:
 * sections are grouped under uppercase headings (e.g. "Summary",
 * "Workflow & Reference"). Active section gets a dark background +
 * white text. Sections with a `count` show a small badge.
 *
 * The active state is owned by the caller (SessionView). This module
 * just renders + notifies.
 *
 * SECURITY: textContent only.
 */

/**
 * @typedef {Object} Section
 * @property {string} id
 * @property {string} label
 * @property {string} group
 * @property {number} [count]
 */

/**
 * Mount the sidebar.
 *
 * @param {HTMLElement} root
 * @param {Section[]} sections
 * @param {string} initialId
 * @param {(id: string) => void} onPick
 * @returns {{setActive: (id: string) => void}}
 */
export function mountSessionSidebar(root, sections, initialId, onPick) {
  root.replaceChildren();

  // Group sections preserving first-seen order.
  const groups = new Map();
  for (const s of sections) {
    if (!groups.has(s.group)) groups.set(s.group, []);
    groups.get(s.group).push(s);
  }

  const nav = document.createElement("nav");
  nav.className = "session-nav";

  const buttons = new Map();

  for (const [groupName, items] of groups) {
    const group = document.createElement("div");
    group.className = "session-nav__group";

    const title = document.createElement("h4");
    title.className = "session-nav__group-title";
    title.textContent = groupName;
    group.appendChild(title);

    const list = document.createElement("ul");
    list.className = "session-nav__list";
    for (const s of items) {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "session-nav__item";
      btn.dataset.sectionId = s.id;

      const lab = document.createElement("span");
      lab.className = "session-nav__item-label";
      lab.textContent = s.label;
      btn.appendChild(lab);

      if (typeof s.count === "number") {
        const count = document.createElement("span");
        count.className = "session-nav__count";
        count.textContent = String(s.count);
        btn.appendChild(count);
      }

      btn.addEventListener("click", () => onPick(s.id));
      li.appendChild(btn);
      list.appendChild(li);
      buttons.set(s.id, btn);
    }
    group.appendChild(list);
    nav.appendChild(group);
  }

  root.appendChild(nav);

  function setActive(id) {
    for (const [sid, btn] of buttons) {
      btn.classList.toggle("session-nav__item--active", sid === id);
    }
  }
  setActive(initialId);

  return { setActive };
}
