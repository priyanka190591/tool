/**
 * tabs.js — generic tab bar.
 *
 * Caller provides:
 *   - An array of tab descriptors { id, label, badge?, render(container) }
 *   - The container element where the bar + active panel render
 *
 * The bar itself is built once. Clicking a tab tears down the previous
 * content with replaceChildren() and calls render(container) on the new
 * tab's descriptor — so render functions can do anything they like with
 * the empty container and don't need to share state.
 *
 * SECURITY: tab labels and badges come from a fixed set in session-view.js
 * (not user-controlled XML), but we still use textContent only to keep the
 * "no innerHTML anywhere" invariant.
 */

/**
 * @typedef {Object} TabDescriptor
 * @property {string} id
 * @property {string} label
 * @property {string|number} [badge]
 * @property {(container: HTMLElement) => void} render
 */

/**
 * Mount a tab bar + active-content area into `root`.
 *
 * @param {HTMLElement} root
 * @param {TabDescriptor[]} tabs
 * @param {string} [initialTabId]
 * @returns {{select: (id: string) => void}}
 */
export function mountTabs(root, tabs, initialTabId) {
  root.replaceChildren();

  const bar = document.createElement("nav");
  bar.className = "tabs";
  bar.setAttribute("role", "tablist");

  const content = document.createElement("div");
  content.className = "tab-content";

  const buttons = new Map(); // id → button

  for (const tab of tabs) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "tab";
    btn.setAttribute("role", "tab");
    btn.dataset.tabId = tab.id;

    const labelNode = document.createTextNode(tab.label);
    btn.appendChild(labelNode);
    if (tab.badge !== undefined) {
      const badge = document.createElement("span");
      badge.className = "tab__badge";
      badge.textContent = String(tab.badge);
      btn.appendChild(badge);
    }
    btn.addEventListener("click", () => select(tab.id));
    bar.appendChild(btn);
    buttons.set(tab.id, btn);
  }

  root.appendChild(bar);
  root.appendChild(content);

  function select(id) {
    const tab = tabs.find((t) => t.id === id);
    if (!tab) return;
    for (const [tid, btn] of buttons) {
      btn.classList.toggle("tab--active", tid === id);
    }
    content.replaceChildren();
    tab.render(content);
  }

  select(initialTabId ?? tabs[0]?.id);
  return { select };
}
