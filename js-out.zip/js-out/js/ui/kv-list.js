/**
 * kv-list.js — render a section/key/value list.
 *
 * Used by the Overall details and Session Details tabs. Input shape:
 *   [{ section: "Identity", key: "Mapping", value: "m_FOO" }, …]
 * We group consecutive rows with the same section into one visual block
 * with a section header.
 *
 * SECURITY: textContent only.
 */

/**
 * Render a section/key/value list into `container`.
 *
 * @param {HTMLElement} container
 * @param {{section: string, key: string, value: string}[]} rows
 */
export function renderKvList(container, rows) {
  container.replaceChildren();
  if (rows.length === 0) {
    const empty = document.createElement("div");
    empty.style.padding = "16px";
    empty.style.color = "var(--color-ink-muted)";
    empty.textContent = "No data.";
    container.appendChild(empty);
    return;
  }

  const wrap = document.createElement("div");
  wrap.className = "kv-list";

  // Group by section so consecutive rows share one section header.
  let currentSection = null;
  let currentBlock = null;
  for (const r of rows) {
    if (r.section !== currentSection) {
      currentSection = r.section;
      currentBlock = document.createElement("section");
      currentBlock.className = "kv-list__section";
      const title = document.createElement("h3");
      title.className = "kv-list__section-title";
      title.textContent = r.section;
      currentBlock.appendChild(title);
      wrap.appendChild(currentBlock);
    }
    const row = document.createElement("div");
    row.className = "kv-list__row";
    const k = document.createElement("div");
    k.className = "kv-list__key";
    k.textContent = r.key;
    const v = document.createElement("div");
    v.className = "kv-list__value";
    v.textContent = r.value;
    row.appendChild(k);
    row.appendChild(v);
    currentBlock.appendChild(row);
  }

  container.appendChild(wrap);
}
