/**
 * session-view.js — right-hand session detail (sidebar + main pane).
 *
 * Mirrors components/SessionView.tsx — including its section list and
 * grouping. Phase 1 scope renders these sections:
 *
 *   Summary
 *     · Overview                  (this file)
 *     · Source → Target           (renderS2T — 6-column condensed view)
 *     · Source SQL                (renderSourceSqlPanel — if any SQL TX)
 *
 *   Session
 *     · Attributes (grouped)      (renderAttributes — if attrs exist)
 *     · Connections               (renderConnections — if conn refs exist)
 *     · Instance Overrides        (renderInstanceOverrides — if any)
 *     · Session Extensions        (renderExtensions — if any)
 *     · Parameters                (renderParameters — if any)
 *
 *   Mapping (only if session.mapping exists)
 *     · Sources / Targets / Transformations / Lookups
 *     · Connectors / Composition
 *
 *   Workflow & Reference
 *     · Workflows (if any)
 *     · Configs   (if any)
 *
 * Phase 3 will add: Validation, Mapping Inspector, Raw XML.
 * Phase 4 will add: Lineage Tracer.
 * Phase 7 will add: Lineage Graph.
 *
 * SECURITY: textContent only.
 */

import { buildMappingJson } from "../lib/build-mapping-json.js";
import { validateSession } from "../lib/validation.js";
import { mountSessionSidebar } from "./session-sidebar.js";
import { mountExportButtons } from "./export-buttons.js";
import { card, pill, stat, keyValueTable } from "./primitives.js";
import {
  renderS2T,
  renderSourceSqlPanel,
  renderAttributes,
  renderConnections,
  renderParameters,
  renderInstanceOverrides,
  renderExtensions,
  renderSources,
  renderTargets,
  renderTransformations,
  renderLookups,
  renderConnectors,
  renderComposition,
  renderWorkflows,
  renderConfigs,
} from "./sections.js";
import { renderValidationPanel } from "./validation-panel.js";
import { renderUnresolvedDiagnostics } from "./unresolved-diagnostics.js";
import { renderRawXmlInspector } from "./raw-xml-inspector.js";
import { renderLineageTracer } from "./lineage-tracer.js";
import { renderLineageGraph } from "./lineage-graph.js";

/**
 * Render the right-hand pane for a given session.
 *
 * @param {HTMLElement} root
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 * @param {(msg: string, kind?: "info"|"success"|"error") => void} toast
 */
export function mountSessionView(root, session, toast) {
  root.replaceChildren();

  const mapping = buildMappingJson(session);
  window.__lastSession = session;
  window.__lastMapping = mapping;

  const m = session.mapping;
  const sourceSqlCount = mapping.source_sql.length;

  const issues = validateSession(session);

  // ── Section catalog. Order + presence conditions mirror SessionView.tsx.
  const sections = [
    { id: "overview",  group: "Summary", label: "Overview",
      render: (c) => renderOverview(c, session, mapping, toast) },
    { id: "validation", group: "Summary", label: "Validation",
      count: issues.length,
      render: (c) => renderValidationPanel(c, issues) },
  ];

  if (m) {
    sections.push({
      id: "s2t", group: "Summary", label: "Source → Target",
      count: mapping.field_mappings.length,
      render: (c) => renderS2T(c, session),
    });
    sections.push({
      id: "tracer", group: "Summary", label: "Lineage Tracer",
      render: (c) => renderLineageTracer(c, session),
    });
    sections.push({
      id: "mapping-inspector", group: "Summary", label: "Mapping Inspector",
      render: (c) => renderUnresolvedDiagnostics(c, session),
    });
  }

  // Source SQL — originally placed in the "Mapping" group in the Next.js
  // build (alongside Sources / Targets / Transformations / Lookups). We
  // mirror that grouping here. Note that the Mapping group itself only
  // appears when `m` (session.mapping) is present, so this push is gated
  // accordingly below — we just queue it in a deferred bucket and append
  // when we build the Mapping section list. To keep ordering simple, since
  // Source SQL renders before Sources in the original section list, we
  // inject it as the first Mapping entry.
  const sourceSqlSection = sourceSqlCount > 0 ? {
    id: "source-sql", group: "Mapping", label: "Source SQL",
    count: sourceSqlCount,
    render: (c) => renderSourceSqlPanel(c, session),
  } : null;

  if (session.attributes.length > 0) {
    sections.push({
      id: "attributes", group: "Session", label: "Attributes",
      count: session.attributes.length,
      render: (c) => renderAttributes(c, session),
    });
  }
  if (session.connectionRefs.length > 0) {
    sections.push({
      id: "connections", group: "Session", label: "Connections",
      count: session.connectionRefs.length,
      render: (c) => renderConnections(c, session),
    });
  }
  if (session.transformationInstances.length > 0) {
    sections.push({
      id: "instance-overrides", group: "Session", label: "Instance Overrides",
      count: session.transformationInstances.length,
      render: (c) => renderInstanceOverrides(c, session),
    });
  }
  if (session.extensions.length > 0) {
    sections.push({
      id: "extensions", group: "Session", label: "Session Extensions",
      count: session.extensions.length,
      render: (c) => renderExtensions(c, session),
    });
  }
  if (session.parameters.length > 0) {
    sections.push({
      id: "parameters", group: "Session", label: "Parameters",
      count: session.parameters.length,
      render: (c) => renderParameters(c, session),
    });
  }

  if (m) {
    // Source SQL goes first in the Mapping group (matches Next.js).
    if (sourceSqlSection) sections.push(sourceSqlSection);

    if (m.sources.length > 0) {
      sections.push({
        id: "sources", group: "Mapping", label: "Sources",
        count: m.sources.length,
        render: (c) => renderSources(c, session),
      });
    }
    if (m.targets.length > 0) {
      sections.push({
        id: "targets", group: "Mapping", label: "Targets",
        count: m.targets.length,
        render: (c) => renderTargets(c, session),
      });
    }
    if (m.transformations.length > 0) {
      const nonLookup = m.transformations.filter((t) => !/lookup/i.test(t.type));
      if (nonLookup.length > 0) {
        sections.push({
          id: "transformations", group: "Mapping", label: "Transformations",
          count: nonLookup.length,
          render: (c) => renderTransformations(c, session),
        });
      }
      const lookups = m.transformations.filter((t) => /lookup/i.test(t.type));
      if (lookups.length > 0) {
        sections.push({
          id: "lookups", group: "Mapping", label: "Lookups",
          count: lookups.length,
          render: (c) => renderLookups(c, session),
        });
      }
    }
    if (m.connectors.length > 0) {
      sections.push({
        id: "graph", group: "Mapping", label: "Lineage Graph",
        render: (c) => renderLineageGraph(c, session),
      });
      sections.push({
        id: "connectors", group: "Mapping", label: "Connectors",
        count: m.connectors.length,
        render: (c) => renderConnectors(c, session),
      });
    }
    if (m.instances.length > 0 || m.mapplets.length > 0) {
      sections.push({
        id: "composition", group: "Mapping", label: "Composition",
        count: m.instances.length + m.mapplets.length,
        render: (c) => renderComposition(c, session),
      });
    }
  }

  if (session.workflows.length > 0) {
    sections.push({
      id: "workflows", group: "Workflow & Reference", label: "Workflows",
      count: session.workflows.length,
      render: (c) => renderWorkflows(c, session),
    });
  }
  if (session.configs.length > 0) {
    sections.push({
      id: "configs", group: "Workflow & Reference", label: "Configs",
      count: session.configs.length,
      render: (c) => renderConfigs(c, session),
    });
  }

  sections.push({
    id: "raw-xml", group: "Workflow & Reference", label: "Raw XML",
    render: (c) => renderRawXmlInspector(c, session.rawXml),
  });

  // ── Layout shell (sidebar + main pane) ────────────────────────────
  const layout = document.createElement("div");
  layout.className = "session-layout";

  const sidebarHost = document.createElement("aside");
  sidebarHost.className = "session-sidebar";
  layout.appendChild(sidebarHost);

  const mainHost = document.createElement("main");
  mainHost.className = "session-main";
  layout.appendChild(mainHost);

  root.appendChild(layout);

  // ── Active-section state. Drives sidebar + main. ──────────────────
  let activeId = sections[0].id;
  const sectionsById = new Map(sections.map((s) => [s.id, s]));

  function renderActive() {
    const sec = sectionsById.get(activeId) ?? sections[0];
    mainHost.replaceChildren();

    const header = document.createElement("div");
    header.className = "section-header";
    const title = document.createElement("h2");
    title.className = "section-header__title";
    title.textContent = sec.label;
    header.appendChild(title);
    const crumb = document.createElement("div");
    crumb.className = "section-header__breadcrumb";
    crumb.textContent = `${session.name} · ${session.fileName}`;
    header.appendChild(crumb);
    mainHost.appendChild(header);

    const content = document.createElement("div");
    content.className = "section-grid";
    mainHost.appendChild(content);

    sec.render(content);
  }

  const sidebarApi = mountSessionSidebar(sidebarHost, sections, activeId, (id) => {
    activeId = id;
    sidebarApi.setActive(id);
    renderActive();
  });

  renderActive();
}

// ── Overview section ────────────────────────────────────────────────────

/**
 * Render the Overview section: a SessionHeader card (with the export
 * button bar in its top-right) + a row of summary stats + optional
 * Attributes / Parameters cards.
 *
 * @param {HTMLElement} container
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 * @param {import("../lib/mapping-schema.js").MappingJson} mapping
 * @param {(msg: string, kind?: "info"|"success"|"error") => void} toast
 */
function renderOverview(container, session, mapping, toast) {
  const pills = [];
  if (session.reusable) {
    pills.push(pill(`Reusable: ${session.reusable}`, session.reusable === "YES" ? "ok" : "default"));
  }
  if (session.isValid) {
    pills.push(pill(`Valid: ${session.isValid}`, session.isValid === "YES" ? "ok" : "warn"));
  }
  if (session.versionNumber) pills.push(pill(`v${session.versionNumber}`));

  const exportHost = document.createElement("span");
  mountExportButtons(exportHost, () => session, toast);

  const headerRight = document.createElement("div");
  headerRight.style.display = "flex";
  headerRight.style.flexWrap = "wrap";
  headerRight.style.alignItems = "center";
  headerRight.style.gap = "0.5rem";
  for (const p of pills) headerRight.appendChild(p);
  headerRight.appendChild(exportHost);

  const headerCard = card({
    title: session.name,
    subtitle:
      session.description ||
      `${session.hasSession ? "Loaded" : "Mapping-only export"} from ${session.fileName}`,
    right: headerRight,
  });

  const stats = document.createElement("div");
  stats.style.display = "grid";
  stats.style.gridTemplateColumns = "repeat(auto-fit, minmax(120px, 1fr))";
  stats.style.gap = "1rem";
  stats.appendChild(stat("Mapping", mapping.mapping_name || "—"));
  stats.appendChild(stat("Field mappings", mapping.field_mappings.length));
  stats.appendChild(stat("Sources", mapping.sources.length));
  stats.appendChild(stat("Targets", mapping.targets.length));
  stats.appendChild(stat("Lookups", mapping.lookups.length));
  stats.appendChild(stat("Transformations", mapping.transformations.length));
  headerCard.body.appendChild(stats);

  container.appendChild(headerCard);
}
