/**
 * session-view.js — right-pane composition.
 *
 * Builds the per-session header + tab bar + active sheet area, plus the
 * export button bar. All sub-rendering is delegated to dedicated modules:
 *   - field-mapping-table.js   for FIELD_MAPPING
 *   - simple-table.js          for LOOKUPS / TRANSFORMATIONS / Source SQL / Connections
 *   - kv-list.js               for Overall details / Session Details
 *
 * This module owns the layout shape; it doesn't render any cells itself.
 *
 * SECURITY: textContent only.
 */

import { buildMappingJson } from "../lib/build-mapping-json.js";
import { mountTabs } from "./tabs.js";
import { renderFieldMappingTable } from "./field-mapping-table.js";
import { renderSimpleTable } from "./simple-table.js";
import { renderKvList } from "./kv-list.js";
import { mountExportButtons } from "./export-buttons.js";

/**
 * Render the right-pane for the given session.
 *
 * @param {HTMLElement} root
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 * @param {(msg: string, kind?: "info"|"success"|"error") => void} toast
 */
export function mountSessionView(root, session, toast) {
  root.replaceChildren();

  const mapping = buildMappingJson(session);
  // Expose for debugging in DevTools — `window.__lastMapping` is documented
  // in README as a debug hook.
  window.__lastSession = session;
  window.__lastMapping = mapping;

  // ── Header (session identity + export buttons) ─────────────────────────
  const header = document.createElement("div");
  header.className = "session-view__header";

  const titleBlock = document.createElement("div");
  const title = document.createElement("h2");
  title.className = "session-view__title";
  title.textContent = session.name;
  titleBlock.appendChild(title);

  const subtitle = document.createElement("div");
  subtitle.className = "session-view__subtitle";
  const subtitleParts = [
    session.fileName,
    mapping.mapping_name ? `mapping=${mapping.mapping_name}` : null,
    session.versionNumber ? `v${session.versionNumber}` : null,
  ].filter(Boolean);
  subtitle.textContent = subtitleParts.join("  •  ");
  titleBlock.appendChild(subtitle);
  header.appendChild(titleBlock);

  mountExportButtons(header, () => session, toast);
  root.appendChild(header);

  // ── Tab bar + content ──────────────────────────────────────────────────
  const tabsContainer = document.createElement("div");
  tabsContainer.style.flex = "1 1 auto";
  tabsContainer.style.display = "flex";
  tabsContainer.style.flexDirection = "column";
  tabsContainer.style.minHeight = "0";
  root.appendChild(tabsContainer);

  /**
   * Tab definitions. Order chosen for review-flow priority: FIELD_MAPPING
   * is the main artefact, Overall details next for orientation, then the
   * sub-sheets in the same order as the XLSX.
   */
  const tabs = [
    {
      id: "field-mapping",
      label: "FIELD_MAPPING",
      badge: mapping.field_mappings.length,
      render: (c) => renderFieldMappingTable(c, mapping.field_mappings),
    },
    {
      id: "overall",
      label: "Overall details",
      render: (c) => renderKvList(c, mapping.overall_details),
    },
    {
      id: "lookups",
      label: "LOOKUPS",
      badge: mapping.lookups.length,
      render: (c) =>
        renderSimpleTable(
          c,
          [
            { key: "lookup_id",     label: "Lookup ID" },
            { key: "source_table",  label: "Source Table" },
            { key: "connection",    label: "Connection" },
            { key: "_join",         label: "Join Condition" },
            { key: "_return",       label: "Return Fields" },
            { key: "is_cached",     label: "Cached" },
            { key: "is_persistent", label: "Persistent" },
            { key: "sql_override",  label: "SQL Override" },
          ],
          mapping.lookups.map((lkp) => ({
            ...lkp,
            _join: lkp.join_conditions.map((c) => `${c.left} = ${c.right}`).join(" AND "),
            _return: lkp.return_fields.join(", "),
          })),
        ),
    },
    {
      id: "transformations",
      label: "TRANSFORMATIONS",
      badge: mapping.transformations.length,
      render: (c) =>
        renderSimpleTable(
          c,
          [
            { key: "name",         label: "Transformation" },
            { key: "type",         label: "Type" },
            { key: "output_field", label: "Output Field" },
            { key: "kind",         label: "Kind" },
            { key: "formula",      label: "Expression" },
          ],
          mapping.transformations.flatMap((t) =>
            t.expressions.length === 0
              ? [{ name: t.name, type: t.type, output_field: "", kind: "", formula: "" }]
              : t.expressions.map((e) => ({
                  name: t.name,
                  type: t.type,
                  output_field: e.output_field,
                  kind: e.kind,
                  formula: e.formula,
                })),
          ),
        ),
    },
    {
      id: "source-sql",
      label: "Source SQL",
      badge: mapping.source_sql.length,
      render: (c) =>
        renderSimpleTable(
          c,
          [
            { key: "transformation",       label: "SQL / Query Name" },
            { key: "transformation_type",  label: "Type" },
            { key: "source_definition",    label: "Source Definition" },
            { key: "connection",           label: "Connection" },
            { key: "connection_type",      label: "Connection Type" },
            { key: "sql_types",            label: "SQL Types Present" },
            { key: "source_tables",        label: "Source Tables" },
            { key: "sql_text",             label: "SQL Text" },
          ],
          mapping.source_sql,
        ),
    },
    {
      id: "connections",
      label: "Connections",
      badge: mapping.connections.length,
      render: (c) =>
        renderSimpleTable(
          c,
          [
            { key: "instance",        label: "Instance" },
            { key: "instance_type",   label: "Instance Type" },
            { key: "connection",      label: "Connection" },
            { key: "connection_type", label: "Connection Type" },
            { key: "subtype",         label: "Subtype" },
            { key: "variable",        label: "Variable" },
          ],
          mapping.connections,
        ),
    },
    {
      id: "session-details",
      label: "Session Details",
      render: (c) => renderKvList(c, mapping.session_details),
    },
  ];

  mountTabs(tabsContainer, tabs);
}
