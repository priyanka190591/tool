/**
 * lineage-graph.js — simplified SVG-based lineage graph.
 *
 * The Next.js build uses React Flow + dagre for layout. Both libraries are
 * substantial (~250 KB combined) and pulling them in would defeat the
 * "static, no toolchain" goal. Instead this file ships a small custom
 * layered layout: instances become nodes, connectors become edges, and a
 * Coffman-Graham-style topological pass assigns each node to a layer
 * (column). Nodes inside a layer are spaced vertically.
 *
 * Limitations vs. the React Flow version:
 *   - No pan/zoom interactive controls (browser CTRL+scroll zooms the SVG)
 *   - No minimap
 *   - No drag-to-reposition (layout is fixed)
 *
 * Trade-off accepted in exchange for zero dependencies + ~250 lines.
 *
 * SECURITY: textContent only.
 */

const NODE_W = 220;
const NODE_H = 64;
const COL_GAP = 80;
const ROW_GAP = 24;
const PADDING = 24;

/**
 * @param {HTMLElement} container
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 */
export function renderLineageGraph(container, session) {
  container.replaceChildren();
  const m = session.mapping;
  if (!m || m.connectors.length === 0) {
    const p = document.createElement("p");
    p.style.color = "var(--ink-500)";
    p.style.fontSize = "13px";
    p.textContent = "No connector graph available.";
    container.appendChild(p);
    return;
  }

  const { nodes, edges } = buildGraph(m.instances, m.connectors);
  const layout = layoutNodes(nodes, edges);

  const width = layout.cols * (NODE_W + COL_GAP) - COL_GAP + PADDING * 2;
  const height = layout.rowsTallest * (NODE_H + ROW_GAP) - ROW_GAP + PADDING * 2;

  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("xmlns", NS);
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.style.width = "100%";
  svg.style.height = Math.min(700, height) + "px";
  svg.style.background = "rgb(246 247 249 / 0.4)";
  svg.style.border = "1px solid var(--ink-100)";
  svg.style.borderRadius = "var(--radius-md)";

  // Arrow marker
  const defs = document.createElementNS(NS, "defs");
  const marker = document.createElementNS(NS, "marker");
  marker.setAttribute("id", "arrow");
  marker.setAttribute("viewBox", "0 0 10 10");
  marker.setAttribute("refX", "10");
  marker.setAttribute("refY", "5");
  marker.setAttribute("markerWidth", "8");
  marker.setAttribute("markerHeight", "8");
  marker.setAttribute("orient", "auto-start-reverse");
  const arrowPath = document.createElementNS(NS, "path");
  arrowPath.setAttribute("d", "M 0 0 L 10 5 L 0 10 z");
  arrowPath.setAttribute("fill", "var(--ink-400)");
  marker.appendChild(arrowPath);
  defs.appendChild(marker);
  svg.appendChild(defs);

  // Edges (drawn first so nodes overlay them)
  const edgesGroup = document.createElementNS(NS, "g");
  for (const e of edges) {
    const a = layout.positions.get(e.from);
    const b = layout.positions.get(e.to);
    if (!a || !b) continue;
    const x1 = a.x + NODE_W;
    const y1 = a.y + NODE_H / 2;
    const x2 = b.x;
    const y2 = b.y + NODE_H / 2;
    const dx = (x2 - x1) * 0.5;
    const path = document.createElementNS(NS, "path");
    path.setAttribute("d", `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`);
    path.setAttribute("fill", "none");
    path.setAttribute("stroke", "var(--ink-300)");
    path.setAttribute("stroke-width", "1.5");
    path.setAttribute("marker-end", "url(#arrow)");
    edgesGroup.appendChild(path);
  }
  svg.appendChild(edgesGroup);

  // Nodes
  const nodesGroup = document.createElementNS(NS, "g");
  for (const n of nodes) {
    const pos = layout.positions.get(n.id);
    if (!pos) continue;
    const cat = categorize(n.type);
    const g = document.createElementNS(NS, "g");
    g.setAttribute("transform", `translate(${pos.x}, ${pos.y})`);

    const rect = document.createElementNS(NS, "rect");
    rect.setAttribute("width", String(NODE_W));
    rect.setAttribute("height", String(NODE_H));
    rect.setAttribute("rx", "6");
    rect.setAttribute("fill", cat.bg);
    rect.setAttribute("stroke", cat.border);
    rect.setAttribute("stroke-width", "1.5");
    g.appendChild(rect);

    // Badge — category label, top-left
    const badge = document.createElementNS(NS, "text");
    badge.setAttribute("x", "12");
    badge.setAttribute("y", "20");
    badge.setAttribute("font-family", "var(--font-sans)");
    badge.setAttribute("font-size", "10");
    badge.setAttribute("font-weight", "700");
    badge.setAttribute("fill", cat.text);
    badge.setAttribute("text-transform", "uppercase");
    badge.textContent = cat.badge;
    g.appendChild(badge);

    // Instance name — centered horizontally
    const name = document.createElementNS(NS, "text");
    name.setAttribute("x", "12");
    name.setAttribute("y", "42");
    name.setAttribute("font-family", "var(--font-mono)");
    name.setAttribute("font-size", "13");
    name.setAttribute("fill", "var(--ink-900)");
    name.textContent = truncate(n.id, 26);
    g.appendChild(name);

    // Type — small subtitle
    const type = document.createElementNS(NS, "text");
    type.setAttribute("x", "12");
    type.setAttribute("y", "57");
    type.setAttribute("font-family", "var(--font-sans)");
    type.setAttribute("font-size", "10");
    type.setAttribute("fill", "var(--ink-500)");
    type.textContent = truncate(n.type, 32);
    g.appendChild(type);

    // Tooltip
    const title = document.createElementNS(NS, "title");
    title.textContent = `${n.id}\nType: ${n.type}`;
    g.appendChild(title);

    nodesGroup.appendChild(g);
  }
  svg.appendChild(nodesGroup);

  container.appendChild(svg);

  // Legend
  const legend = document.createElement("div");
  legend.style.display = "flex";
  legend.style.flexWrap = "wrap";
  legend.style.gap = "0.5rem";
  legend.style.marginTop = "0.5rem";
  legend.style.fontSize = "11px";
  legend.style.color = "var(--ink-500)";
  legend.textContent =
    "Layout: left → right. Sources / Source Qualifiers on the left, Targets on the right.";
  container.appendChild(legend);
}

// ── Graph building ──────────────────────────────────────────────────────

function buildGraph(instances, connectors) {
  const nodes = [];
  const seen = new Set();
  for (const inst of instances) {
    if (seen.has(inst.name)) continue;
    seen.add(inst.name);
    nodes.push({ id: inst.name, type: inst.type });
  }
  // Some connectors reference instances not declared in INSTANCE — add them too.
  for (const c of connectors) {
    if (!seen.has(c.fromInstance)) {
      seen.add(c.fromInstance);
      nodes.push({ id: c.fromInstance, type: c.fromInstanceType });
    }
    if (!seen.has(c.toInstance)) {
      seen.add(c.toInstance);
      nodes.push({ id: c.toInstance, type: c.toInstanceType });
    }
  }
  const edges = [];
  const seenEdge = new Set();
  for (const c of connectors) {
    const key = `${c.fromInstance}→${c.toInstance}`;
    if (seenEdge.has(key)) continue;
    seenEdge.add(key);
    edges.push({ from: c.fromInstance, to: c.toInstance });
  }
  return { nodes, edges };
}

// ── Layered layout (Coffman-Graham-ish) ─────────────────────────────────

function layoutNodes(nodes, edges) {
  const inDeg = new Map();
  const adj = new Map();
  for (const n of nodes) {
    inDeg.set(n.id, 0);
    adj.set(n.id, []);
  }
  for (const e of edges) {
    inDeg.set(e.to, (inDeg.get(e.to) ?? 0) + 1);
    adj.get(e.from).push(e.to);
  }
  // Topological layer assignment.
  const layer = new Map();
  const queue = [];
  for (const n of nodes) {
    if ((inDeg.get(n.id) ?? 0) === 0) {
      layer.set(n.id, 0);
      queue.push(n.id);
    }
  }
  while (queue.length) {
    const u = queue.shift();
    const lu = layer.get(u) ?? 0;
    for (const v of adj.get(u) ?? []) {
      layer.set(v, Math.max(layer.get(v) ?? 0, lu + 1));
      const d = (inDeg.get(v) ?? 0) - 1;
      inDeg.set(v, d);
      if (d === 0) queue.push(v);
    }
  }
  // Nodes never reached (cyclic components) → place at the right edge.
  for (const n of nodes) if (!layer.has(n.id)) layer.set(n.id, 0);

  // Group by layer.
  const byLayer = new Map();
  for (const n of nodes) {
    const l = layer.get(n.id) ?? 0;
    if (!byLayer.has(l)) byLayer.set(l, []);
    byLayer.get(l).push(n.id);
  }
  const cols = Math.max(...byLayer.keys()) + 1;
  // Tallest row count drives canvas height.
  const rowsTallest = Math.max(...[...byLayer.values()].map((arr) => arr.length));

  const positions = new Map();
  for (const [l, arr] of byLayer) {
    arr.sort();
    arr.forEach((id, i) => {
      positions.set(id, {
        x: PADDING + l * (NODE_W + COL_GAP),
        y: PADDING + i * (NODE_H + ROW_GAP),
      });
    });
  }
  return { cols, rowsTallest, positions };
}

// ── Categorization (matches LineageGraph.tsx) ───────────────────────────

function categorize(rawType) {
  const t = (rawType || "").toLowerCase();
  if (t.includes("source qualifier")) return { badge: "SQ",          bg: "#f0f9ff", border: "#7dd3fc", text: "#0c4a6e" };
  if (t.includes("source"))           return { badge: "Source",      bg: "#eff6ff", border: "#93c5fd", text: "#1e3a8a" };
  if (t.includes("target"))           return { badge: "Target",      bg: "#ecfdf5", border: "#6ee7b7", text: "#064e3b" };
  if (t.includes("lookup"))           return { badge: "Lookup",      bg: "#faf5ff", border: "#d8b4fe", text: "#581c87" };
  if (t.includes("router"))           return { badge: "Router",      bg: "#fffbeb", border: "#fcd34d", text: "#78350f" };
  if (t.includes("filter"))           return { badge: "Filter",      bg: "#fffbeb", border: "#fcd34d", text: "#78350f" };
  if (t.includes("expression"))       return { badge: "Expression",  bg: "#f0fdfa", border: "#5eead4", text: "#134e4a" };
  if (t.includes("update strategy"))  return { badge: "Update Strategy", bg: "#fff1f2", border: "#fda4af", text: "#9f1239" };
  if (t.includes("aggregator"))       return { badge: "Aggregator",  bg: "#eef2ff", border: "#a5b4fc", text: "#312e81" };
  if (t.includes("joiner"))           return { badge: "Joiner",      bg: "#eef2ff", border: "#a5b4fc", text: "#312e81" };
  if (t.includes("sorter"))           return { badge: "Sorter",      bg: "#eef2ff", border: "#a5b4fc", text: "#312e81" };
  if (t.includes("normalizer"))       return { badge: "Normalizer",  bg: "#eef2ff", border: "#a5b4fc", text: "#312e81" };
  if (t.includes("union"))            return { badge: "Union",       bg: "#eef2ff", border: "#a5b4fc", text: "#312e81" };
  if (t.includes("rank"))             return { badge: "Rank",        bg: "#eef2ff", border: "#a5b4fc", text: "#312e81" };
  if (t.includes("sequence"))         return { badge: "Sequence",    bg: "#fafaf9", border: "#d6d3d1", text: "#44403c" };
  return { badge: rawType || "Instance", bg: "#ffffff", border: "#d5d9e2", text: "#1f2230" };
}

function truncate(s, len) {
  if (!s) return "";
  return s.length > len ? s.slice(0, len - 1) + "…" : s;
}
