/**
 * simple-table.js — generic header + rows table renderer.
 *
 * Used by sub-sheets (LOOKUPS, TRANSFORMATIONS, Source SQL, Connections)
 * that don't need the heavy FIELD_MAPPING grid features (pinned columns,
 * load-type pills). One column list + one row list — that's it.
 *
 * SECURITY: textContent only.
 */

/**
 * @typedef {Object} SimpleCol
 * @property {string} key
 * @property {string} label
 */

/**
 * Render a generic table into `container`.
 *
 * @param {HTMLElement} container
 * @param {SimpleCol[]} cols
 * @param {Object[]} rows
 */
export function renderSimpleTable(container, cols, rows) {
  container.replaceChildren();

  if (rows.length === 0) {
    const empty = document.createElement("div");
    empty.style.padding = "16px";
    empty.style.color = "var(--color-ink-muted)";
    empty.textContent = "No rows.";
    container.appendChild(empty);
    return;
  }

  const wrap = document.createElement("div");
  wrap.className = "data-table-wrap";
  const table = document.createElement("table");
  table.className = "data-table";

  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  for (const col of cols) {
    const th = document.createElement("th");
    th.textContent = col.label;
    headRow.appendChild(th);
  }
  thead.appendChild(headRow);
  table.appendChild(thead);

  const tbody = document.createElement("tbody");
  for (const r of rows) {
    const tr = document.createElement("tr");
    for (const col of cols) {
      const td = document.createElement("td");
      const raw = r[col.key];
      const display = raw == null || raw === "" ? "—" : String(raw);
      if (display === "—") td.classList.add("cell--null");
      td.textContent = display;
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  container.appendChild(wrap);
}
