/**
 * session-list.js — left-pane session picker.
 *
 * Responsibilities:
 *   - Render one button per ParsedSession, grouped by source file
 *   - Visually mark the active session
 *   - Notify the app when the user picks one (callback model — no global state)
 *
 * Pure DOM rendering. No parsing, no XML, no I/O. The caller hands us an
 * already-resolved ParsedSession[]; we don't know or care how it got there.
 *
 * SECURITY: every text node comes from XML content under js-out/sessions/.
 * We never use innerHTML with that content; instead we build elements with
 * createElement + textContent so an XML file containing markup or scripts
 * cannot inject DOM into the dashboard.
 */

/**
 * @callback OnPick
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 */

/**
 * Mount the session list into a container element.
 *
 * @param {HTMLElement} root            container element (e.g. <aside id="session-list">)
 * @param {import("../lib/mapping-schema.js").ParsedSession[]} sessions
 * @param {OnPick} onPick
 * @returns {{setActive: (s: import("../lib/mapping-schema.js").ParsedSession) => void}}
 */
export function mountSessionList(root, sessions, onPick) {
  // Wipe via replaceChildren rather than setting innerHTML. Same effect,
  // but never parses HTML — defense in depth.
  root.replaceChildren();

  if (sessions.length === 0) {
    const empty = document.createElement("div");
    empty.className = "session-list__empty";
    empty.textContent =
      "No sessions found in /sessions/. Drop XML files there and refresh.";
    root.appendChild(empty);
    return { setActive: () => {} };
  }

  // Group by file name (multi-session XMLs render under one header).
  const byFile = new Map();
  for (const s of sessions) {
    let bucket = byFile.get(s.fileName);
    if (!bucket) {
      bucket = [];
      byFile.set(s.fileName, bucket);
    }
    bucket.push(s);
  }

  const itemEls = new Map(); // session → button

  for (const [fileName, group] of byFile) {
    const header = document.createElement("div");
    header.className = "session-list__group-header";
    header.textContent = fileName;
    root.appendChild(header);

    for (const session of group) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "session-list__item";

      // Session display name — bold first line. textContent only — no HTML
      // parsing path is reachable, so even an XML file containing markup or
      // script tags renders as literal text.
      const nameEl = document.createElement("strong");
      nameEl.textContent = session.name;
      btn.appendChild(nameEl);

      // Secondary metadata line under the name.
      const metaEl = document.createElement("span");
      metaEl.className = "session-list__item-meta";
      const metaParts = [];
      metaParts.push(
        session.mappingName ? `mapping=${session.mappingName}` : "no mapping",
      );
      if (!session.hasSession) metaParts.push("(no <SESSION> in XML)");
      metaEl.textContent = metaParts.join(" ");
      btn.appendChild(metaEl);

      btn.addEventListener("click", () => onPick(session));
      root.appendChild(btn);
      itemEls.set(session, btn);
    }
  }

  return {
    setActive(session) {
      for (const [s, el] of itemEls) {
        el.classList.toggle("session-list__item--active", s === session);
      }
    },
  };
}
