/**
 * field-mapping-table.js — render the FIELD_MAPPING sheet as an HTML table.
 *
 * The on-screen view mirrors the XLSX column order EXCEPT we omit Tgt
 * Precision/Scale/Nullable/Key and Parameter File — they're available in
 * the export but burn screen real estate. (XLSX still has every column.)
 *
 * SECURITY: every cell value comes from parsed XML. We use textContent
 * exclusively to avoid HTML injection. The Load Type column gets a
 * decorative pill via classList only (the class name comes from a fixed
 * mapping, not user input).
 */

import { fill } from "../lib/format.js";
import { LOAD_TYPES } from "../lib/mapping-schema.js";

/**
 * Column descriptors. `pin: true` means the column sticks to the left
 * during horizontal scroll. `loadType: true` opts a column into the
 * Load Type pill renderer.
 */
const COLS = [
  { key: "is_used",                       label: "Used",            pin: true },
  { key: "source_table",                  label: "Source Table",    pin: true },
  { key: "source_database",               label: "Source Database" },
  { key: "source_column",                 label: "Source Column" },
  { key: "source_datatype",               label: "Source Datatype" },
  { key: "source_precision",              label: "Src Precision" },
  { key: "source_scale",                  label: "Src Scale" },
  { key: "source_nullable",               label: "Src Nullable" },
  { key: "source_key",                    label: "Src Key" },
  { key: "business_logic_expression",     label: "Business Logic / Expression" },
  { key: "expression_type",               label: "Expression Type" },
  { key: "transformation_path",           label: "Transformation Path" },
  { key: "lookups_used",                  label: "Lookups Used" },
  { key: "lookup_type",                   label: "Lookup Type" },
  { key: "lookup_join_condition",         label: "Lookup Join Condition" },
  { key: "lookup_return_column",          label: "Lookup Return Column" },
  { key: "lookup_keys_source_to_lookup",  label: "Lookup Keys (Source → Lookup)" },
  { key: "joiners_used",                  label: "Joiners Used" },
  { key: "routers_used",                  label: "Routers Used" },
  { key: "aggregators_used",              label: "Aggregators Used" },
  { key: "source_qualifier",              label: "Source Qualifier" },
  { key: "error_logic",                   label: "Error Handling Logic" },
  { key: "load_type",                     label: "Load Type",        loadType: true },
  { key: "target_table",                  label: "Target Table" },
  { key: "target_database",               label: "Target Database" },
  { key: "target_column",                 label: "Target Column" },
  { key: "target_datatype",               label: "Target Datatype" },
  { key: "notes",                         label: "Notes" },
];

/**
 * Render the FIELD_MAPPING grid into `container`.
 *
 * @param {HTMLElement} container
 * @param {import("../lib/mapping-schema.js").FieldMappingJson[]} rows
 */
export function renderFieldMappingTable(container, rows) {
  container.replaceChildren();
  const wrap = document.createElement("div");
  wrap.className = "data-table-wrap";

  const table = document.createElement("table");
  table.className = "data-table";

  // Header row
  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  for (const col of COLS) {
    const th = document.createElement("th");
    th.textContent = col.label;
    if (col.pin) th.classList.add("col--pin");
    headRow.appendChild(th);
  }
  thead.appendChild(headRow);
  table.appendChild(thead);

  // Body rows
  const tbody = document.createElement("tbody");
  for (const r of rows) {
    const tr = document.createElement("tr");
    for (const col of COLS) {
      const td = document.createElement("td");
      if (col.pin) td.classList.add("col--pin");
      const raw = r[col.key];
      const display = fill(raw);
      if (display === "NULL") td.classList.add("cell--null");

      if (col.loadType) {
        // Decorative pill. Map known load types to a class suffix; unknown
        // values fall back to the UNSPECIFIED look so a typo can't break
        // styling.
        const pill = document.createElement("span");
        pill.className = "load-type-pill " + loadTypePillClass(display);
        pill.textContent = display;
        td.appendChild(pill);
      } else {
        td.textContent = display;
      }
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);

  wrap.appendChild(table);
  container.appendChild(wrap);
}

function loadTypePillClass(value) {
  // Match strictly against the LOAD_TYPES enum so an attacker-controlled
  // string can't sneak arbitrary CSS class names into the DOM.
  switch (value) {
    case LOAD_TYPES.INSERT:      return "load-type-pill--INSERT";
    case LOAD_TYPES.UPDATE:      return "load-type-pill--UPDATE";
    case LOAD_TYPES.DELETE:      return "load-type-pill--DELETE";
    case LOAD_TYPES.REJECT:      return "load-type-pill--REJECT";
    case LOAD_TYPES.DATA_DRIVEN: return "load-type-pill--DATA-DRIVEN";
    default:                     return "load-type-pill--UNSPECIFIED";
  }
}
