/**
 * export-buttons.js — segmented XLSX / CSV / JSON / Markdown button group.
 *
 * Visual: matches the segmented control rendered inside SessionHeader in
 * components/SessionView.tsx — XLSX is a dark primary button, the other
 * three are light secondary buttons sharing one border with thin dividers.
 *
 * Disables the whole group while an export is in flight so a slow XLSX
 * build can't be fired twice.
 *
 * SECURITY: button labels and tooltips are constant strings — no
 * untrusted DOM here.
 */

import { sessionToCsv } from "../lib/exports-csv.js";
import { sessionToJson } from "../lib/exports-json.js";
import { sessionToMarkdown } from "../lib/exports-md.js";
import { buildXlsxBuffer } from "../lib/exports-xlsx.js";
import { downloadBinary, downloadText } from "../lib/downloads.js";
import { icon, ICON_DOWNLOAD } from "./primitives.js";

/**
 * @param {HTMLElement} container
 * @param {() => import("../lib/mapping-schema.js").ParsedSession|null} getSession
 * @param {(msg: string, kind?: "info"|"success"|"error") => void} toast
 */
export function mountExportButtons(container, getSession, toast) {
  const bar = document.createElement("div");
  bar.className = "export-bar";

  // ── XLSX (primary dark button, with download icon) ────────────────
  const xlsxBtn = document.createElement("button");
  xlsxBtn.type = "button";
  xlsxBtn.className = "export-bar__btn export-bar__btn--primary";
  xlsxBtn.title = "Clean 7-sheet workbook (Overall details + FIELD_MAPPING + LOOKUPS + …)";
  xlsxBtn.appendChild(icon(ICON_DOWNLOAD));
  const xlsxLabel = document.createTextNode(" XLSX");
  xlsxBtn.appendChild(xlsxLabel);
  bar.appendChild(xlsxBtn);

  // ── CSV / JSON / Markdown (secondary buttons) ─────────────────────
  const csvBtn = makeSecondary("CSV", "FIELD_MAPPING as CSV (same columns as the XLSX)");
  bar.appendChild(csvBtn);
  const jsonBtn = makeSecondary("JSON", "MappingJson — normalized intermediate (same data as XLSX)");
  bar.appendChild(jsonBtn);
  const mdBtn = makeSecondary("MD", "Markdown documentation");
  bar.appendChild(mdBtn);

  container.appendChild(bar);

  const allButtons = [xlsxBtn, csvBtn, jsonBtn, mdBtn];

  function setDisabled(disabled) {
    for (const b of allButtons) b.disabled = disabled;
  }

  function wire(btn, label, run) {
    btn.addEventListener("click", async () => {
      const session = getSession();
      if (!session) {
        toast("Select a session first", "error");
        return;
      }
      setDisabled(true);
      const originalText = btn.textContent;
      if (btn === xlsxBtn) xlsxLabel.textContent = " Building…";
      try {
        await run(session);
        toast(`${label} ready`, "success");
      } catch (err) {
        console.error(`[export ${label}]`, err);
        toast(`${label} failed: ${err.message}`, "error");
      } finally {
        setDisabled(false);
        if (btn === xlsxBtn) xlsxLabel.textContent = " XLSX";
        else btn.textContent = originalText;
      }
    });
  }

  wire(xlsxBtn, "XLSX", async (s) => {
    const buf = await buildXlsxBuffer(s);
    downloadBinary(
      fileNameFor(s, "xlsx"),
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buf,
    );
  });
  wire(csvBtn, "CSV", (s) => downloadText(fileNameFor(s, "csv"), "text/csv", sessionToCsv(s)));
  wire(jsonBtn, "JSON", (s) => downloadText(fileNameFor(s, "json"), "application/json", sessionToJson(s)));
  wire(mdBtn, "MD",   (s) => downloadText(fileNameFor(s, "md"),   "text/markdown",   sessionToMarkdown(s)));
}

function makeSecondary(label, title) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "export-bar__btn";
  b.title = title;
  b.textContent = label;
  return b;
}

function fileNameFor(session, ext) {
  const safe = (session.name || session.fileName || "session").replace(/[^A-Za-z0-9._-]+/g, "_");
  return `${safe}.${ext}`;
}
