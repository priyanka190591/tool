/**
 * export-buttons.js — XLSX / CSV / JSON / Markdown button bar.
 *
 * Wired into session-view.js's header. Each button calls the matching
 * export module and triggers a download via downloads.js. We disable the
 * whole bar while an export is in flight so a slow XLSX build can't get
 * fired twice.
 *
 * SECURITY: button labels are constant strings — no untrusted DOM here.
 */

import { sessionToCsv } from "../lib/exports-csv.js";
import { sessionToJson } from "../lib/exports-json.js";
import { sessionToMarkdown } from "../lib/exports-md.js";
import { buildXlsxBuffer } from "../lib/exports-xlsx.js";
import { downloadBinary, downloadText } from "../lib/downloads.js";

/**
 * Mount the export button bar.
 *
 * @param {HTMLElement} container       parent to append the bar to
 * @param {() => import("../lib/mapping-schema.js").ParsedSession|null} getSession
 *        called each time a button is clicked — returns the current session
 *        or null. Indirected so the bar doesn't have to be re-mounted when
 *        the active session changes.
 * @param {(msg: string, kind?: "info"|"success"|"error") => void} toast
 */
export function mountExportButtons(container, getSession, toast) {
  const bar = document.createElement("div");
  bar.className = "export-bar";

  const buttons = [
    { label: "XLSX",     async: true,  run: handleXlsx },
    { label: "CSV",      async: false, run: handleCsv },
    { label: "JSON",     async: false, run: handleJson },
    { label: "Markdown", async: false, run: handleMd },
  ];

  /** @type {HTMLButtonElement[]} */
  const btnEls = [];

  for (const b of buttons) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "export-bar__btn";
    btn.textContent = b.label;
    btn.addEventListener("click", async () => {
      const session = getSession();
      if (!session) {
        toast("Select a session first", "error");
        return;
      }
      setDisabled(true);
      try {
        await b.run(session);
        toast(`${b.label} export ready`, "success");
      } catch (err) {
        // Surface the error message; full stack goes to console.
        console.error(`[export ${b.label}]`, err);
        toast(`${b.label} export failed: ${err.message}`, "error");
      } finally {
        setDisabled(false);
      }
    });
    bar.appendChild(btn);
    btnEls.push(btn);
  }

  container.appendChild(bar);

  function setDisabled(disabled) {
    for (const el of btnEls) el.disabled = disabled;
  }

  // ── individual handlers (no business logic — just wiring) ─────────────

  async function handleXlsx(session) {
    const buf = await buildXlsxBuffer(session);
    downloadBinary(
      fileNameFor(session, "xlsx"),
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      buf,
    );
  }

  function handleCsv(session) {
    downloadText(fileNameFor(session, "csv"), "text/csv", sessionToCsv(session));
  }

  function handleJson(session) {
    downloadText(
      fileNameFor(session, "json"),
      "application/json",
      sessionToJson(session),
    );
  }

  function handleMd(session) {
    downloadText(
      fileNameFor(session, "md"),
      "text/markdown",
      sessionToMarkdown(session),
    );
  }
}

/** Build a sensible default download filename for a session. */
function fileNameFor(session, ext) {
  const safe = (session.name || session.fileName || "session").replace(/[^A-Za-z0-9._-]+/g, "_");
  return `${safe}.${ext}`;
}
