/**
 * primitives.js — Card / Pill / Stat / KeyValueTable factory helpers.
 *
 * Mirror of components/ui.tsx. These return real DOM elements (not strings)
 * so callers can `container.appendChild(card({...}))` directly. Keeping the
 * surface small (4 factories, no class hierarchies) makes them easy to
 * grep + edit.
 *
 * SECURITY: textContent only; we never accept HTML strings.
 */

/**
 * Build a Card element with optional title / subtitle / right-aligned content.
 *
 * @param {{title?: string, subtitle?: string, right?: Node|Node[]}} opts
 * @returns {HTMLElement}  the card; append child content into card.body
 */
export function card(opts = {}) {
  const root = document.createElement("section");
  root.className = "card";

  if (opts.title || opts.subtitle || opts.right) {
    const header = document.createElement("header");
    header.className = "card__header";

    const titleBlock = document.createElement("div");
    if (opts.title) {
      const h2 = document.createElement("h2");
      h2.className = "card__title";
      h2.textContent = opts.title;
      titleBlock.appendChild(h2);
    }
    if (opts.subtitle) {
      const p = document.createElement("p");
      p.className = "card__subtitle";
      p.textContent = opts.subtitle;
      titleBlock.appendChild(p);
    }
    header.appendChild(titleBlock);

    if (opts.right) {
      const right = document.createElement("div");
      if (Array.isArray(opts.right)) {
        for (const n of opts.right) if (n) right.appendChild(n);
      } else {
        right.appendChild(opts.right);
      }
      header.appendChild(right);
    }
    root.appendChild(header);
  }

  // Caller fills root.body with content.
  const body = document.createElement("div");
  body.className = "card__body";
  root.appendChild(body);
  // Expose body as a property so callers don't have to know the structure.
  root.body = body;
  return root;
}

/**
 * Build a Pill element.
 *
 * @param {string} text
 * @param {"default"|"ok"|"warn"|"bad"} [tone]
 * @returns {HTMLElement}
 */
export function pill(text, tone = "default") {
  const span = document.createElement("span");
  span.className = `pill pill--${tone}`;
  span.textContent = text;
  return span;
}

/**
 * Build a Stat element (uppercase label over value).
 *
 * @param {string} label
 * @param {string|number} value
 * @returns {HTMLElement}
 */
export function stat(label, value) {
  const root = document.createElement("div");
  root.className = "stat";
  const l = document.createElement("span");
  l.className = "stat__label";
  l.textContent = label;
  const v = document.createElement("span");
  v.className = "stat__value";
  v.textContent = String(value);
  root.appendChild(l);
  root.appendChild(v);
  return root;
}

/**
 * Build a key/value table from an array of {name, value} rows.
 *
 * @param {{name: string, value: string}[]} rows
 * @param {string} [emptyMessage]
 * @returns {HTMLElement}
 */
export function keyValueTable(rows, emptyMessage = "No values.") {
  if (!rows || rows.length === 0) {
    const p = document.createElement("p");
    p.style.fontSize = "13px";
    p.style.color = "var(--ink-500)";
    p.textContent = emptyMessage;
    return p;
  }
  const wrap = document.createElement("div");
  // Border lives on the table itself — match the Tailwind look.
  const table = document.createElement("table");
  table.className = "kv-table";
  const tbody = document.createElement("tbody");
  for (const r of rows) {
    const tr = document.createElement("tr");
    const nameTd = document.createElement("td");
    nameTd.className = "kv-table__name";
    nameTd.textContent = r.name;
    const valTd = document.createElement("td");
    valTd.className = "kv-table__value";
    if (r.value === "" || r.value == null) {
      valTd.classList.add("kv-table__empty");
      valTd.textContent = "—";
    } else {
      valTd.textContent = r.value;
    }
    tr.appendChild(nameTd);
    tr.appendChild(valTd);
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  return wrap;
}

/**
 * Tiny SVG icon helper. Returns an inline SVG sized 14×14 by default.
 *
 * @param {string} pathD   SVG path data
 * @param {{size?: number, className?: string}} [opts]
 * @returns {SVGElement}
 */
export function icon(pathD, opts = {}) {
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg");
  svg.setAttribute("viewBox", "0 0 20 20");
  svg.setAttribute("width", String(opts.size ?? 14));
  svg.setAttribute("height", String(opts.size ?? 14));
  svg.setAttribute("fill", "currentColor");
  svg.setAttribute("aria-hidden", "true");
  if (opts.className) svg.setAttribute("class", opts.className);
  const p = document.createElementNS(NS, "path");
  p.setAttribute("d", pathD);
  p.setAttribute("fill-rule", "evenodd");
  p.setAttribute("clip-rule", "evenodd");
  svg.appendChild(p);
  return svg;
}

// ── Common SVG path strings (Heroicons-style) ────────────────────────────

export const ICON_SEARCH =
  "M9 3.5a5.5 5.5 0 1 0 3.477 9.785l3.119 3.119a.75.75 0 0 0 1.06-1.061l-3.118-3.118A5.5 5.5 0 0 0 9 3.5ZM5 9a4 4 0 1 1 8 0 4 4 0 0 1-8 0Z";

export const ICON_CHEVRON_DOWN =
  "M5.23 7.21a.75.75 0 0 1 1.06.02L10 11.06l3.71-3.83a.75.75 0 1 1 1.08 1.04l-4.24 4.38a.75.75 0 0 1-1.08 0L5.21 8.27a.75.75 0 0 1 .02-1.06Z";

export const ICON_DOWNLOAD =
  "M10 3a.75.75 0 0 1 .75.75v7.69l2.22-2.22a.75.75 0 1 1 1.06 1.06l-3.5 3.5a.75.75 0 0 1-1.06 0l-3.5-3.5a.75.75 0 1 1 1.06-1.06l2.22 2.22V3.75A.75.75 0 0 1 10 3ZM3.75 14.5a.75.75 0 0 1 .75.75v.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-.5a.75.75 0 0 1 1.5 0v.5A1.75 1.75 0 0 1 15.25 17H4.75A1.75 1.75 0 0 1 3 15.75v-.5a.75.75 0 0 1 .75-.75Z";
