/**
 * validation-panel.js — render validation issues grouped by severity.
 *
 * Mirrors components/ValidationPanel.tsx.
 *
 * SECURITY: textContent only.
 */

const SEVERITY_LABEL = { error: "errors", warning: "warnings", info: "info" };

/**
 * @param {HTMLElement} container
 * @param {import("../lib/validation.js").ValidationIssue[]} issues
 */
export function renderValidationPanel(container, issues) {
  container.replaceChildren();
  if (issues.length === 0) {
    const p = document.createElement("p");
    p.style.color = "var(--emerald-800)";
    p.style.fontSize = "14px";
    p.textContent = "No issues detected.";
    container.appendChild(p);
    return;
  }

  const grouped = { error: [], warning: [], info: [] };
  for (const i of issues) grouped[i.severity].push(i);

  // Summary tag row
  const summary = document.createElement("div");
  summary.className = "validation-summary";
  for (const sev of ["error", "warning", "info"]) {
    const tag = document.createElement("span");
    tag.className = `validation-tag validation-tag--${sev}`;
    const dot = document.createElement("span");
    dot.className = "validation-tag__dot";
    tag.appendChild(dot);
    const label = document.createTextNode(`${grouped[sev].length} ${SEVERITY_LABEL[sev]}`);
    tag.appendChild(label);
    summary.appendChild(tag);
  }
  container.appendChild(summary);

  // Issue list
  const list = document.createElement("div");
  list.className = "validation-list";
  for (const sev of ["error", "warning", "info"]) {
    for (const issue of grouped[sev]) {
      const row = document.createElement("div");
      row.className = `validation-issue validation-issue--${sev}`;
      const dot = document.createElement("span");
      dot.className = "validation-issue__dot";
      row.appendChild(dot);
      const body = document.createElement("div");
      body.className = "validation-issue__body";
      const head = document.createElement("div");
      head.className = "validation-issue__head";
      const code = document.createElement("code");
      code.className = "validation-issue__code";
      code.textContent = issue.code;
      head.appendChild(code);
      if (issue.location) {
        const loc = document.createElement("span");
        loc.className = "validation-issue__location";
        loc.textContent = issue.location;
        head.appendChild(loc);
      }
      body.appendChild(head);
      const msg = document.createElement("div");
      msg.className = "validation-issue__msg";
      msg.textContent = issue.message;
      body.appendChild(msg);
      row.appendChild(body);
      list.appendChild(row);
    }
  }
  container.appendChild(list);
}
