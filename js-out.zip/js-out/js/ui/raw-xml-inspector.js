/**
 * raw-xml-inspector.js — line-numbered XML viewer with filter.
 *
 * Mirrors components/RawXmlInspector.tsx.
 *
 * SECURITY: textContent only.
 */

/**
 * @param {HTMLElement} container
 * @param {string} xml  raw XML text
 */
export function renderRawXmlInspector(container, xml) {
  container.replaceChildren();
  const root = document.createElement("div");
  root.className = "raw-xml";

  const lines = xml.split(/\r?\n/);
  const lineCount = lines.length;
  const bytes = new Blob([xml]).size;

  // ── Toolbar (counts + filter + Show source) ──────────────────────
  const bar = document.createElement("div");
  bar.className = "raw-xml__bar";

  const counts = document.createElement("div");
  counts.className = "raw-xml__counts";
  const linesLabel = document.createElement("span");
  linesLabel.textContent = `${lineCount.toLocaleString()} lines`;
  const dot = document.createElement("span");
  dot.textContent = "·";
  const bytesLabel = document.createElement("span");
  bytesLabel.textContent = `${(bytes / 1024).toFixed(1)} KB`;
  counts.appendChild(linesLabel);
  counts.appendChild(dot);
  counts.appendChild(bytesLabel);
  bar.appendChild(counts);

  const right = document.createElement("div");
  right.style.display = "flex";
  right.style.alignItems = "center";
  right.style.gap = "0.5rem";

  const filterInput = document.createElement("input");
  filterInput.type = "search";
  filterInput.placeholder = "Filter XML (e.g. CONNECTOR, Lookup condition)…";
  filterInput.className = "diag-controls__input";
  filterInput.style.width = "18rem";
  filterInput.style.flex = "0 0 auto";
  right.appendChild(filterInput);

  const showBtn = document.createElement("button");
  showBtn.type = "button";
  showBtn.className = "btn-secondary";
  showBtn.textContent = "Show source";
  right.appendChild(showBtn);

  bar.appendChild(right);
  root.appendChild(bar);

  // ── Filter panel ───────────────────────────────────────────────
  const filterPanel = document.createElement("div");
  filterPanel.className = "raw-xml__panel";
  filterPanel.hidden = true;
  const filterCount = document.createElement("div");
  filterCount.style.fontSize = "12px";
  filterCount.style.color = "var(--ink-500)";
  filterCount.style.marginBottom = "4px";
  filterPanel.appendChild(filterCount);
  const filterPre = document.createElement("pre");
  filterPre.className = "raw-xml__pre";
  filterPanel.appendChild(filterPre);
  root.appendChild(filterPanel);

  // ── Full source panel ──────────────────────────────────────────
  const fullPre = document.createElement("pre");
  fullPre.className = "raw-xml__pre raw-xml__pre--full";
  fullPre.hidden = true;
  fullPre.textContent = xml;
  root.appendChild(fullPre);

  // ── State ──────────────────────────────────────────────────────
  let shown = false;
  showBtn.addEventListener("click", () => {
    shown = !shown;
    fullPre.hidden = !shown;
    showBtn.textContent = shown ? "Hide source" : "Show source";
  });

  filterInput.addEventListener("input", () => {
    const q = filterInput.value.trim().toLowerCase();
    if (!q) {
      filterPanel.hidden = true;
      return;
    }
    const matches = [];
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].toLowerCase().includes(q)) {
        matches.push({ line: lines[i], i });
        if (matches.length >= 500) break;
      }
    }
    filterPanel.hidden = false;
    filterCount.textContent =
      `${matches.length} match${matches.length === 1 ? "" : "es"}` +
      (matches.length === 500 ? " (capped at 500)" : "");
    filterPre.textContent =
      matches.length > 0
        ? matches.map((r) => `${String(r.i + 1).padStart(5, " ")}  ${r.line}`).join("\n")
        : "No matches.";
  });

  container.appendChild(root);
}
