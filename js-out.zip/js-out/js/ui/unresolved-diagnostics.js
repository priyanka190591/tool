/**
 * unresolved-diagnostics.js — Mapping Inspector for unresolved field mappings.
 *
 * Lighter port of components/UnresolvedDiagnostics.tsx: lists every
 * FIELD_MAPPING row, filterable by status / target table / free-text. For
 * each unresolved row we surface the lineage walk's last instance + last
 * field so reviewers can jump to the upstream point where resolution
 * broke. The interactive per-identifier classifier from the original
 * (extractIdentifiers + classifyIdentifier) is not ported in Phase 3 —
 * Phase 4 (Lineage Tracer) covers the deep-dive workflow.
 *
 * SECURITY: textContent only.
 */

import { buildMappingJson } from "../lib/build-mapping-json.js";
import { isFieldMappingUnresolved } from "../lib/build-mapping-json.js";
import { buildLineage } from "../lib/lineage.js";
import { pill } from "./primitives.js";

/**
 * @param {HTMLElement} container
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 */
export function renderUnresolvedDiagnostics(container, session) {
  container.replaceChildren();

  const mapping = buildMappingJson(session);
  const allRows = mapping.field_mappings.filter((r) => r.is_used === "YES");
  const lineage = buildLineage(session);
  const linByCol = new Map();
  for (const l of lineage) {
    linByCol.set(`${l.targetTable}::${l.targetColumn}`, l);
  }

  const total = allRows.length;
  const unresolvedRows = allRows.filter((r) => isFieldMappingUnresolved(r));
  const resolvedRows = allRows.filter((r) => !isFieldMappingUnresolved(r));

  // ── Controls ───────────────────────────────────────────────────────
  const controls = document.createElement("div");
  controls.className = "diag-controls";

  const statusSelect = document.createElement("select");
  statusSelect.className = "diag-controls__select";
  for (const opt of [
    { v: "unresolved", l: `Unresolved (${unresolvedRows.length})` },
    { v: "resolved",   l: `Resolved (${resolvedRows.length})` },
    { v: "all",        l: `All (${total})` },
  ]) {
    const o = document.createElement("option");
    o.value = opt.v;
    o.textContent = opt.l;
    statusSelect.appendChild(o);
  }
  controls.appendChild(statusSelect);

  const targetSelect = document.createElement("select");
  targetSelect.className = "diag-controls__select";
  const targetTables = [...new Set(allRows.map((r) => r.target_table))].sort();
  const allOpt = document.createElement("option");
  allOpt.value = "all";
  allOpt.textContent = "All targets";
  targetSelect.appendChild(allOpt);
  for (const t of targetTables) {
    const o = document.createElement("option");
    o.value = t;
    o.textContent = t;
    targetSelect.appendChild(o);
  }
  controls.appendChild(targetSelect);

  const filter = document.createElement("input");
  filter.type = "search";
  filter.className = "diag-controls__input";
  filter.placeholder = "Filter by table / column / expression…";
  controls.appendChild(filter);

  container.appendChild(controls);

  // ── List host ──────────────────────────────────────────────────────
  const list = document.createElement("div");
  list.style.background = "#fff";
  list.style.border = "1px solid var(--ink-100)";
  list.style.borderRadius = "var(--radius-md)";
  list.style.marginTop = "0.75rem";
  list.style.maxHeight = "70vh";
  list.style.overflow = "auto";
  container.appendChild(list);

  // ── Re-render on control change ───────────────────────────────────
  const render = () => {
    list.replaceChildren();
    const status = statusSelect.value;
    const targetT = targetSelect.value;
    const q = filter.value.trim().toLowerCase();

    let pool = allRows;
    if (status === "unresolved") pool = unresolvedRows;
    else if (status === "resolved") pool = resolvedRows;
    if (targetT !== "all") pool = pool.filter((r) => r.target_table === targetT);
    if (q) {
      pool = pool.filter((r) =>
        (r.target_table + "." + r.target_column).toLowerCase().includes(q) ||
        (r.source_table ?? "").toLowerCase().includes(q) ||
        (r.business_logic_expression ?? "").toLowerCase().includes(q),
      );
    }

    if (pool.length === 0) {
      const empty = document.createElement("div");
      empty.style.padding = "1rem";
      empty.style.color = "var(--ink-500)";
      empty.style.fontSize = "13px";
      empty.textContent = "No rows match.";
      list.appendChild(empty);
      return;
    }

    const cap = 200;
    const display = pool.slice(0, cap);
    if (pool.length > cap) {
      const note = document.createElement("div");
      note.style.padding = "0.5rem 1rem";
      note.style.fontSize = "12px";
      note.style.color = "var(--ink-500)";
      note.textContent = `Showing ${cap} of ${pool.length} rows. Refine the filter to see more.`;
      list.appendChild(note);
    }

    for (const r of display) {
      const lin = linByCol.get(`${r.target_table}::${r.target_column}`);
      const row = document.createElement("div");
      row.className = "diag-row";

      const head = document.createElement("div");
      head.className = "diag-row__head";
      const tgt = document.createElement("span");
      tgt.className = "diag-row__target";
      tgt.textContent = `${r.target_table}.${r.target_column}`;
      head.appendChild(tgt);
      head.appendChild(pill(isFieldMappingUnresolved(r) ? "Unresolved" : "Resolved",
        isFieldMappingUnresolved(r) ? "warn" : "ok"));
      if (r.load_type && r.load_type !== "UNSPECIFIED") {
        head.appendChild(pill(r.load_type));
      }
      row.appendChild(head);

      const src = document.createElement("div");
      const srcClass = isFieldMappingUnresolved(r) ? "diag-row__source" : "diag-row__source diag-row__source--resolved";
      src.className = srcClass;
      const srcText = r.source_table
        ? (r.source_column ? `${r.source_table}.${r.source_column}` : r.source_table)
        : "—";
      src.textContent = `Source: ${srcText}`;
      row.appendChild(src);

      if (r.business_logic_expression) {
        const expr = document.createElement("div");
        expr.className = "diag-row__detail";
        expr.textContent = `Expression: ${r.business_logic_expression}`;
        row.appendChild(expr);
      }

      if (lin && (lin.lastInstance || lin.lastField)) {
        const last = document.createElement("div");
        last.className = "diag-row__note";
        last.textContent = `Walk ended at: ${lin.lastInstance ?? "?"}.${lin.lastField ?? "?"}`;
        row.appendChild(last);
      }

      if (r.notes) {
        const notes = document.createElement("div");
        notes.className = "diag-row__note";
        notes.textContent = `Notes: ${r.notes}`;
        row.appendChild(notes);
      }
      list.appendChild(row);
    }
  };

  statusSelect.addEventListener("change", render);
  targetSelect.addEventListener("change", render);
  filter.addEventListener("input", render);
  render();
}
