/**
 * session-picker.js — top-of-page session selector card.
 *
 * Mirrors components/SessionPicker.tsx + the surrounding picker card in
 * DashboardClient.tsx. Visual:
 *
 *   ┌───────────────────────────────────────────────────────────────┐
 *   │ Session XML   [ filename ▼ ]              N files · M sessions │
 *   └───────────────────────────────────────────────────────────────┘
 *
 * Clicking the dropdown opens a search-filtered list. Picking a session
 * notifies the caller via `onPick`. Clicking outside closes the panel.
 *
 * SECURITY: textContent only; no innerHTML; all session names come from
 * parsed XML, which we never interpolate as HTML.
 */

import { icon, ICON_CHEVRON_DOWN } from "./primitives.js";

/**
 * @typedef {Object} Option
 * @property {string} fileName
 * @property {number} sessionIndex
 * @property {string} sessionName
 * @property {string} [mappingName]
 * @property {string} label
 * @property {import("../lib/mapping-schema.js").ParsedSession} session
 */

/**
 * Mount the picker card.
 *
 * @param {HTMLElement} root
 * @param {import("../lib/mapping-schema.js").ParsedSession[]} sessions
 * @param {(s: import("../lib/mapping-schema.js").ParsedSession) => void} onPick
 * @returns {{setActive: (s: import("../lib/mapping-schema.js").ParsedSession) => void}}
 */
export function mountSessionPicker(root, sessions, onPick) {
  root.replaceChildren();

  /** @type {Option[]} */
  const options = flatten(sessions);

  // ── Picker (label + dropdown) ─────────────────────────────────────
  const picker = document.createElement("div");
  picker.className = "picker";

  const label = document.createElement("label");
  label.className = "picker__label";
  label.textContent = "Session XML";
  picker.appendChild(label);

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "picker__btn";
  const btnText = document.createElement("span");
  btnText.className = "picker__btn-text";
  btnText.textContent = options.length === 0 ? "No XML files found" : "Select a session…";
  btn.appendChild(btnText);
  btn.appendChild(icon(ICON_CHEVRON_DOWN, { className: "picker__btn-chevron" }));
  if (options.length === 0) btn.disabled = true;
  picker.appendChild(btn);

  const panel = document.createElement("div");
  panel.className = "picker__panel";
  panel.hidden = true;
  picker.appendChild(panel);

  // ── Stats ─────────────────────────────────────────────────────────
  const stats = document.createElement("div");
  stats.className = "picker-card__stats";
  const fileCount = new Set(sessions.map((s) => s.fileName)).size;
  stats.textContent = `${fileCount} file${fileCount === 1 ? "" : "s"} · ${sessions.length} session${sessions.length === 1 ? "" : "s"}`;

  root.appendChild(picker);
  root.appendChild(stats);

  // ── State / behavior ──────────────────────────────────────────────
  let activeSession = null;

  function open() {
    panel.hidden = false;
    renderPanel("");
    // Focus the search input on open.
    const inp = panel.querySelector(".picker__search-input");
    if (inp) inp.focus();
  }
  function close() { panel.hidden = true; }
  btn.addEventListener("click", () => (panel.hidden ? open() : close()));

  // Dismiss on outside click.
  document.addEventListener("mousedown", (e) => {
    if (!picker.contains(e.target)) close();
  });

  function renderPanel(query) {
    panel.replaceChildren();
    const searchWrap = document.createElement("div");
    searchWrap.className = "picker__search";
    const search = document.createElement("input");
    search.type = "search";
    search.className = "picker__search-input";
    search.placeholder = "Search by file, session, or mapping…";
    search.value = query;
    search.addEventListener("input", () => renderListOnly(search.value));
    searchWrap.appendChild(search);
    panel.appendChild(searchWrap);

    const list = document.createElement("ul");
    list.className = "picker__list";
    panel.appendChild(list);
    renderListOnly(query);

    function renderListOnly(q) {
      list.replaceChildren();
      const matches = filter(options, q);
      if (matches.length === 0) {
        const empty = document.createElement("li");
        empty.className = "picker__empty";
        empty.textContent = "No matches.";
        list.appendChild(empty);
        return;
      }
      for (const o of matches) {
        const li = document.createElement("li");
        const optBtn = document.createElement("button");
        optBtn.type = "button";
        optBtn.className = "picker__option";
        if (activeSession === o.session) optBtn.classList.add("picker__option--active");

        const name = document.createElement("span");
        name.className = "picker__option-name";
        name.textContent = o.sessionName;
        optBtn.appendChild(name);

        const meta = document.createElement("span");
        meta.className = "picker__option-meta";
        meta.textContent = o.mappingName
          ? `${o.fileName} · ${o.mappingName}`
          : o.fileName;
        optBtn.appendChild(meta);

        optBtn.addEventListener("click", () => {
          api.setActive(o.session);
          onPick(o.session);
          close();
        });
        li.appendChild(optBtn);
        list.appendChild(li);
      }
    }
  }

  const api = {
    setActive(session) {
      activeSession = session;
      const o = options.find((opt) => opt.session === session);
      btnText.textContent = o
        ? o.label
        : (sessions.length === 0 ? "No XML files found" : "Select a session…");
    },
  };
  return api;
}

// ── Helpers ──────────────────────────────────────────────────────────────

function flatten(sessions) {
  // Group by filename so we can include the file path in multi-session
  // labels. Single-session-per-file labels show just the filename to keep
  // the dropdown button short.
  const byFile = new Map();
  for (const s of sessions) {
    let bucket = byFile.get(s.fileName);
    if (!bucket) { bucket = []; byFile.set(s.fileName, bucket); }
    bucket.push(s);
  }
  const out = [];
  for (const [fileName, list] of byFile) {
    const multi = list.length > 1;
    for (const s of list) {
      out.push({
        fileName,
        sessionIndex: s.sessionIndex,
        sessionName: s.name,
        mappingName: s.mappingName,
        label: multi ? `${fileName}  ›  ${s.name}` : fileName,
        session: s,
      });
    }
  }
  return out;
}

function filter(options, q) {
  const needle = q.trim().toLowerCase();
  if (!needle) return options;
  return options.filter(
    (o) =>
      o.fileName.toLowerCase().includes(needle) ||
      o.sessionName.toLowerCase().includes(needle) ||
      (o.mappingName ?? "").toLowerCase().includes(needle),
  );
}
