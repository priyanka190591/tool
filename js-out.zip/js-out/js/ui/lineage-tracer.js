/**
 * lineage-tracer.js — interactive per-column lineage walker.
 *
 * Simplified port of components/LineageTracer.tsx. Lets the user pick a
 * target table + column and see the full lineage walk as a vertical step
 * list: source → transformations → target. Uses MappingJson + LineageRow
 * data already produced by build-mapping-json.js.
 *
 * SECURITY: textContent only.
 */

import { buildMappingJson } from "../lib/build-mapping-json.js";
import { buildLineage } from "../lib/lineage.js";
import { card, pill, stat, keyValueTable } from "./primitives.js";

/**
 * @param {HTMLElement} container
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 */
export function renderLineageTracer(container, session) {
  container.replaceChildren();
  const mapping = buildMappingJson(session);
  const rows = mapping.field_mappings.filter((r) => r.is_used === "YES");

  if (rows.length === 0) {
    const empty = document.createElement("div");
    empty.className = "state-panel";
    empty.textContent = "No lineage available. This XML has no mapping definition or no target columns.";
    container.appendChild(empty);
    return;
  }

  // Lineage rows keyed by target — gives us lastInstance / lastField / etc.
  const lineage = buildLineage(session);
  const linByCol = new Map();
  for (const l of lineage) {
    linByCol.set(`${l.targetTable}::${l.targetColumn}`, l);
  }

  // Group rows by target_table for the dropdown.
  const byTable = new Map();
  for (const r of rows) {
    const k = r.target_table;
    if (!byTable.has(k)) byTable.set(k, []);
    byTable.get(k).push(r);
  }
  const tables = [...byTable.keys()].sort();

  // ── Controls card ──────────────────────────────────────────────────
  const controls = card({ title: "Pick a target column" });

  const row1 = document.createElement("div");
  row1.style.display = "flex";
  row1.style.flexWrap = "wrap";
  row1.style.gap = "0.75rem";
  row1.style.alignItems = "end";

  const tableLabel = document.createElement("label");
  tableLabel.style.display = "flex";
  tableLabel.style.flexDirection = "column";
  tableLabel.style.gap = "4px";
  tableLabel.style.fontSize = "12px";
  const tableLabelText = document.createElement("span");
  tableLabelText.className = "stat__label";
  tableLabelText.textContent = "Target Table";
  tableLabel.appendChild(tableLabelText);
  const tableSelect = document.createElement("select");
  tableSelect.className = "diag-controls__select";
  for (const t of tables) {
    const o = document.createElement("option");
    o.value = t;
    o.textContent = t;
    tableSelect.appendChild(o);
  }
  tableLabel.appendChild(tableSelect);
  row1.appendChild(tableLabel);

  const colLabel = document.createElement("label");
  colLabel.style.display = "flex";
  colLabel.style.flexDirection = "column";
  colLabel.style.gap = "4px";
  colLabel.style.flex = "1 1 200px";
  const colLabelText = document.createElement("span");
  colLabelText.className = "stat__label";
  colLabelText.textContent = "Target Column";
  colLabel.appendChild(colLabelText);
  const colSelect = document.createElement("select");
  colSelect.className = "diag-controls__select";
  colLabel.appendChild(colSelect);
  row1.appendChild(colLabel);

  controls.body.appendChild(row1);
  container.appendChild(controls);

  // ── Detail host ────────────────────────────────────────────────────
  const detailHost = document.createElement("div");
  detailHost.style.display = "grid";
  detailHost.style.gap = "var(--gap-md)";
  detailHost.style.marginTop = "var(--gap-md)";
  container.appendChild(detailHost);

  // ── Rebuild logic ──────────────────────────────────────────────────
  const repopulateColumns = (selectedTable) => {
    colSelect.replaceChildren();
    for (const r of byTable.get(selectedTable) ?? []) {
      const o = document.createElement("option");
      o.value = `${r.target_table}::${r.target_column}::${r.load_type}`;
      o.textContent = `${r.target_column}` + (r.load_type !== "UNSPECIFIED" ? `  [${r.load_type}]` : "");
      colSelect.appendChild(o);
    }
  };

  const render = () => {
    const tbl = tableSelect.value;
    const key = colSelect.value;
    const row = (byTable.get(tbl) ?? []).find((r) => `${r.target_table}::${r.target_column}::${r.load_type}` === key);
    detailHost.replaceChildren();
    if (!row) return;
    renderRowDetail(detailHost, row, linByCol.get(`${row.target_table}::${row.target_column}`));
  };

  tableSelect.addEventListener("change", () => {
    repopulateColumns(tableSelect.value);
    render();
  });
  colSelect.addEventListener("change", render);

  tableSelect.value = tables[0];
  repopulateColumns(tables[0]);
  render();
}

// ── Detail panel ────────────────────────────────────────────────────────

function renderRowDetail(host, row, lineageRow) {
  // Summary card
  const right = document.createElement("div");
  right.style.display = "flex";
  right.style.gap = "0.5rem";
  if (row.load_type && row.load_type !== "UNSPECIFIED") right.appendChild(pill(row.load_type));
  right.appendChild(pill(row.expression_type || "Direct"));

  const summary = card({
    title: `${row.target_table}.${row.target_column}`,
    subtitle: row.business_logic_expression ?? "(direct passthrough)",
    right,
  });

  const stats = document.createElement("div");
  stats.style.display = "grid";
  stats.style.gridTemplateColumns = "repeat(auto-fit, minmax(140px, 1fr))";
  stats.style.gap = "1rem";
  stats.appendChild(stat("Source",
    row.source_table ? (row.source_column ? `${row.source_table}.${row.source_column}` : row.source_table) : "—"));
  stats.appendChild(stat("Source datatype",
    row.source_datatype ? typeStr(row.source_datatype, row.source_precision, row.source_scale) : "—"));
  stats.appendChild(stat("Target datatype",
    row.target_datatype ? typeStr(row.target_datatype, row.target_precision, row.target_scale) : "—"));
  if (row.lookup_used) stats.appendChild(stat("Lookup", row.lookup_used));
  if (row.joiners_used) stats.appendChild(stat("Joiners", row.joiners_used));
  if (row.routers_used) stats.appendChild(stat("Routers", row.routers_used));
  if (row.aggregators_used) stats.appendChild(stat("Aggregators", row.aggregators_used));
  summary.body.appendChild(stats);
  host.appendChild(summary);

  // Steps card — show the transformation path as a numbered vertical list.
  const stepsCard = card({ title: "Transformation path (Step-by-step)" });
  const path = (row.transformation_path || "").split(" → ").filter(Boolean);
  if (path.length === 0) {
    stepsCard.body.appendChild(emptyText("No transformation steps captured."));
  } else {
    const list = document.createElement("ol");
    list.style.margin = "0";
    list.style.padding = "0 0 0 1.25rem";
    list.style.display = "grid";
    list.style.gap = "0.25rem";
    list.style.fontSize = "13px";
    list.style.fontFamily = "var(--font-mono)";
    for (const step of path) {
      const li = document.createElement("li");
      li.textContent = step;
      list.appendChild(li);
    }
    stepsCard.body.appendChild(list);
  }
  host.appendChild(stepsCard);

  // Expression chain (if present)
  if (row.expression_chain) {
    const chainCard = card({ title: "Expression chain" });
    const pre = document.createElement("pre");
    pre.style.margin = "0";
    pre.style.fontFamily = "var(--font-mono)";
    pre.style.fontSize = "12px";
    pre.style.whiteSpace = "pre-wrap";
    pre.style.wordBreak = "break-word";
    pre.textContent = row.expression_chain.split(" || ").join("\n");
    chainCard.body.appendChild(pre);
    host.appendChild(chainCard);
  }

  // Notes + walk-end info
  if (row.notes || (lineageRow && (lineageRow.lastInstance || lineageRow.lastField))) {
    const meta = card({ title: "Lineage walk notes" });
    const kvRows = [];
    if (lineageRow?.lastInstance) kvRows.push({ name: "Walk ended at instance", value: lineageRow.lastInstance });
    if (lineageRow?.lastField) kvRows.push({ name: "Walk ended at field", value: lineageRow.lastField });
    if (row.notes) kvRows.push({ name: "Notes", value: row.notes });
    if (row.error_logic) kvRows.push({ name: "Error logic", value: row.error_logic });
    if (row.router_condition) kvRows.push({ name: "Router condition", value: row.router_condition });
    if (row.default_logic) kvRows.push({ name: "Default logic", value: row.default_logic });
    meta.body.appendChild(keyValueTable(kvRows, "No notes."));
    host.appendChild(meta);
  }
}

function typeStr(dt, prec, scale) {
  if (!dt) return "";
  if (prec) {
    if (scale && scale !== "0") return `${dt}(${prec},${scale})`;
    return `${dt}(${prec})`;
  }
  return dt;
}

function emptyText(t) {
  const p = document.createElement("p");
  p.style.color = "var(--ink-500)";
  p.style.fontSize = "13px";
  p.textContent = t;
  return p;
}
