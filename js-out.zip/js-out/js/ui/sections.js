/**
 * sections.js — per-section render functions for SessionView.
 *
 * Mirrors the section render bodies in components/SessionView.tsx:
 *   - renderS2T            (the 6-column "Source → Target" condensed view)
 *   - renderSourceSqlPanel (collapsible card per SQ / Lookup with SQL)
 *   - renderAttributes     (grouped attribute KV tables)
 *   - renderConnections    (table)
 *   - renderInstanceOverrides
 *   - renderExtensions
 *   - renderParameters     (KV table only)
 *   - renderSources / renderTargets (SourceTargetBlock per def)
 *   - renderTransformations / renderLookups (TransformationBlock per def)
 *   - renderConnectors (table)
 *   - renderComposition
 *   - renderWorkflows
 *   - renderConfigs
 *
 * Phase 1 scope. Validation / Mapping Inspector / Lineage Tracer / Raw XML
 * / Lineage Graph land in later phases.
 *
 * SECURITY: textContent only; no innerHTML.
 */

import { buildMappingJson } from "../lib/build-mapping-json.js";
import { card, pill, keyValueTable } from "./primitives.js";
import { GROUP_ORDER, groupAttributes } from "../lib/mapping-schema.js";

// ── Source → Target (S2T) ───────────────────────────────────────────────

/**
 * Render the 6-column condensed Source → Target view that the original
 * Source → Target tab shows. Columns:
 *   Target | Source | Load | Expression / logic | Path | Router / Notes
 *
 * @param {HTMLElement} container
 * @param {import("../lib/mapping-schema.js").ParsedSession} session
 */
export function renderS2T(container, session) {
  const rows = buildMappingJson(session).field_mappings;
  if (rows.length === 0) {
    container.appendChild(emptyParagraph(
      "No lineage available (mapping not present or no target columns).",
    ));
    return;
  }
  const wrap = document.createElement("div");
  wrap.className = "plain-table-wrap";
  const table = document.createElement("table");
  table.className = "plain-table";

  table.appendChild(buildThead(["Target", "Source", "Load", "Expression / logic", "Path", "Router / Notes"]));

  const tbody = document.createElement("tbody");
  for (const r of rows) {
    const tr = document.createElement("tr");

    // Target — table (bold) + column (mono)
    {
      const td = document.createElement("td");
      const top = document.createElement("div");
      top.className = "cell-bold";
      top.textContent = r.target_table;
      const sub = document.createElement("div");
      sub.className = "cell-mono";
      sub.textContent = r.target_column;
      td.appendChild(top);
      td.appendChild(sub);
      tr.appendChild(td);
    }

    // Source — table + column. Computed/unresolved values render in rose.
    {
      const td = document.createElement("td");
      const srcTable = r.source_table || "";
      const computed = srcTable.startsWith("(") && !srcTable.startsWith("(lookup ");
      const top = document.createElement("div");
      top.className = computed ? "s2t-source--computed" : "cell-bold";
      top.textContent = srcTable || "—";
      td.appendChild(top);
      if (r.source_column) {
        const sub = document.createElement("div");
        sub.className = "cell-mono";
        sub.textContent = r.source_column;
        td.appendChild(sub);
      }
      tr.appendChild(td);
    }

    // Load
    {
      const td = document.createElement("td");
      td.className = "cell-muted";
      td.textContent = r.load_type && r.load_type !== "UNSPECIFIED" ? r.load_type : "—";
      tr.appendChild(td);
    }

    // Expression / logic
    {
      const td = document.createElement("td");
      td.className = "cell-mono col-medium";
      if (r.business_logic_expression) {
        td.textContent = r.business_logic_expression;
      } else {
        td.classList.add("cell-dim");
        td.textContent = "—";
      }
      tr.appendChild(td);
    }

    // Path
    {
      const td = document.createElement("td");
      td.className = "cell-muted col-narrow";
      td.textContent = r.transformation_path || "—";
      tr.appendChild(td);
    }

    // Router / Notes
    {
      const td = document.createElement("td");
      td.className = "cell-muted col-narrow";
      if (r.router_condition) {
        const div = document.createElement("div");
        div.className = "cell-mono";
        div.textContent = r.router_condition;
        td.appendChild(div);
      }
      if (r.notes) {
        const div = document.createElement("div");
        div.className = "cell-muted";
        div.style.marginTop = "2px";
        div.textContent = r.notes;
        td.appendChild(div);
      }
      if (!r.router_condition && !r.notes) td.textContent = "—";
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  container.appendChild(wrap);
}

// ── Source SQL panel ────────────────────────────────────────────────────

export function renderSourceSqlPanel(container, session) {
  const rows = buildMappingJson(session).source_sql;
  if (rows.length === 0) {
    container.appendChild(emptyParagraph(
      "No SQL-bearing transformations (Source Qualifier / Lookup / etc.) in this mapping.",
    ));
    return;
  }
  for (const sq of rows) {
    const filled = sq.sql_entries.filter((e) => e.value.trim().length > 0);
    const labelOnly = sq.sql_entries.filter((e) => e.value.trim().length === 0);

    const subtitleParts = [
      sq.transformation_type || null,
      sq.source_definition ? `Source: ${sq.source_definition}` : null,
      sq.connection
        ? `Connection: ${sq.connection}${sq.connection_type ? ` (${sq.connection_type})` : ""}`
        : null,
    ].filter(Boolean);

    const right = document.createElement("div");
    right.style.display = "flex";
    right.style.gap = "0.5rem";
    right.appendChild(
      pill(sq.has_sql ? `${filled.length} SQL${filled.length === 1 ? "" : "s"}` : "No SQL value",
           sq.has_sql ? "ok" : "default"),
    );
    if (sq.source_tables) right.appendChild(pill(`FROM: ${sq.source_tables}`));

    const c = card({
      title: sq.transformation,
      subtitle: subtitleParts.join(" · ") || undefined,
      right,
    });

    if (filled.length > 0) {
      const grid = document.createElement("div");
      grid.style.display = "grid";
      grid.style.gap = "0.75rem";
      for (const e of filled) {
        const wrap = document.createElement("div");
        const h = document.createElement("div");
        h.className = "block__subheading";
        h.textContent = e.label;
        wrap.appendChild(h);
        wrap.appendChild(sqlBlock(e.value));
        grid.appendChild(wrap);
      }
      if (labelOnly.length > 0) {
        const note = document.createElement("div");
        note.style.fontSize = "12px";
        note.style.color = "var(--ink-500)";
        note.textContent = "Also declared (empty value): " + labelOnly.map((e) => e.label).join(", ");
        grid.appendChild(note);
      }
      c.body.appendChild(grid);
    } else if (labelOnly.length > 0) {
      c.body.appendChild(emptyParagraph(
        "Attributes declared but all values empty: " + labelOnly.map((e) => e.label).join(", "),
      ));
    } else {
      c.body.appendChild(emptyParagraph("No SQL-bearing attributes on this transformation."));
    }
    container.appendChild(c);
  }
}

/**
 * Plain monospace SQL block (placeholder — Phase 3 may replace with the
 * full SqlBlock component that has copy-to-clipboard).
 */
function sqlBlock(sql) {
  const pre = document.createElement("pre");
  pre.style.fontFamily = "var(--font-mono)";
  pre.style.fontSize = "12px";
  pre.style.background = "var(--ink-50)";
  pre.style.padding = "0.75rem";
  pre.style.borderRadius = "var(--radius-md)";
  pre.style.border = "1px solid var(--ink-100)";
  pre.style.overflowX = "auto";
  pre.style.margin = "0";
  pre.style.whiteSpace = "pre-wrap";
  pre.style.wordBreak = "break-word";
  pre.textContent = sql;
  return pre;
}

// ── Attributes (grouped) ────────────────────────────────────────────────

export function renderAttributes(container, session) {
  if (session.attributes.length === 0) {
    container.appendChild(emptyParagraph("No attributes."));
    return;
  }
  const groups = groupAttributes(session.attributes);
  const grid = document.createElement("div");
  grid.className = "attributes-grid";
  for (const g of GROUP_ORDER) {
    const rows = groups[g];
    if (!rows || rows.length === 0) continue;
    const block = document.createElement("div");
    const h = document.createElement("h3");
    h.className = "attributes-group__title";
    h.textContent = g;
    block.appendChild(h);
    block.appendChild(keyValueTable(rows));
    grid.appendChild(block);
  }
  container.appendChild(grid);
}

// ── Connections table ───────────────────────────────────────────────────

export function renderConnections(container, session) {
  const refs = session.connectionRefs;
  if (refs.length === 0) {
    container.appendChild(emptyParagraph("No connection references on this session."));
    return;
  }
  const wrap = document.createElement("div");
  wrap.className = "plain-table-wrap";
  const table = document.createElement("table");
  table.className = "plain-table";
  table.appendChild(buildThead(["Instance", "Instance type", "Connection", "Type", "Subtype", "Variable"]));
  const tbody = document.createElement("tbody");
  for (const c of refs) {
    const tr = document.createElement("tr");
    appendCell(tr, c.instanceName || "—", "cell-bold");
    appendCell(tr, c.instanceType || "—", "cell-muted");
    appendCell(tr, c.connectionName || "—", "cell-mono");
    const td = document.createElement("td");
    td.appendChild(pill(c.connectionType || "—"));
    tr.appendChild(td);
    appendCell(tr, c.connectionSubtype || "—", "cell-muted");
    appendCell(tr, c.variable || "—", "cell-mono cell-muted");
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  container.appendChild(wrap);
}

// ── Parameters (plain KV table) ─────────────────────────────────────────

export function renderParameters(container, session) {
  container.appendChild(keyValueTable(session.parameters, "No parameters."));
}

// ── Instance overrides (collapsible blocks) ─────────────────────────────

export function renderInstanceOverrides(container, session) {
  if (session.transformationInstances.length === 0) {
    container.appendChild(emptyParagraph("No instance overrides."));
    return;
  }
  const grid = document.createElement("div");
  grid.style.display = "grid";
  grid.style.gap = "0.75rem";
  for (const t of session.transformationInstances) {
    const right = document.createElement("div");
    right.className = "block__meta";
    right.appendChild(pill(t.type || "—"));
    const ct = document.createElement("span");
    ct.className = "block__meta-text";
    ct.textContent = `${t.attributes.length} attrs`;
    right.appendChild(ct);
    const det = collapsibleBlock(t.name || "(unnamed)", t.description, right);
    det.body.appendChild(keyValueTable(t.attributes, "No overrides on this instance."));
    grid.appendChild(det);
  }
  container.appendChild(grid);
}

// ── Session extensions (collapsible blocks) ─────────────────────────────

export function renderExtensions(container, session) {
  if (session.extensions.length === 0) {
    container.appendChild(emptyParagraph("No session extensions."));
    return;
  }
  const grid = document.createElement("div");
  grid.style.display = "grid";
  grid.style.gap = "0.75rem";
  for (const e of session.extensions) {
    const right = document.createElement("div");
    right.className = "block__meta";
    right.appendChild(pill(e.type || "—"));
    if (e.subtype) right.appendChild(pill(e.subtype));
    const ct = document.createElement("span");
    ct.className = "block__meta-text";
    ct.textContent = `${e.attributes.length} attrs`;
    right.appendChild(ct);
    const det = collapsibleBlock(e.name || "(unnamed)", undefined, right);
    det.body.appendChild(keyValueTable(e.attributes));
    grid.appendChild(det);
  }
  container.appendChild(grid);
}

// ── Sources / Targets / Transformations / Lookups (collapsible blocks) ──

export function renderSources(container, session) {
  return renderSourceTargetList(container, session.mapping?.sources ?? [], "source");
}

export function renderTargets(container, session) {
  return renderSourceTargetList(container, session.mapping?.targets ?? [], "target");
}

function renderSourceTargetList(container, defs, kind) {
  if (defs.length === 0) {
    container.appendChild(emptyParagraph(kind === "source" ? "No sources." : "No targets."));
    return;
  }
  const grid = document.createElement("div");
  grid.style.display = "grid";
  grid.style.gap = "0.75rem";
  for (const def of defs) {
    grid.appendChild(buildSourceTargetBlock(def, kind));
  }
  container.appendChild(grid);
}

function buildSourceTargetBlock(def, kind) {
  const right = document.createElement("div");
  right.className = "block__meta";
  if (def.databaseType) right.appendChild(pill(def.databaseType));
  if (kind === "source" && def.databaseName) right.appendChild(metaText(def.databaseName));
  if (kind === "source" && def.ownerName)   right.appendChild(metaText("/ " + def.ownerName));
  right.appendChild(metaText(`${def.fields.length} fields`));

  const det = collapsibleBlock(def.name, def.description, right);

  if (def.fields.length === 0) {
    det.body.appendChild(emptyParagraph("No fields."));
    return det;
  }

  const wrap = document.createElement("div");
  wrap.className = "plain-table-wrap";
  const table = document.createElement("table");
  table.className = "plain-table";
  table.appendChild(buildThead(["#", "Field", "Type", "Prec/Scale", "Key", "Nullable"]));
  const tbody = document.createElement("tbody");
  def.fields.forEach((f, i) => {
    const tr = document.createElement("tr");
    appendCell(tr, String(f.fieldNumber ?? i + 1), "cell-muted");
    appendCell(tr, f.name, "cell-bold");
    appendCell(tr, f.datatype, "cell-mono");
    const ps = (f.precision ?? "—") + (f.scale && f.scale !== "0" ? `, ${f.scale}` : "");
    appendCell(tr, ps, "cell-mono cell-muted");
    appendCell(tr, f.keyType ?? "—", "cell-muted");
    appendCell(tr, f.nullable ?? "—", "cell-muted");
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  wrap.appendChild(table);
  det.body.appendChild(wrap);
  return det;
}

export function renderTransformations(container, session) {
  const all = (session.mapping?.transformations ?? []).filter((t) => !/lookup/i.test(t.type));
  return renderTransformationList(container, all, "No non-lookup transformations.");
}

export function renderLookups(container, session) {
  const all = (session.mapping?.transformations ?? []).filter((t) => /lookup/i.test(t.type));
  return renderTransformationList(container, all, "No lookups.");
}

function renderTransformationList(container, defs, emptyMessage) {
  if (defs.length === 0) {
    container.appendChild(emptyParagraph(emptyMessage));
    return;
  }
  const grid = document.createElement("div");
  grid.style.display = "grid";
  grid.style.gap = "0.75rem";
  for (const def of defs) grid.appendChild(buildTransformationBlock(def));
  container.appendChild(grid);
}

function buildTransformationBlock(def) {
  const sqlAttr = def.tableAttributes.find((a) => /^(sql query|lookup sql override)$/i.test(a.name));
  const right = document.createElement("div");
  right.className = "block__meta";
  right.appendChild(pill(def.type));
  if (def.reusable === "YES") right.appendChild(pill("reusable", "ok"));
  right.appendChild(metaText(`${def.fields.length} ports · ${def.tableAttributes.length} attrs`));

  const det = collapsibleBlock(def.name, def.description, right);

  if (sqlAttr) {
    const h = document.createElement("h4");
    h.className = "block__subheading";
    h.textContent = sqlAttr.name;
    det.body.appendChild(h);
    det.body.appendChild(sqlBlock(sqlAttr.value));
  }

  const restAttrs = def.tableAttributes.filter((a) => a !== sqlAttr);
  if (restAttrs.length > 0) {
    const h = document.createElement("h4");
    h.className = "block__subheading";
    h.textContent = "Settings (TABLEATTRIBUTE)";
    det.body.appendChild(h);
    det.body.appendChild(keyValueTable(restAttrs));
  }

  if (def.fields.length > 0) {
    const h = document.createElement("h4");
    h.className = "block__subheading";
    h.textContent = "Ports";
    det.body.appendChild(h);
    const wrap = document.createElement("div");
    wrap.className = "plain-table-wrap";
    const table = document.createElement("table");
    table.className = "plain-table";
    table.appendChild(buildThead(["Port", "Direction", "Type", "P/S", "Expression"]));
    const tbody = document.createElement("tbody");
    for (const f of def.fields) {
      const tr = document.createElement("tr");
      appendCell(tr, f.name, "cell-bold");
      appendCell(tr, f.portType, "cell-muted");
      appendCell(tr, f.datatype, "cell-mono");
      const ps = (f.precision ?? "—") + (f.scale && f.scale !== "0" ? `, ${f.scale}` : "");
      appendCell(tr, ps, "cell-mono cell-muted");
      const td = document.createElement("td");
      td.className = "cell-mono col-medium";
      if (f.expression) td.textContent = f.expression;
      else { td.classList.add("cell-dim"); td.textContent = "—"; }
      tr.appendChild(td);
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    wrap.appendChild(table);
    det.body.appendChild(wrap);
  }

  if (def.metadataExtensions.length > 0) {
    const h = document.createElement("h4");
    h.className = "block__subheading";
    h.textContent = "Metadata extensions";
    det.body.appendChild(h);
    det.body.appendChild(keyValueTable(def.metadataExtensions));
  }

  return det;
}

// ── Connectors table ────────────────────────────────────────────────────

export function renderConnectors(container, session) {
  const list = session.mapping?.connectors ?? [];
  if (list.length === 0) {
    container.appendChild(emptyParagraph("No connectors."));
    return;
  }
  const wrap = document.createElement("div");
  wrap.className = "plain-table-wrap";
  wrap.style.maxHeight = "600px";
  wrap.style.overflowY = "auto";
  const table = document.createElement("table");
  table.className = "plain-table";
  table.appendChild(buildThead(["From instance", "From field", "", "To instance", "To field"]));
  const tbody = document.createElement("tbody");
  for (const c of list) {
    const tr = document.createElement("tr");
    appendCell(tr, c.fromInstance, "cell-bold");
    appendCell(tr, c.fromField, "cell-mono");
    appendCell(tr, "→", "cell-dim");
    appendCell(tr, c.toInstance, "cell-bold");
    appendCell(tr, c.toField, "cell-mono");
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);
  wrap.appendChild(table);
  container.appendChild(wrap);
}

// ── Composition (instances + mapplets quick listing) ────────────────────

export function renderComposition(container, session) {
  const m = session.mapping;
  if (!m) {
    container.appendChild(emptyParagraph("No mapping."));
    return;
  }
  if (m.instances.length === 0 && m.mapplets.length === 0) {
    container.appendChild(emptyParagraph("No instances or mapplets."));
    return;
  }
  if (m.instances.length > 0) {
    const c = card({ title: `Instances (${m.instances.length})` });
    const rows = m.instances.map((i) => ({
      name: i.name,
      value: [i.type, i.transformationName ? `→ ${i.transformationName}` : null]
        .filter(Boolean)
        .join("  ·  "),
    }));
    c.body.appendChild(keyValueTable(rows));
    container.appendChild(c);
  }
  if (m.mapplets.length > 0) {
    const c = card({ title: `Mapplets (${m.mapplets.length})` });
    const rows = m.mapplets.map((mp) => ({
      name: mp.name,
      value: `${mp.transformationCount} transformations · ${mp.instanceCount} instances`,
    }));
    c.body.appendChild(keyValueTable(rows));
    container.appendChild(c);
  }
}

// ── Workflows ───────────────────────────────────────────────────────────

export function renderWorkflows(container, session) {
  if (session.workflows.length === 0) {
    container.appendChild(emptyParagraph("No workflows."));
    return;
  }
  const grid = document.createElement("div");
  grid.style.display = "grid";
  grid.style.gap = "0.75rem";
  for (const w of session.workflows) {
    const right = document.createElement("div");
    right.className = "block__meta";
    if (w.isValid) right.appendChild(pill(`Valid: ${w.isValid}`, w.isValid === "YES" ? "ok" : "warn"));
    if (w.isEnabled) right.appendChild(pill(`Enabled: ${w.isEnabled}`));
    if (w.schedulerName) right.appendChild(metaText(`scheduler: ${w.schedulerName}`));

    const det = collapsibleBlock(w.name, w.description, right);

    if (w.tasks.length > 0) {
      const h = document.createElement("h4");
      h.className = "block__subheading";
      h.textContent = `Tasks (${w.tasks.length})`;
      det.body.appendChild(h);
      const rows = w.tasks.map((t) => ({
        name: t.name,
        value: `${t.taskType}${t.taskName ? ` → ${t.taskName}` : ""}`,
      }));
      det.body.appendChild(keyValueTable(rows));
    }
    if (w.links.length > 0) {
      const h = document.createElement("h4");
      h.className = "block__subheading";
      h.textContent = `Links (${w.links.length})`;
      det.body.appendChild(h);
      const rows = w.links.map((l) => ({
        name: `${l.fromTask} → ${l.toTask}`,
        value: l.condition ?? "—",
      }));
      det.body.appendChild(keyValueTable(rows));
    }
    if (w.attributes.length > 0) {
      const h = document.createElement("h4");
      h.className = "block__subheading";
      h.textContent = "Attributes";
      det.body.appendChild(h);
      det.body.appendChild(keyValueTable(w.attributes));
    }
    grid.appendChild(det);
  }
  container.appendChild(grid);
}

// ── Configs ─────────────────────────────────────────────────────────────

export function renderConfigs(container, session) {
  if (session.configs.length === 0) {
    container.appendChild(emptyParagraph("No configs."));
    return;
  }
  const grid = document.createElement("div");
  grid.style.display = "grid";
  grid.style.gap = "0.75rem";
  for (const cfg of session.configs) {
    const right = document.createElement("div");
    right.className = "block__meta";
    right.appendChild(metaText(`${cfg.attributes.length} attrs`));
    const det = collapsibleBlock(cfg.name, cfg.description, right);
    det.body.appendChild(keyValueTable(cfg.attributes, "No attributes."));
    grid.appendChild(det);
  }
  container.appendChild(grid);
}

// ── Shared helpers ──────────────────────────────────────────────────────

/**
 * Build a <thead><tr><th>…</th></tr></thead> with text labels only.
 */
function buildThead(labels) {
  const thead = document.createElement("thead");
  const tr = document.createElement("tr");
  for (const l of labels) {
    const th = document.createElement("th");
    th.textContent = l;
    tr.appendChild(th);
  }
  thead.appendChild(tr);
  return thead;
}

function appendCell(tr, text, className) {
  const td = document.createElement("td");
  if (className) td.className = className;
  td.textContent = text;
  tr.appendChild(td);
  return td;
}

function metaText(text) {
  const span = document.createElement("span");
  span.className = "block__meta-text";
  span.textContent = text;
  return span;
}

function emptyParagraph(text) {
  const p = document.createElement("p");
  p.style.fontSize = "13px";
  p.style.color = "var(--ink-500)";
  p.textContent = text;
  return p;
}

/**
 * Build a <details> block (collapsible) with a summary + body. Returns an
 * object { root, body } so callers can append into body directly.
 */
function collapsibleBlock(title, description, right) {
  const details = document.createElement("details");
  details.className = "block";

  const summary = document.createElement("summary");
  summary.className = "block__summary";

  const titleBlock = document.createElement("div");
  const t = document.createElement("div");
  t.className = "block__title";
  t.textContent = title;
  titleBlock.appendChild(t);
  if (description) {
    const d = document.createElement("div");
    d.className = "block__sub";
    d.textContent = description;
    titleBlock.appendChild(d);
  }
  summary.appendChild(titleBlock);
  if (right) summary.appendChild(right);
  details.appendChild(summary);

  const body = document.createElement("div");
  body.className = "block__body";
  details.appendChild(body);
  details.body = body;
  return details;
}
