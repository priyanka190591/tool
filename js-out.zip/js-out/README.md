# Session Dashboard — Vanilla Static Build

Framework-free re-implementation of the Session Dashboard. Pure HTML / CSS /
ES6 modules. No Node.js, no npm, no build step. Runs on any minimal web
server that returns directory listings (or where you maintain a JSON
manifest of XML files yourself).

---

## Quick start

Use the existing `serve.ps1` you already have (the one bundled with the
Next.js build under `out/serve.ps1`). Point it at this folder and open
the printed URL in a browser:

```powershell
cd js-out
..\out\serve.ps1
# → http://localhost:8080  (default port)
# → http://localhost:9090  if you pass -Port 9090
```

Or copy `serve.ps1` into `js-out/` so it lives next to `index.html`:

```powershell
Copy-Item ..\out\serve.ps1 .
.\serve.ps1
```

### Other servers

`app.js` discovers XML files via either:

1. `GET /sessions/index.json` returning `{"files": ["s_FOO.xml", …]}`, or
2. `GET /sessions/` returning **either** the same JSON shape **or** an HTML
   directory index containing `<a href="…xml">` links.

The bundled `serve.ps1` does option 2 (HTML index) — it works as-is. So do
most other generic static servers (Apache + `Indexes`, nginx + `autoindex
on`, IIS with directory browsing enabled).

If your server cannot list directories, hand-maintain
`sessions/index.json`:

```json
{ "files": ["s_FOO.xml", "s_BAR.xml"] }
```

---

## Folder layout

```
js-out/
├── index.html                  # Entry page (minimal HTML shell)
├── README.md                   # This file
├── css/
│   ├── base.css                # Reset, root variables, layout primitives
│   ├── components.css          # Top bar, tabs, buttons, toast, kv-list
│   └── tables.css              # FIELD_MAPPING grid + load-type pill
├── js/
│   ├── app.js                  # Application entry — wires everything together
│   ├── lib/                    # Business logic (no DOM)
│   │   ├── xml-parser.js       # DOMParser wrapper with namespace stripping
│   │   ├── sessions-parser.js  # Parse IDMC session XML → ParsedSession[]
│   │   ├── mapping-schema.js   # JSDoc type definitions + constants
│   │   ├── lineage.js          # Source Table 6-step resolver, lineage walk
│   │   ├── build-mapping-json.js # Canonical MappingJson — feeds every export
│   │   ├── format.js           # NULL helpers, datatype string, csv-escape
│   │   ├── downloads.js        # Save-As helpers (uses <a download>)
│   │   ├── exports-csv.js      # FIELD_MAPPING → CSV
│   │   ├── exports-json.js     # MappingJson → JSON download
│   │   ├── exports-md.js       # MappingJson → Markdown summary
│   │   └── exports-xlsx.js     # MappingJson → multi-sheet XLSX (uses ExcelJS)
│   └── ui/                     # DOM rendering (no business logic)
│       ├── session-list.js     # Left pane — list of sessions
│       ├── session-view.js     # Right pane — header + tabs + active content
│       ├── tabs.js             # Tab bar with badge counts
│       ├── field-mapping-table.js # FIELD_MAPPING grid renderer
│       ├── simple-table.js     # Generic header+rows table (for sub-sheets)
│       ├── kv-list.js          # Key/value section list (overall/session details)
│       └── export-buttons.js   # XLSX / CSV / JSON / Markdown buttons
├── vendor/
│   └── exceljs.min.js          # ExcelJS UMD bundle (bundled, ~948 KB)
└── sessions/
    └── *.xml                   # Drop your IDMC session XML files here
```

---

## What does and does NOT carry over from the Next.js build

### Included (parity with the Next.js FIELD_MAPPING)

- Source Table 6-step resolver, including the recent fixes:
  - `DUMMY_/SQ_` wrapper exclusion
  - `ISourceNode*` / `ILookupNode*` synthetic-node exclusion (so multi-source
    cells no longer leak `"real_table, ISourceNode18"`)
- **Load Type** column (INSERT / UPDATE / DELETE / REJECT / DATA DRIVEN /
  UNSPECIFIED) derived from update-strategy expressions and target options
- **Raw Expression (XML)** column removed from XLSX / CSV (matches latest)
- Multi-source merge separator convention (`, ` between tables, `; ` between
  per-table column groups, `/` within a group)
- Lookup output-port resolution → lookup table name
- Connections lookup (Source Database / Target Database columns)
- Source SQL sheet (SQ + Lookup SQL extracted with FROM/JOIN parsing)
- Lookups, Transformations, Session Details, Overall details, Connections sheets

### Simplified vs. the Next.js build

- Expression port-walking handles direct identifiers and simple `IIF`/
  function arguments. Deeply nested expression trees and some passthrough
  chains may resolve to `(computed)` here where the TS build resolved to a
  specific source. These show up as `(unresolved at <instance>)` rows.
- Lookup SQL Override FROM-table extraction uses a single-pass regex
  (subqueries / CTEs may produce fewer tables than the TS build).
- No expression-style chain trace beyond the first hop.

### Not included

- Lineage graph (D3 visualization)
- Diff view
- Search page
- Validation panel
- Raw XML inspector

If any of those matter for your workflow, keep using the Next.js build in
`../out/` — it has them. This vanilla build is for environments where you
need everything in one read-only folder with no Node footprint.

---

## How to add / remove sessions

Drop new `.xml` files into `js-out/sessions/`. Hard-refresh the browser
(Ctrl/Cmd-Shift-R). The bundled `serve.py` / `serve.ps1` re-list the
directory on every request, so new files show up immediately.

If you're using a host that cannot list directories, also update
`sessions/index.json`:

```json
{ "files": ["s_FOO.xml", "s_BAR.xml"] }
```

---

## Browser support

Anything that supports ES Modules natively:

- Chrome / Edge ≥ 63
- Firefox ≥ 60
- Safari ≥ 11

(Released 2018 or later. No IE.)

---

## Debugging tips

1. Open DevTools → Network tab and reload. If a `.js` file shows
   Content-Type `application/octet-stream`, your server doesn't know about
   the `.js` extension — use the bundled `serve.py` / `serve.ps1` or fix
   your host's MIME map.
2. Open DevTools → Console. The app logs every load + parse step.
3. If the left pane stays on "Loading sessions…", check that
   `/sessions/` returns either a JSON object with `files: [...]` or an
   HTML page that contains `href="something.xml"` lines.
4. To inspect what's behind an export, run this in the Console after
   selecting a session:

   ```js
   import('./js/lib/build-mapping-json.js').then(m =>
     console.log(m.buildMappingJson(window.__lastSession))
   );
   ```

---

## License / attribution

ExcelJS (vendor/exceljs.min.js) is MIT-licensed; see
[github.com/exceljs/exceljs](https://github.com/exceljs/exceljs).
