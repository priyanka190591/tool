# Session Dashboard — Vanilla Static Build

Framework-free re-implementation of the Session Dashboard. Pure HTML / CSS /
ES6 modules. No Node.js, no npm, no build step. Runs on any minimal web
server that returns directory listings (or where you maintain a JSON
manifest of XML files yourself).

---

## Quick start

Use your existing `serve.ps1`. Point it at this folder and open the
printed URL in a browser:

```powershell
cd js-out
..\out\serve.ps1
```

Or copy the script in so it lives beside `index.html`:

```powershell
Copy-Item ..\out\serve.ps1 .
.\serve.ps1
```

Then visit:

| Page | URL |
|---|---|
| Main dashboard | `http://localhost:8080/index.html` |
| Diff | `http://localhost:8080/diff/index.html` |
| Search | `http://localhost:8080/search/index.html` |

### Other servers

`app.js` discovers XML files via either:

1. `GET /sessions/index.json` returning `{"files": ["s_FOO.xml", …]}`, or
2. `GET /sessions/` returning **either** the same JSON shape **or** an HTML
   directory index containing `<a href="…xml">` links.

Most generic static servers do option 2 out of the box (Apache + `Indexes`,
nginx + `autoindex on`, IIS with directory browsing enabled).

If your server cannot list directories, hand-maintain
`sessions/index.json`:

```json
{ "files": ["s_FOO.xml", "s_BAR.xml"] }
```

---

## Folder layout

```
js-out/
├── index.html                  # Main dashboard entry
├── README.md                   # This file
├── css/
│   ├── tokens.css              # Design tokens (ink palette, radii, fonts, sizes)
│   ├── base.css                # Reset + page-level layout shell
│   ├── components.css          # Top bar / picker / sidebar / Card / Pill / Stat / etc.
│   └── tables.css              # FIELD_MAPPING + sub-sheet grids
├── js/
│   ├── app.js                  # Main dashboard entry — wires everything together
│   ├── lib/                    # Business logic (no DOM)
│   │   ├── xml-parser.js           # DOMParser wrapper
│   │   ├── sessions-parser.js      # IDMC XML → ParsedSession[]
│   │   ├── mapping-schema.js       # JSDoc types + constants + attribute grouping
│   │   ├── lineage.js              # FULL-FIDELITY port of the TS lineage walker
│   │   ├── build-mapping-json.js   # Canonical MappingJson (powers every export)
│   │   ├── validation.js           # Validation rules (port of lib/validation.ts)
│   │   ├── diff.js                 # Two-session diff (port of lib/diff.ts)
│   │   ├── search-index.js         # In-memory cross-session search
│   │   ├── session-loader.js       # Shared /sessions/ discovery helper
│   │   ├── format.js               # NULL helpers, csv-escape, datatype string
│   │   ├── downloads.js            # Save-As helpers (uses <a download>)
│   │   ├── exports-csv.js          # FIELD_MAPPING → CSV
│   │   ├── exports-json.js         # MappingJson → JSON download
│   │   ├── exports-md.js           # MappingJson → Markdown summary
│   │   └── exports-xlsx.js         # MappingJson → multi-sheet XLSX (uses ExcelJS)
│   ├── ui/                     # DOM rendering (no business logic)
│   │   ├── primitives.js           # card() / pill() / stat() / keyValueTable() / icon()
│   │   ├── top-bar.js              # Header search + Diff + Download-all
│   │   ├── session-picker.js       # Top-of-page session selector dropdown
│   │   ├── session-sidebar.js      # 240px section navigation
│   │   ├── session-view.js         # Right-hand pane composition (sidebar + main)
│   │   ├── sections.js             # Per-section render bodies (S2T, Source SQL, etc.)
│   │   ├── validation-panel.js     # Validation issues grouped by severity
│   │   ├── unresolved-diagnostics.js  # Mapping Inspector
│   │   ├── lineage-tracer.js       # Pick-a-column tracer
│   │   ├── lineage-graph.js        # SVG-rendered layered lineage graph
│   │   ├── raw-xml-inspector.js    # Line-numbered XML viewer with filter
│   │   └── export-buttons.js       # XLSX / CSV / JSON / MD button group
│   └── pages/                  # Sub-page entry scripts
│       ├── diff-page.js            # /diff/index.html
│       └── search-page.js          # /search/index.html
├── vendor/
│   └── exceljs.min.js          # ExcelJS UMD bundle (bundled, ~948 KB)
├── diff/
│   └── index.html              # Diff page shell
├── search/
│   └── index.html              # Search page shell
└── sessions/
    └── *.xml                   # Drop your IDMC session XML files here
```

---

## What's included

**Sections (sidebar order):**

- **Summary** — Overview / Validation / Source → Target / Lineage Tracer /
  Mapping Inspector / Source SQL
- **Session** — Attributes (grouped) / Connections / Instance Overrides /
  Session Extensions / Parameters
- **Mapping** — Sources / Targets / Transformations / Lookups / Lineage
  Graph / Connectors / Composition
- **Workflow & Reference** — Workflows / Configs / Raw XML

**Pages:**

- `/index.html` — Main dashboard with all of the above
- `/diff/index.html` — Two-session diff across attributes / parameters /
  connections / expressions / lookups / SQL / columns / connectors
- `/search/index.html` — Cross-session substring search

**Exports** (all formats from the Overview header):

- **XLSX** — 7-sheet workbook (Overall details / FIELD_MAPPING / LOOKUPS /
  TRANSFORMATIONS / Source SQL / Connections / Session Details)
- **CSV** — FIELD_MAPPING with identical column order to the XLSX
- **JSON** — MappingJson + session metadata
- **Markdown** — Field mappings table + lookups + transformations

**Recent fixes preserved:**

- Source Table 6-step resolver with `DUMMY_/SQ_` wrapper exclusion and
  `ISourceNode*` / `ILookupNode*` synthetic-node exclusion
- Load Type column (XLSX + CSV); Raw Expression (XML) column removed

---

## Simplifications vs. the Next.js build

- **Lineage Graph** uses a custom SVG layered layout instead of React Flow
  + dagre. Layout is fixed (no drag); no minimap; pan/zoom via browser
  Ctrl+scroll only.
- **Mapping Inspector** lists rows + their lineage walk's last instance /
  last field. The interactive per-identifier classification UI from
  the React build is not ported — use the **Lineage Tracer** for a
  per-column drill-down.
- **Raw XML Inspector** does substring filtering (no syntax highlighting).
- No **CopyButton** widget; copy SQL by selecting it.

---

## How to add / remove sessions

Drop new `.xml` files into `js-out/sessions/`. Hard-refresh the browser
(Ctrl/Cmd-Shift-R). The dashboard re-discovers files on every reload.

---

## Browser support

ES Modules required:

- Chrome / Edge ≥ 63
- Firefox ≥ 60
- Safari ≥ 11

(All released 2018 or later.)

---

## Debugging tips

1. Open DevTools → Network. A `.js` file served as
   `application/octet-stream` means your server doesn't know the `.js`
   MIME type — fix the host config or use the bundled `serve.ps1`.
2. Open DevTools → Console. The app logs every load + parse step.
3. After picking a session, you can poke at the parsed data:

   ```js
   console.log(window.__lastSession);
   console.log(window.__lastMapping);
   ```

4. To rebuild MappingJson from console:

   ```js
   import("./js/lib/build-mapping-json.js").then(m =>
     console.log(m.buildMappingJson(window.__lastSession))
   );
   ```

---

## License / attribution

ExcelJS (`vendor/exceljs.min.js`) — MIT, github.com/exceljs/exceljs.
Everything else is hand-written for this project.
