// Parallel vitest config that runs the existing Next.js test suite against
// the vanilla js-out/ runtime. The same tests/*.test.ts files load
// without modification because we remap `@/lib/*` to thin shims under
// tests-jsout-shims/ that re-export from js-out/js/lib/*.js.

import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: {
    alias: {
      // Redirect all `@/lib/*` imports through our shim layer (which then
      // pulls from js-out). The base `@` alias still points at the repo root
      // for any imports that don't hit the shimmed lib/.
      "@/lib": path.resolve(__dirname, "tests-jsout-shims/lib"),
      "@": path.resolve(__dirname, "."),
    },
  },
  test: {
    globals: false,
    include: ["tests/**/*.test.ts"],
    // folder-tree is pure-TypeScript with no js-out counterpart in this
    // release; exclude it from the vanilla suite so the count stays in
    // sync with the actual js-out coverage.
    exclude: ["tests/folder-tree.test.ts", "**/node_modules/**"],
    environment: "node",
    setupFiles: ["tests-jsout-shims/setup.ts"],
  },
});
