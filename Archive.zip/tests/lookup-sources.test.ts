import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildLineage } from "@/lib/lineage";
import { buildMappingJson } from "@/lib/build-mapping-json";
import type { ParsedSession } from "@/lib/sessions-types";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadFirst(file: string): Promise<ParsedSession> {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(path.basename(file), xml)[0];
}

describe("lookup source aggregation", () => {
  it("includes both lookup table and upstream key source for a connected lookup", () => {
    // SRC (X, KEY) → SQ → EXP wires KEY into LKP.IN_KEY; LKP.OUT → TGT.Y
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="KEY" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="string" PRECISION="20" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="KEY" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="LKP" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_KEY" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="string" PRECISION="20"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="DIM_LKP"/>
          <TABLEATTRIBUTE NAME="Lookup condition" VALUE="KEY = IN_KEY"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="LKP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="LKP" TRANSFORMATION_TYPE="Lookup Procedure"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="KEY" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier" TOFIELD="KEY"/>
        <CONNECTOR FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" FROMFIELD="KEY" TOINSTANCE="LKP" TOINSTANCETYPE="Lookup Procedure" TOFIELD="IN_KEY"/>
        <CONNECTOR FROMINSTANCE="LKP" FROMINSTANCETYPE="Lookup Procedure" FROMFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("synthetic.xml", xml)[0];
    const r = buildLineage(s)[0];
    // Tables sorted alphabetically: "DIM_LKP, SRC"
    expect(r.sourceTable).toBe("DIM_LKP, SRC");
    // Column groups joined with "; "; within-group with "/"
    expect(r.sourceColumn).toBe("OUT; KEY");
    expect(r.lookupsUsed).toBe("LKP");
  });

  it("regression: sales fixture REGION_KEY shows DIM_REGION and STG_SALES", async () => {
    const rows = buildLineage(await loadFirst("Sales/s_SALES_DIM_FULL.xml"));
    const r = rows.find((x) => x.targetColumn === "REGION_KEY")!;
    expect(r.sourceTable).toContain("DIM_REGION");
    expect(r.sourceTable).toContain("STG_SALES");
    expect(r.sourceColumn).toContain("REGION_KEY");
    expect(r.sourceColumn).toContain("REGION_CODE");
    // Separator convention — STG_SALES resolves via SQL Override → STAGE.STG_SALES.
    expect(r.sourceTable).toBe("DIM_REGION, STAGE.STG_SALES");
    expect(r.sourceColumn).toBe("REGION_KEY; REGION_CODE");
  });

  it("regression: sales fixture CUSTOMER_KEY shows DIM_CUSTOMER and STG_SALES", async () => {
    const rows = buildLineage(await loadFirst("Sales/s_SALES_DIM_FULL.xml"));
    const r = rows.find((x) => x.targetColumn === "CUSTOMER_KEY")!;
    expect(r.sourceTable).toBe("DIM_CUSTOMER, STAGE.STG_SALES");
    expect(r.sourceColumn).toBe("CUSTOMER_KEY; CUSTOMER_ID");
  });

  it("COMPTIME: lookup-derived rows include both PAY_PERIOD and upstream key source", async () => {
    // Find any row whose path passes through lkp_PAY_PERIOD.
    const rows = buildLineage(await loadFirst("COMPTIME.xml"));
    const lookupRow = rows.find((r) => r.lookupsUsed.includes("lkp_PAY_PERIOD"));
    if (!lookupRow) return; // first session may not include lkp_PAY_PERIOD; tolerate
    expect(lookupRow.sourceTable).toContain("PAY_PERIOD");
    // At least one additional upstream source should be aggregated alongside.
    const tables = lookupRow.sourceTable.split(", ");
    expect(tables.length).toBeGreaterThan(1);
  });

  it("unconnected :LKP.NAME(args) call resolves lookup table + arg sources", () => {
    // EXP_CALL.OUT EXPRESSION ":LKP.LKP_RATES(IN_KEY)" — LKP_RATES is a Lookup
    // transformation defined in the same file. The IN_KEY arg references EXP_CALL.IN
    // which is wired from SRC.X.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC"><SOURCEFIELD NAME="X" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="decimal" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="LKP_RATES" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_KEY" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="RATE" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="decimal" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="DIM_RATES"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_CALL" TYPE="Expression">
          <TRANSFORMFIELD NAME="IN_KEY" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="decimal" PRECISION="10" EXPRESSION=":LKP.LKP_RATES(IN_KEY)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="EXP_CALL" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_CALL"/>
        <INSTANCE NAME="LKP_RATES" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="LKP_RATES"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="EXP_CALL" TOINSTANCETYPE="Expression" TOFIELD="IN_KEY"/>
        <CONNECTOR FROMINSTANCE="EXP_CALL" FROMINSTANCETYPE="Expression" FROMFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("synthetic-unconnected.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceTable).toContain("DIM_RATES");
    expect(r.sourceTable).toContain("SRC");
    expect(r.sourceColumn).toContain("RATE");
    expect(r.sourceColumn).toContain("X");
    expect(r.lookupsUsed).toContain("LKP_RATES");
    // The :LKP. call must survive inlining intact, not be mangled into "(X)"
    expect(r.expression).toContain(":LKP.LKP_RATES");
  });

  it(":LKP.NAME(args) with UNKNOWN lookup definition still records name + traces args back to source", () => {
    // Real-world IDMC pattern: an unconnected lookup whose <TRANSFORMATION>
    // definition lives in a different folder / reusable / mapplet. The :LKP.
    // call references its NAME but our parser can't find the definition. We
    // must still: (1) record the lookup name in lookups_used, (2) trace each
    // arg back to its source via CONNECTORs. Without this, rows whose only
    // upstream is an unknown lookup would show "(computed)" with no source.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="Line">
        <SOURCEFIELD NAME="Id" DATATYPE="string" PRECISION="120" FIELDNUMBER="1"/>
        <SOURCEFIELD NAME="SystemId" DATATYPE="string" PRECISION="20" FIELDNUMBER="2"/>
      </SOURCE>
      <TARGET NAME="risk"><TARGETFIELD NAME="personalumbrellalimit" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_Line" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="Id" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="120"/>
          <TRANSFORMFIELD NAME="SystemId" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="20"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT Id, SystemId FROM Line WHERE CMMContainer = 'Policy'"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_Anchor11" TYPE="Expression">
          <TRANSFORMFIELD NAME="LineId" PORTTYPE="INPUT" DATATYPE="string" PRECISION="120"/>
          <TRANSFORMFIELD NAME="SystemId" PORTTYPE="INPUT" DATATYPE="string" PRECISION="20"/>
          <TRANSFORMFIELD NAME="PersonalUmbrellaLimit" PORTTYPE="OUTPUT" DATATYPE="int4" PRECISION="10" EXPRESSION="TO_INTEGER(:LKP.LKP_LIABILITY_LIMIT(SystemId, LineId, 'PUCov'))"/>
        </TRANSFORMATION>
        <!-- No <TRANSFORMATION NAME="LKP_LIABILITY_LIMIT"> — it's a shared lookup we don't have a def for. -->
        <INSTANCE NAME="Line" TYPE="SOURCE" TRANSFORMATION_NAME="Line"/>
        <INSTANCE NAME="SQ_Line" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_Line" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP_Anchor11" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_Anchor11"/>
        <INSTANCE NAME="risk" TYPE="TARGET" TRANSFORMATION_NAME="risk"/>
        <CONNECTOR FROMINSTANCE="Line" FROMINSTANCETYPE="Source Definition" FROMFIELD="Id" TOINSTANCE="SQ_Line" TOINSTANCETYPE="Source Qualifier" TOFIELD="Id"/>
        <CONNECTOR FROMINSTANCE="Line" FROMINSTANCETYPE="Source Definition" FROMFIELD="SystemId" TOINSTANCE="SQ_Line" TOINSTANCETYPE="Source Qualifier" TOFIELD="SystemId"/>
        <CONNECTOR FROMINSTANCE="SQ_Line" FROMINSTANCETYPE="Source Qualifier" FROMFIELD="Id" TOINSTANCE="EXP_Anchor11" TOINSTANCETYPE="Expression" TOFIELD="LineId"/>
        <CONNECTOR FROMINSTANCE="SQ_Line" FROMINSTANCETYPE="Source Qualifier" FROMFIELD="SystemId" TOINSTANCE="EXP_Anchor11" TOINSTANCETYPE="Expression" TOFIELD="SystemId"/>
        <CONNECTOR FROMINSTANCE="EXP_Anchor11" FROMINSTANCETYPE="Expression" FROMFIELD="PersonalUmbrellaLimit" TOINSTANCE="risk" TOINSTANCETYPE="Target Definition" TOFIELD="personalumbrellalimit"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("unknown-lkp.xml", xml)[0];
    const json = buildMappingJson(s);
    const r = json.field_mappings[0];
    // Lookup name recorded even though we have no <TRANSFORMATION> for it.
    expect(r.lookups_used).toContain("LKP_LIABILITY_LIMIT");
    // Args (SystemId, LineId) traced back to upstream — source must include Line.
    expect(r.source_table).toContain("Line");
    expect(r.source_column).toMatch(/(Id|SystemId)/);
    // Source datatype propagated from one of the resolved args.
    expect(r.source_datatype).not.toBeNull();
    // Source qualifier + SQL Override now captured via arg sub-trace.
    expect(r.source_qualifier).toBe("SQ_Line");
    expect(r.sq_sql_query).toContain("FROM Line");
    // Expression Type recognizes the row as Lookup-derived.
    expect(r.expression_type).toBe("Lookup");
    // The expression preserves the :LKP. call intact.
    expect(r.business_logic_expression).toContain(":LKP.LKP_LIABILITY_LIMIT");
  });

  it("aggregation merges columns when multiple lookup keys come from the same upstream table", () => {
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="A" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/>
        <SOURCEFIELD NAME="B" DATATYPE="string" PRECISION="10" FIELDNUMBER="2"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="LKP" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_A" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="IN_B" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="DIM_LKP"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="LKP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="LKP"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="A" TOINSTANCE="LKP" TOINSTANCETYPE="Lookup Procedure" TOFIELD="IN_A"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="B" TOINSTANCE="LKP" TOINSTANCETYPE="Lookup Procedure" TOFIELD="IN_B"/>
        <CONNECTOR FROMINSTANCE="LKP" FROMINSTANCETYPE="Lookup Procedure" FROMFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("synthetic-multi-key.xml", xml)[0];
    const r = buildLineage(s)[0];
    // SRC contributed two keys (A and B); they should be joined with "/" within the SRC group.
    expect(r.sourceTable).toBe("DIM_LKP, SRC");
    expect(r.sourceColumn).toBe("OUT; A/B");
  });
});
