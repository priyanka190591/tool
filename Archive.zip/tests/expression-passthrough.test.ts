import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildLineage, inlineExpression } from "@/lib/lineage";
import type { Connector, ParsedSession, TransformationDef } from "@/lib/sessions";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadFirst(file: string): Promise<ParsedSession> {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(file, xml)[0];
}

describe("trivial passthrough expressions", () => {
  it("does not surface 'EXPRESSION=SSN' as business logic on the COMPTIME fixture", async () => {
    const s = await loadFirst("COMPTIME.xml");
    const rows = buildLineage(s);
    for (const r of rows) {
      // A single-identifier expression matching a known port name is noise.
      // If we see one, the fix has regressed.
      if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(r.expression || "")) {
        throw new Error(
          `Row for ${r.targetTable}.${r.targetColumn} captured a bare identifier as expression: "${r.expression}"`,
        );
      }
    }
  });

  it("captures the non-trivial upstream expression when the closest port is a passthrough", () => {
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC"><SOURCEFIELD NAME="X" DATATYPE="integer" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="EXP_REAL" TYPE="Expression">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT" DATATYPE="integer"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="integer" EXPRESSION="X * 2"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_PASS" TYPE="Expression">
          <TRANSFORMFIELD NAME="IN" PORTTYPE="INPUT" DATATYPE="integer"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="integer" EXPRESSION="IN"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="EXP_REAL" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_REAL"/>
        <INSTANCE NAME="EXP_PASS" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_PASS"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="EXP_REAL" TOINSTANCETYPE="Expression" TOFIELD="X"/>
        <CONNECTOR FROMINSTANCE="EXP_REAL" FROMINSTANCETYPE="Expression" FROMFIELD="OUT" TOINSTANCE="EXP_PASS" TOINSTANCETYPE="Expression" TOFIELD="IN"/>
        <CONNECTOR FROMINSTANCE="EXP_PASS" FROMINSTANCETYPE="Expression" FROMFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("synthetic.xml", xml)[0];
    const rows = buildLineage(s);
    const tgt = rows.find((r) => r.targetColumn === "Y");
    expect(tgt).toBeDefined();
    // The closest expression is "IN" (trivial passthrough) — must NOT be captured.
    // The real upstream expression is "X * 2" — must be captured.
    expect(tgt!.expression).not.toBe("IN");
    expect(tgt!.expression).not.toBe("X");
    expect(tgt!.expression).toContain("X * 2");
    expect(tgt!.sourceTable).toBe("SRC");
    expect(tgt!.sourceColumn).toBe("X");
  });

  it("inlines cascaded non-trivial expressions into one resolved formula", () => {
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC"><SOURCEFIELD NAME="X" DATATYPE="string" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="string" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="EXP_TRIM" TYPE="Expression">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT" DATATYPE="string"/>
          <TRANSFORMFIELD NAME="TRIMMED" PORTTYPE="OUTPUT" DATATYPE="string" EXPRESSION="TRIM(X)"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_UPPER" TYPE="Expression">
          <TRANSFORMFIELD NAME="TRIMMED" PORTTYPE="INPUT" DATATYPE="string"/>
          <TRANSFORMFIELD NAME="CLEAN" PORTTYPE="OUTPUT" DATATYPE="string" EXPRESSION="UPPER(TRIMMED)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="EXP_TRIM" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_TRIM"/>
        <INSTANCE NAME="EXP_UPPER" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_UPPER"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="EXP_TRIM" TOINSTANCETYPE="Expression" TOFIELD="X"/>
        <CONNECTOR FROMINSTANCE="EXP_TRIM" FROMINSTANCETYPE="Expression" FROMFIELD="TRIMMED" TOINSTANCE="EXP_UPPER" TOINSTANCETYPE="Expression" TOFIELD="TRIMMED"/>
        <CONNECTOR FROMINSTANCE="EXP_UPPER" FROMINSTANCETYPE="Expression" FROMFIELD="CLEAN" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("cascade.xml", xml)[0];
    const rows = buildLineage(s);
    const tgt = rows.find((r) => r.targetColumn === "Y")!;
    // Closest non-trivial expression is UPPER(TRIMMED). After inlining, TRIMMED
    // should be substituted with TRIM(X) → UPPER((TRIM(X))).
    expect(tgt.expression).toContain("UPPER");
    expect(tgt.expression).toContain("TRIM");
    expect(tgt.expression).toContain("X");
  });
});

describe("inlineExpression", () => {
  it("preserves bare identifiers when no upstream expression exists", () => {
    const idx = {
      connectorByTo: new Map<string, Connector>(),
      txByName: new Map<string, TransformationDef>(),
      sourcesByName: new Map(),
    };
    expect(inlineExpression("X * 2", "EXP", idx)).toBe("X * 2");
  });

  it("does not touch known functions", () => {
    const idx = {
      connectorByTo: new Map<string, Connector>(),
      txByName: new Map<string, TransformationDef>(),
      sourcesByName: new Map(),
    };
    expect(inlineExpression("SYSTIMESTAMP", "EXP", idx)).toBe("SYSTIMESTAMP");
    expect(inlineExpression("ROUND(X, 2)", "EXP", idx)).toBe("ROUND(X, 2)");
  });
});
