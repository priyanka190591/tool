import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";
import { buildCleanWorkbook } from "@/lib/xlsx-clean";
import JSZip from "jszip";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadFirst(file: string) {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(path.basename(file), xml)[0];
}

async function inspect(buf: ArrayBuffer) {
  const zip = await JSZip.loadAsync(buf);
  const workbookXml = await zip.file("xl/workbook.xml")!.async("text");
  const sheetNames = Array.from(workbookXml.matchAll(/<sheet[^>]*name="([^"]+)"/g)).map(
    (m) => m[1],
  );
  // sheet1.xml may be either FIELD_MAPPING or one of the others — they're addressed by relationship.
  const sheetEntries = await Promise.all(
    Object.keys(zip.files)
      .filter((p) => /^xl\/worksheets\/sheet\d+\.xml$/.test(p))
      .sort()
      .map((p) => zip.file(p)!.async("text")),
  );
  return { sheetNames, sheetEntries };
}

describe("Clean 3-sheet XLSX (Prompt 10)", () => {
  it("workbook contains the 6 expected sheets in the spec order", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const { sheetNames } = await inspect(buf);
    expect(sheetNames).toEqual([
      "Overall details",
      "FIELD_MAPPING",
      "LOOKUPS",
      "TRANSFORMATIONS",
      "Source SQL",
      "Connections",
      "Session Details",
    ]);
  });

  // Sheet positions after the new spec order:
  //   sheet1.xml = Overall details
  //   sheet2.xml = FIELD_MAPPING
  //   sheet3.xml = LOOKUPS
  //   sheet4.xml = TRANSFORMATIONS
  //   sheet5.xml = Source SQL
  //   sheet6.xml = Connections
  //   sheet7.xml = Session Details

  it("SQL Override appears on LOOKUPS sheet, NEVER on FIELD_MAPPING (de-dup contract)", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const fieldMappingSheet = await zip.file("xl/worksheets/sheet2.xml")!.async("text");
    const lookupsSheet = await zip.file("xl/worksheets/sheet3.xml")!.async("text");
    const sharedStrings = (await zip.file("xl/sharedStrings.xml")?.async("text")) ?? "";

    const sqlSnippet = "SELECT REGION_KEY, REGION_CODE FROM EDW.DIM_REGION";
    expect(sharedStrings).toContain(sqlSnippet);

    const sqlSharedIndex = sharedStrings
      .split("<si>")
      .findIndex((chunk) => chunk.includes(sqlSnippet)) - 1;
    expect(sqlSharedIndex).toBeGreaterThanOrEqual(0);
    const tag = `<v>${sqlSharedIndex}</v>`;
    expect(lookupsSheet).toContain(tag);
    expect(fieldMappingSheet.split(tag).length).toBeLessThanOrEqual(1);
  });

  it("FIELD_MAPPING row count === json.field_mappings.length", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const fieldMappingSheet = await zip.file("xl/worksheets/sheet2.xml")!.async("text");
    const rowMatches = fieldMappingSheet.match(/<row[ >]/g) ?? [];
    expect(rowMatches.length).toBe(json.field_mappings.length + 1);
  });

  it("FIELD_MAPPING uses the strict header order from spec", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const fieldMappingSheet = await zip.file("xl/worksheets/sheet2.xml")!.async("text");
    const sharedStrings = (await zip.file("xl/sharedStrings.xml")?.async("text")) ?? "";
    const stringsList = Array.from(sharedStrings.matchAll(/<t[^>]*>([^<]*)<\/t>/g)).map((m) => m[1]);
    const headerRow = fieldMappingSheet.match(/<row[^>]*r="1"[^>]*>([\s\S]*?)<\/row>/);
    const headerCellRefs = [...(headerRow?.[1].matchAll(/<v>(\d+)<\/v>/g) ?? [])].map((m) => Number(m[1]));
    const headers = headerCellRefs.map((i) => stringsList[i]);
    expect(headers).toEqual([
      "Used",
      "Source Table", "Source Database", "Source Column",
      "Source Datatype", "Src Precision", "Src Scale", "Src Nullable", "Src Key",
      "Business Logic / Expression",
      "Expression Type", "Expression Chain", "Transformation Path", "Logical Steps",
      "Lookups Used", "Lookup Type", "Lookup Join Condition", "Lookup Return Column",
      "Lookup Keys (Source → Lookup)",
      "Joiners Used", "Joiner Join Type", "Joiner Join Condition",
      "Routers Used",
      "Aggregators Used", "Aggregator Group By",
      "Source Qualifier",
      "CDQ Dimension (heuristic)", "CDQ Rule (heuristic)",
      "Error Handling Logic",
      "Load Type",
      "Target Table", "Target Database", "Target Column",
      "Target Datatype", "Tgt Precision", "Tgt Scale", "Tgt Nullable", "Tgt Key",
      "Parameter File", "Notes",
    ]);
  });

  it("FIELD_MAPPING fills empty cells with literal 'NULL' (per spec)", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const fieldMappingSheet = await zip.file("xl/worksheets/sheet2.xml")!.async("text");
    const sharedStrings = (await zip.file("xl/sharedStrings.xml")?.async("text")) ?? "";
    const stringsList = Array.from(sharedStrings.matchAll(/<t[^>]*>([^<]*)<\/t>/g)).map((m) => m[1]);
    const nullIndex = stringsList.indexOf("NULL");
    expect(nullIndex).toBeGreaterThan(-1);
    const tag = `<v>${nullIndex}</v>`;
    const count = (fieldMappingSheet.split(tag).length - 1);
    expect(count).toBeGreaterThan(10);
  });

  it("LOOKUPS row count === json.lookups.length (no duplication)", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const lookupsSheet = await zip.file("xl/worksheets/sheet3.xml")!.async("text");
    const rowMatches = lookupsSheet.match(/<row[ >]/g) ?? [];
    expect(rowMatches.length).toBe(json.lookups.length + 1);
  });

  it("Overall details sheet has Identity + Resolution + Counts sections", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const overallSheet = await zip.file("xl/worksheets/sheet1.xml")!.async("text");
    const sharedStrings = (await zip.file("xl/sharedStrings.xml")?.async("text")) ?? "";
    expect(sharedStrings).toContain("Identity");
    expect(sharedStrings).toContain("Resolution");
    expect(sharedStrings).toContain("Counts");
    expect(sharedStrings).toContain("Total field mappings");
    // Row count = header + one row per overall_details entry.
    const rowMatches = overallSheet.match(/<row[ >]/g) ?? [];
    expect(rowMatches.length).toBe(json.overall_details.length + 1);
  });

  it("Source SQL sheet covers SQs AND lookups, with one row per SQL-bearing TX", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const sourceSqlSheet = await zip.file("xl/worksheets/sheet5.xml")!.async("text");
    const rowMatches = sourceSqlSheet.match(/<row[ >]/g) ?? [];
    expect(rowMatches.length).toBe(json.source_sql.length + 1);
    expect(json.source_sql.length).toBeGreaterThan(0);

    // s_SALES_DIM_FULL has a lookup (lkp_REGION) with a Lookup Sql Override —
    // it must appear in the Source SQL sheet alongside the Source Qualifier.
    const sharedStrings = (await zip.file("xl/sharedStrings.xml")?.async("text")) ?? "";
    expect(sharedStrings).toContain("Lookup Sql Override");
    expect(json.source_sql.some((r) => /lookup/i.test(r.transformation_type))).toBe(true);
    expect(json.source_sql.some((r) => /source qualifier/i.test(r.transformation_type))).toBe(true);
  });

  it("never emits per-target `FM_<table>` sheets — single FIELD_MAPPING is canonical", async () => {
    // Per-target sheets were tried in Phase A.3 but removed: reviewers prefer
    // one unified sheet they can filter in Excel. This guard prevents them
    // from being re-introduced silently.
    const xml = await fs.readFile(path.join(SESSIONS_DIR, "COMPTIME.xml"), "utf8");
    const sessions = parseSessionsFromXml("COMPTIME.xml", xml);
    for (const session of sessions) {
      const json = buildMappingJson(session);
      const buf = await buildCleanWorkbook(json);
      const { sheetNames } = await inspect(buf);
      expect(
        sheetNames.filter((n) => n.startsWith("FM_")),
        `${session.name}: no per-target sheets expected`,
      ).toEqual([]);
    }
  });

  it("Connections sheet exists with one row per CONNECTIONREFERENCE", async () => {
    const session = await loadFirst("COMPTIME.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const connectionsSheet = await zip.file("xl/worksheets/sheet6.xml")!.async("text");
    const rowMatches = connectionsSheet.match(/<row[ >]/g) ?? [];
    expect(rowMatches.length).toBe(json.connections.length + 1); // +1 header
    expect(json.connections.length).toBeGreaterThan(0);
    // Sanity: at least one ConnectionRow has both an instance and a
    // connection name populated (no all-empty rows on a real fixture).
    expect(
      json.connections.some((c) => c.instance && c.connection),
    ).toBe(true);
  });

  it("TRANSFORMATIONS sheet classifies expressions by Kind so reviewers can filter passthroughs in Excel", async () => {
    // Every expression has a Kind tag: Passthrough / Local Variable / Computed.
    // Reviewers can filter the Kind column in Excel to focus on real logic
    // OR see the full graph of wires. Pin: at least one Computed expression
    // exists on s_SALES_DIM_FULL (NET_AMOUNT = ROUND(... QTY * UNIT_PRICE ...)),
    // and every passthrough has formula.trim() == output_field.
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const allExpressions = json.transformations.flatMap((t) => t.expressions);
    expect(allExpressions.some((e) => e.kind === "Computed")).toBe(true);
    for (const e of allExpressions) {
      if (e.kind === "Passthrough") {
        expect(e.formula.trim().toLowerCase()).toBe(e.output_field.toLowerCase());
      }
      if (e.kind === "Computed") {
        expect(e.formula.trim().toLowerCase()).not.toBe(e.output_field.toLowerCase());
      }
    }
  });

  it("Session Details sheet exists and references the Attributes/Parameters sections it carries", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const buf = await buildCleanWorkbook(json);
    const zip = await JSZip.loadAsync(buf);
    const sessionDetailsSheet = await zip.file("xl/worksheets/sheet7.xml")!.async("text");
    const rowMatches = sessionDetailsSheet.match(/<row[ >]/g) ?? [];
    // Header + one row per entry (entry count may be zero for minimal fixtures —
    // the sheet is always present).
    expect(rowMatches.length).toBe(json.session_details.length + 1);
  });
});
