import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadFirst(file: string) {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(path.basename(file), xml)[0];
}

function buildXml(body: string): string {
  return `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      ${body}
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
}

describe("Phase B.1 — unmapped source field rows", () => {
  it("emits a row with is_used=NO for every SOURCEFIELD not wired to a target", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const unmapped = json.field_mappings.filter((r) => r.is_used === "NO");
    expect(unmapped.length).toBeGreaterThan(0);
    for (const r of unmapped) {
      expect(r.target_table).toBe("UNUSED");
      expect(r.target_column).toBe("UNUSED");
      expect(r.notes).toMatch(/not connected/i);
      expect(r.source_table).toBeTruthy();
      expect(r.source_column).toBeTruthy();
    }
  });
});

describe("Phase B.2 — Lookup Type column (Connected vs Unconnected)", () => {
  it("marks port-connected lookups as Connected", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    // FACT_SALES.CUSTOMER_KEY is sourced via a connected lookup (lkp_CUSTOMER).
    const row = json.field_mappings.find(
      (r) => r.target_table === "FACT_SALES" && r.target_column === "CUSTOMER_KEY",
    )!;
    expect(row).toBeDefined();
    expect(row.lookup_type).toBe("Connected");
    expect(row.lookup_join_condition).toBeTruthy();
    expect(row.lookup_return_column).toBeTruthy();
  });
});

describe("Phase B.3 — Joiner / Aggregator dedicated columns", () => {
  it("populates joiner_join_type when row goes through a Joiner", () => {
    // Synthetic: SRC1 + SRC2 → JNR (NORMAL JOIN) → TGT.
    const xml = buildXml(`
      <SOURCE NAME="A"><SOURCEFIELD NAME="X" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <SOURCE NAME="B"><SOURCEFIELD NAME="X" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_A" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="SQ_B" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="JNR" TYPE="Joiner">
          <TRANSFORMFIELD NAME="A_X" PORTTYPE="MASTER_INPUT/INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="B_X" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="10" EXPRESSION="A_X"/>
          <TABLEATTRIBUTE NAME="Join Type" VALUE="NORMAL JOIN"/>
          <TABLEATTRIBUTE NAME="Join Condition" VALUE="A_X = B_X"/>
        </TRANSFORMATION>
        <INSTANCE NAME="A" TYPE="SOURCE" TRANSFORMATION_NAME="A"/>
        <INSTANCE NAME="B" TYPE="SOURCE" TRANSFORMATION_NAME="B"/>
        <INSTANCE NAME="SQ_A" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_A" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="SQ_B" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_B" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="JNR" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="JNR" TRANSFORMATION_TYPE="Joiner"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="A" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ_A" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="B" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ_B" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ_A" FROMINSTANCETYPE="Source Qualifier" TOFIELD="A_X" TOINSTANCE="JNR" TOINSTANCETYPE="Joiner"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ_B" FROMINSTANCETYPE="Source Qualifier" TOFIELD="B_X" TOINSTANCE="JNR" TOINSTANCETYPE="Joiner"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="JNR" FROMINSTANCETYPE="Joiner" TOFIELD="Y" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="A" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const json = buildMappingJson(session);
    const row = json.field_mappings.find((r) => r.target_column === "Y" && r.is_used === "YES")!;
    expect(row.joiner_join_type ?? "").toMatch(/NORMAL JOIN/);
    expect(row.joiner_join_condition ?? "").toMatch(/A_X\s*=\s*B_X/);
  });
});

describe("Phase C.1 — raw XML expression preserved alongside resolved", () => {
  it("populates raw_expression_xml with the original <TRANSFORMFIELD EXPRESSION>", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    // NET_AMOUNT carries a derived expression in the XML — raw_expression_xml
    // should hold the original even after inlining rewrites business_logic_expression.
    const row = json.field_mappings.find((r) => r.target_column === "NET_AMOUNT")!;
    expect(row.raw_expression_xml).toBeTruthy();
    expect(row.business_logic_expression).toBeTruthy();
  });
});

describe("Phase C.2 — Logical Steps column", () => {
  it("labels each instance in the path with its transformation kind", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const row = json.field_mappings.find((r) => r.is_used === "YES" && (r.transformation_path?.length ?? 0) > 0)!;
    expect(row.logical_steps ?? "").toMatch(/^Step 1: /);
    // At minimum the path includes a Source / Source Qualifier / Target hop.
    expect(row.logical_steps ?? "").toMatch(/Source Qualifier|Source|Target/);
  });
});

describe("Phase C.4 — Error Handling Logic column", () => {
  it("captures ERROR('...') calls when present in the expression", async () => {
    // COMPTIME.xml has 19 ERROR() calls per Phase 0 grep.
    const xml = await fs.readFile(path.join(SESSIONS_DIR, "COMPTIME.xml"), "utf8");
    const sessions = parseSessionsFromXml("COMPTIME.xml", xml);
    let foundErrorRow = false;
    for (const s of sessions) {
      const json = buildMappingJson(s);
      for (const r of json.field_mappings) {
        if (r.error_logic) {
          expect(r.error_logic).toMatch(/Raises|ERROR/i);
          foundErrorRow = true;
        }
      }
    }
    expect(foundErrorRow, "Expected at least one row with error_logic populated").toBe(true);
  });
});
