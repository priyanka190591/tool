import { describe, it, expect } from "vitest";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";

// These tests pin down the variant-aware port-resolution behavior added to
// lib/lineage.ts (resolveConnectorPort + findSiblingInputPort step 6). Each
// case is a synthetic IDMC XML with a deliberate port-name mismatch between
// what's referenced in an expression and what the actual input port is
// named. Before the fix, every one of these would dead-end as "(computed)"
// with NULL source — the prod-data scenario the user reported.

function buildXml(body: string): string {
  return `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      ${body}
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
}

describe("port name variant resolution (Phase 1)", () => {
  it("Expression arg with `in_` prefix variant resolves to upstream source", () => {
    // EXP.OUT = TO_CHAR(SystemId)   ← expression text says "SystemId"
    // EXP input port is named in_SystemId (IDMC prefix convention)
    // CONNECTOR feeds SQ.SystemId → EXP.in_SystemId
    // Without resolveConnectorPort the bare-identifier scan misses this and
    // Source Table dead-ends at (computed).
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="SystemId" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="risksystemid" DATATYPE="string" PRECISION="20" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="SystemId" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="in_SystemId" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="20" EXPRESSION="TO_CHAR(SystemId)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="SystemId" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="SystemId" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="SystemId" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="in_SystemId" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="risksystemid" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "risksystemid")!;
    expect(row).toBeDefined();
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("SystemId");
    expect(row.business_logic_expression).toContain("TO_CHAR(SystemId)");
  });

  it("Expression arg with CamelCase ↔ lowercase resolves (case-fold)", () => {
    // Expression text says "Sqftarea1" (mixed case), actual input port is
    // "SqFtArea1". Case-fold variant matching recovers the link.
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="SqFtArea1" DATATYPE="double" PRECISION="12" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="sqfeetarea" DATATYPE="string" PRECISION="20" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="SqFtArea1" PORTTYPE="INPUT/OUTPUT" DATATYPE="double" PRECISION="12"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="SqFtArea1" PORTTYPE="INPUT" DATATYPE="double" PRECISION="12"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="20" EXPRESSION="TO_CHAR(sqftarea1)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="SqFtArea1" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="SqFtArea1" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="SqFtArea1" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="SqFtArea1" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="sqfeetarea" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "sqfeetarea")!;
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("SqFtArea1");
  });

  it("Expression arg with snake_case ↔ lowercase resolves (word-form)", () => {
    // Expression text says "risksystemid", actual input port is RISK_SYSTEM_ID.
    // Word-form normalization (lowercase + underscores stripped) matches.
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="RISK_SYSTEM_ID" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="OUT_ID" DATATYPE="string" PRECISION="20" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="RISK_SYSTEM_ID" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="RISK_SYSTEM_ID" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="20" EXPRESSION="UPPER(risksystemid)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="RISK_SYSTEM_ID" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="RISK_SYSTEM_ID" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="RISK_SYSTEM_ID" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="RISK_SYSTEM_ID" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="OUT_ID" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "OUT_ID")!;
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("RISK_SYSTEM_ID");
  });

  it("Direct passthrough with output/input name mismatch still resolves", () => {
    // No expression on the output port — pure direct chain. But the target
    // column is "riskhashkey" (lowercase) and the actual chain uses
    // "RiskHashKey" (CamelCase). Without variant resolution at traceField
    // dead-end, the walk breaks immediately and source becomes (computed).
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="RiskHashKey" DATATYPE="string" PRECISION="64" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="RiskHashKey" DATATYPE="string" PRECISION="64" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="RiskHashKey" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="64"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="RiskHashKey" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="64"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="RiskHashKey" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="RiskHashKey" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="RiskHashKey" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="RiskHashKey" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="RiskHashKey" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="riskhashkey" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "RiskHashKey")!;
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("RiskHashKey");
  });

  it("Renaming wire `EXPRESSION=X` is recognized as trivial when actual port is `in_X`", () => {
    // EXP.OUT has EXPRESSION="X" (literally), but EXP's actual input port is
    // "in_X" (IDMC prefix convention). Without variant resolution inside
    // isTrivialPassthrough this looks like business logic ("X"), gets captured
    // as the expression, and the trace has to recover sources via Layer 1.
    // With the improvement, the wire is recognized as trivial, no fake
    // business logic is captured, and currentField redirects straight to in_X.
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="X" DATATYPE="integer" PRECISION="5" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" PRECISION="5" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="integer" PRECISION="5"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="in_X" PORTTYPE="INPUT" DATATYPE="integer" PRECISION="5"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="integer" PRECISION="5" EXPRESSION="X"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="in_X" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="Y" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "Y")!;
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("X");
    // The bare "X" is a renaming wire, not business logic.
    expect(row.business_logic_expression ?? "").not.toBe("X");
  });

  it("Router output→input redirect tries one-digit strip first (input keeps its own digits)", () => {
    // Real IDMC pattern: Router has INPUT port "SqFtArea1" (the "1" is part
    // of the name). For group N, the Router emits OUTPUT port "SqFtArea1N"
    // (e.g. "SqFtArea13" for group 3). Stripping ALL trailing digits would
    // produce "SqFtArea" — wrong target. The fix is to try one digit at a
    // time, longest prefix first.
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="SqFtArea1" DATATYPE="double" PRECISION="12" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="OUT" DATATYPE="double" PRECISION="12" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="SqFtArea1" PORTTYPE="INPUT/OUTPUT" DATATYPE="double" PRECISION="12"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="RTR" TYPE="Router">
          <TRANSFORMFIELD NAME="SqFtArea1" PORTTYPE="INPUT" DATATYPE="double" PRECISION="12"/>
          <TRANSFORMFIELD NAME="SqFtArea13" PORTTYPE="OUTPUT" DATATYPE="double" PRECISION="12"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="RTR" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="RTR" TRANSFORMATION_TYPE="Router"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="SqFtArea1" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="SqFtArea1" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="SqFtArea1" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="SqFtArea1" TOINSTANCE="RTR" TOINSTANCETYPE="Router"/>
        <CONNECTOR FROMFIELD="SqFtArea13" FROMINSTANCE="RTR" FROMINSTANCETYPE="Router" TOFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "OUT")!;
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("SqFtArea1");
  });

  it("Trivial passthrough recognizes expressions with SQL comments + trailing whitespace", () => {
    // Output expression is "RAW /* legacy alias */" plus trailing NBSP.
    // Should be treated as a trivial port reference (no business logic),
    // walk redirects to the input port, source resolves cleanly.
    const xml = buildXml(`
      <SOURCE NAME="SRC">
        <SOURCEFIELD NAME="RAW" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="OUT" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="RAW" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="RAW" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="10" EXPRESSION="RAW /* legacy alias */&#xA0;"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="RAW" FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" TOFIELD="RAW" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="RAW" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="RAW" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="SRC" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "OUT")!;
    expect(row.source_table).toBe("SRC");
    expect(row.source_column).toBe("RAW");
  });
});
