import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";
import { sessionToCsv, sessionToJson, sessionToMarkdown } from "@/lib/exports";
import { isFieldMappingUnresolved, type MappingJson } from "@/lib/mapping-schema";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadFirst(file: string) {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(path.basename(file), xml)[0];
}

// Same columns the XLSX FIELD_MAPPING sheet pins (tests/clean-xlsx.test.ts).
// If this list ever drifts from the XLSX header order, paste-from-CSV-to-XLSX
// stops working — keep them in lockstep.
const FIELD_MAPPING_HEADERS = [
  "Used",
  "Source Table", "Source Database", "Source Column",
  "Source Datatype", "Src Precision", "Src Scale", "Src Nullable", "Src Key",
  "Business Logic / Expression",
  "Expression Type", "Expression Chain", "Transformation Path", "Logical Steps",
  "Lookups Used", "Lookup Type", "Lookup Join Condition", "Lookup Return Column",
  "Lookup Keys (Source → Lookup)",
  "Joiners Used", "Joiner Join Type", "Joiner Join Condition",
  "Routers Used",
  "Aggregators Used", "Aggregator Group By",
  "Source Qualifier",
  "CDQ Dimension (heuristic)", "CDQ Rule (heuristic)",
  "Error Handling Logic",
  "Load Type",
  "Target Table", "Target Database", "Target Column",
  "Target Datatype", "Tgt Precision", "Tgt Scale", "Tgt Nullable", "Tgt Key",
  "Parameter File", "Notes",
];

describe("Exports parity (CSV / JSON / MD all derive from MappingJson)", () => {
  it("CSV header row matches the XLSX spec exactly, in order", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const csv = sessionToCsv(session);
    const firstLine = csv.split("\n")[0];
    const headers = firstLine.split(",");
    expect(headers).toEqual(FIELD_MAPPING_HEADERS);
  });

  it("CSV row count == json.field_mappings.length (1 header + N data rows)", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const csv = sessionToCsv(session);
    // SQ SQL Query cells contain newlines (multi-line SQL). Naive line-split
    // would over-count. Walk the string respecting quoted strings instead.
    let rowCount = 0;
    let inQuotes = false;
    for (let i = 0; i < csv.length; i++) {
      const ch = csv[i];
      if (ch === '"') {
        // Toggle, but `""` inside a quoted cell is an escaped quote, not a close.
        if (inQuotes && csv[i + 1] === '"') {
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === "\n" && !inQuotes) {
        rowCount++;
      }
    }
    expect(rowCount).toBe(json.field_mappings.length + 1);
  });

  it("CSV renders null cells as literal 'NULL' (XLSX convention)", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const csv = sessionToCsv(session);
    // PRODUCT_KEY is unmapped on this fixture — its row should contain at
    // least one "NULL" cell where source-side fields are blank.
    expect(csv).toMatch(/(^|,)NULL(,|\n|$)/);
  });

  it("JSON export carries the full MappingJson shape under `mapping`", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const text = sessionToJson(session);
    const parsed: { session: unknown; mapping: MappingJson } = JSON.parse(text);
    expect(parsed.mapping.schema_version).toBe("1");
    expect(Array.isArray(parsed.mapping.field_mappings)).toBe(true);
    expect(Array.isArray(parsed.mapping.lookups)).toBe(true);
    expect(Array.isArray(parsed.mapping.transformations)).toBe(true);
    expect(parsed.mapping.field_mappings.length).toBeGreaterThan(0);
  });

  it("Markdown export includes the FIELD_MAPPING table heading + Load Type column", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const md = sessionToMarkdown(session);
    expect(md).toContain("## Field mappings (FIELD_MAPPING)");
    // Header row includes Load Type — the canonical MappingJson column that
    // the old lineage-row Markdown didn't have.
    expect(md).toContain("| Load Type |");
  });

  it("Overall details resolved/unresolved counts match the canonical predicate", async () => {
    // Regression guard: previously the Overall Details sheet counted every
    // parenthesized source label ("(literal)", "(system)", "(aggregated)",
    // "(lookup …)") as unresolved, while the Mapping Inspector only counted
    // "(computed)" / "(not wired)" / "(unresolved …)" as unresolved. Result
    // was visible drift like "Inspector: 100% resolved, Overall details: 98%".
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const json = buildMappingJson(session);
    const unresolved = json.field_mappings.filter(isFieldMappingUnresolved).length;
    const resolved = json.field_mappings.length - unresolved;
    const overallResolved = json.overall_details.find(
      (r) => r.section === "Resolution" && r.key === "Resolved",
    );
    const overallUnresolved = json.overall_details.find(
      (r) => r.section === "Resolution" && r.key === "Unresolved",
    );
    expect(overallResolved?.value).toMatch(new RegExp(`^${resolved} `));
    expect(overallUnresolved?.value).toMatch(new RegExp(`^${unresolved} `));
  });
});
