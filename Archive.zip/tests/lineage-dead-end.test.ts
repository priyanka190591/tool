import { describe, it, expect } from "vitest";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildLineage } from "@/lib/lineage";

/**
 * Regression coverage for the "(computed) with blank Source Column" bug:
 * when a trace walks through trivial-passthrough Expressions and runs out of
 * incoming connectors, we must surface the topmost-upstream instance + port
 * instead of leaving the row uninformative.
 */

describe("dead-end passthrough chains surface (unresolved at <instance>)", () => {
  it("trace through trivial-passthrough chain ending in a plain dead-end port", () => {
    // TGT.Y ← P1.X (EXPR='X' — trivial, has incoming connector to P1.X)
    //       ← P2.X (no EXPRESSION, no incoming connector — true dead-end)
    // The trivial-skip prevents capturing 'X' at P1; P2 has nothing to capture.
    // Expectation: (unresolved at P2) / "X" — the new fallback format.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="P1" TYPE="Expression">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="integer" EXPRESSION="X"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="P2" TYPE="Expression">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="integer"/>
        </TRANSFORMATION>
        <INSTANCE NAME="P1" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="P1"/>
        <INSTANCE NAME="P2" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="P2"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="P1" FROMINSTANCETYPE="Expression" FROMFIELD="X" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
        <CONNECTOR FROMINSTANCE="P2" FROMINSTANCETYPE="Expression" FROMFIELD="X" TOINSTANCE="P1" TOINSTANCETYPE="Expression" TOFIELD="X"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("dead-end.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceTable).toMatch(/^\(unresolved at /);
    expect(r.sourceTable).toContain("P2");
    expect(r.sourceColumn).toBe("X");
  });

  it("legitimate (computed) rows (system functions, literals) keep that label", () => {
    // TGT.Y ← EXP.OUT (EXPR='SYSTIMESTAMP', no upstream wire)
    // SYSTIMESTAMP is a real system value, not a port — captured as expression.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="timestamp" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="timestamp" EXPRESSION="SYSTIMESTAMP"/>
        </TRANSFORMATION>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" FROMFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("computed.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceTable).toBe("(computed)");
    expect(r.sourceColumn).toContain("SYSTIMESTAMP");
  });

  it("(not wired) is preserved for targets with no incoming connector at all", () => {
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("not-wired.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceTable).toBe("(not wired)");
    expect(r.sourceColumn).toBe("");
  });
});

describe("INSTANCE name ≠ SOURCE definition name resolves correctly", () => {
  it("SOURCE def lookup via INSTANCE.TRANSFORMATION_NAME — gives real table + datatype", () => {
    // Instance ISourceNode154 wraps SOURCE def REAL_TABLE. Direct lookup of
    // ISourceNode154 misses; the INSTANCE-fallback must resolve to REAL_TABLE.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="REAL_TABLE" DATABASETYPE="Oracle">
        <SOURCEFIELD NAME="X" DATATYPE="number" PRECISION="10" SCALE="0" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="number" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <INSTANCE NAME="ISourceNode154" TYPE="SOURCE" TRANSFORMATION_NAME="REAL_TABLE"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="ISourceNode154" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("instance-name.xml", xml)[0];
    const r = buildLineage(s)[0];
    // Real table name, not the synthetic instance name.
    expect(r.sourceTable).toBe("REAL_TABLE");
    expect(r.sourceColumn).toBe("X");
    // Datatype + precision + scale carried through from SOURCEFIELD on the def.
    expect(r.sourceDataType).toBe("number");
    expect(r.sourcePrecision).toBe("10");
    expect(r.sourceScale).toBe("0");
  });

  it("Router output port (X2, UPDATE group) redirects to sibling INPUT port (X)", () => {
    // IDMC Router pattern: input port "X" feeds two output groups whose ports
    // are "X1" (INSERT) and "X2" (UPDATE). CONNECTOR wires upstream → X
    // (input), and TGT.col wires from X2 (output). Walk must redirect from
    // X2 → X to find the real upstream connector.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC"><SOURCEFIELD NAME="X" DATATYPE="integer" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="RTR" TYPE="Router">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT" DATATYPE="integer" PRECISION="10"/>
          <TRANSFORMFIELD NAME="X1" PORTTYPE="OUTPUT" DATATYPE="integer" PRECISION="10" GROUP="INS"/>
          <TRANSFORMFIELD NAME="X2" PORTTYPE="OUTPUT" DATATYPE="integer" PRECISION="10" GROUP="UPD"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="RTR" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="RTR"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="RTR" TOINSTANCETYPE="Router" TOFIELD="X"/>
        <CONNECTOR FROMINSTANCE="RTR" FROMINSTANCETYPE="Router" FROMFIELD="X2" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("router.xml", xml)[0];
    const r = buildLineage(s)[0];
    // Walk must follow RTR.X2 → RTR.X → SRC.X — NOT dead-end at the Router.
    expect(r.sourceTable).toBe("SRC");
    expect(r.sourceColumn).toBe("X");
    expect(r.routersUsed).toBe("RTR");
  });

  it("Router output with _INSERT/_UPDATE suffix also redirects", () => {
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC"><SOURCEFIELD NAME="X" DATATYPE="integer" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="RTR" TYPE="Router">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT" DATATYPE="integer" PRECISION="10"/>
          <TRANSFORMFIELD NAME="X_INSERT" PORTTYPE="OUTPUT" DATATYPE="integer" PRECISION="10" GROUP="INS"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="RTR" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="RTR"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="RTR" TOINSTANCETYPE="Router" TOFIELD="X"/>
        <CONNECTOR FROMINSTANCE="RTR" FROMINSTANCETYPE="Router" FROMFIELD="X_INSERT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("router-suffix.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceTable).toBe("SRC");
    expect(r.sourceColumn).toBe("X");
  });

  it("BUSINESSNAME on the SOURCE def still wins when reached via instance fallback", () => {
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="REAL_TABLE" BUSINESSNAME="Customer Master" DATABASETYPE="Oracle">
        <SOURCEFIELD NAME="X" DATATYPE="number" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="number" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <INSTANCE NAME="ISourceNode99" TYPE="SOURCE" TRANSFORMATION_NAME="REAL_TABLE"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="ISourceNode99" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("biz-name.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceTable).toBe("Customer Master");
  });
});
