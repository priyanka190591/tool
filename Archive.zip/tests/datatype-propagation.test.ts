import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildLineage } from "@/lib/lineage";
import type { ParsedSession } from "@/lib/sessions-types";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function load(file: string, sessionName?: string): Promise<ParsedSession> {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  const all = parseSessionsFromXml(path.basename(file), xml);
  if (sessionName) {
    const s = all.find((x) => x.name === sessionName);
    if (!s) throw new Error(`Session ${sessionName} not found in ${file}`);
    return s;
  }
  return all[0];
}

describe("source datatype/precision/scale propagation", () => {
  it("direct-source rows carry the source column's full data shape", async () => {
    const rows = buildLineage(await load("Sales/s_SALES_DIM_FULL.xml"));
    const saleId = rows.find((r) => r.targetColumn === "SALE_ID")!;
    expect(saleId.sourceDataType).toBe("number");
    expect(saleId.sourcePrecision).toBe("18");
    expect(saleId.sourceScale).toBe("0");
    expect(saleId.sourceNullable).toBe("NOTNULL");
    expect(saleId.sourceKey).toBe("PRIMARY KEY");
  });

  it("expression-walked single-source rows propagate the upstream column's datatype", async () => {
    // FACT_SALES.SALE_DT = TRUNC(SALE_TS, 'DD') — sole identifier SALE_TS traces
    // back to STG_SALES.SALE_TS which is timestamp(29,6).
    const rows = buildLineage(await load("Sales/s_SALES_DIM_FULL.xml"));
    const saleDt = rows.find((r) => r.targetColumn === "SALE_DT")!;
    // SQ SQL Override resolves SOURCE table to fully qualified STAGE.STG_SALES.
    expect(saleDt.sourceTable).toBe("STAGE.STG_SALES");
    expect(saleDt.sourceColumn).toBe("SALE_TS");
    expect(saleDt.sourceDataType).toBe("timestamp");
    expect(saleDt.sourcePrecision).toBe("29");
    expect(saleDt.sourceScale).toBe("6");
  });

  it("expression-walked multi-source rows propagate the first resolved sub-trace's datatype", async () => {
    // FACT_SALES.NET_AMOUNT = ROUND(QTY * UNIT_PRICE * (1 - NVL(DISCOUNT_PCT,0)/100), 2)
    // — three identifiers, all from STG_SALES, different datatypes. We populate
    // with the first-resolved one rather than leaving the cell blank.
    const rows = buildLineage(await load("Sales/s_SALES_DIM_FULL.xml"));
    const netAmount = rows.find((r) => r.targetColumn === "NET_AMOUNT")!;
    expect(netAmount.sourceTable).toBe("STAGE.STG_SALES");
    expect(netAmount.sourceColumn).toBe("DISCOUNT_PCT/QTY/UNIT_PRICE");
    // Not blank — propagated from one of the resolved sub-traces.
    expect(netAmount.sourceDataType).not.toBe("");
    expect(netAmount.sourcePrecision).not.toBe("");
  });

  it("lookup-sourced rows carry the lookup output port's datatype", async () => {
    const rows = buildLineage(await load("Sales/s_SALES_DIM_FULL.xml"));
    const regionKey = rows.find((r) => r.targetColumn === "REGION_KEY")!;
    // LKP_REGION.REGION_KEY is decimal(18,0).
    expect(regionKey.sourceDataType).toBe("decimal");
    expect(regionKey.sourcePrecision).toBe("18");
    expect(regionKey.sourceScale).toBe("0");
  });

  it("rows resolved via lookup early-return capture the lookup port's datatype", async () => {
    // This row resolves through walkExpressionPorts → traceField entering the
    // lookup directly at its OUTPUT port (early-return path). The fix ensures
    // the port's datatype/precision is captured there too.
    const rows = buildLineage(await load("COMPTIME.xml", "s_COMPTIME_Current_Pay_Period"));
    const r = rows.find((x) => x.targetColumn === "PAY_PERIOD");
    if (!r) return; // tolerate if structure changes
    expect(r.sourceDataType).not.toBe("");
    expect(r.sourcePrecision).not.toBe("");
  });

  it("genuine (computed)/system-value rows correctly leave datatype blank", async () => {
    const rows = buildLineage(await load("Sales/s_SALES_DIM_FULL.xml"));
    const loadTs = rows.find((r) => r.targetColumn === "LOAD_TS")!;
    // SYSTIMESTAMP has no upstream column to inherit a datatype from.
    expect(loadTs.sourceTable).toBe("(computed)");
    expect(loadTs.sourceDataType).toBe("");
  });

  it("(not wired) rows correctly leave datatype blank", async () => {
    const rows = buildLineage(await load("Sales/s_SALES_DIM_FULL.xml"));
    const productKey = rows.find((r) => r.targetColumn === "PRODUCT_KEY")!;
    expect(productKey.sourceTable).toBe("(not wired)");
    expect(productKey.sourceDataType).toBe("");
  });

  it("unconnected :LKP.NAME(args) row prefers the arg's true source datatype over the lookup port's default", () => {
    // Bug C contract: when the lookup's underlying table (DIM_RATES) is NOT
    // registered as a SOURCE, we don't claim the lookup port's `decimal(14,4)`
    // as source_datatype — instead the arg (IN_KEY → SRC.X, "string") wins.
    // Surfaces an honest source-side trace rather than a misleading default.
    // A note explains why the lookup port type was suppressed.
    const xml = `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="SRC"><SOURCEFIELD NAME="X" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="decimal" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="LKP_RATES" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_KEY" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="RATE" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="decimal" PRECISION="14" SCALE="4"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="DIM_RATES"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_CALL" TYPE="Expression">
          <TRANSFORMFIELD NAME="IN_KEY" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="decimal" PRECISION="14" SCALE="4" EXPRESSION=":LKP.LKP_RATES(IN_KEY)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="SRC" TYPE="SOURCE" TRANSFORMATION_NAME="SRC"/>
        <INSTANCE NAME="EXP_CALL" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP_CALL"/>
        <INSTANCE NAME="LKP_RATES" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="LKP_RATES"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="SRC" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="EXP_CALL" TOINSTANCETYPE="Expression" TOFIELD="IN_KEY"/>
        <CONNECTOR FROMINSTANCE="EXP_CALL" FROMINSTANCETYPE="Expression" FROMFIELD="OUT" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
    const s = parseSessionsFromXml("synthetic-lkp.xml", xml)[0];
    const r = buildLineage(s)[0];
    expect(r.sourceDataType).toBe("string");
    expect(r.sourcePrecision).toBe("10");
    expect(r.notes).toMatch(/not used as source/i);
  });
});
