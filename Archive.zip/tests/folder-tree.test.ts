import { describe, it, expect } from "vitest";
import { buildFolderTree } from "@/lib/folder-tree";
import type { FileEntry } from "@/lib/sessions";

function f(path: string, sessions = 1): FileEntry {
  const name = path.split("/").pop() ?? path;
  return {
    path,
    fileName: name,
    sessions: Array.from({ length: sessions }, (_, i) => ({
      index: i,
      name: `${name}#${i}`,
    })),
  };
}

describe("buildFolderTree", () => {
  it("returns an empty root for empty input", () => {
    const root = buildFolderTree([]);
    expect(root.path).toBe("");
    expect(root.name).toBe("");
    expect(root.files).toEqual([]);
    expect(root.folders).toEqual([]);
    expect(root.totalFiles).toBe(0);
    expect(root.totalSessions).toBe(0);
  });

  it("places root-level files directly under root", () => {
    const root = buildFolderTree([f("a.xml"), f("b.xml", 2)]);
    expect(root.files.map((f) => f.fileName)).toEqual(["a.xml", "b.xml"]);
    expect(root.folders).toEqual([]);
    expect(root.totalFiles).toBe(2);
    expect(root.totalSessions).toBe(3); // 1 + 2
  });

  it("nests files into subfolders by path segments", () => {
    const root = buildFolderTree([
      f("Sales/2024/Q1/foo.xml"),
      f("Sales/bar.xml"),
      f("Customers/baz.xml", 3),
    ]);
    expect(root.totalFiles).toBe(3);
    expect(root.totalSessions).toBe(5);
    expect(root.folders.map((f) => f.name)).toEqual(["Customers", "Sales"]);

    const sales = root.folders.find((f) => f.name === "Sales")!;
    expect(sales.path).toBe("Sales");
    expect(sales.files.map((f) => f.fileName)).toEqual(["bar.xml"]);
    expect(sales.folders.map((f) => f.name)).toEqual(["2024"]);
    expect(sales.totalFiles).toBe(2);

    const q1 = sales.folders[0].folders[0];
    expect(q1.path).toBe("Sales/2024/Q1");
    expect(q1.name).toBe("Q1");
    expect(q1.files.map((f) => f.fileName)).toEqual(["foo.xml"]);
    expect(q1.totalFiles).toBe(1);
  });

  it("sorts folders before files at each level, both alpha", () => {
    const root = buildFolderTree([
      f("zeta.xml"),
      f("Beta/x.xml"),
      f("Alpha/y.xml"),
      f("apple.xml"),
    ]);
    expect(root.folders.map((f) => f.name)).toEqual(["Alpha", "Beta"]);
    expect(root.files.map((f) => f.fileName)).toEqual(["apple.xml", "zeta.xml"]);
  });

  it("rolls up totalFiles and totalSessions through every level", () => {
    const root = buildFolderTree([
      f("A/B/C/deep.xml", 4),
      f("A/B/wide.xml", 2),
      f("A/top.xml", 1),
    ]);
    expect(root.totalFiles).toBe(3);
    expect(root.totalSessions).toBe(7);
    const a = root.folders[0];
    expect(a.totalFiles).toBe(3);
    expect(a.totalSessions).toBe(7);
    const b = a.folders[0];
    expect(b.totalFiles).toBe(2);
    expect(b.totalSessions).toBe(6);
    const c = b.folders[0];
    expect(c.totalFiles).toBe(1);
    expect(c.totalSessions).toBe(4);
  });

  it("rejects paths containing '..' or empty segments", () => {
    expect(() => buildFolderTree([f("../escape.xml")])).toThrow();
    expect(() => buildFolderTree([f("Sales//foo.xml")])).toThrow();
    expect(() => buildFolderTree([f("/leading.xml")])).toThrow();
  });
});
