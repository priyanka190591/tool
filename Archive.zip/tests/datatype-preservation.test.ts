import { describe, it, expect } from "vitest";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";

// Pins Phase A.1 behavior: when a lookup transformation returns a column AND
// the lookup's underlying physical table is also registered as a <SOURCE> in
// the same XML, the FIELD_MAPPING row's source_datatype must reflect the
// SOURCE field's true type (e.g. int4) rather than the lookup output port's
// IDMC-defaulted varchar(N).

function buildXml(body: string): string {
  return `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      ${body}
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
}

describe("Datatype preservation across Lookup hops (Phase A.1)", () => {
  it("uses the SOURCE field datatype (int4) when the lookup table is a registered SOURCE", () => {
    // Lookup `lkp_BLDG` returns SqFt from physical table dbo.bldg.
    // bldg has SOURCEFIELD NAME="SqFt" DATATYPE="int4".
    // Lookup OUTPUT port `SqFt` is declared as varchar(765) (IDMC default).
    // Expected: FIELD_MAPPING source_datatype = int4 (not varchar(765)).
    const xml = buildXml(`
      <SOURCE NAME="dbo.bldg">
        <SOURCEFIELD NAME="SqFt" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
        <SOURCEFIELD NAME="BldgKey" DATATYPE="int4" PRECISION="10" FIELDNUMBER="2"/>
      </SOURCE>
      <SOURCE NAME="STG">
        <SOURCEFIELD NAME="BldgKey" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT">
        <TARGETFIELD NAME="SqFtOut" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="BldgKey" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="lkp_BLDG" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_BldgKey" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="SqFt" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="varchar" PRECISION="765"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="dbo.bldg"/>
          <TABLEATTRIBUTE NAME="Lookup condition" VALUE="BldgKey = IN_BldgKey"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="lkp_BLDG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="lkp_BLDG" TRANSFORMATION_TYPE="Lookup Procedure"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="BldgKey" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="BldgKey" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="BldgKey" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="IN_BldgKey" TOINSTANCE="lkp_BLDG" TOINSTANCETYPE="Lookup Procedure"/>
        <CONNECTOR FROMFIELD="SqFt" FROMINSTANCE="lkp_BLDG" FROMINSTANCETYPE="Lookup Procedure" TOFIELD="SqFtOut" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "SqFtOut")!;
    expect(row).toBeDefined();
    // source_table shows the underlying PHYSICAL table name (e.g. "dbo.bldg")
    // rather than the lookup instance ID. The lookup_id lives in
    // `lookups_used` / `lookup_used` for cross-reference to the LOOKUPS sheet.
    expect(row.source_table ?? "").toContain("dbo.bldg");
    expect(row.source_column ?? "").toContain("SqFt");
    expect(row.lookups_used ?? "").toContain("lkp_BLDG");
    expect(row.lookup_used).toBe("lkp_BLDG");
    // The bug we're fixing: was varchar(765), should be int4 from the SOURCE.
    expect(row.source_datatype).toBe("int4");
  });

  it("falls back to lookup port datatype + adds a note when no SOURCE def for the lookup table exists", () => {
    // Same shape as above, but no <SOURCE NAME="dbo.bldg"> is declared.
    // We can't recover the true physical type — accept the lookup port's
    // varchar(765) but annotate so the reviewer knows the source.
    const xml = buildXml(`
      <SOURCE NAME="STG">
        <SOURCEFIELD NAME="BldgKey" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT">
        <TARGETFIELD NAME="SqFtOut" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="BldgKey" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="lkp_BLDG" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_BldgKey" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="SqFt" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="varchar" PRECISION="765"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="dbo.bldg"/>
          <TABLEATTRIBUTE NAME="Lookup condition" VALUE="BldgKey = IN_BldgKey"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="lkp_BLDG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="lkp_BLDG" TRANSFORMATION_TYPE="Lookup Procedure"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="BldgKey" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="BldgKey" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="BldgKey" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="IN_BldgKey" TOINSTANCE="lkp_BLDG" TOINSTANCETYPE="Lookup Procedure"/>
        <CONNECTOR FROMFIELD="SqFt" FROMINSTANCE="lkp_BLDG" FROMINSTANCETYPE="Lookup Procedure" TOFIELD="SqFtOut" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "SqFtOut")!;
    expect(row.source_datatype).toBe("varchar");
    expect(row.source_precision).toBe("765");
    // Note must mention the fallback so reviewers don't trust varchar(765) as
    // the true physical type.
    expect(row.notes ?? "").toMatch(/inherited from lookup output port/i);
  });

  // Bug B regression guard: lookup table name and SOURCE def NAME differ
  // only in case (real-world IDMC quirk). The case-folded sourcesByNameCi
  // index now matches them.
  it("Bug B: matches SOURCE def case-insensitively when lookup table case differs", () => {
    const xml = buildXml(`
      <SOURCE NAME="DBO.BLDG">
        <SOURCEFIELD NAME="SqFt" DATATYPE="numeric" PRECISION="12" SCALE="2" FIELDNUMBER="1"/>
        <SOURCEFIELD NAME="BldgKey" DATATYPE="int4" PRECISION="10" FIELDNUMBER="2"/>
      </SOURCE>
      <SOURCE NAME="STG">
        <SOURCEFIELD NAME="BldgKey" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT">
        <TARGETFIELD NAME="SqFtOut" DATATYPE="numeric" PRECISION="12" SCALE="2" FIELDNUMBER="1"/>
      </TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="BldgKey" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="lkp_BLDG" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_BldgKey" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="SqFt" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="varchar" PRECISION="765"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="dbo.bldg"/>
          <TABLEATTRIBUTE NAME="Lookup condition" VALUE="BldgKey = IN_BldgKey"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="lkp_BLDG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="lkp_BLDG" TRANSFORMATION_TYPE="Lookup Procedure"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="BldgKey" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="BldgKey" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="BldgKey" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="IN_BldgKey" TOINSTANCE="lkp_BLDG" TOINSTANCETYPE="Lookup Procedure"/>
        <CONNECTOR FROMFIELD="SqFt" FROMINSTANCE="lkp_BLDG" FROMINSTANCETYPE="Lookup Procedure" TOFIELD="SqFtOut" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "SqFtOut")!;
    expect(row.source_datatype).toBe("numeric");
    expect(row.source_precision).toBe("12");
    expect(row.source_scale).toBe("2");
  });

  // Bug C regression guard: unconnected :LKP.NAME(args) call where the
  // lookup's underlying SOURCE def is NOT present. Previously firstResolved
  // got the lookup port's varchar default and propagated as sourceDataType.
  // Fix: only set firstResolved when trueType is found; let other args win.
  it("Bug C: unconnected :LKP.X(SystemId) lets SystemId arg's true datatype win", () => {
    // Lookup `LKP_LIMIT` is defined in the XML but its source table
    // ("EXT_LIMIT") is NOT registered as a SOURCE — Phase A.1 returns null.
    // Expression `:LKP.LKP_LIMIT(SystemId)` arg SystemId IS connected to
    // an SQ port whose upstream SOURCE field is int4. The row should
    // surface int4, not the lookup's varchar(765) default.
    const xml = buildXml(`
      <SOURCE NAME="STG">
        <SOURCEFIELD NAME="SystemId" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT">
        <TARGETFIELD NAME="OutLimit" DATATYPE="varchar" PRECISION="100" FIELDNUMBER="1"/>
      </TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="SystemId" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="LKP_LIMIT" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_SystemId" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="Limit" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="varchar" PRECISION="765"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="EXT_LIMIT"/>
          <TABLEATTRIBUTE NAME="Lookup condition" VALUE="SystemId = IN_SystemId"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="SystemId" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="OUT" PORTTYPE="OUTPUT" DATATYPE="varchar" PRECISION="100" EXPRESSION=":LKP.LKP_LIMIT(SystemId)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="LKP_LIMIT" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="LKP_LIMIT" TRANSFORMATION_TYPE="Lookup Procedure"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="SystemId" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="SystemId" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="SystemId" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="SystemId" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="OUT" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="OutLimit" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "OutLimit")!;
    // SystemId's int4 from STG should win — NOT the lookup port's varchar(765).
    expect(row.source_datatype).toBe("int4");
    // Note must explain that the lookup port datatype was suppressed.
    expect(row.notes ?? "").toMatch(/not used as source/i);
  });
});
