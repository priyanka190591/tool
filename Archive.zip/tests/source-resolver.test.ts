import { describe, it, expect } from "vitest";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildLineage } from "@/lib/lineage";

/**
 * Verifies the spec's 6-step Source Table priority chain and the Hard Source
 * Table Rule (no IDMC technical wrappers when a cleaner XML-supported name
 * exists). Built as synthetic XMLs so each rule can be exercised in isolation.
 */

function makeXml(opts: {
  sourceName?: string;
  sourceAttrs?: string;
  sqSqlOverride?: string;
}): string {
  const escapeAttr = (s: string) =>
    s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const sourceName = opts.sourceName ?? "SRC";
  const sourceNameAttr = escapeAttr(sourceName);
  const sourceAttrs = opts.sourceAttrs ?? "";
  const sqAttrs = opts.sqSqlOverride
    ? `<TABLEATTRIBUTE NAME="Sql Query" VALUE="${escapeAttr(opts.sqSqlOverride)}"/>`
    : "";
  return `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      <SOURCE NAME="${sourceNameAttr}" ${sourceAttrs}>
        <SOURCEFIELD NAME="X" DATATYPE="integer" PRECISION="10" FIELDNUMBER="1"/>
      </SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="integer" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="integer" PRECISION="10"/>
          ${sqAttrs}
        </TRANSFORMATION>
        <INSTANCE NAME="${sourceNameAttr}" TYPE="SOURCE" TRANSFORMATION_NAME="${sourceNameAttr}"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMINSTANCE="${sourceNameAttr}" FROMINSTANCETYPE="Source Definition" FROMFIELD="X" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier" TOFIELD="X"/>
        <CONNECTOR FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" FROMFIELD="X" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition" TOFIELD="Y"/>
      </MAPPING>
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
}

function resolve(xml: string): string {
  const s = parseSessionsFromXml("synthetic.xml", xml)[0];
  return buildLineage(s)[0].sourceTable;
}

describe("Source Table priority chain (rules 1–6)", () => {
  it("priority 1 — SQL Override FROM clause beats SOURCE NAME", () => {
    const xml = makeXml({
      sourceName: "DUMMY_SRC_QUERY",
      sqSqlOverride: "SELECT X FROM REAL_SCHEMA.REAL_TABLE WHERE X > 0",
    });
    expect(resolve(xml)).toBe("REAL_SCHEMA.REAL_TABLE");
  });

  it("priority 1 — SQL Override extracts all FROM and JOIN tables", () => {
    const xml = makeXml({
      sourceName: "DUMMY_SRC_QUERY",
      sqSqlOverride: "SELECT a.X FROM EMP a JOIN DEPT d ON a.dept_id = d.id LEFT JOIN LOC l ON l.id = d.loc_id",
    });
    expect(resolve(xml)).toBe("EMP, DEPT, LOC");
  });

  it("priority 1 — SQL Override skips subqueries (paren after FROM does not match)", () => {
    const xml = makeXml({
      sourceName: "DUMMY_SRC_QUERY",
      sqSqlOverride: "SELECT X FROM (SELECT X FROM INNER_TBL) sub",
    });
    // Only INNER_TBL gets captured — outer FROM (... is not an identifier.
    expect(resolve(xml)).toBe("INNER_TBL");
  });

  it("priority 2 — BUSINESSNAME wins when SOURCE NAME is a wrapper", () => {
    const xml = makeXml({
      sourceName: "DUMMY_SRC_QUERY",
      sourceAttrs: 'BUSINESSNAME="REAL_BUSINESS_TABLE"',
    });
    expect(resolve(xml)).toBe("REAL_BUSINESS_TABLE");
  });

  it("priority 3 — REFERENCEDTABLE wins when no BUSINESSNAME", () => {
    const xml = makeXml({
      sourceName: "DUMMY_SRC_QUERY",
      sourceAttrs: 'REFERENCEDTABLE="REF_TBL" REFERENCEDDBD="MY_DB"',
    });
    expect(resolve(xml)).toBe("MY_DB.REF_TBL");
  });

  it("priority 3 — REFERENCEDTABLE without REFERENCEDDBD is unqualified", () => {
    const xml = makeXml({
      sourceName: "DUMMY_SRC_QUERY",
      sourceAttrs: 'REFERENCEDTABLE="REF_TBL"',
    });
    expect(resolve(xml)).toBe("REF_TBL");
  });

  it("priority 5 — SOURCE NAME used unchanged when it's not a wrapper and no overrides", () => {
    const xml = makeXml({ sourceName: "REAL_TABLE" });
    expect(resolve(xml)).toBe("REAL_TABLE");
  });

  it("priority 6 — DUMMY_<table> falls through to cleaned name", () => {
    const xml = makeXml({ sourceName: "DUMMY_PAY_PERIOD" });
    expect(resolve(xml)).toBe("PAY_PERIOD");
  });

  it("priority 6 — DUMMY_SQ_<table> strips both prefixes", () => {
    const xml = makeXml({ sourceName: "DUMMY_SQ_EMP" });
    expect(resolve(xml)).toBe("EMP");
  });

  it("priority 6 — SQ_<table> strips SQ_ prefix", () => {
    const xml = makeXml({ sourceName: "SQ_DEPT" });
    expect(resolve(xml)).toBe("DEPT");
  });

  it("priority 6 — SQ_SHORTCUT_<table> strips compound prefix", () => {
    const xml = makeXml({ sourceName: "SQ_SHORTCUT_ORDERS" });
    expect(resolve(xml)).toBe("ORDERS");
  });

  it("strips surrounding double quotes (Oracle-style case-sensitive names)", () => {
    const xml = makeXml({ sourceName: '"adv_prod_dw"' });
    expect(resolve(xml)).toBe("adv_prod_dw");
  });

  it("strips surrounding quotes AND wrapper prefix together", () => {
    const xml = makeXml({ sourceName: '"DUMMY_SQ_glclass"' });
    expect(resolve(xml)).toBe("glclass");
  });

  it("strips surrounding backticks (MySQL-style)", () => {
    const xml = makeXml({ sourceName: "`mysql_table`" });
    expect(resolve(xml)).toBe("mysql_table");
  });

  it("priority 1 — SQL Override FROM extracts wrapper-prefixed names AND cleans them", () => {
    // Real-world IDMC pattern: SQ override literally references the wrapped
    // SOURCE name (e.g. FROM DUMMY_SQ_risk_stg). The Hard Rule still applies —
    // we must NOT leak the wrapper into Source Table.
    const xml = makeXml({
      sourceName: "SRC",
      sqSqlOverride: "SELECT X FROM DUMMY_SQ_risk_stg WHERE X > 0",
    });
    expect(resolve(xml)).toBe("risk_stg");
  });

  it("priority 1 — SQL Override JOIN tables all get cleaned", () => {
    const xml = makeXml({
      sourceName: "SRC",
      sqSqlOverride: "SELECT * FROM SQ_emp e JOIN DUMMY_dept d ON e.dept_id = d.id",
    });
    expect(resolve(xml)).toBe("emp, dept");
  });
});

describe("Hard Source Table Rule (no technical wrappers leak)", () => {
  it("BUSINESSNAME of 'DUMMY_FOO' is itself a wrapper — falls through, not trusted", () => {
    // If BUSINESSNAME is also a wrapper, don't trust it; fall through to next rule.
    const xml = makeXml({
      sourceName: "REAL_NAME",
      sourceAttrs: 'BUSINESSNAME="DUMMY_NOT_REAL"',
    });
    expect(resolve(xml)).toBe("REAL_NAME");
  });

  it("non-strippable wrapper (e.g. DUMMY_ followed by gibberish) falls back to original", () => {
    // cleanWrapperPrefix only strips when the remainder is a valid identifier.
    // DUMMY_ with nothing after it would strip to empty → keep original.
    const xml = makeXml({ sourceName: "DUMMY_" });
    expect(resolve(xml)).toBe("DUMMY_");
  });
});

describe("Real fixture: SQ SQL Override resolution", () => {
  it("sales fixture: SQ FROM STAGE.STG_SALES surfaces as STAGE.STG_SALES", async () => {
    const fs = await import("node:fs/promises");
    const path = await import("node:path");
    const xml = await fs.readFile(
      path.join(process.cwd(), "public", "sessions", "Sales", "s_SALES_DIM_FULL.xml"),
      "utf8",
    );
    const s = parseSessionsFromXml("s_SALES_DIM_FULL.xml", xml)[0];
    const saleId = buildLineage(s).find((r) => r.targetColumn === "SALE_ID")!;
    expect(saleId.sourceTable).toBe("STAGE.STG_SALES");
  });
});
