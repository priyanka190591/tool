// Diagnostic test — NOT a unit test. Skipped unless UA_XML_PATH is set.
//
// Usage:
//   UA_XML_PATH=/abs/path/to/prod.xml npx vitest run tests/_diagnose.test.ts
//   UA_XML_PATH=/abs/path/to/prod.xml UA_ROW=sqfeetarea npx vitest run tests/_diagnose.test.ts
//
// For every FIELD_MAPPING row where Source Table is unresolved
// (null / "(computed)" / "(not wired)" / "(unresolved ...)"), prints:
//   • target column, load type, transformation path, captured expression
//   • lastInstance/lastField — where the walk dead-ended
//   • the ports that EXIST on the dead-end instance
//   • the CONNECTORs targeting that instance (so you can see what's wired in)
//   • for each identifier in the expression: whether our variant resolver
//     would find a match, and if not, the variants it tried
//
// UA_ROW filters to target columns whose name contains the substring.
// UA_LIMIT caps the number of rows printed (default 20).

import { describe, it } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildLineage } from "@/lib/lineage";
import { buildMappingJson } from "@/lib/build-mapping-json";
import { isFieldMappingUnresolved } from "@/lib/mapping-schema";

const XML_PATH = process.env.UA_XML_PATH;
const ROW_FILTER = (process.env.UA_ROW || "").toLowerCase();
const LIMIT = Number(process.env.UA_LIMIT || "20");

const KNOWN_FUNCTIONS = new Set([
  "TO_CHAR", "TO_DATE", "TO_NUMBER", "TO_INTEGER", "TO_DECIMAL", "TO_BIGINT",
  "IIF", "DECODE", "NVL", "COALESCE", "ISNULL", "IS_NULL", "TRIM", "LTRIM", "RTRIM",
  "UPPER", "LOWER", "INITCAP", "SUBSTR", "SUBSTRING", "REPLACE", "INSTR", "LENGTH",
  "LPAD", "RPAD", "CONCAT", "ABS", "ROUND", "TRUNC", "FLOOR", "CEIL", "MOD",
  "SUM", "COUNT", "AVG", "MAX", "MIN", "MEDIAN", "FIRST", "LAST", "PERCENTILE",
  "SYSDATE", "SYSTIMESTAMP", "SESSSTARTTIME", "CURRENT_DATE", "CURRENT_TIMESTAMP",
  "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "NULL", "TRUE", "FALSE",
]);

function extractIdentifiers(expr: string): string[] {
  const ids = new Set<string>();
  const re = /[A-Za-z_][A-Za-z0-9_]*/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(expr))) ids.add(m[0]);
  return [...ids];
}

describe.skipIf(!XML_PATH)("[diagnostic] unresolved rows in prod XML", () => {
  it("prints diagnosis for each unresolved row", async () => {
    const xml = await fs.readFile(path.resolve(XML_PATH!), "utf8");
    const sessions = parseSessionsFromXml(path.basename(XML_PATH!), xml);

    for (const session of sessions) {
      const mapping = buildMappingJson(session);
      const lineage = buildLineage(session);
      // Group lineage rows by target column; some rows have multiple branches
      // (INSERT + UPDATE) — we just want one trace per (table, column) for
      // diagnosis context.
      const lineageByCol = new Map<string, (typeof lineage)[number][]>();
      for (const l of lineage) {
        const k = `${l.targetTable}::${l.targetColumn}`;
        const arr = lineageByCol.get(k) ?? [];
        arr.push(l);
        lineageByCol.set(k, arr);
      }

      const incomingByInstance = new Map<string, typeof session.mapping.connectors>();
      for (const c of session.mapping.connectors) {
        const arr = incomingByInstance.get(c.toInstance) ?? [];
        arr.push(c);
        incomingByInstance.set(c.toInstance, arr);
      }
      const txByName = new Map(session.mapping.transformations.map((t) => [t.name, t]));

      const unresolved = mapping.field_mappings.filter((r) => {
        if (ROW_FILTER && !(r.target_column || "").toLowerCase().includes(ROW_FILTER)) {
          return false;
        }
        return isFieldMappingUnresolved(r);
      });

      console.log(`\n=== ${session.fileName} :: ${session.sessionName ?? session.mappingName} ===`);
      console.log(`  total field_mappings: ${mapping.field_mappings.length}`);
      console.log(`  unresolved: ${unresolved.length}${ROW_FILTER ? ` (filter="${ROW_FILTER}")` : ""}`);
      console.log(`  showing first ${Math.min(LIMIT, unresolved.length)}`);

      for (const r of unresolved.slice(0, LIMIT)) {
        const candidates = lineageByCol.get(`${r.target_table}::${r.target_column}`) ?? [];
        // Prefer the lineage row whose load_type matches; fall back to first.
        const trace =
          candidates.find((c) => (c.loadType ?? "") === (r.load_type ?? "")) ??
          candidates[0];
        console.log(`\n  ─── ${r.target_table}.${r.target_column}  (loadType=${r.load_type ?? "?"})`);
        console.log(`      source_table  = ${r.source_table}`);
        console.log(`      source_column = ${r.source_column}`);
        console.log(`      expression    = ${(r.business_logic_expression || "").slice(0, 250)}`);
        console.log(`      path          = ${r.transformation_path}`);
        if (!trace) {
          console.log(`      (no matching lineage row — orphan?)`);
          continue;
        }
        if (!trace.lastInstance) {
          console.log(`      lastInstance  = (none — walk found no incoming connector at the target instance; check target wiring)`);
          continue;
        }
        console.log(`      lastInstance  = ${trace.lastInstance}`);
        console.log(`      lastField     = ${trace.lastField}`);
        const lastInst = trace.lastInstance;
        const lastTx = txByName.get(lastInst);
        if (lastTx) {
          console.log(`      ports on ${lastInst}:`);
          for (const f of lastTx.fields.slice(0, 30)) {
            console.log(`        - ${f.name}  [${f.portType ?? ""}]${f.expression ? `  EXPRESSION="${f.expression.slice(0, 60)}"` : ""}`);
          }
          if (lastTx.fields.length > 30) {
            console.log(`        ... (${lastTx.fields.length - 30} more)`);
          }
        } else {
          console.log(`      (instance ${lastInst} not in txByName — SOURCE/TARGET or mapplet)`);
        }
        const incoming = incomingByInstance.get(lastInst) ?? [];
        if (incoming.length > 0) {
          console.log(`      connectors targeting ${lastInst}:`);
          for (const c of incoming.slice(0, 30)) {
            console.log(`        - ${c.fromInstance}.${c.fromField}  →  ${lastInst}.${c.toField}`);
          }
          if (incoming.length > 30) console.log(`        ... (${incoming.length - 30} more)`);
        } else {
          console.log(`      no connectors target ${lastInst}`);
        }

        // Per-identifier variant analysis on the expression.
        const expr = trace.expression || "";
        if (expr && lastTx) {
          const inputPortNames = lastTx.fields
            .filter((f) => /INPUT/i.test(f.portType || ""))
            .map((f) => f.name);
          const ids = extractIdentifiers(expr).filter(
            (id) => !KNOWN_FUNCTIONS.has(id.toUpperCase()),
          );
          if (ids.length > 0) {
            console.log(`      identifiers in expression:`);
            for (const id of ids) {
              const exact = inputPortNames.includes(id);
              const prefixHit = ["in_", "IN_", "i_", "input_", "INPUT_"]
                .map((p) => `${p}${id}`)
                .find((v) => inputPortNames.includes(v));
              const ciHit = inputPortNames.find((n) => n.toLowerCase() === id.toLowerCase());
              const wfHit = inputPortNames.find(
                (n) => n.toLowerCase().replace(/_/g, "") === id.toLowerCase().replace(/_/g, ""),
              );
              const hit = exact
                ? `EXACT: ${id}`
                : prefixHit
                  ? `prefix-add: ${prefixHit}`
                  : ciHit
                    ? `case-fold: ${ciHit}`
                    : wfHit
                      ? `word-form: ${wfHit}`
                      : `NO MATCH — candidate input ports: ${inputPortNames.slice(0, 10).join(", ")}${inputPortNames.length > 10 ? "…" : ""}`;
              console.log(`        - "${id}"  →  ${hit}`);
            }
          }
        }
      }
    }
  });
});
