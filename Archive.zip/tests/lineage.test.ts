import { describe, it, expect, beforeAll } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import type { ParsedSession } from "@/lib/sessions-types";
import { buildLineage, type LineageRow } from "@/lib/lineage";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadSessionByName(file: string, sessionName?: string): Promise<ParsedSession> {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  const all = parseSessionsFromXml(path.basename(file), xml);
  if (sessionName) {
    const s = all.find((x) => x.name === sessionName);
    if (!s) throw new Error(`Session ${sessionName} not found in ${file}`);
    return s;
  }
  return all[0];
}

function findRow(rows: LineageRow[], table: string, column: string): LineageRow {
  const r = rows.find((x) => x.targetTable === table && x.targetColumn === column);
  if (!r) throw new Error(`Row not found: ${table}.${column}`);
  return r;
}

describe("buildLineage — direct resolution", () => {
  let sales: LineageRow[];
  beforeAll(async () => {
    sales = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
  });

  it("emits one row per target field in the mapping", () => {
    expect(sales.length).toBe(8);
  });

  it("resolves a direct source-qualifier passthrough column", () => {
    const r = findRow(sales, "FACT_SALES", "SALE_ID");
    // SQ has SQL Override "SELECT ... FROM STAGE.STG_SALES ..." — priority 1
    // resolves the source table to the fully qualified name from FROM clause.
    expect(r.sourceTable).toBe("STAGE.STG_SALES");
    expect(r.sourceColumn).toBe("SALE_ID");
    expect(r.transformationPath).toContain("FACT_SALES");
    expect(r.transformationPath).toContain("STG_SALES");
  });

  it("matches every target datatype to the mapping target definition", () => {
    for (const r of sales) {
      expect(r.targetDataType).not.toBe("");
    }
  });
});

describe("buildLineage — expression-port walking (multi-source)", () => {
  it("resolves a computed column to all upstream source columns", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "NET_AMOUNT");
    expect(r.expression).toMatch(/ROUND\(QTY \* UNIT_PRICE/);
    // SQ SQL Override → STAGE.STG_SALES wins priority 1
    expect(r.sourceTable).toBe("STAGE.STG_SALES");
    const cols = r.sourceColumn.split("/").sort();
    expect(cols).toEqual(["DISCOUNT_PCT", "QTY", "UNIT_PRICE"]);
  });

  it("walks through TRUNC() to resolve to a source column", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "SALE_DT");
    expect(r.expression).toContain("TRUNC");
    expect(r.sourceTable).toBe("STAGE.STG_SALES");
    expect(r.sourceColumn).toBe("SALE_TS");
  });

  it("walks an aggregator's COUNT() back to its input source", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Build_Message_Counters"));
    const r = findRow(rows, "COUNTER_TBL", "COUNTER_VALUE");
    expect(r.sourceTable).toBe("U0287D01");
    expect(r.aggregatorsUsed).toContain("agg_ALL_RECORDS");
  });
});

describe("buildLineage — lookup port resolution", () => {
  it("resolves a column whose expression references a lookup output port", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Load_COMP_TIME_DAILY_TBL"));
    const r = findRow(rows, "COMP_TIME_DAILY_TBL", "PP_END_YEAR");
    expect(r.sourceTable).toBe("PAY_PERIOD");
    expect(r.lookupsUsed).not.toBe("");
  });

  it("resolves a multi-lookup-port expression to the same lookup table", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Load_COMP_TIME_DAILY_TBL"));
    const r = findRow(rows, "COMP_TIME_DAILY_TBL", "PP_YEAR_NUM");
    expect(r.sourceTable).toBe("PAY_PERIOD");
    // The composed expression that pulls from both lookup ports lives in the chain
    expect(r.expressionChain).toContain("lkp_PP_END_YEAR");
  });

  it("includes the lookup table AND the upstream key-source tables for connected lookups", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "CUSTOMER_KEY");
    // Lookup table contributes the table + the read output column.
    expect(r.sourceTable).toContain("DIM_CUSTOMER");
    expect(r.sourceColumn).toContain("CUSTOMER_KEY");
    // Lookup KEY (IN_CUSTOMER_ID) traces back through EXP_CALC.CUSTOMER_ID to
    // STAGE.STG_SALES (resolved via the SQ's SQL Override FROM clause).
    expect(r.sourceTable).toContain("STG_SALES"); // STAGE.STG_SALES is a superset of "STG_SALES"
    expect(r.sourceColumn).toContain("CUSTOMER_ID");
    expect(r.lookupsUsed).toContain("LKP_CUSTOMER");
  });
});

describe("buildLineage — blank-source classification", () => {
  it("labels SYSTIMESTAMP-derived columns as (computed) with the expression in Source Column", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "LOAD_TS");
    expect(r.sourceTable).toBe("(computed)");
    expect(r.sourceColumn).toMatch(/SYSTIMESTAMP/i);
    expect(r.expression).toMatch(/SYSTIMESTAMP/i);
  });

  it("labels truly disconnected target columns as (not wired)", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "PRODUCT_KEY");
    expect(r.sourceTable).toBe("(not wired)");
    expect(r.expression).toBe("");
  });

  it("labels string-literal expressions as (computed) with the literal in Source Column", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Build_Message_Counters"));
    const r = findRow(rows, "COUNTER_TBL", "COUNTER_DESCRIPTION");
    expect(r.sourceTable).toBe("(computed)");
    expect(r.sourceColumn).toMatch(/^'.*'$/);
  });

  it("labels port-wired but upstream-dead columns as (computed)", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Build_Message_Counters"));
    const r = findRow(rows, "COUNTER_TBL", "RUN_DATE");
    expect(r.sourceTable).toBe("(computed)");
  });
});

describe("buildLineage — connection column propagation", () => {
  it("populates Target Connection from CONNECTIONREFERENCE", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    for (const r of rows) {
      expect(r.targetConnection).toBe("ORACLE_EDW");
      expect(r.targetConnectionType).toBe("Relational");
    }
  });

  it("populates Source Connection for SQ-sourced rows", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "SALE_ID");
    expect(r.sourceConnection).toBe("SNOWFLAKE_STAGE");
  });

  it("propagates Source Connection through expression-port walking", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "NET_AMOUNT");
    expect(r.sourceConnection).toBe("SNOWFLAKE_STAGE");
  });

  it("falls back to lookup connection for lookup-sourced rows", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "CUSTOMER_KEY");
    expect(r.sourceConnection).toBe("ORACLE_EDW");
    expect(r.sourceConnectionType).toBe("Relational");
  });

  it("leaves Source Connection blank for system-value / constant / not-wired rows", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "LOAD_TS");
    expect(r.sourceConnection).toBe("");
  });
});

describe("buildLineage — CDQ dimension inference", () => {
  it("infers Accuracy for direct source passthrough", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "SALE_ID");
    // CDQ values no longer carry the inline "[heuristic] " prefix —
    // the (heuristic) disclaimer lives in the column header instead.
    expect(r.cdqDimension).toMatch(/Accuracy/);
  });

  it("infers Accuracy for lookup-sourced rows (reference data validation)", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "CUSTOMER_KEY");
    expect(r.cdqDimension).toMatch(/Accuracy/);
  });

  it("infers Completeness when expression uses NVL/ISNULL", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "NET_AMOUNT");
    expect(r.cdqDimension).toMatch(/Completeness/);
  });

  it("infers Consistency when path includes an Aggregator", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Build_Message_Counters"));
    const r = findRow(rows, "COUNTER_TBL", "COUNTER_VALUE");
    expect(r.cdqDimension).toMatch(/Consistency/);
  });

  it("infers Conformity when expression uses IS_DATE", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Load_COMP_TIME_DAILY_TBL"));
    const r = findRow(rows, "COMP_TIME_DAILY_TBL", "PP_END_DATE");
    expect(r.cdqDimension).toMatch(/Conformity/);
  });

  it("leaves cdqDimension empty for (not wired) rows; classifies (computed) rows", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const notWired = findRow(rows, "FACT_SALES", "PRODUCT_KEY");
    expect(notWired.cdqDimension).toBe("");
    // (computed) rows still get a dimension (system-value LOAD_TS counts as Timeliness)
    const loadTs = findRow(rows, "FACT_SALES", "LOAD_TS");
    expect(loadTs.cdqDimension).toMatch(/Timeliness/);
  });

  it("never emits the legacy '[heuristic] ' inline prefix on cdqDimension values", async () => {
    // The (heuristic) disclaimer lives in the column header; cells must NOT
    // repeat the prefix anymore. Pinning this so the prefix can't sneak back.
    for (const file of ["Sales/s_SALES_DIM_FULL.xml", "COMPTIME.xml"]) {
      const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
      for (const s of parseSessionsFromXml(path.basename(file), xml)) {
        for (const r of buildLineage(s)) {
          if (r.cdqDimension) {
            expect(r.cdqDimension.startsWith("[heuristic]"), `${file}:${r.targetTable}.${r.targetColumn}`).toBe(false);
          }
        }
      }
    }
  });
});

describe("buildLineage — CDQ rule inference", () => {
  it("detects NULL_DEFAULT from NVL(...)", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "NET_AMOUNT");
    expect(r.cdqRule).toMatch(/NULL_DEFAULT/);
  });

  it("detects DATE_PARSE_CHECK with format mask from IS_DATE(..., 'YYYYMMDD')", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Load_COMP_TIME_DAILY_TBL"));
    const r = findRow(rows, "COMP_TIME_DAILY_TBL", "PP_END_DATE");
    expect(r.cdqRule).toMatch(/DATE_PARSE_CHECK\[YYYYMMDD\]/);
  });

  it("detects REFERENCE_LOOKUP when a lookup is used", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "CUSTOMER_KEY");
    expect(r.cdqRule).toMatch(/REFERENCE_LOOKUP/);
  });

  it("detects RECORD_COUNT from COUNT() in an aggregator", async () => {
    const rows = buildLineage(await loadSessionByName("COMPTIME.xml", "s_COMPTIME_Build_Message_Counters"));
    const r = findRow(rows, "COUNTER_TBL", "COUNTER_VALUE");
    expect(r.cdqRule).toMatch(/RECORD_COUNT/);
  });

  it("detects ROUND from a ROUND() expression", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    const r = findRow(rows, "FACT_SALES", "NET_AMOUNT");
    expect(r.cdqRule).toMatch(/ROUND/);
  });

  it("leaves cdqRule empty for unresolved rows", async () => {
    const rows = buildLineage(await loadSessionByName("Sales/s_SALES_DIM_FULL.xml"));
    expect(findRow(rows, "FACT_SALES", "PRODUCT_KEY").cdqRule).toBe("");
    // LOAD_TS is (computed) but the SYSTIMESTAMP expression yields LOAD_TIMESTAMP rule
    expect(findRow(rows, "FACT_SALES", "LOAD_TS").cdqRule).toMatch(/LOAD_TIMESTAMP/);
  });

  it("never emits the legacy '[heuristic] ' inline prefix on cdqRule values", async () => {
    for (const file of ["Sales/s_SALES_DIM_FULL.xml", "COMPTIME.xml"]) {
      const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
      for (const s of parseSessionsFromXml(path.basename(file), xml)) {
        for (const r of buildLineage(s)) {
          if (r.cdqRule) {
            expect(r.cdqRule.startsWith("[heuristic]"), `${file}:${r.targetTable}.${r.targetColumn}`).toBe(false);
          }
        }
      }
    }
  });
});

describe("buildLineage — invariants across all fixtures", () => {
  it("never returns rows with a blank Source Table cell", async () => {
    for (const file of ["Sales/s_SALES_DIM_FULL.xml", "COMPTIME.xml"]) {
      const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
      for (const s of parseSessionsFromXml(path.basename(file), xml)) {
        for (const r of buildLineage(s)) {
          expect(r.sourceTable, `${file}/${s.name}: ${r.targetTable}.${r.targetColumn} had blank sourceTable`).not.toBe("");
        }
      }
    }
  });

  it("emits exactly one row per target field across all full-mapping sessions", async () => {
    for (const file of ["Sales/s_SALES_DIM_FULL.xml", "COMPTIME.xml"]) {
      const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
      for (const s of parseSessionsFromXml(path.basename(file), xml)) {
        if (!s.mapping) continue;
        const rows = buildLineage(s);
        const targetInstances = s.mapping.instances.filter((i) => /target/i.test(i.type));
        let expected = 0;
        if (targetInstances.length > 0) {
          for (const ti of targetInstances) {
            const def = s.mapping.targets.find((t) => t.name === (ti.transformationName ?? ti.name));
            if (def) expected += def.fields.length;
          }
        } else {
          expected = s.mapping.targets.reduce((a, t) => a + t.fields.length, 0);
        }
        expect(rows.length, `${file}/${s.name}`).toBe(expected);
      }
    }
  });
});
