import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";

// Pins the three FIELD_MAPPING enhancements:
//   1. source_database / target_database columns from CONNECTIONREFERENCE
//   2. parameter_file regex broadening + parameters list fallback
//   3. sq_sql_query population independent of the backward walk

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function loadFirst(file: string) {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(path.basename(file), xml)[0];
}

function buildXml(body: string): string {
  return `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      ${body}
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
}

describe("Source Database / Target Database columns", () => {
  it("populates from CONNECTIONREFERENCE nested inside SESSIONEXTENSION (real IDMC shape)", () => {
    // Real IDMC XMLs put <CONNECTIONREFERENCE> INSIDE <SESSIONEXTENSION>,
    // with the parent's SINSTANCENAME identifying which instance the
    // connection ref applies to. The CONNECTIONREFERENCE itself has no
    // SESSIONEXTENSIONNAME / INSTANCENAME attribute. Also: CONNECTIONNAME
    // is the actual connection (e.g. "INFO_TARGET"), CNXREFNAME is a role
    // label ("DB Connection") — easy to confuse.
    const xml = buildXml(`
      <SOURCE NAME="STG"><SOURCEFIELD NAME="X" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT X FROM STG"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="Y" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s">
        <SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/>
        <SESSIONEXTENSION NAME="Relational Reader" SINSTANCENAME="SQ_STG" TRANSFORMATIONTYPE="Source Qualifier" TYPE="READER">
          <CONNECTIONREFERENCE CNXREFNAME="DB Connection" CONNECTIONNAME="EDW_PROD_SRC" CONNECTIONTYPE="Relational" CONNECTIONSUBTYPE="Oracle"/>
        </SESSIONEXTENSION>
        <SESSIONEXTENSION NAME="Relational Writer" SINSTANCENAME="TGT" TRANSFORMATIONTYPE="Target Definition" TYPE="WRITER">
          <CONNECTIONREFERENCE CNXREFNAME="DB Connection" CONNECTIONNAME="EDW_PROD_TGT" CONNECTIONTYPE="Relational" CONNECTIONSUBTYPE="Oracle"/>
        </SESSIONEXTENSION>
      </SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "Y" && r.is_used === "YES")!;
    // Must use CONNECTIONNAME ("EDW_PROD_SRC"), not the CNXREFNAME label
    // ("DB Connection").
    expect(row.source_database).toBe("EDW_PROD_SRC");
    expect(row.target_database).toBe("EDW_PROD_TGT");
  });

  it("populates from CONNECTIONREFERENCE entries", () => {
    const xml = buildXml(`
      <SOURCE NAME="STG"><SOURCEFIELD NAME="X" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT X FROM STG"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="Y" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s">
        <SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/>
        <CONNECTIONREFERENCE CNXREFNAME="EDW_PROD_SRC" CONNECTIONTYPE="Oracle" SESSIONEXTENSIONNAME="SQ_STG" REFOBJECTTYPE="Source Qualifier"/>
        <CONNECTIONREFERENCE CNXREFNAME="EDW_PROD_TGT" CONNECTIONTYPE="Oracle" SESSIONEXTENSIONNAME="TGT" REFOBJECTTYPE="Target Definition"/>
      </SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "Y" && r.is_used === "YES")!;
    expect(row.source_database).toBe("EDW_PROD_SRC");
    expect(row.target_database).toBe("EDW_PROD_TGT");
  });
});

describe("Parameter File regex broadening", () => {
  it("matches the canonical 'Parameter Filename' attribute", async () => {
    const session = await loadFirst("Sales/s_SALES_DIM_FULL.xml");
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.is_used === "YES")!;
    expect(row.parameter_file ?? "").toMatch(/\.param$/);
  });

  it("matches the abbreviated 'Param Filename' vendor variant", () => {
    const xml = buildXml(`
      <SOURCE NAME="A"><SOURCEFIELD NAME="X" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Y" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <INSTANCE NAME="A" TYPE="SOURCE" TRANSFORMATION_NAME="A"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="A" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="Y" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s">
        <SESSTRANSFORMATIONINST NAME="A" TRANSFORMATIONTYPE="Source Definition"/>
        <ATTRIBUTE NAME="Param Filename" VALUE="$PMRootDir/Param/s_test.param"/>
      </SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.is_used === "YES")!;
    expect(row.parameter_file).toBe("$PMRootDir/Param/s_test.param");
  });
});

describe("SQ SQL Query — populated independent of walk", () => {
  it("surfaces the only-SQ's SQL for lookup-fed rows that don't visit any SQ", () => {
    // Lookup is invoked unconnectedly; walk doesn't reach the SQ. The
    // mapping has one SQ — its SQL should be the SQ SQL Query value.
    const xml = buildXml(`
      <SOURCE NAME="STG"><SOURCEFIELD NAME="Id" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT"><TARGETFIELD NAME="Out" DATATYPE="varchar" PRECISION="100" FIELDNUMBER="1"/></TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="Id" PORTTYPE="INPUT/OUTPUT" DATATYPE="int4" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT Id FROM STG WHERE active = 1"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="lkp_LIMIT" TYPE="Lookup Procedure">
          <TRANSFORMFIELD NAME="IN_Id" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="Limit" PORTTYPE="LOOKUP/OUTPUT" DATATYPE="varchar" PRECISION="100"/>
          <TABLEATTRIBUTE NAME="Lookup table name" VALUE="EXT_LIMIT"/>
          <TABLEATTRIBUTE NAME="Lookup Sql Override" VALUE="SELECT Limit FROM EXT_LIMIT"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="Id" PORTTYPE="INPUT" DATATYPE="int4" PRECISION="10"/>
          <TRANSFORMFIELD NAME="Out" PORTTYPE="OUTPUT" DATATYPE="varchar" PRECISION="100" EXPRESSION=":LKP.lkp_LIMIT(Id)"/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG" TYPE="SOURCE" TRANSFORMATION_NAME="STG"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="lkp_LIMIT" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="lkp_LIMIT" TRANSFORMATION_TYPE="Lookup Procedure"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="Id" FROMINSTANCE="STG" FROMINSTANCETYPE="Source Definition" TOFIELD="Id" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="Id" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="Id" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="Out" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="Out" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="STG" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "Out" && r.is_used === "YES")!;
    expect(row.sq_sql_query ?? "").toContain("SELECT Id FROM STG WHERE active = 1");
  });

  it("leaves sq_sql_query null for pure literal rows even when one SQ exists", () => {
    // Target column is a hardcoded literal — the sole-SQ fallback shouldn't
    // attribute the SQ's SQL to it (it has no data dependence on the SQ).
    const xml = buildXml(`
      <SOURCE NAME="A"><SOURCEFIELD NAME="X" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/></SOURCE>
      <TARGET NAME="TGT">
        <TARGETFIELD NAME="DataField" DATATYPE="string" PRECISION="10" FIELDNUMBER="1"/>
        <TARGETFIELD NAME="LiteralField" DATATYPE="string" PRECISION="10" FIELDNUMBER="2"/>
      </TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT/OUTPUT" DATATYPE="string" PRECISION="10"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE="SELECT X FROM A"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP" TYPE="Expression">
          <TRANSFORMFIELD NAME="X" PORTTYPE="INPUT" DATATYPE="string" PRECISION="10"/>
          <TRANSFORMFIELD NAME="DataOut" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="10" EXPRESSION="X"/>
          <TRANSFORMFIELD NAME="LitOut" PORTTYPE="OUTPUT" DATATYPE="string" PRECISION="10" EXPRESSION="'Y'"/>
        </TRANSFORMATION>
        <INSTANCE NAME="A" TYPE="SOURCE" TRANSFORMATION_NAME="A"/>
        <INSTANCE NAME="SQ" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="EXP" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="EXP" TRANSFORMATION_TYPE="Expression"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="A" FROMINSTANCETYPE="Source Definition" TOFIELD="X" TOINSTANCE="SQ" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="X" FROMINSTANCE="SQ" FROMINSTANCETYPE="Source Qualifier" TOFIELD="X" TOINSTANCE="EXP" TOINSTANCETYPE="Expression"/>
        <CONNECTOR FROMFIELD="DataOut" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="DataField" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
        <CONNECTOR FROMFIELD="LitOut" FROMINSTANCE="EXP" FROMINSTANCETYPE="Expression" TOFIELD="LiteralField" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="A" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const dataRow = m.field_mappings.find((r) => r.target_column === "DataField" && r.is_used === "YES")!;
    const literalRow = m.field_mappings.find((r) => r.target_column === "LiteralField" && r.is_used === "YES")!;
    expect(dataRow.sq_sql_query ?? "").toContain("SELECT X FROM A");
    // LiteralField source resolves to "(literal)" — should NOT inherit SQ SQL.
    expect(literalRow.source_table).toMatch(/literal/i);
    expect(literalRow.sq_sql_query).toBeNull();
  });
});
