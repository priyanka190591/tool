import { it } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";

it("list the 23 unresolved rows from ORDERS_INCREMENTAL", async () => {
  const xml = await fs.readFile(
    path.join(process.cwd(), "public", "sessions", "Sales", "2024", "Q1", "s_ORDERS_INCREMENTAL.xml"),
    "utf8",
  );
  const sessions = parseSessionsFromXml("s_ORDERS_INCREMENTAL.xml", xml);
  for (const session of sessions) {
    if (!session.mapping) continue;
    const json = buildMappingJson(session);
    console.log(`\n=== ${session.name} ===`);
    const unresolved = json.field_mappings.filter((r) => !r.source_table);
    console.log(`Total unresolved: ${unresolved.length} of ${json.field_mappings.length}`);
    console.log("");
    for (const r of unresolved) {
      const exprPreview = (r.final_expression ?? "").replace(/\s+/g, " ").slice(0, 100);
      console.log(
        `  ${r.target_table}.${r.target_column.padEnd(28)} | notes=${(r.notes ?? "—").padEnd(24)} | load=${r.load_type.padEnd(14)} | expr=${exprPreview || "(none)"}`,
      );
    }
  }
});
