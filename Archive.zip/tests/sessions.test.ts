import { describe, it, expect } from "vitest";
import { promises as fs } from "node:fs";
import path from "node:path";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import type { ParsedSession } from "@/lib/sessions-types";
import { buildLineage } from "@/lib/lineage";
import { validateSession } from "@/lib/validation";
import { diffSessions } from "@/lib/diff";

const SESSIONS_DIR = path.join(process.cwd(), "public", "sessions");

async function load(file: string): Promise<ParsedSession[]> {
  const xml = await fs.readFile(path.join(SESSIONS_DIR, file), "utf8");
  return parseSessionsFromXml(path.basename(file), xml);
}

async function first(file: string): Promise<ParsedSession> {
  const all = await load(file);
  expect(all.length).toBeGreaterThan(0);
  return all[0];
}

describe("parseSessionsFromXml", () => {
  it("parses the simple customer load fixture", async () => {
    const sessions = await load("s_CUSTOMER_LOAD.xml");
    expect(sessions).toHaveLength(1);
    const s = sessions[0];
    expect(s.name).toBe("s_CUSTOMER_LOAD");
    expect(s.mappingName).toBe("m_CUSTOMER_LOAD");
    expect(s.attributes.length).toBeGreaterThan(10);
    expect(s.connectionRefs.length).toBeGreaterThanOrEqual(3);
    expect(s.parameters).toEqual(
      expect.arrayContaining([{ name: "$$BATCH_ID", value: "20260529" }]),
    );
  });

  it("parses the complex sales fixture with mapping context", async () => {
    const s = await first("Sales/s_SALES_DIM_FULL.xml");
    expect(s.name).toBe("s_SALES_DIM_FULL");
    expect(s.mapping?.connectors.length).toBeGreaterThan(20);
    expect(s.mapping?.sources.length).toBeGreaterThan(0);
    expect(s.mapping?.targets.length).toBeGreaterThan(0);
    const lookup = s.mapping?.transformations.find((t) => t.name === "LKP_REGION");
    expect(lookup).toBeDefined();
    const cond = lookup?.tableAttributes.find((a) => a.name === "Lookup condition");
    expect(cond?.value).toContain("REGION_CODE = IN_REGION_CODE");
  });
});

describe("buildLineage", () => {
  it("traces target columns back to source columns with expressions", async () => {
    const s = await first("Sales/s_SALES_DIM_FULL.xml");
    const rows = buildLineage(s);
    expect(rows.length).toBeGreaterThan(0);
    const netAmount = rows.find((r) => r.targetColumn === "NET_AMOUNT");
    expect(netAmount?.expression).toMatch(/ROUND.*UNIT_PRICE/);
    const regionKey = rows.find((r) => r.targetColumn === "REGION_KEY");
    // sourceTable now aggregates the lookup table AND the upstream key-source table.
    expect(regionKey?.sourceTable).toContain("DIM_REGION");
    expect(regionKey?.sourceTable).toContain("STG_SALES");
    expect(regionKey?.lookupsUsed).toContain("LKP_REGION");
    const saleId = rows.find((r) => r.targetColumn === "SALE_ID");
    // SQ SQL Override "SELECT ... FROM STAGE.STG_SALES" wins priority 1.
    expect(saleId?.sourceTable).toBe("STAGE.STG_SALES");
    expect(saleId?.sourceColumn).toBe("SALE_ID");
  });
});

describe("validateSession", () => {
  it("returns issue list for parsed session", async () => {
    const s = await first("Sales/s_SALES_DIM_FULL.xml");
    const issues = validateSession(s);
    expect(Array.isArray(issues)).toBe(true);
  });

  it("detects unmapped target columns (PRODUCT_KEY in the sales fixture has no incoming CONNECTOR)", async () => {
    const s = await first("Sales/s_SALES_DIM_FULL.xml");
    const issues = validateSession(s);
    const unmapped = issues.filter((i) => i.code === "TARGET_UNMAPPED");
    expect(unmapped.length).toBeGreaterThanOrEqual(1);
    expect(unmapped.some((i) => i.location?.includes("PRODUCT_KEY"))).toBe(true);
  });

  it("flags undeclared parameter references", async () => {
    const s = await first("Sales/s_SALES_DIM_FULL.xml");
    const issues = validateSession(s);
    expect(issues.some((i) => i.code === "PARAM_NOT_DECLARED")).toBeDefined();
  });
});

describe("diffSessions", () => {
  it("computes diff between two parsed sessions", async () => {
    const a = await first("s_CUSTOMER_LOAD.xml");
    const b = await first("Sales/2024/Q1/s_ORDERS_INCREMENTAL.xml");
    const d = diffSessions(a, b);
    expect(d.sections.length).toBeGreaterThan(0);
    expect(d.totals.added + d.totals.removed + d.totals.changed).toBeGreaterThan(0);
  });
});
