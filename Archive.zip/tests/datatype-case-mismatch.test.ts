import { describe, it, expect } from "vitest";
import { parseSessionsFromXml } from "@/lib/sessions-parser";
import { buildMappingJson } from "@/lib/build-mapping-json";

// Bug A regression guard: when the SOURCEFIELD's NAME attribute case differs
// from the CONNECTOR's FROMFIELD case (a real-world IDMC quirk), the strict
// `===` match previously dropped the SOURCEFIELD lookup → sourceDataType
// rendered as NULL despite the SOURCE def actually carrying it. The fix
// makes the field lookup case-insensitive.

function buildXml(body: string): string {
  return `<?xml version="1.0"?>
<POWERMART>
  <REPOSITORY>
    <FOLDER>
      ${body}
    </FOLDER>
  </REPOSITORY>
</POWERMART>`;
}

describe("Bug A — SOURCEFIELD case-insensitive match", () => {
  it("recovers source_datatype when SOURCEFIELD NAME case differs from CONNECTOR FROMFIELD", () => {
    // SOURCEFIELD declared as uppercase "SYSTEMID" / "RISKID"; connectors
    // and SQ ports use mixed case "SystemId" / "RiskId". The walk should
    // still find the SOURCEFIELD and return its int4 datatype.
    const xml = buildXml(`
      <SOURCE NAME="STG_RISK">
        <SOURCEFIELD NAME="SYSTEMID" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
        <SOURCEFIELD NAME="RISKID" DATATYPE="integer" PRECISION="10" FIELDNUMBER="2"/>
      </SOURCE>
      <TARGET NAME="TGT">
        <TARGETFIELD NAME="OutSystemId" DATATYPE="int4" PRECISION="10" FIELDNUMBER="1"/>
      </TARGET>
      <MAPPING NAME="m">
        <TRANSFORMATION NAME="SQ_STG" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="SystemId" PORTTYPE="INPUT/OUTPUT" DATATYPE="varchar" PRECISION="765"/>
          <TRANSFORMFIELD NAME="RiskId" PORTTYPE="INPUT/OUTPUT" DATATYPE="varchar" PRECISION="765"/>
          <TABLEATTRIBUTE NAME="Sql Query" VALUE=""/>
        </TRANSFORMATION>
        <INSTANCE NAME="STG_RISK" TYPE="SOURCE" TRANSFORMATION_NAME="STG_RISK"/>
        <INSTANCE NAME="SQ_STG" TYPE="TRANSFORMATION" TRANSFORMATION_NAME="SQ_STG" TRANSFORMATION_TYPE="Source Qualifier"/>
        <INSTANCE NAME="TGT" TYPE="TARGET" TRANSFORMATION_NAME="TGT"/>
        <CONNECTOR FROMFIELD="SystemId" FROMINSTANCE="STG_RISK" FROMINSTANCETYPE="Source Definition" TOFIELD="SystemId" TOINSTANCE="SQ_STG" TOINSTANCETYPE="Source Qualifier"/>
        <CONNECTOR FROMFIELD="SystemId" FROMINSTANCE="SQ_STG" FROMINSTANCETYPE="Source Qualifier" TOFIELD="OutSystemId" TOINSTANCE="TGT" TOINSTANCETYPE="Target Definition"/>
      </MAPPING>
      <SESSION NAME="s"><SESSTRANSFORMATIONINST NAME="STG_RISK" TRANSFORMATIONTYPE="Source Definition"/></SESSION>
    `);
    const session = parseSessionsFromXml("s.xml", xml)[0];
    const m = buildMappingJson(session);
    const row = m.field_mappings.find((r) => r.target_column === "OutSystemId")!;
    expect(row).toBeDefined();
    expect(row.source_table).toBe("STG_RISK");
    expect(row.source_column).toBe("SystemId");
    // The bug: previously NULL because find(f.name === "SystemId") missed
    // "SYSTEMID". After the fix the case-insensitive match recovers int4.
    expect(row.source_datatype).toBe("int4");
    expect(row.source_precision).toBe("10");
  });
});
