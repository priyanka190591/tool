"use client";

import { useMemo, useState } from "react";
import type { FileEntry } from "@/lib/sessions";
import type { SessionDiff, DiffSection, DiffPair } from "@/lib/diff";
import { setHashParams } from "@/lib/href";

export function DiffPicker({
  entries,
  initial,
}: {
  entries: FileEntry[];
  initial: { leftFile?: string; leftSession?: string; rightFile?: string; rightSession?: string };
}) {
  const options = useMemo(() => flatten(entries), [entries]);
  const [leftKey, setLeftKey] = useState(initialKey(initial.leftFile, initial.leftSession));
  const [rightKey, setRightKey] = useState(initialKey(initial.rightFile, initial.rightSession));

  return (
    <form
      className="mt-3 flex flex-wrap items-end gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        const left = decodeKey(leftKey);
        const right = decodeKey(rightKey);
        setHashParams((sp) => {
          sp.delete("leftFile");
          sp.delete("leftSession");
          sp.delete("rightFile");
          sp.delete("rightSession");
          if (left) {
            sp.set("leftFile", left.fileName);
            sp.set("leftSession", left.sessionName);
          }
          if (right) {
            sp.set("rightFile", right.fileName);
            sp.set("rightSession", right.sessionName);
          }
        });
      }}
    >
      <Select label="Left" value={leftKey} onChange={setLeftKey} options={options} />
      <Select label="Right" value={rightKey} onChange={setRightKey} options={options} />
      <button
        type="submit"
        className="rounded-md bg-ink-900 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-ink-800"
      >
        Compare
      </button>
    </form>
  );
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { key: string; label: string }[];
}) {
  return (
    <div>
      <label className="block text-[11px] uppercase tracking-wider text-ink-500">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-80 rounded-md border border-ink-200 bg-white px-3 py-2 text-sm shadow-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
      >
        <option value="">— select —</option>
        {options.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

function flatten(entries: FileEntry[]) {
  return entries.flatMap((e) =>
    e.sessions.map((s) => ({
      key: `${e.fileName}::${s.name}`,
      label: e.sessions.length > 1 ? `${e.fileName} › ${s.name}` : e.fileName,
    })),
  );
}

function initialKey(file?: string, session?: string) {
  if (!file || !session) return "";
  return `${file}::${session}`;
}

function decodeKey(k: string): { fileName: string; sessionName: string } | null {
  if (!k.includes("::")) return null;
  const idx = k.indexOf("::");
  return { fileName: k.slice(0, idx), sessionName: k.slice(idx + 2) };
}

export function DiffView({ diff }: { diff: SessionDiff }) {
  const [filter, setFilter] = useState<"all" | "changes">("changes");
  const totalChanges = diff.totals.added + diff.totals.removed + diff.totals.changed;
  return (
    <div className="grid gap-4">
      <div className="rounded-lg border border-ink-200 bg-white px-5 py-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm">
            <div className="text-ink-500">
              <span className="font-medium text-ink-900">{diff.leftLabel}</span> ↔{" "}
              <span className="font-medium text-ink-900">{diff.rightLabel}</span>
            </div>
            <div className="mt-1 flex items-center gap-3 text-xs">
              <Counter label="added" count={diff.totals.added} className="bg-emerald-100 text-emerald-800" />
              <Counter label="removed" count={diff.totals.removed} className="bg-rose-100 text-rose-800" />
              <Counter label="changed" count={diff.totals.changed} className="bg-amber-100 text-amber-800" />
              <Counter label="same" count={diff.totals.same} className="bg-ink-100 text-ink-700" />
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-md border border-ink-200 bg-white p-0.5 text-xs">
            <button
              type="button"
              onClick={() => setFilter("changes")}
              className={`rounded px-2 py-1 ${filter === "changes" ? "bg-ink-900 text-white" : "text-ink-700"}`}
            >
              Changes only
            </button>
            <button
              type="button"
              onClick={() => setFilter("all")}
              className={`rounded px-2 py-1 ${filter === "all" ? "bg-ink-900 text-white" : "text-ink-700"}`}
            >
              All rows
            </button>
          </div>
        </div>
        {totalChanges === 0 ? (
          <div className="mt-3 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
            No differences detected across compared sections.
          </div>
        ) : null}
      </div>

      {diff.sections.map((sec) => (
        <SectionView key={sec.title} section={sec} showAll={filter === "all"} />
      ))}
    </div>
  );
}

function Counter({ label, count, className }: { label: string; count: number; className: string }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 font-medium ${className}`}>
      {count} {label}
    </span>
  );
}

function SectionView({ section, showAll }: { section: DiffSection; showAll: boolean }) {
  const rows = showAll ? section.pairs : section.pairs.filter((p) => p.status !== "same");
  if (rows.length === 0) {
    return (
      <details className="rounded-lg border border-ink-200 bg-white px-5 py-3 shadow-sm">
        <summary className="cursor-pointer text-sm font-semibold text-ink-900">
          {section.title} <span className="text-ink-500">(no changes)</span>
        </summary>
        <p className="mt-2 text-xs text-ink-500">All {section.summary.same} entries match.</p>
      </details>
    );
  }
  return (
    <div className="rounded-lg border border-ink-200 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-ink-100 px-5 py-3">
        <h3 className="text-sm font-semibold text-ink-900">{section.title}</h3>
        <div className="flex items-center gap-2 text-xs">
          <Counter label="+" count={section.summary.added} className="bg-emerald-100 text-emerald-800" />
          <Counter label="−" count={section.summary.removed} className="bg-rose-100 text-rose-800" />
          <Counter label="Δ" count={section.summary.changed} className="bg-amber-100 text-amber-800" />
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-ink-100 bg-ink-50/40 text-left text-xs uppercase tracking-wider text-ink-500">
              <th className="px-4 py-2 w-16">Status</th>
              <th className="px-4 py-2">Key</th>
              <th className="px-4 py-2">Left</th>
              <th className="px-4 py-2">Right</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {rows.map((p, i) => (
              <Row key={`${p.key}-${i}`} pair={p} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Row({ pair }: { pair: DiffPair }) {
  const bg =
    pair.status === "added"
      ? "bg-emerald-50/60"
      : pair.status === "removed"
        ? "bg-rose-50/60"
        : pair.status === "changed"
          ? "bg-amber-50/60"
          : "";
  return (
    <tr className={`align-top ${bg}`}>
      <td className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-ink-700">
        {pair.status === "added" ? "+ added" : pair.status === "removed" ? "− removed" : pair.status === "changed" ? "Δ changed" : "same"}
      </td>
      <td className="px-4 py-2 font-mono text-[12.5px] text-ink-900">{pair.key}</td>
      <td className="px-4 py-2 font-mono text-[12.5px] text-ink-900 whitespace-pre-wrap break-words">
        {pair.left ?? <span className="text-ink-400">—</span>}
      </td>
      <td className="px-4 py-2 font-mono text-[12.5px] text-ink-900 whitespace-pre-wrap break-words">
        {pair.right ?? <span className="text-ink-400">—</span>}
      </td>
    </tr>
  );
}
