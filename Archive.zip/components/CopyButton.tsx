"use client";

import { useState } from "react";

export function CopyButton({
  text,
  label = "Copy",
  className = "",
}: {
  text: string;
  label?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          /* silent — user can copy manually */
        }
      }}
      className={`inline-flex items-center gap-1 rounded border border-ink-200 bg-white px-2 py-0.5 text-[11px] font-medium text-ink-700 shadow-sm hover:bg-ink-50 ${className}`}
    >
      <svg width="10" height="10" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
        <path d="M8 2a2 2 0 0 0-2 2v1H4a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2v-1h2a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H8Zm5 11V7a2 2 0 0 0-2-2H8V4h7v9h-2Z" />
      </svg>
      {copied ? "Copied" : label}
    </button>
  );
}
