"use client";

import { useEffect, useState } from "react";
import { listFileEntries, parseSessionFile, type FileEntry } from "@/lib/sessions";
import { diffSessions, type SessionDiff } from "@/lib/diff";
import { DiffPicker, DiffView } from "@/components/DiffView";
import { useHashParams } from "@/lib/href";

export function DiffClient() {
  const sp = useHashParams();
  const leftFile = sp.get("leftFile") ?? undefined;
  const leftSession = sp.get("leftSession") ?? undefined;
  const rightFile = sp.get("rightFile") ?? undefined;
  const rightSession = sp.get("rightSession") ?? undefined;

  const [entries, setEntries] = useState<FileEntry[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [diff, setDiff] = useState<SessionDiff | null>(null);
  const [diffError, setDiffError] = useState<string | null>(null);
  const [computing, setComputing] = useState(false);

  useEffect(() => {
    let cancelled = false;
    listFileEntries()
      .then((e) => {
        if (!cancelled) setEntries(e);
      })
      .catch((err) => {
        if (!cancelled) setLoadError(err instanceof Error ? err.message : String(err));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!leftFile || !rightFile) {
      setDiff(null);
      setDiffError(null);
      return;
    }
    let cancelled = false;
    setComputing(true);
    setDiffError(null);
    Promise.all([parseSessionFile(leftFile, leftSession), parseSessionFile(rightFile, rightSession)])
      .then(([left, right]) => {
        if (!cancelled) setDiff(diffSessions(left, right));
      })
      .catch((err) => {
        if (!cancelled) setDiffError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setComputing(false);
      });
    return () => {
      cancelled = true;
    };
  }, [leftFile, leftSession, rightFile, rightSession]);

  return (
    <div className="grid gap-6">
      <div className="rounded-lg border border-ink-200 bg-white px-5 py-4 shadow-sm">
        <h2 className="text-sm font-semibold text-ink-900">Compare two sessions</h2>
        <p className="mt-1 text-xs text-ink-500">
          Pick a left and right session — the dashboard surfaces added, removed, and changed values
          across attributes, parameters, expressions, lookups, SQL, schemas, and connectors.
        </p>
        {entries ? (
          <DiffPicker entries={entries} initial={{ leftFile, leftSession, rightFile, rightSession }} />
        ) : (
          <p className="mt-3 text-xs text-ink-500">Loading sessions…</p>
        )}
      </div>

      {loadError ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-800">
          {loadError}
        </div>
      ) : diffError ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-800">
          {diffError}
        </div>
      ) : computing ? (
        <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-10 text-center text-sm text-ink-500">
          Computing diff…
        </div>
      ) : diff ? (
        <DiffView diff={diff} />
      ) : (
        <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-10 text-center">
          <p className="text-sm text-ink-500">Choose two sessions to see what changed.</p>
        </div>
      )}
    </div>
  );
}
