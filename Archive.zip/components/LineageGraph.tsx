"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Background,
  Controls,
  Handle,
  MiniMap,
  Position,
  ReactFlow,
  type Edge,
  type Node,
  type NodeProps,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import dagre from "@dagrejs/dagre";
import type { Connector, MappingInstance } from "@/lib/sessions";

const NODE_W = 220;
const NODE_H = 64;

type Category = { badge: string; className: string; edge: string };

function categorize(rawType: string): Category {
  const t = (rawType || "").toLowerCase();
  if (t.includes("source qualifier")) return { badge: "SQ", className: "border-sky-300 bg-sky-50 text-sky-900", edge: "#0284c7" };
  if (t.includes("source")) return { badge: "Source", className: "border-blue-300 bg-blue-50 text-blue-900", edge: "#2563eb" };
  if (t.includes("target")) return { badge: "Target", className: "border-emerald-300 bg-emerald-50 text-emerald-900", edge: "#059669" };
  if (t.includes("lookup")) return { badge: "Lookup", className: "border-purple-300 bg-purple-50 text-purple-900", edge: "#7c3aed" };
  if (t.includes("filter") || t.includes("router"))
    return { badge: t.includes("router") ? "Router" : "Filter", className: "border-amber-300 bg-amber-50 text-amber-900", edge: "#d97706" };
  if (t.includes("expression")) return { badge: "Expression", className: "border-teal-300 bg-teal-50 text-teal-900", edge: "#0d9488" };
  if (t.includes("update strategy")) return { badge: "Update Strategy", className: "border-rose-300 bg-rose-50 text-rose-900", edge: "#e11d48" };
  if (t.includes("aggregator") || t.includes("joiner") || t.includes("sorter") || t.includes("normalizer") || t.includes("union") || t.includes("rank")) {
    const label = (rawType.match(/Aggregator|Joiner|Sorter|Normalizer|Union|Rank/i) || ["Transform"])[0];
    return { badge: label, className: "border-indigo-300 bg-indigo-50 text-indigo-900", edge: "#4f46e5" };
  }
  if (t.includes("sequence")) return { badge: "Sequence", className: "border-stone-300 bg-stone-50 text-stone-900", edge: "#78716c" };
  return { badge: rawType || "Instance", className: "border-ink-200 bg-white text-ink-900", edge: "#838ca3" };
}

type InstanceNodeData = {
  name: string;
  type: string;
  category: Category;
  highlight?: "primary" | "upstream" | "downstream" | "none";
  [k: string]: unknown;
};
type InstanceFlowNode = Node<InstanceNodeData, "instance">;

function InstanceNode({
  data,
  sourcePosition,
  targetPosition,
}: NodeProps<InstanceFlowNode>) {
  const { name, type, category, highlight = "none" } = data;
  const ring =
    highlight === "primary"
      ? "ring-2 ring-ink-900 ring-offset-2"
      : highlight === "upstream"
        ? "ring-2 ring-sky-400 ring-offset-1"
        : highlight === "downstream"
          ? "ring-2 ring-emerald-400 ring-offset-1"
          : "";
  const dim = highlight === "none" ? "" : highlight === "primary" || highlight === "upstream" || highlight === "downstream" ? "" : "opacity-40";
  return (
    <div className={`relative rounded-lg border ${category.className} shadow-sm ${ring} ${dim}`} style={{ width: NODE_W, height: NODE_H }}>
      <Handle type="target" position={targetPosition ?? Position.Left} style={{ background: "#94a3b8", width: 8, height: 8, border: "none" }} />
      <div className="flex h-full flex-col justify-center px-3 py-2">
        <div className="text-[10px] font-semibold uppercase tracking-wider opacity-70">{category.badge}</div>
        <div className="truncate text-sm font-semibold">{name}</div>
        {type && type.toLowerCase() !== category.badge.toLowerCase() ? (
          <div className="truncate text-[10px] opacity-60">{type}</div>
        ) : null}
      </div>
      <Handle type="source" position={sourcePosition ?? Position.Right} style={{ background: "#94a3b8", width: 8, height: 8, border: "none" }} />
    </div>
  );
}

const nodeTypes = Object.freeze({ instance: InstanceNode });

export function LineageGraph({
  connectors,
  instances,
  storageKey,
}: {
  connectors: Connector[];
  instances: MappingInstance[];
  storageKey?: string;
}) {
  const [direction, setDirection] = useState<"LR" | "TB">("LR");
  const [selected, setSelected] = useState<string | null>(null);
  const [positions, setPositions] = useState<Record<string, { x: number; y: number }>>({});

  // Hydrate persistent positions
  useEffect(() => {
    if (!storageKey) return;
    try {
      const raw = localStorage.getItem(`lineage:positions:${storageKey}`);
      if (raw) setPositions(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, [storageKey]);

  // Build base nodes/edges
  const base = useMemo(() => {
    const types = new Map<string, string>();
    for (const inst of instances) types.set(inst.name, inst.transformationType || inst.type || "");
    for (const c of connectors) {
      if (!types.has(c.fromInstance)) types.set(c.fromInstance, c.fromInstanceType);
      if (!types.has(c.toInstance)) types.set(c.toInstance, c.toInstanceType);
    }

    const pairs = new Map<string, { from: string; to: string; count: number; fields: string[] }>();
    for (const c of connectors) {
      const k = `${c.fromInstance}${c.toInstance}`;
      const cur = pairs.get(k);
      if (cur) {
        cur.count++;
        cur.fields.push(`${c.fromField} → ${c.toField}`);
      } else pairs.set(k, { from: c.fromInstance, to: c.toInstance, count: 1, fields: [`${c.fromField} → ${c.toField}`] });
    }

    const g = new dagre.graphlib.Graph();
    g.setGraph({ rankdir: direction, nodesep: 36, ranksep: 90, marginx: 24, marginy: 24 });
    g.setDefaultEdgeLabel(() => ({}));
    for (const name of types.keys()) g.setNode(name, { width: NODE_W, height: NODE_H });
    for (const p of pairs.values()) g.setEdge(p.from, p.to);
    dagre.layout(g);

    const adjFwd = new Map<string, Set<string>>();
    const adjRev = new Map<string, Set<string>>();
    for (const p of pairs.values()) {
      if (!adjFwd.has(p.from)) adjFwd.set(p.from, new Set());
      adjFwd.get(p.from)!.add(p.to);
      if (!adjRev.has(p.to)) adjRev.set(p.to, new Set());
      adjRev.get(p.to)!.add(p.from);
    }

    return { types, pairs, layout: g, adjFwd, adjRev };
  }, [connectors, instances, direction]);

  const upstream = useMemo(() => bfs(selected, base.adjRev), [selected, base.adjRev]);
  const downstream = useMemo(() => bfs(selected, base.adjFwd), [selected, base.adjFwd]);

  const nodes: Node[] = useMemo(() => {
    const out: Node[] = [];
    for (const [name, type] of base.types.entries()) {
      const persisted = positions[name];
      const pos = persisted ?? base.layout.node(name);
      const category = categorize(type);
      let highlight: "primary" | "upstream" | "downstream" | "none" = "none";
      if (selected) {
        if (name === selected) highlight = "primary";
        else if (upstream.has(name)) highlight = "upstream";
        else if (downstream.has(name)) highlight = "downstream";
      }
      out.push({
        id: name,
        type: "instance",
        data: { name, type, category, highlight },
        position: persisted
          ? { x: persisted.x, y: persisted.y }
          : { x: pos.x - NODE_W / 2, y: pos.y - NODE_H / 2 },
        sourcePosition: direction === "LR" ? Position.Right : Position.Bottom,
        targetPosition: direction === "LR" ? Position.Left : Position.Top,
      });
    }
    return out;
  }, [base, positions, direction, selected, upstream, downstream]);

  const edges: Edge[] = useMemo(() => {
    return Array.from(base.pairs.values()).map((p, i) => {
      const fromCat = categorize(base.types.get(p.from) ?? "");
      const isHighlighted =
        selected != null &&
        ((p.from === selected || p.to === selected) ||
          (upstream.has(p.from) && upstream.has(p.to)) ||
          (downstream.has(p.from) && downstream.has(p.to)) ||
          (upstream.has(p.from) && p.to === selected) ||
          (downstream.has(p.to) && p.from === selected));
      const dim = selected != null && !isHighlighted;
      return {
        id: `e${i}`,
        source: p.from,
        target: p.to,
        type: "smoothstep",
        label: `${p.count}`,
        labelStyle: { fontSize: 10, fill: "#3f4658", fontWeight: 600 },
        labelBgStyle: { fill: "#ffffff", fillOpacity: 0.9 },
        labelBgPadding: [4, 2],
        labelBgBorderRadius: 4,
        style: {
          stroke: fromCat.edge,
          strokeWidth: isHighlighted ? 2.4 : 1.6,
          opacity: dim ? 0.18 : 0.9,
        },
        data: { fields: p.fields },
      } satisfies Edge;
    });
  }, [base, selected, upstream, downstream]);

  const onNodeDragStop = useCallback(
    (_: unknown, node: Node) => {
      const next = { ...positions, [node.id]: node.position };
      setPositions(next);
      if (storageKey) {
        try {
          localStorage.setItem(`lineage:positions:${storageKey}`, JSON.stringify(next));
        } catch {
          /* ignore */
        }
      }
    },
    [positions, storageKey],
  );

  const onNodeClick = useCallback((_: unknown, node: Node) => {
    setSelected((prev) => (prev === node.id ? null : node.id));
  }, []);

  const onPaneClick = useCallback(() => setSelected(null), []);

  const resetLayout = useCallback(() => {
    setPositions({});
    if (storageKey) {
      try {
        localStorage.removeItem(`lineage:positions:${storageKey}`);
      } catch {
        /* ignore */
      }
    }
  }, [storageKey]);

  const selectedEdges =
    selected != null
      ? Array.from(base.pairs.values()).filter((p) => p.from === selected || p.to === selected)
      : [];

  return (
    <div className="overflow-hidden rounded-md border border-ink-100 bg-white">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink-100 bg-ink-50/40 px-3 py-2">
        <div className="flex items-center gap-2 text-xs text-ink-600">
          <span className="font-medium text-ink-700">{base.types.size} instances</span>
          <span aria-hidden>·</span>
          <span>{base.pairs.size} edges</span>
          <span aria-hidden>·</span>
          <span>{connectors.length} field-level links</span>
          {selected ? (
            <>
              <span aria-hidden>·</span>
              <span className="text-ink-900">selected: <code className="font-mono">{selected}</code></span>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="rounded border border-ink-200 bg-white px-1.5 py-0.5 text-[11px] hover:bg-ink-50"
              >
                clear
              </button>
            </>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-md border border-ink-200 bg-white p-0.5 text-xs">
            <button
              type="button"
              onClick={() => setDirection("LR")}
              className={`rounded px-2 py-1 ${direction === "LR" ? "bg-ink-900 text-white" : "text-ink-700"}`}
            >
              Left → Right
            </button>
            <button
              type="button"
              onClick={() => setDirection("TB")}
              className={`rounded px-2 py-1 ${direction === "TB" ? "bg-ink-900 text-white" : "text-ink-700"}`}
            >
              Top → Bottom
            </button>
          </div>
          <button
            type="button"
            onClick={resetLayout}
            className="rounded-md border border-ink-200 bg-white px-2 py-1 text-xs text-ink-700 hover:bg-ink-50"
          >
            Reset layout
          </button>
        </div>
      </div>
      <div style={{ height: 600 }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          fitView
          fitViewOptions={{ padding: 0.2 }}
          minZoom={0.15}
          maxZoom={2.5}
          nodesDraggable
          nodesConnectable={false}
          elementsSelectable
          onNodeClick={onNodeClick}
          onNodeDragStop={onNodeDragStop}
          onPaneClick={onPaneClick}
        >
          <Background gap={18} color="#eceef2" />
          <Controls showInteractive={false} />
          <MiniMap
            pannable
            zoomable
            nodeColor={(n) => {
              const cat = (n.data as { category?: Category } | undefined)?.category;
              return cat?.edge ?? "#cbd5e1";
            }}
            maskColor="rgba(15, 23, 42, 0.06)"
          />
        </ReactFlow>
      </div>
      {selected ? (
        <div className="border-t border-ink-100 bg-ink-50/30 px-3 py-2 text-xs">
          <div className="mb-1 font-medium text-ink-700">
            Field-level edges for <code className="font-mono">{selected}</code>:
          </div>
          {selectedEdges.length === 0 ? (
            <div className="text-ink-500">No edges.</div>
          ) : (
            <div className="grid gap-2 sm:grid-cols-2">
              {selectedEdges.map((p, i) => (
                <details key={i} className="rounded border border-ink-100 bg-white px-2 py-1">
                  <summary className="cursor-pointer text-ink-900">
                    <span className="font-mono">{p.from}</span> → <span className="font-mono">{p.to}</span>{" "}
                    <span className="text-ink-500">({p.fields.length} fields)</span>
                  </summary>
                  <ul className="mt-1 space-y-0.5 font-mono text-[11px] text-ink-700">
                    {p.fields.map((f, j) => (
                      <li key={j}>{f}</li>
                    ))}
                  </ul>
                </details>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="border-t border-ink-100 bg-ink-50/30 px-3 py-2 text-[11px] text-ink-500">
          Click a node to highlight upstream (blue) and downstream (green) paths and see field-level edges.
          Drag nodes to rearrange; layout persists.
        </div>
      )}
    </div>
  );
}

function bfs(start: string | null, adj: Map<string, Set<string>>): Set<string> {
  const out = new Set<string>();
  if (!start) return out;
  const q: string[] = [start];
  while (q.length > 0) {
    const cur = q.shift()!;
    for (const next of adj.get(cur) ?? []) {
      if (!out.has(next) && next !== start) {
        out.add(next);
        q.push(next);
      }
    }
  }
  return out;
}
