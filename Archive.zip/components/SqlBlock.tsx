import { CopyButton } from "@/components/CopyButton";

const KEYWORDS = new Set([
  "SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "NULL", "IS", "IN",
  "INSERT", "UPDATE", "DELETE", "INTO", "VALUES", "SET",
  "JOIN", "INNER", "LEFT", "RIGHT", "OUTER", "ON", "FULL", "CROSS",
  "GROUP", "BY", "ORDER", "HAVING", "DISTINCT", "AS", "UNION", "ALL", "INTERSECT", "EXCEPT",
  "CASE", "WHEN", "THEN", "ELSE", "END", "IF", "EXISTS",
  "WITH", "RECURSIVE",
  "CREATE", "TABLE", "VIEW", "ALTER", "DROP", "TRUNCATE",
  "LIKE", "BETWEEN", "ASC", "DESC", "LIMIT", "OFFSET", "FETCH", "ROWS",
  "TO_DATE", "TO_TIMESTAMP", "TO_CHAR", "TRUNC", "NVL", "COALESCE", "ROUND",
  "SUM", "AVG", "COUNT", "MIN", "MAX",
  "SYSDATE", "SYSTIMESTAMP", "CURRENT_DATE", "CURRENT_TIMESTAMP",
]);

export function SqlBlock({ sql, label = "SQL" }: { sql: string; label?: string }) {
  if (!sql) return <p className="text-sm text-ink-500">No SQL.</p>;
  const tokens = tokenize(sql);
  return (
    <div className="rounded-md border border-ink-100 bg-ink-950/[0.02]">
      <div className="flex items-center justify-between border-b border-ink-100 px-3 py-1.5 text-[11px] uppercase tracking-wider text-ink-500">
        <span>{label}</span>
        <CopyButton text={sql} />
      </div>
      <pre className="max-h-[420px] overflow-auto px-3 py-2 font-mono text-[12.5px] leading-5 text-ink-900">
        <code>
          {tokens.map((t, i) => {
            if (t.kind === "keyword") return <span key={i} className="font-semibold text-indigo-700">{t.text}</span>;
            if (t.kind === "string") return <span key={i} className="text-emerald-700">{t.text}</span>;
            if (t.kind === "number") return <span key={i} className="text-amber-700">{t.text}</span>;
            if (t.kind === "comment") return <span key={i} className="italic text-ink-400">{t.text}</span>;
            if (t.kind === "param") return <span key={i} className="font-semibold text-rose-600">{t.text}</span>;
            return <span key={i}>{t.text}</span>;
          })}
        </code>
      </pre>
    </div>
  );
}

type Token = { text: string; kind: "keyword" | "string" | "number" | "comment" | "param" | "text" };

function tokenize(sql: string): Token[] {
  const out: Token[] = [];
  const pattern =
    /(--[^\n]*|\/\*[\s\S]*?\*\/|'(?:''|[^'])*'|"(?:""|[^"])*"|\$\$[A-Za-z_][A-Za-z0-9_]*|\$[A-Za-z_][A-Za-z0-9_]*|[A-Za-z_][A-Za-z0-9_]*|\d+\.?\d*|\s+|[^\w\s])/g;
  const tokens = sql.match(pattern) ?? [];
  for (const tok of tokens) {
    if (tok.startsWith("--") || tok.startsWith("/*")) out.push({ text: tok, kind: "comment" });
    else if (tok.startsWith("'") || tok.startsWith('"')) out.push({ text: tok, kind: "string" });
    else if (tok.startsWith("$")) out.push({ text: tok, kind: "param" });
    else if (/^\d/.test(tok)) out.push({ text: tok, kind: "number" });
    else if (/^[A-Za-z_]/.test(tok) && KEYWORDS.has(tok.toUpperCase())) out.push({ text: tok, kind: "keyword" });
    else out.push({ text: tok, kind: "text" });
  }
  return out;
}
