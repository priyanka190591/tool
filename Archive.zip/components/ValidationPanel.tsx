import type { ValidationIssue } from "@/lib/validation";

const SEVERITY: Record<
  ValidationIssue["severity"],
  { label: string; ring: string; bg: string; dot: string }
> = {
  error: { label: "Errors", ring: "border-rose-200", bg: "bg-rose-50", dot: "bg-rose-500" },
  warning: { label: "Warnings", ring: "border-amber-200", bg: "bg-amber-50", dot: "bg-amber-500" },
  info: { label: "Info", ring: "border-sky-200", bg: "bg-sky-50", dot: "bg-sky-500" },
};

export function ValidationPanel({ issues }: { issues: ValidationIssue[] }) {
  if (issues.length === 0) {
    return <p className="text-sm text-emerald-700">No issues detected.</p>;
  }
  const grouped: Record<ValidationIssue["severity"], ValidationIssue[]> = {
    error: [],
    warning: [],
    info: [],
  };
  for (const i of issues) grouped[i.severity].push(i);
  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap items-center gap-2 text-xs">
        {(["error", "warning", "info"] as const).map((sev) => (
          <span
            key={sev}
            className={`inline-flex items-center gap-1.5 rounded-full border ${SEVERITY[sev].ring} ${SEVERITY[sev].bg} px-2 py-0.5`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${SEVERITY[sev].dot}`} />
            {grouped[sev].length} {SEVERITY[sev].label.toLowerCase()}
          </span>
        ))}
      </div>
      <div className="grid gap-2">
        {(["error", "warning", "info"] as const).flatMap((sev) =>
          grouped[sev].map((i, idx) => (
            <div
              key={`${sev}-${idx}`}
              className={`flex items-start gap-3 rounded-md border ${SEVERITY[sev].ring} ${SEVERITY[sev].bg} px-3 py-2 text-sm`}
            >
              <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${SEVERITY[sev].dot}`} />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-2">
                  <code className="font-mono text-[11px] font-semibold text-ink-700">{i.code}</code>
                  {i.location ? (
                    <span className="font-mono text-[11px] text-ink-500">{i.location}</span>
                  ) : null}
                </div>
                <div className="mt-0.5 text-ink-900">{i.message}</div>
              </div>
            </div>
          )),
        )}
      </div>
    </div>
  );
}
