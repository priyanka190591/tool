"use client";

import { useEffect, useState } from "react";
import { SessionPicker } from "@/components/SessionPicker";
import { SessionView } from "@/components/SessionView";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import {
  listFileEntries,
  parseSessionFile,
  type FileEntry,
  type ParsedSession,
} from "@/lib/sessions";
import { useHashParams } from "@/lib/href";

export function DashboardClient() {
  const hashParams = useHashParams();
  // Prefer the new `path=` key; fall back to legacy `file=` for one release
  // so old shared links still resolve. `file=` carried only a leaf name, so
  // when it matches a single `FileEntry.fileName` we resolve to that entry's
  // full path.
  const sessionName = hashParams.get("session") ?? undefined;
  const explicitPath = hashParams.get("path") ?? undefined;
  const legacyFile = hashParams.get("file") ?? undefined;

  const [entries, setEntries] = useState<FileEntry[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [parsed, setParsed] = useState<ParsedSession | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);
  const [parsing, setParsing] = useState(false);

  useEffect(() => {
    let cancelled = false;
    listFileEntries()
      .then((e) => {
        if (!cancelled) setEntries(e);
      })
      .catch((err) => {
        if (!cancelled) setLoadError(err instanceof Error ? err.message : String(err));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!entries) return;
    const selected =
      explicitPath && entries.some((e) => e.path === explicitPath)
        ? explicitPath
        : legacyFile
          ? entries.find((e) => e.fileName === legacyFile)?.path
          : undefined;
    if (!selected) {
      setParsed(null);
      setParseError(null);
      return;
    }
    let cancelled = false;
    setParsing(true);
    setParseError(null);
    parseSessionFile(selected, sessionName)
      .then((p) => {
        if (!cancelled) setParsed(p);
      })
      .catch((err) => {
        if (!cancelled) setParseError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setParsing(false);
      });
    return () => {
      cancelled = true;
    };
  }, [entries, explicitPath, legacyFile, sessionName]);

  const totalSessions = (entries ?? []).reduce((acc, e) => acc + e.sessions.length, 0);
  const selectedPath: string | undefined = (() => {
    if (!entries) return undefined;
    if (explicitPath && entries.some((e) => e.path === explicitPath)) return explicitPath;
    if (legacyFile) return entries.find((e) => e.fileName === legacyFile)?.path;
    return undefined;
  })();

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-ink-200 bg-white px-5 py-4 shadow-sm">
        <SessionPicker
          entries={entries ?? []}
          selectedPath={selectedPath}
          selectedSession={sessionName}
        />
        <div className="flex items-center gap-3 text-xs text-ink-500">
          {entries ? (
            <span>
              {entries.length} file{entries.length === 1 ? "" : "s"} · {totalSessions} session
              {totalSessions === 1 ? "" : "s"}
            </span>
          ) : (
            <span>Loading…</span>
          )}
        </div>
      </div>

      {loadError ? (
        <ErrorState message={loadError} hint="Check that sessions/index.json exists next to your XML files." />
      ) : entries === null ? (
        <LoadingState />
      ) : entries.length === 0 ? (
        <EmptyState />
      ) : !selectedPath ? (
        <NoSelection />
      ) : parseError ? (
        <ErrorState message={parseError} />
      ) : parsing || !parsed ? (
        <LoadingState />
      ) : (
        <ErrorBoundary label="Session view">
          <SessionView session={parsed} />
        </ErrorBoundary>
      )}
    </div>
  );
}

function LoadingState() {
  return (
    <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-12 text-center">
      <p className="text-sm text-ink-500">Loading…</p>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-12 text-center">
      <h2 className="text-sm font-semibold text-ink-900">No session XML files yet</h2>
      <p className="mx-auto mt-2 max-w-md text-sm text-ink-500">
        Drop your IDMC session XML files into the{" "}
        <code className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[12px]">sessions/</code>{" "}
        folder next to this app, then run{" "}
        <code className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[12px]">refresh-sessions.ps1</code>{" "}
        and refresh this page.
      </p>
    </div>
  );
}

function NoSelection() {
  return (
    <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-12 text-center">
      <h2 className="text-sm font-semibold text-ink-900">Select a session to inspect</h2>
      <p className="mt-2 text-sm text-ink-500">Pick a file from the dropdown above to see its details.</p>
    </div>
  );
}

function ErrorState({ message, hint }: { message: string; hint?: string }) {
  return (
    <div className="rounded-lg border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-800">
      <strong className="font-semibold">Could not load.</strong>
      <p className="mt-1 font-mono text-[12.5px]">{message}</p>
      {hint ? <p className="mt-1 text-xs text-rose-700">{hint}</p> : null}
    </div>
  );
}
