"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import type { FileEntry } from "@/lib/sessions";
import { setHashParams } from "@/lib/href";
import { buildFolderTree, type FolderNode } from "@/lib/folder-tree";
import { downloadFolderXlsx } from "@/lib/downloads";

export function SessionPicker({
  entries,
  selectedPath,
  selectedSession,
}: {
  entries: FileEntry[];
  selectedPath?: string;
  selectedSession?: string;
}) {
  const [pending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [bundlingPath, setBundlingPath] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const root = useMemo(() => buildFolderTree(entries), [entries]);

  const selectedLabel = useMemo(() => {
    if (!selectedPath) return null;
    const entry = entries.find((e) => e.path === selectedPath);
    if (!entry) return null;
    if (!selectedSession || entry.sessions.length <= 1) return entry.fileName;
    return `${entry.fileName}  ›  ${selectedSession}`;
  }, [entries, selectedPath, selectedSession]);

  // When the user types in the search box, every ancestor of a match is
  // expanded; non-matching subtrees collapse.
  const expandedPaths = useMemo(() => {
    if (!query.trim()) return new Set<string>();
    const q = query.trim().toLowerCase();
    const set = new Set<string>();
    const walk = (n: FolderNode): boolean => {
      const fileMatch = n.files.some(
        (f) =>
          f.fileName.toLowerCase().includes(q) ||
          f.sessions.some(
            (s) =>
              s.name.toLowerCase().includes(q) ||
              (s.mappingName ?? "").toLowerCase().includes(q),
          ),
      );
      let childMatch = false;
      for (const child of n.folders) {
        if (walk(child)) childMatch = true;
      }
      if (fileMatch || childMatch) {
        if (n.path !== "") set.add(n.path);
        return true;
      }
      return false;
    };
    walk(root);
    return set;
  }, [root, query]);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function pickFile(file: FileEntry, sessionName?: string) {
    startTransition(() => {
      setHashParams((sp) => {
        sp.set("path", file.path);
        sp.delete("file"); // strip legacy hash param
        if (sessionName && file.sessions.length > 1) sp.set("session", sessionName);
        else sp.delete("session");
      });
      setOpen(false);
      setQuery("");
    });
  }

  async function downloadFolder(folder: FolderNode) {
    if (bundlingPath) return;
    setBundlingPath(folder.path);
    try {
      const { bundled, failed } = await downloadFolderXlsx(folder);
      if (failed > 0) {
        alert(`Bundled ${bundled} session${bundled === 1 ? "" : "s"}; ${failed} file${failed === 1 ? "" : "s"} failed to parse (see console).`);
      }
    } catch (e) {
      alert(`Download failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBundlingPath(null);
    }
  }

  return (
    <div className="flex items-center gap-3" ref={containerRef}>
      <label htmlFor="session-picker" className="text-sm font-medium text-ink-700">
        Session XML
      </label>
      <div className="relative w-[28rem]">
        <button
          type="button"
          id="session-picker"
          onClick={() => setOpen((v) => !v)}
          disabled={pending || root.totalFiles === 0}
          className="flex w-full items-center justify-between gap-2 rounded-md border border-ink-200 bg-white px-3 py-2 text-left text-sm text-ink-900 shadow-sm transition focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <span className="truncate">
            {selectedLabel
              ? selectedLabel
              : root.totalFiles === 0
                ? "No XML files found"
                : "Select a session…"}
          </span>
          <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor" className="text-ink-400" aria-hidden>
            <path
              fillRule="evenodd"
              d="M5.23 7.21a.75.75 0 0 1 1.06.02L10 11.06l3.71-3.83a.75.75 0 1 1 1.08 1.04l-4.24 4.38a.75.75 0 0 1-1.08 0L5.21 8.27a.75.75 0 0 1 .02-1.06Z"
              clipRule="evenodd"
            />
          </svg>
        </button>
        {open ? (
          <div className="absolute z-30 mt-1 w-full overflow-hidden rounded-md border border-ink-200 bg-white shadow-lg">
            <div className="border-b border-ink-100 p-2">
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by file, session, or mapping…"
                className="w-full rounded border border-ink-200 px-2 py-1 text-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
              />
            </div>
            <div className="max-h-[28rem] overflow-y-auto">
              {root.totalFiles === 0 ? (
                <div className="px-3 py-2 text-sm text-ink-500">No XML files.</div>
              ) : (
                <TreeRows
                  node={root}
                  query={query.trim().toLowerCase()}
                  forceExpand={query.trim() !== ""}
                  expandedPaths={expandedPaths}
                  depth={0}
                  bundlingPath={bundlingPath}
                  onPickSession={pickFile}
                  onDownloadFolder={downloadFolder}
                  selectedPath={selectedPath}
                  selectedSession={selectedSession}
                />
              )}
            </div>
          </div>
        ) : null}
      </div>
      {pending ? <span className="text-xs text-ink-500">Loading…</span> : null}
    </div>
  );
}

function TreeRows({
  node,
  query,
  forceExpand,
  expandedPaths,
  depth,
  bundlingPath,
  onPickSession,
  onDownloadFolder,
  selectedPath,
  selectedSession,
}: {
  node: FolderNode;
  query: string;
  forceExpand: boolean;
  expandedPaths: Set<string>;
  depth: number;
  bundlingPath: string | null;
  onPickSession: (file: FileEntry, sessionName?: string) => void;
  onDownloadFolder: (folder: FolderNode) => void;
  selectedPath?: string;
  selectedSession?: string;
}) {
  return (
    <ul>
      {node.folders.map((sub) => (
        <FolderRow
          key={sub.path}
          folder={sub}
          query={query}
          forceExpand={forceExpand}
          expandedPaths={expandedPaths}
          depth={depth}
          bundlingPath={bundlingPath}
          onPickSession={onPickSession}
          onDownloadFolder={onDownloadFolder}
          selectedPath={selectedPath}
          selectedSession={selectedSession}
        />
      ))}
      {node.files.map((file) =>
        matchesQuery(file, query) ? (
          <FileRow
            key={file.path}
            file={file}
            depth={depth}
            onPickSession={onPickSession}
            selectedPath={selectedPath}
            selectedSession={selectedSession}
          />
        ) : null,
      )}
    </ul>
  );
}

function FolderRow({
  folder,
  query,
  forceExpand,
  expandedPaths,
  depth,
  bundlingPath,
  onPickSession,
  onDownloadFolder,
  selectedPath,
  selectedSession,
}: {
  folder: FolderNode;
  query: string;
  forceExpand: boolean;
  expandedPaths: Set<string>;
  depth: number;
  bundlingPath: string | null;
  onPickSession: (file: FileEntry, sessionName?: string) => void;
  onDownloadFolder: (folder: FolderNode) => void;
  selectedPath?: string;
  selectedSession?: string;
}) {
  const [openLocal, setOpenLocal] = useState(false);
  const expanded = forceExpand ? expandedPaths.has(folder.path) : openLocal;
  // If this folder has no descendants matching the query, drop it from the
  // rendered tree entirely (instead of showing an empty folder).
  if (forceExpand && !expandedPaths.has(folder.path)) return null;
  const bundling = bundlingPath === folder.path;
  return (
    <li>
      <div
        className="flex items-center gap-1 px-2 py-1 text-sm hover:bg-ink-50"
        style={{ paddingLeft: 8 + depth * 16 }}
      >
        <button
          type="button"
          onClick={() => setOpenLocal((v) => !v)}
          className="flex h-4 w-4 items-center justify-center text-ink-500"
          aria-label={expanded ? "Collapse folder" : "Expand folder"}
        >
          <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
            {expanded ? (
              <path d="M1 3.5h8L5 8z" />
            ) : (
              <path d="M3.5 1v8L8 5z" />
            )}
          </svg>
        </button>
        <span className="truncate font-medium text-ink-900">{folder.name}</span>
        <span className="text-[11px] text-ink-500">
          ({folder.totalFiles} file{folder.totalFiles === 1 ? "" : "s"}
          {" · "}
          {folder.totalSessions} session{folder.totalSessions === 1 ? "" : "s"})
        </span>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDownloadFolder(folder);
          }}
          disabled={bundlingPath !== null}
          title={`Download all sessions under ${folder.path} as a .zip`}
          className="ml-auto rounded border border-ink-200 bg-white px-1.5 py-0.5 text-[11px] text-ink-700 hover:bg-ink-50 disabled:opacity-50"
        >
          {bundling ? "…" : "⬇"}
        </button>
      </div>
      {expanded ? (
        <TreeRows
          node={folder}
          query={query}
          forceExpand={forceExpand}
          expandedPaths={expandedPaths}
          depth={depth + 1}
          bundlingPath={bundlingPath}
          onPickSession={onPickSession}
          onDownloadFolder={onDownloadFolder}
          selectedPath={selectedPath}
          selectedSession={selectedSession}
        />
      ) : null}
    </li>
  );
}

function FileRow({
  file,
  depth,
  onPickSession,
  selectedPath,
  selectedSession,
}: {
  file: FileEntry;
  depth: number;
  onPickSession: (file: FileEntry, sessionName?: string) => void;
  selectedPath?: string;
  selectedSession?: string;
}) {
  return (
    <li>
      {file.sessions.map((s) => {
        const active =
          selectedPath === file.path &&
          (file.sessions.length === 1 || selectedSession === s.name);
        return (
          <button
            key={`${file.path}|${s.index}`}
            type="button"
            onClick={() => onPickSession(file, s.name)}
            className={`flex w-full flex-col gap-0.5 py-1 text-left text-sm hover:bg-ink-50 ${active ? "bg-ink-100/60" : ""}`}
            style={{ paddingLeft: 8 + (depth + 1) * 16, paddingRight: 8 }}
          >
            <span className="font-medium text-ink-900">{s.name}</span>
            <span className="text-[11px] text-ink-500">
              {file.fileName}
              {s.mappingName ? ` · ${s.mappingName}` : ""}
            </span>
          </button>
        );
      })}
    </li>
  );
}

function matchesQuery(file: FileEntry, query: string): boolean {
  if (!query) return true;
  if (file.fileName.toLowerCase().includes(query)) return true;
  return file.sessions.some(
    (s) =>
      s.name.toLowerCase().includes(query) ||
      (s.mappingName ?? "").toLowerCase().includes(query),
  );
}
