"use client";

import { Fragment, useMemo, useState } from "react";
import { Pill } from "@/components/ui";
import type { ParsedSession } from "@/lib/sessions";
import { buildMappingJson } from "@/lib/build-mapping-json";
import type { FieldMappingJson, MappingJson } from "@/lib/mapping-schema";

type StepKind = "source" | "transformation" | "target" | "label";

type TraceStep = {
  kind: StepKind;
  name: string;
  type: string;
  field?: string;
  dataType?: string;
  connection?: string;
  connectionType?: string;
  description?: string;
  expressions: { field: string; expr: string }[];
};

export function LineageTracer({ session }: { session: ParsedSession }) {
  const mapping = useMemo(() => buildMappingJson(session), [session]);
  const rows = mapping.field_mappings;
  const byTable = useMemo(() => {
    const map = new Map<string, FieldMappingJson[]>();
    for (const r of rows) {
      const k = r.target_table;
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(r);
    }
    return map;
  }, [rows]);
  const tables = useMemo(() => [...byTable.keys()].sort(), [byTable]);

  const [tableName, setTableName] = useState<string>(tables[0] ?? "");
  const columnsForTable = byTable.get(tableName) ?? [];
  const [columnKey, setColumnKey] = useState<string>(
    columnsForTable[0] ? rowKey(columnsForTable[0]) : "",
  );

  // Reset selection when the table changes and no key matches anymore.
  const effKey = columnsForTable.some((c) => rowKey(c) === columnKey)
    ? columnKey
    : columnsForTable[0]
      ? rowKey(columnsForTable[0])
      : "";

  const row = byTable.get(tableName)?.find((r) => rowKey(r) === effKey);

  if (rows.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-12 text-center">
        <h3 className="text-sm font-semibold text-ink-900">No lineage available</h3>
        <p className="mt-2 text-sm text-ink-500">
          This XML has no mapping definition. The tracer requires a full IDMC export with
          mapping + connector blocks.
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-5">
      <div className="rounded-lg border border-ink-200 bg-white px-5 py-4 shadow-sm">
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-ink-500">
              Target Table
            </label>
            <select
              value={tableName}
              onChange={(e) => {
                setTableName(e.target.value);
                const cols = byTable.get(e.target.value) ?? [];
                setColumnKey(cols[0] ? rowKey(cols[0]) : "");
              }}
              className="rounded-md border border-ink-200 bg-white px-3 py-2 text-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
            >
              {tables.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-ink-500">
              Target Column
            </label>
            <select
              value={effKey}
              onChange={(e) => setColumnKey(e.target.value)}
              className="rounded-md border border-ink-200 bg-white px-3 py-2 text-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
            >
              {columnsForTable.map((c) => (
                <option key={rowKey(c)} value={rowKey(c)}>
                  {c.target_column}
                  {c.target_datatype ? ` (${c.target_datatype})` : ""}
                  {c.load_type && c.load_type !== "UNSPECIFIED" ? ` · ${c.load_type}` : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="ml-auto text-xs text-ink-500">
            {rows.length} columns · {tables.length} target table{tables.length === 1 ? "" : "s"}
          </div>
        </div>
        {row ? <SummaryBar row={row} /> : null}
      </div>

      {row ? <TracePath row={row} session={session} mapping={mapping} /> : null}
    </div>
  );
}

// Build a stable per-row key. Same (table, column) appears multiple times
// when a Router splits load (INSERT vs UPDATE) — include load_type so each
// branch is selectable.
function rowKey(r: FieldMappingJson): string {
  return `${r.target_column}|${r.load_type ?? ""}`;
}

function SummaryBar({ row }: { row: FieldMappingJson }) {
  const src = row.source_table || "";
  const classified = src.startsWith("(") && !src.startsWith("(lookup ");
  return (
    <div className="mt-4 grid grid-cols-2 gap-3 rounded-md border border-ink-100 bg-ink-50/40 p-3 sm:grid-cols-4">
      <SummaryItem label="Resolved as" value={classified ? src : "Direct source"} />
      <SummaryItem label="Source" value={src || "—"} />
      <SummaryItem
        label="Path length"
        value={row.transformation_path ? String(row.transformation_path.split(" → ").length) : "0"}
      />
      <SummaryItem label="Lookups used" value={row.lookups_used || "—"} />
    </div>
  );
}

function SummaryItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-ink-500">{label}</div>
      <div className="text-sm font-medium text-ink-900 break-words">{value}</div>
    </div>
  );
}

function TracePath({
  row,
  session,
  mapping,
}: {
  row: FieldMappingJson;
  session: ParsedSession;
  mapping: MappingJson;
}) {
  const steps = useMemo(() => buildSteps(row, session, mapping), [row, session, mapping]);
  return (
    <div>
      <div className="mb-3 text-xs uppercase tracking-wider text-ink-500">
        Field flow — source at top, target at bottom
      </div>
      <div className="space-y-0">
        {steps.map((step, i) => (
          <Fragment key={`${step.kind}-${step.name}-${i}`}>
            <StepCard step={step} />
            {i < steps.length - 1 ? <Connector /> : null}
          </Fragment>
        ))}
      </div>
      {row.router_condition ? (
        <div className="mt-4 rounded-md border border-sky-200 bg-sky-50/60 px-3 py-2 text-xs text-ink-700">
          <strong className="font-semibold text-ink-900">Router condition:</strong>{" "}
          <span className="font-mono">{row.router_condition}</span>
        </div>
      ) : null}
      {row.notes ? (
        <div className="mt-2 rounded-md border border-ink-100 bg-ink-50/60 px-3 py-2 text-xs text-ink-600">
          <strong className="font-semibold text-ink-700">Notes:</strong> {row.notes}
        </div>
      ) : null}
    </div>
  );
}

function buildSteps(
  row: FieldMappingJson,
  session: ParsedSession,
  mapping: MappingJson,
): TraceStep[] {
  const m = session.mapping;
  if (!m) return [];

  // Parse the expression chain: "EXP_CALC.NET_AMOUNT: ROUND(...) || UPD_FACT.NET_AMOUNT: NET_AMOUNT"
  const exprByInstance = new Map<string, { field: string; expr: string }[]>();
  if (row.expression_chain) {
    for (const segment of row.expression_chain.split(" || ")) {
      const match = segment.match(/^([^.]+)\.(.+?):\s*([\s\S]+)$/);
      if (!match) continue;
      const [, inst, field, expr] = match;
      if (!exprByInstance.has(inst)) exprByInstance.set(inst, []);
      exprByInstance.get(inst)!.push({ field, expr });
    }
  }

  const path = row.transformation_path ? row.transformation_path.split(" → ") : [];
  const steps: TraceStep[] = [];

  const srcTable = row.source_table || "";
  const sourceLabeled = srcTable.startsWith("(") && !srcTable.startsWith("(lookup ");
  const hasResolvedSource = !!srcTable && !sourceLabeled;

  // Look up connection bindings by instance name (same map buildLineage uses).
  const connByInstance = new Map(
    session.connectionRefs.map((c) => [c.instanceName, { name: c.connectionName, type: c.connectionType }]),
  );

  if (hasResolvedSource) {
    // Multi-source format is "T1, T2" / cols "A; B" (per Clean schema).
    const sources = srcTable.split(",").map((s) => s.trim());
    const sourceColGroups = row.source_column ? row.source_column.split("; ") : [];
    sources.forEach((srcName, i) => {
      const def = m.sources.find((s) => s.name === srcName);
      const lookupMatch = mapping.lookups.find((l) => l.lookup_id === srcName);
      const conn = connByInstance.get(srcName) ?? (lookupMatch?.connection ? { name: lookupMatch.connection, type: "" } : undefined);
      steps.push({
        kind: "source",
        name: srcName,
        type: def
          ? `Source · ${def.databaseType ?? "?"}`
          : lookupMatch
            ? "Lookup table"
            : "Source",
        field: sourceColGroups[i] ?? sourceColGroups.join("/"),
        dataType: row.source_datatype
          ? `${row.source_datatype}${row.source_precision ? `(${row.source_precision}${row.source_scale && row.source_scale !== "0" ? "," + row.source_scale : ""})` : ""}`
          : undefined,
        connection: i === 0 ? conn?.name : undefined,
        connectionType: i === 0 ? conn?.type : undefined,
        description: def?.description,
        expressions: [],
      });
    });
  } else if (sourceLabeled) {
    steps.push({
      kind: "label",
      name: srcTable,
      type: "Source unavailable",
      description: classifyDescription(srcTable),
      expressions: [],
    });
  }

  // Add transformation steps from the path. Drop source-type instances (already shown above)
  // and the final target-type instance (rendered separately below).
  for (let i = 0; i < path.length; i++) {
    const instName = path[i];
    const inst = m.instances.find((x) => x.name === instName);
    const txDef = m.transformations.find((t) => t.name === instName);
    const instType = (inst?.type ?? txDef?.type ?? "").trim();

    const isSource = /source/i.test(instType) && !/qualifier/i.test(instType);
    const isTarget = /target/i.test(instType);
    if (isSource && hasResolvedSource) continue;
    if (isTarget && i === path.length - 1) continue;

    steps.push({
      kind: isSource ? "source" : isTarget ? "target" : "transformation",
      name: instName,
      type: prettyType(instType) || (isSource ? "Source" : "Transformation"),
      expressions: exprByInstance.get(instName) ?? [],
      description: inst?.description ?? txDef?.description,
    });
  }

  // Target step (always last). Connection lookup uses the target instance
  // name; some sessions wire the connection via the TARGET DEFINITION name
  // directly, so fall back to that if the instance has no binding.
  const tgtConn =
    connByInstance.get(row.target_table) ??
    (path.length > 0 ? connByInstance.get(path[path.length - 1]) : undefined);

  steps.push({
    kind: "target",
    name: row.target_table,
    type: row.load_type && row.load_type !== "UNSPECIFIED" ? `Target · ${row.load_type}` : "Target",
    field: row.target_column,
    dataType: row.target_datatype
      ? `${row.target_datatype}${row.target_precision ? `(${row.target_precision}${row.target_scale && row.target_scale !== "0" ? "," + row.target_scale : ""})` : ""}`
      : undefined,
    connection: tgtConn?.name,
    connectionType: tgtConn?.type,
    expressions: exprByInstance.get(row.target_table) ?? [],
  });

  return steps;
}

function prettyType(t: string): string {
  if (!t) return "";
  return t.replace(/^Source\s+Definition$/i, "Source").replace(/^Target\s+Definition$/i, "Target");
}

function classifyDescription(label: string): string {
  if (label === "(not wired)") {
    return "Target column has no incoming connector in the mapping.";
  }
  if (label === "(computed)") {
    return "Value is derived from an expression that doesn't reduce to a single source column (e.g. arithmetic, IIF, lookup result via :LKP, or computed default).";
  }
  if (label === "(system)") {
    return "Value comes from a system function or parameter (SYSDATE / SESSSTARTTIME / $$VAR).";
  }
  if (label === "(literal)") {
    return "Value is a hardcoded literal (string, number, or NULL).";
  }
  if (label === "(aggregated)") {
    return "Value comes from an aggregate function (SUM / COUNT / AVG / etc.).";
  }
  if (label.startsWith("(unresolved")) {
    return "Walk dead-ended before reaching a source. See Mapping Inspector for diagnostics.";
  }
  if (label.startsWith("(lookup ")) {
    return "Value comes from a lookup whose underlying table name could not be read from the XML.";
  }
  return "";
}

function StepCard({ step }: { step: TraceStep }) {
  const palette: Record<StepKind, { border: string; bg: string; chip: string }> = {
    source: {
      border: "border-emerald-300",
      bg: "bg-emerald-50/40",
      chip: "bg-emerald-100 text-emerald-900",
    },
    transformation: {
      border: "border-sky-300",
      bg: "bg-sky-50/40",
      chip: "bg-sky-100 text-sky-900",
    },
    target: {
      border: "border-amber-300",
      bg: "bg-amber-50/40",
      chip: "bg-amber-100 text-amber-900",
    },
    label: {
      border: "border-rose-300",
      bg: "bg-rose-50/40",
      chip: "bg-rose-100 text-rose-900",
    },
  };
  const p = palette[step.kind];
  const kindLabel =
    step.kind === "source"
      ? "Source"
      : step.kind === "target"
      ? "Target"
      : step.kind === "label"
      ? "Unresolved"
      : "Transformation";
  return (
    <div className={`rounded-lg border-2 ${p.border} ${p.bg} px-5 py-4`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span
            className={`inline-block rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${p.chip}`}
          >
            {kindLabel}
          </span>
          <h4 className="text-sm font-semibold text-ink-900">{step.name}</h4>
          {step.type ? <Pill>{step.type}</Pill> : null}
        </div>
        {step.field ? (
          <div className="text-xs text-ink-700">
            <span className="font-semibold text-ink-900">{step.field}</span>
            {step.dataType ? <span className="ml-2 font-mono text-[11px] text-ink-500">{step.dataType}</span> : null}
          </div>
        ) : null}
      </div>
      {step.connection ? (
        <div className="mt-1 text-xs text-ink-500">
          Connection: <span className="font-medium text-ink-700">{step.connection}</span>
          {step.connectionType ? <span className="ml-1">({step.connectionType})</span> : null}
        </div>
      ) : null}
      {step.description ? (
        <div className="mt-1 text-xs text-ink-600">{step.description}</div>
      ) : null}
      {step.expressions.length > 0 ? (
        <div className="mt-3 space-y-2">
          {step.expressions.map((e, i) => (
            <div key={i} className="rounded border border-ink-200 bg-white px-3 py-2 shadow-sm">
              <div className="text-[10px] uppercase tracking-wider text-ink-500">{e.field}</div>
              <pre className="mt-1 whitespace-pre-wrap break-words font-mono text-[12px] text-ink-900">
                {e.expr}
              </pre>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function Connector() {
  return (
    <div className="flex justify-center py-1 text-ink-400">
      <svg width="14" height="22" viewBox="0 0 14 22" fill="none" aria-hidden>
        <path
          d="M7 0 L7 16 M2 12 L7 17 L12 12"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}
