"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, KeyValueTable, Pill, Stat } from "@/components/ui";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { LineageGraph } from "@/components/LineageGraph";
import { RawXmlInspector } from "@/components/RawXmlInspector";
import { CopyButton } from "@/components/CopyButton";
import { SqlBlock } from "@/components/SqlBlock";
import { ValidationPanel } from "@/components/ValidationPanel";
import { LineageTracer } from "@/components/LineageTracer";
import { UnresolvedDiagnostics } from "@/components/UnresolvedDiagnostics";
import {
  GROUP_ORDER,
  groupAttributes,
  type ConfigDef,
  type MappletDef,
  type ParsedSession,
  type SourceDef,
  type TargetDef,
  type TransformationDef,
  type WorkflowDef,
} from "@/lib/sessions";
import {
  downloadSessionCleanXlsx,
  downloadSessionCsv,
  downloadSessionJson,
  downloadSessionMarkdown,
} from "@/lib/downloads";
import { validateSession } from "@/lib/validation";
import { buildMappingJson } from "@/lib/build-mapping-json";
import { setHashParams, useHashParams } from "@/lib/href";

type SectionId = string;

type Section = {
  id: SectionId;
  label: string;
  group: string;
  count?: number;
  render: () => React.ReactElement;
};

export function SessionView({ session }: { session: ParsedSession }) {
  const issues = useMemo(() => validateSession(session), [session]);
  // Show the same row count S2T + Mapping Inspector + XLSX use — the
  // canonical MappingJson rows, not raw lineage.
  const fieldMappings = useMemo(
    () => (session.mapping ? buildMappingJson(session).field_mappings : []),
    [session],
  );
  const storageKey = `${session.fileName}::${session.name}`;
  const m = session.mapping;
  const groups = session.attributes.length > 0 ? groupAttributes(session.attributes) : {};

  const sections: Section[] = useMemo(() => {
    const list: Section[] = [
      {
        id: "overview",
        label: "Overview",
        group: "Summary",
        render: () => <SessionHeader session={session} />,
      },
      {
        id: "validation",
        label: "Validation",
        group: "Summary",
        count: issues.length,
        render: () => <ValidationPanel issues={issues} />,
      },
    ];

    if (m) {
      list.push({
        id: "s2t",
        label: "Source → Target",
        group: "Summary",
        count: fieldMappings.length,
        render: () => <S2TTable session={session} />,
      });
      list.push({
        id: "tracer",
        label: "Lineage Tracer",
        group: "Summary",
        render: () => <LineageTracer session={session} />,
      });
      list.push({
        id: "diagnose",
        label: "Mapping Inspector",
        group: "Summary",
        render: () => <UnresolvedDiagnostics session={session} />,
      });
      // Count transformations exposing any SQL-bearing TABLEATTRIBUTE
      // (SQs + Lookups + anything else). Matches the Source SQL panel scope.
      const sourceSqlCount = m.transformations.filter((t) =>
        t.tableAttributes.some((a) => /\b(sql|query|override|filter)\b/i.test(a.name)),
      ).length;
      if (sourceSqlCount > 0) {
        list.push({
          id: "source-sql",
          label: "Source SQL",
          group: "Mapping",
          count: sourceSqlCount,
          render: () => <SourceSqlPanel session={session} />,
        });
      }
    }

    if (session.attributes.length > 0) {
      list.push({
        id: "attributes",
        label: "Attributes",
        group: "Session",
        count: session.attributes.length,
        render: () => (
          <div className="grid gap-4 lg:grid-cols-2">
            {GROUP_ORDER.filter((g) => groups[g] && groups[g].length > 0).map((g) => (
              <div key={g}>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">{g}</h3>
                <KeyValueTable rows={groups[g]} />
              </div>
            ))}
          </div>
        ),
      });
    }
    if (session.connectionRefs.length > 0) {
      list.push({
        id: "connections",
        label: "Connections",
        group: "Session",
        count: session.connectionRefs.length,
        render: () => <ConnectionsTable session={session} />,
      });
    }
    if (session.transformationInstances.length > 0) {
      list.push({
        id: "instance-overrides",
        label: "Instance Overrides",
        group: "Session",
        count: session.transformationInstances.length,
        render: () => <TxInstancesList session={session} />,
      });
    }
    if (session.extensions.length > 0) {
      list.push({
        id: "extensions",
        label: "Session Extensions",
        group: "Session",
        count: session.extensions.length,
        render: () => <ExtensionsList session={session} />,
      });
    }
    if (session.parameters.length > 0) {
      list.push({
        id: "parameters",
        label: "Parameters",
        group: "Session",
        count: session.parameters.length,
        render: () => <KeyValueTable rows={session.parameters} />,
      });
    }

    if (m) {
      if (m.sources.length > 0) {
        list.push({
          id: "sources",
          label: "Sources",
          group: "Mapping",
          count: m.sources.length,
          render: () => (
            <div className="grid gap-3">
              {m.sources.map((s, i) => (
                <SourceTargetBlock key={i} kind="source" def={s} />
              ))}
            </div>
          ),
        });
      }
      if (m.targets.length > 0) {
        list.push({
          id: "targets",
          label: "Targets",
          group: "Mapping",
          count: m.targets.length,
          render: () => (
            <div className="grid gap-3">
              {m.targets.map((t, i) => (
                <SourceTargetBlock key={i} kind="target" def={t} />
              ))}
            </div>
          ),
        });
      }
      if (m.transformations.length > 0) {
        list.push({
          id: "transformations",
          label: "Transformations",
          group: "Mapping",
          count: m.transformations.length,
          render: () => (
            <div className="grid gap-3">
              {m.transformations.map((t, i) => (
                <TransformationBlock key={i} def={t} />
              ))}
            </div>
          ),
        });
        const lookups = m.transformations.filter((t) => /lookup/i.test(t.type));
        if (lookups.length > 0) {
          list.push({
            id: "lookups",
            label: "Lookups",
            group: "Mapping",
            count: lookups.length,
            render: () => (
              <div className="grid gap-3">
                {lookups.map((t, i) => (
                  <TransformationBlock key={i} def={t} />
                ))}
              </div>
            ),
          });
        }
      }
      if (m.connectors.length > 0) {
        list.push({
          id: "graph",
          label: "Lineage Graph",
          group: "Mapping",
          render: () => (
            <ErrorBoundary label="Lineage graph">
              <LineageGraph connectors={m.connectors} instances={m.instances} storageKey={storageKey} />
            </ErrorBoundary>
          ),
        });
        list.push({
          id: "connectors",
          label: "Connectors",
          group: "Mapping",
          count: m.connectors.length,
          render: () => <ConnectorsTable connectors={m.connectors} />,
        });
      }
      if (m.instances.length > 0 || m.mapplets.length > 0) {
        list.push({
          id: "composition",
          label: "Composition",
          group: "Mapping",
          count: m.instances.length + m.mapplets.length,
          render: () => <CompositionView instances={m.instances} mapplets={m.mapplets} />,
        });
      }
    }

    if (session.workflows.length > 0) {
      list.push({
        id: "workflows",
        label: "Workflows",
        group: "Workflow & Reference",
        count: session.workflows.length,
        render: () => <WorkflowsBody workflows={session.workflows} />,
      });
    }
    if (session.configs.length > 0) {
      list.push({
        id: "configs",
        label: "Configs",
        group: "Workflow & Reference",
        count: session.configs.length,
        render: () => <ConfigsBody configs={session.configs} />,
      });
    }
    list.push({
      id: "raw",
      label: "Raw XML",
      group: "Workflow & Reference",
      render: () => (
        <ErrorBoundary label="Raw XML inspector">
          <RawXmlInspector xml={session.rawXml} />
        </ErrorBoundary>
      ),
    });

    return list;
  }, [session, issues, fieldMappings, m, groups, storageKey]);

  const hashParams = useHashParams();
  const requested = hashParams.get("view") ?? "";
  const activeId = sections.some((s) => s.id === requested) ? requested : sections[0]?.id ?? "overview";
  const active = sections.find((s) => s.id === activeId) ?? sections[0];

  // Reset to overview if the user picks a different session and the previous
  // section isn't in the new list.
  useEffect(() => {
    if (!sections.some((s) => s.id === requested) && requested) {
      setHashParams((sp) => sp.delete("view"));
    }
  }, [sections, requested]);

  function pickSection(id: SectionId) {
    setHashParams((sp) => sp.set("view", id));
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
      <Sidebar sections={sections} activeId={active?.id ?? ""} onPick={pickSection} />
      <main className="min-w-0">
        {active ? (
          <>
            <div className="mb-4 flex items-baseline justify-between gap-3 border-b border-ink-200 pb-3">
              <h2 className="text-lg font-semibold text-ink-900">{active.label}</h2>
              <div className="text-xs text-ink-500">
                {session.name} · {session.fileName}
              </div>
            </div>
            <div className="grid gap-6">{active.render()}</div>
          </>
        ) : null}
      </main>
    </div>
  );
}

function Sidebar({
  sections,
  activeId,
  onPick,
}: {
  sections: Section[];
  activeId: SectionId;
  onPick: (id: SectionId) => void;
}) {
  const grouped = useMemo(() => {
    const map = new Map<string, Section[]>();
    for (const s of sections) {
      if (!map.has(s.group)) map.set(s.group, []);
      map.get(s.group)!.push(s);
    }
    return [...map.entries()];
  }, [sections]);

  return (
    <aside className="lg:sticky lg:top-6 lg:self-start">
      <nav className="rounded-lg border border-ink-200 bg-white p-2 shadow-sm">
        {grouped.map(([group, items]) => (
          <div key={group} className="mb-2 last:mb-0">
            <h4 className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-ink-500">
              {group}
            </h4>
            <ul className="grid gap-0.5">
              {items.map((s) => {
                const active = s.id === activeId;
                return (
                  <li key={s.id}>
                    <button
                      type="button"
                      onClick={() => onPick(s.id)}
                      className={`flex w-full items-center justify-between gap-2 rounded-md px-3 py-1.5 text-left text-sm transition ${
                        active
                          ? "bg-ink-900 text-white"
                          : "text-ink-700 hover:bg-ink-100"
                      }`}
                    >
                      <span className="truncate">{s.label}</span>
                      {typeof s.count === "number" ? (
                        <span
                          className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                            active ? "bg-white/15 text-white" : "bg-ink-100 text-ink-600"
                          }`}
                        >
                          {s.count}
                        </span>
                      ) : null}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}

function SessionHeader({ session }: { session: ParsedSession }) {
  const [busy, setBusy] = useState(false);
  async function withBusy(fn: () => unknown | Promise<unknown>) {
    if (busy) return;
    setBusy(true);
    try {
      await fn();
    } catch (e) {
      console.error(e);
      alert(`Download failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Card
      title={session.name}
      subtitle={
        session.description ||
        `${session.hasSession ? "Loaded" : "Mapping-only export"} from ${session.fileName}`
      }
      right={
        <div className="flex flex-wrap items-center gap-2">
          {session.reusable ? (
            <Pill tone={session.reusable === "YES" ? "ok" : "default"}>Reusable: {session.reusable}</Pill>
          ) : null}
          {session.isValid ? (
            <Pill tone={session.isValid === "YES" ? "ok" : "warn"}>Valid: {session.isValid}</Pill>
          ) : null}
          {session.versionNumber ? <Pill>v{session.versionNumber}</Pill> : null}
          <div className="flex items-center overflow-hidden rounded-md border border-ink-200 bg-white shadow-sm text-xs">
            <button
              type="button"
              disabled={busy}
              onClick={() => withBusy(() => downloadSessionCleanXlsx(session))}
              className="flex items-center gap-1 bg-ink-900 px-3 py-1.5 font-semibold text-white hover:bg-ink-800 disabled:opacity-60"
              title="Clean 3-sheet workbook (FIELD_MAPPING + LOOKUPS + TRANSFORMATIONS)"
            >
              <DownloadIcon /> {busy ? "Building…" : "XLSX"}
            </button>
            <button
              type="button"
              onClick={() => withBusy(() => downloadSessionCsv(session))}
              className="px-2 py-1.5 text-ink-700 hover:bg-ink-50 border-l border-ink-200"
              title="FIELD_MAPPING as CSV (same columns as the XLSX)"
            >
              CSV
            </button>
            <button
              type="button"
              onClick={() => withBusy(() => downloadSessionJson(session))}
              className="px-2 py-1.5 text-ink-700 hover:bg-ink-50"
              title="MappingJson — normalized intermediate (same data as XLSX)"
            >
              JSON
            </button>
            <button
              type="button"
              onClick={() => withBusy(() => downloadSessionMarkdown(session))}
              className="px-2 py-1.5 text-ink-700 hover:bg-ink-50"
              title="Markdown documentation"
            >
              MD
            </button>
          </div>
        </div>
      }
    >
      <div className="grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4">
        <Stat label="Repository" value={session.repository?.name ?? "—"} />
        <Stat label="Folder" value={session.folder?.name ?? "—"} />
        <Stat label="Mapping" value={session.mappingName ?? session.mapping?.name ?? "—"} />
        <Stat label="Config" value={session.configReference ?? "—"} />
        <Stat label="Attributes" value={session.attributes.length} />
        <Stat label="Tx instances" value={session.transformationInstances.length} />
        <Stat label="Connections" value={session.connectionRefs.length} />
        <Stat label="Parameters" value={session.parameters.length} />
        <Stat label="Tx defs" value={session.mapping?.transformations.length ?? 0} />
        <Stat label="Sources" value={session.mapping?.sources.length ?? 0} />
        <Stat label="Targets" value={session.mapping?.targets.length ?? 0} />
        <Stat label="Connectors" value={session.mapping?.connectors.length ?? 0} />
      </div>
    </Card>
  );
}

function DownloadIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
      <path d="M10 3a1 1 0 0 1 1 1v7.586l2.293-2.293a1 1 0 1 1 1.414 1.414l-4 4a1 1 0 0 1-1.414 0l-4-4a1 1 0 1 1 1.414-1.414L9 11.586V4a1 1 0 0 1 1-1Z" />
      <path d="M3 15a1 1 0 0 1 1-1h12a1 1 0 1 1 0 2H4a1 1 0 0 1-1-1Z" />
    </svg>
  );
}

function S2TTable({ session }: { session: ParsedSession }) {
  const rows = useMemo(() => buildMappingJson(session).field_mappings, [session]);
  if (rows.length === 0) {
    return <p className="text-sm text-ink-500">No lineage available (mapping not present or no target columns).</p>;
  }
  return (
    <div className="overflow-x-auto rounded-md border border-ink-100">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-white">
          <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
            <th className="px-3 py-2">Target</th>
            <th className="px-3 py-2">Source</th>
            <th className="px-3 py-2">Load</th>
            <th className="px-3 py-2">Expression / logic</th>
            <th className="px-3 py-2">Path</th>
            <th className="px-3 py-2">Router / Notes</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-100">
          {rows.map((r, i) => {
            const srcTable = r.source_table || "";
            const computed = srcTable.startsWith("(") && !srcTable.startsWith("(lookup ");
            return (
              <tr key={i} className="even:bg-ink-50/40 align-top">
                <td className="px-3 py-2">
                  <div className="font-medium text-ink-900">{r.target_table}</div>
                  <div className="font-mono text-[12px] text-ink-700">{r.target_column}</div>
                </td>
                <td className="px-3 py-2">
                  <div className={`font-medium ${computed ? "text-rose-700" : "text-ink-900"}`}>
                    {srcTable || "—"}
                  </div>
                  {r.source_column ? (
                    <div className="font-mono text-[12px] text-ink-700">{r.source_column}</div>
                  ) : null}
                </td>
                <td className="px-3 py-2 text-xs text-ink-700">
                  {r.load_type && r.load_type !== "UNSPECIFIED" ? r.load_type : "—"}
                </td>
                <td className="px-3 py-2 font-mono text-[12px] text-ink-900 break-words max-w-md">
                  {r.business_logic_expression || <span className="text-ink-400">—</span>}
                </td>
                <td className="px-3 py-2 text-xs text-ink-600 break-words max-w-xs">
                  {r.transformation_path || "—"}
                </td>
                <td className="px-3 py-2 text-xs text-ink-600 break-words max-w-xs">
                  {r.router_condition ? (
                    <div className="font-mono">{r.router_condition}</div>
                  ) : null}
                  {r.notes ? <div className="mt-0.5 text-ink-500">{r.notes}</div> : null}
                  {!r.router_condition && !r.notes ? "—" : null}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// Source SQL panel — one collapsible card per transformation that carries
// any SQL-bearing TABLEATTRIBUTE (Source Qualifiers AND Lookups). Each SQL
// slot (Sql Override, Lookup Sql Override, Pre SQL, Post SQL, Source Filter,
// etc.) renders as its own labeled SqlBlock so reviewers can scan + copy
// individual queries. Same data the XLSX "Source SQL" sheet exports.
function SourceSqlPanel({ session }: { session: ParsedSession }) {
  const rows = useMemo(() => buildMappingJson(session).source_sql, [session]);
  if (rows.length === 0) {
    return (
      <p className="text-sm text-ink-500">
        No SQL-bearing transformations (Source Qualifier / Lookup / etc.) in this mapping.
      </p>
    );
  }
  return (
    <div className="grid gap-3">
      {rows.map((sq) => {
        const filled = sq.sql_entries.filter((e) => e.value.trim().length > 0);
        const labelOnly = sq.sql_entries.filter((e) => e.value.trim().length === 0);
        return (
          <Card
            key={sq.transformation}
            title={sq.transformation}
            subtitle={[
              sq.transformation_type || null,
              sq.source_definition ? `Source: ${sq.source_definition}` : null,
              sq.connection
                ? `Connection: ${sq.connection}${sq.connection_type ? ` (${sq.connection_type})` : ""}`
                : null,
            ]
              .filter(Boolean)
              .join(" · ")}
            right={
              <div className="flex items-center gap-2">
                <Pill tone={sq.has_sql ? "ok" : "default"}>
                  {sq.has_sql ? `${filled.length} SQL${filled.length === 1 ? "" : "s"}` : "No SQL value"}
                </Pill>
                {sq.source_tables ? (
                  <Pill tone="default">FROM: {sq.source_tables}</Pill>
                ) : null}
              </div>
            }
          >
            {filled.length > 0 ? (
              <div className="grid gap-3 px-4 py-3">
                {filled.map((e, i) => (
                  <div key={`${e.label}-${i}`}>
                    <div className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-ink-500">
                      {e.label}
                    </div>
                    <SqlBlock sql={e.value} />
                  </div>
                ))}
                {labelOnly.length > 0 ? (
                  <div className="text-xs text-ink-500">
                    Also declared (empty value):{" "}
                    {labelOnly.map((e) => e.label).join(", ")}
                  </div>
                ) : null}
              </div>
            ) : labelOnly.length > 0 ? (
              <p className="px-4 py-3 text-sm text-ink-500">
                Attributes declared but all values empty: {labelOnly.map((e) => e.label).join(", ")}
              </p>
            ) : (
              <p className="px-4 py-3 text-sm text-ink-500">
                No SQL-bearing attributes on this transformation.
              </p>
            )}
          </Card>
        );
      })}
    </div>
  );
}

function ConnectionsTable({ session }: { session: ParsedSession }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
            <th className="px-3 py-2">Instance</th>
            <th className="px-3 py-2">Instance type</th>
            <th className="px-3 py-2">Connection</th>
            <th className="px-3 py-2">Type</th>
            <th className="px-3 py-2">Subtype</th>
            <th className="px-3 py-2">Variable</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-100">
          {session.connectionRefs.map((c, i) => (
            <tr key={i} className="even:bg-ink-50/40">
              <td className="px-3 py-2 font-medium text-ink-900">{c.instanceName || "—"}</td>
              <td className="px-3 py-2 text-ink-700">{c.instanceType || "—"}</td>
              <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{c.connectionName || "—"}</td>
              <td className="px-3 py-2"><Pill>{c.connectionType || "—"}</Pill></td>
              <td className="px-3 py-2 text-ink-700">{c.connectionSubtype || "—"}</td>
              <td className="px-3 py-2 font-mono text-[12.5px] text-ink-700">{c.variable || "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TxInstancesList({ session }: { session: ParsedSession }) {
  return (
    <div className="grid gap-3">
      {session.transformationInstances.map((t, i) => (
        <details key={i} className="group rounded-md border border-ink-100 bg-ink-50/30 open:bg-white">
          <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3">
            <div>
              <div className="text-sm font-semibold text-ink-900">{t.name || "(unnamed)"}</div>
              {t.description ? <div className="text-xs text-ink-500">{t.description}</div> : null}
            </div>
            <div className="flex items-center gap-2">
              <Pill>{t.type || "—"}</Pill>
              <span className="text-xs text-ink-500">{t.attributes.length} attrs</span>
            </div>
          </summary>
          <div className="border-t border-ink-100 px-4 py-3">
            <KeyValueTable rows={t.attributes} empty="No overrides on this instance." />
          </div>
        </details>
      ))}
    </div>
  );
}

function ExtensionsList({ session }: { session: ParsedSession }) {
  return (
    <div className="grid gap-3">
      {session.extensions.map((e, i) => (
        <details key={i} className="group rounded-md border border-ink-100 bg-ink-50/30 open:bg-white">
          <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3">
            <div className="text-sm font-semibold text-ink-900">{e.name || "(unnamed)"}</div>
            <div className="flex items-center gap-2">
              <Pill>{e.type || "—"}</Pill>
              {e.subtype ? <Pill>{e.subtype}</Pill> : null}
              <span className="text-xs text-ink-500">{e.attributes.length} attrs</span>
            </div>
          </summary>
          <div className="border-t border-ink-100 px-4 py-3">
            <KeyValueTable rows={e.attributes} />
          </div>
        </details>
      ))}
    </div>
  );
}

function ConnectorsTable({ connectors }: { connectors: TransformationDef extends never ? never : NonNullable<ParsedSession["mapping"]>["connectors"] }) {
  return (
    <div className="max-h-[600px] overflow-auto rounded-md border border-ink-100">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-white">
          <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
            <th className="px-3 py-2">From instance</th>
            <th className="px-3 py-2">From field</th>
            <th className="px-3 py-2"></th>
            <th className="px-3 py-2">To instance</th>
            <th className="px-3 py-2">To field</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-100">
          {connectors.map((c, i) => (
            <tr key={i} className="even:bg-ink-50/40">
              <td className="px-3 py-2 font-medium text-ink-900">
                {c.fromInstance}
                <div className="text-[11px] text-ink-500">{c.fromInstanceType}</div>
              </td>
              <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{c.fromField}</td>
              <td className="px-3 py-2 text-ink-400">→</td>
              <td className="px-3 py-2 font-medium text-ink-900">
                {c.toInstance}
                <div className="text-[11px] text-ink-500">{c.toInstanceType}</div>
              </td>
              <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{c.toField}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CompositionView({
  instances,
  mapplets,
}: {
  instances: NonNullable<ParsedSession["mapping"]>["instances"];
  mapplets: MappletDef[];
}) {
  return (
    <div className="grid gap-6">
      {instances.length > 0 ? (
        <div>
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Mapping instances ({instances.length})</h3>
          <div className="overflow-x-auto rounded-md border border-ink-100">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
                  <th className="px-3 py-2">Instance</th>
                  <th className="px-3 py-2">Kind</th>
                  <th className="px-3 py-2">Definition</th>
                  <th className="px-3 py-2">Tx type</th>
                  <th className="px-3 py-2">Reusable</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {instances.map((inst, i) => (
                  <tr key={i} className="even:bg-ink-50/40">
                    <td className="px-3 py-2 font-medium text-ink-900">{inst.name}</td>
                    <td className="px-3 py-2"><Pill>{inst.type || "—"}</Pill></td>
                    <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{inst.transformationName || "—"}</td>
                    <td className="px-3 py-2 text-ink-700">{inst.transformationType || "—"}</td>
                    <td className="px-3 py-2 text-ink-700">{inst.reusable || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}
      {mapplets.length > 0 ? (
        <div>
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Mapplets ({mapplets.length})</h3>
          <div className="grid gap-2 sm:grid-cols-2">
            {mapplets.map((m, i) => (
              <div key={i} className="rounded-md border border-ink-100 bg-ink-50/40 px-3 py-2">
                <div className="text-sm font-semibold text-ink-900">{m.name}</div>
                {m.description ? <div className="text-xs text-ink-500">{m.description}</div> : null}
                <div className="mt-1 text-[11px] text-ink-500">
                  {m.instanceCount} instances · {m.transformationCount} transformations
                  {m.versionNumber ? ` · v${m.versionNumber}` : ""}
                  {m.isValid ? ` · valid: ${m.isValid}` : ""}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function SourceTargetBlock({ def, kind }: { def: SourceDef | TargetDef; kind: "source" | "target" }) {
  const isTarget = kind === "target";
  const databaseName = !isTarget ? (def as SourceDef).databaseName : undefined;
  const ownerName = !isTarget ? (def as SourceDef).ownerName : undefined;
  return (
    <details className="group rounded-md border border-ink-100 bg-ink-50/30 open:bg-white">
      <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3">
        <div>
          <div className="text-sm font-semibold text-ink-900">{def.name}</div>
          {def.description ? <div className="text-xs text-ink-500">{def.description}</div> : null}
        </div>
        <div className="flex items-center gap-2">
          {def.databaseType ? <Pill>{def.databaseType}</Pill> : null}
          {databaseName ? <span className="text-xs text-ink-500">{databaseName}</span> : null}
          {ownerName ? <span className="text-xs text-ink-500">/ {ownerName}</span> : null}
          <span className="text-xs text-ink-500">{def.fields.length} fields</span>
        </div>
      </summary>
      <div className="border-t border-ink-100 px-4 py-3">
        {def.fields.length === 0 ? (
          <p className="text-sm text-ink-500">No fields.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
                  <th className="px-3 py-2">#</th>
                  <th className="px-3 py-2">Field</th>
                  <th className="px-3 py-2">Type</th>
                  <th className="px-3 py-2">Prec/Scale</th>
                  <th className="px-3 py-2">Key</th>
                  <th className="px-3 py-2">Nullable</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {def.fields.map((f, i) => (
                  <tr key={i} className="even:bg-ink-50/40">
                    <td className="px-3 py-2 text-ink-500">{f.fieldNumber ?? i + 1}</td>
                    <td className="px-3 py-2 font-medium text-ink-900">{f.name}</td>
                    <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{f.datatype}</td>
                    <td className="px-3 py-2 font-mono text-[12.5px] text-ink-700">
                      {f.precision ?? "—"}
                      {f.scale && f.scale !== "0" ? `, ${f.scale}` : ""}
                    </td>
                    <td className="px-3 py-2 text-ink-700">{f.keyType ?? "—"}</td>
                    <td className="px-3 py-2 text-ink-700">{f.nullable ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </details>
  );
}

function TransformationBlock({ def }: { def: TransformationDef }) {
  const sqlAttr = def.tableAttributes.find((a) => /^(sql query|lookup sql override)$/i.test(a.name));
  return (
    <details className="group rounded-md border border-ink-100 bg-ink-50/30 open:bg-white">
      <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3">
        <div>
          <div className="text-sm font-semibold text-ink-900">{def.name}</div>
          {def.description ? <div className="text-xs text-ink-500">{def.description}</div> : null}
        </div>
        <div className="flex items-center gap-2">
          <Pill>{def.type}</Pill>
          {def.reusable === "YES" ? <Pill tone="ok">reusable</Pill> : null}
          <span className="text-xs text-ink-500">{def.fields.length} ports · {def.tableAttributes.length} attrs</span>
        </div>
      </summary>
      <div className="space-y-4 border-t border-ink-100 px-4 py-3">
        {sqlAttr ? (
          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">{sqlAttr.name}</h4>
            <SqlBlock sql={sqlAttr.value} label={sqlAttr.name} />
          </div>
        ) : null}
        {def.tableAttributes.length > 0 ? (
          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Settings (TABLEATTRIBUTE)</h4>
            <KeyValueTable rows={def.tableAttributes.filter((a) => a !== sqlAttr)} />
          </div>
        ) : null}
        {def.fields.length > 0 ? (
          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Ports</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
                    <th className="px-3 py-2">Port</th>
                    <th className="px-3 py-2">Direction</th>
                    <th className="px-3 py-2">Type</th>
                    <th className="px-3 py-2">P/S</th>
                    <th className="px-3 py-2">Expression</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {def.fields.map((f, i) => (
                    <tr key={i} className="even:bg-ink-50/40 align-top">
                      <td className="px-3 py-2 font-medium text-ink-900">{f.name}</td>
                      <td className="px-3 py-2 text-ink-700">{f.portType}</td>
                      <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{f.datatype}</td>
                      <td className="px-3 py-2 font-mono text-[12.5px] text-ink-700">
                        {f.precision ?? "—"}
                        {f.scale && f.scale !== "0" ? `, ${f.scale}` : ""}
                      </td>
                      <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900 break-all">
                        {f.expression ? (
                          <span className="inline-flex items-start gap-1">
                            <span>{f.expression}</span>
                            <CopyButton text={f.expression} />
                          </span>
                        ) : (
                          <span className="text-ink-400">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
        {def.metadataExtensions.length > 0 ? (
          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Metadata extensions</h4>
            <KeyValueTable rows={def.metadataExtensions} />
          </div>
        ) : null}
      </div>
    </details>
  );
}

function WorkflowsBody({ workflows }: { workflows: WorkflowDef[] }) {
  return (
    <div className="grid gap-3">
      {workflows.map((w, i) => (
        <details key={i} className="group rounded-md border border-ink-100 bg-ink-50/30 open:bg-white">
          <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3">
            <div>
              <div className="text-sm font-semibold text-ink-900">{w.name || "(unnamed)"}</div>
              {w.description ? <div className="text-xs text-ink-500">{w.description}</div> : null}
            </div>
            <div className="flex items-center gap-2">
              {w.isValid ? <Pill tone={w.isValid === "YES" ? "ok" : "warn"}>Valid: {w.isValid}</Pill> : null}
              {w.isEnabled ? <Pill>{w.isEnabled === "YES" ? "Enabled" : "Disabled"}</Pill> : null}
              <span className="text-xs text-ink-500">{w.tasks.length} tasks · {w.links.length} links</span>
            </div>
          </summary>
          <div className="space-y-4 border-t border-ink-100 px-4 py-3">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Stat label="Server" value={w.serverName ?? "—"} />
              <Stat label="Scheduler" value={w.schedulerName ?? "—"} />
              <Stat label="Tasks" value={w.tasks.length} />
              <Stat label="Links" value={w.links.length} />
            </div>
            {w.tasks.length > 0 ? (
              <div>
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Tasks</h4>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
                      <th className="px-3 py-2">Instance</th>
                      <th className="px-3 py-2">Task</th>
                      <th className="px-3 py-2">Type</th>
                      <th className="px-3 py-2">Reusable</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {w.tasks.map((t, j) => (
                      <tr key={j} className="even:bg-ink-50/40">
                        <td className="px-3 py-2 font-medium text-ink-900">{t.name}</td>
                        <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{t.taskName || "—"}</td>
                        <td className="px-3 py-2"><Pill>{t.taskType || "—"}</Pill></td>
                        <td className="px-3 py-2 text-ink-700">{t.reusable || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}
            {w.links.length > 0 ? (
              <div>
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Links / conditions</h4>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-ink-100 text-left text-xs uppercase tracking-wider text-ink-500">
                      <th className="px-3 py-2">From</th>
                      <th className="px-3 py-2"></th>
                      <th className="px-3 py-2">To</th>
                      <th className="px-3 py-2">Condition</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {w.links.map((l, j) => (
                      <tr key={j} className="even:bg-ink-50/40">
                        <td className="px-3 py-2 font-medium text-ink-900">{l.fromTask}</td>
                        <td className="px-3 py-2 text-ink-400">→</td>
                        <td className="px-3 py-2 font-medium text-ink-900">{l.toTask}</td>
                        <td className="px-3 py-2 font-mono text-[12.5px] text-ink-900">{l.condition || <span className="text-ink-400">—</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : null}
            {w.attributes.length > 0 ? (
              <div>
                <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Workflow attributes</h4>
                <KeyValueTable rows={w.attributes} />
              </div>
            ) : null}
          </div>
        </details>
      ))}
    </div>
  );
}

function ConfigsBody({ configs }: { configs: ConfigDef[] }) {
  return (
    <div className="grid gap-3">
      {configs.map((c, i) => (
        <details key={i} className="group rounded-md border border-ink-100 bg-ink-50/30 open:bg-white">
          <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3">
            <div>
              <div className="text-sm font-semibold text-ink-900">{c.name || "(unnamed)"}</div>
              {c.description ? <div className="text-xs text-ink-500">{c.description}</div> : null}
            </div>
            <span className="text-xs text-ink-500">{c.attributes.length} attrs</span>
          </summary>
          <div className="border-t border-ink-100 px-4 py-3">
            <KeyValueTable rows={c.attributes} />
          </div>
        </details>
      ))}
    </div>
  );
}
