import type { ReactNode } from "react";

export function Card({
  title,
  subtitle,
  right,
  children,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="rounded-lg border border-ink-200 bg-white shadow-sm">
      <header className="flex items-start justify-between gap-4 border-b border-ink-100 px-5 py-3">
        <div>
          <h2 className="text-sm font-semibold tracking-tight text-ink-900">{title}</h2>
          {subtitle ? <p className="mt-0.5 text-xs text-ink-500">{subtitle}</p> : null}
        </div>
        {right}
      </header>
      <div className="px-5 py-4">{children}</div>
    </section>
  );
}

export function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex flex-col">
      <span className="text-[11px] uppercase tracking-wider text-ink-500">{label}</span>
      <span className="mt-1 text-sm font-medium text-ink-900">{value}</span>
    </div>
  );
}

export function Pill({ children, tone = "default" }: { children: ReactNode; tone?: "default" | "ok" | "warn" }) {
  const tones: Record<string, string> = {
    default: "bg-ink-100 text-ink-700",
    ok: "bg-emerald-100 text-emerald-800",
    warn: "bg-amber-100 text-amber-800",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function KeyValueTable({
  rows,
  empty = "No values.",
}: {
  rows: { name: string; value: string }[];
  empty?: string;
}) {
  if (rows.length === 0) return <p className="text-sm text-ink-500">{empty}</p>;
  return (
    <div className="overflow-hidden rounded-md border border-ink-100">
      <table className="w-full divide-y divide-ink-100 text-sm">
        <tbody className="divide-y divide-ink-100">
          {rows.map((r, i) => (
            <tr key={`${r.name}-${i}`} className="even:bg-ink-50/40">
              <td className="w-1/3 max-w-xs px-3 py-2 align-top font-medium text-ink-700">{r.name}</td>
              <td className="px-3 py-2 align-top font-mono text-[12.5px] text-ink-900 break-all">
                {r.value || <span className="text-ink-400">—</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
