"use client";

import { useState } from "react";
import { listSessionFiles, parseAllSessions } from "@/lib/sessions";
import { downloadAllSessionsXlsx } from "@/lib/downloads";
import { navigateTo, pageHref } from "@/lib/href";

export function TopBar() {
  const [q, setQ] = useState("");
  const [bundling, setBundling] = useState(false);

  async function onDownloadAll() {
    if (bundling) return;
    setBundling(true);
    try {
      const files = await listSessionFiles();
      const all = [];
      for (const f of files) {
        try {
          const parsed = await parseAllSessions(f);
          for (const p of parsed) all.push(p);
        } catch {
          // skip unparseable
        }
      }
      await downloadAllSessionsXlsx(all);
    } catch (e) {
      alert(`Download failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBundling(false);
    }
  }

  return (
    <div className="flex items-center gap-3">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (q.trim()) navigateTo(pageHref("/search", { q: q.trim() }));
        }}
        className="relative"
      >
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search across all sessions…"
          className="w-72 rounded-md border border-ink-200 bg-white py-1.5 pl-8 pr-3 text-sm shadow-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
        />
        <svg
          width="14"
          height="14"
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden
          className="pointer-events-none absolute left-2.5 top-2 text-ink-400"
        >
          <path
            fillRule="evenodd"
            d="M9 3.5a5.5 5.5 0 1 0 3.477 9.785l3.119 3.119a.75.75 0 0 0 1.06-1.061l-3.118-3.118A5.5 5.5 0 0 0 9 3.5ZM5 9a4 4 0 1 1 8 0 4 4 0 0 1-8 0Z"
            clipRule="evenodd"
          />
        </svg>
      </form>
      <a
        href={pageHref("/diff")}
        className="rounded-md border border-ink-200 bg-white px-3 py-1.5 text-xs font-medium text-ink-700 shadow-sm hover:bg-ink-50"
      >
        Diff
      </a>
      <button
        type="button"
        onClick={onDownloadAll}
        disabled={bundling}
        className="inline-flex items-center gap-1 rounded-md bg-ink-900 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-ink-800 disabled:opacity-60"
      >
        {bundling ? "Bundling…" : "Download all (.zip)"}
      </button>
    </div>
  );
}
