"use client";

import { useMemo, useState } from "react";
import { Card, Pill } from "@/components/ui";
import type { ParsedSession } from "@/lib/sessions-types";
import { buildLineage, type LineageRow } from "@/lib/lineage";
import { buildMappingJson } from "@/lib/build-mapping-json";
import { isFieldMappingUnresolved } from "@/lib/mapping-schema";

// Identifiers in IDMC expressions we should NOT try to resolve as ports.
// Mirrors the KNOWN_FUNCTIONS list in lib/lineage.ts (a tighter subset is
// fine for diagnostic purposes — false positives just show up as "NO MATCH").
const KNOWN_FUNCTIONS = new Set([
  "TO_CHAR", "TO_DATE", "TO_NUMBER", "TO_INTEGER", "TO_DECIMAL", "TO_BIGINT",
  "IIF", "DECODE", "NVL", "COALESCE", "ISNULL", "IS_NULL",
  "TRIM", "LTRIM", "RTRIM", "UPPER", "LOWER", "INITCAP",
  "SUBSTR", "SUBSTRING", "REPLACE", "INSTR", "LENGTH", "LPAD", "RPAD", "CONCAT",
  "ABS", "ROUND", "TRUNC", "FLOOR", "CEIL", "MOD",
  "SUM", "COUNT", "AVG", "MAX", "MIN", "MEDIAN", "FIRST", "LAST", "PERCENTILE",
  "SYSDATE", "SYSTIMESTAMP", "SESSSTARTTIME", "CURRENT_DATE", "CURRENT_TIMESTAMP",
  "ADD_TO_DATE", "DATE_DIFF", "GET_DATE_PART", "DATE_COMPARE",
  "AND", "OR", "NOT", "IN", "BETWEEN", "LIKE", "NULL", "TRUE", "FALSE",
]);

// Resolved/unresolved semantics live in lib/mapping-schema so every consumer
// agrees. Use isFieldMappingUnresolved(row) below — no local definition.

function extractIdentifiers(expr: string): string[] {
  const out = new Set<string>();
  const re = /[A-Za-z_][A-Za-z0-9_]*/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(expr))) out.add(m[0]);
  return [...out];
}

type IdentifierStatus =
  | { kind: "exact-wired"; portName: string }
  | { kind: "prefix-add"; resolvedAs: string }
  | { kind: "case-fold"; resolvedAs: string }
  | { kind: "word-form"; resolvedAs: string }
  | { kind: "port-exists-unwired"; portName: string }
  | { kind: "no-port" };

// Mirrors the actual resolver in lib/lineage.ts:resolveConnectorPort.
// Critically, each step gates on a CONNECTOR actually targeting the port —
// not just on the port existing. This matches what walkExpressionPorts /
// traceField will do at runtime.
function classifyIdentifier(
  id: string,
  inputPortNames: string[],
  hasConnector: (toField: string) => boolean,
): IdentifierStatus {
  if (hasConnector(id)) return { kind: "exact-wired", portName: id };
  for (const p of ["in_", "IN_", "i_", "input_", "INPUT_"]) {
    const v = `${p}${id}`;
    if (hasConnector(v)) return { kind: "prefix-add", resolvedAs: v };
  }
  const ci = inputPortNames.find((n) => n.toLowerCase() === id.toLowerCase());
  if (ci && hasConnector(ci)) return { kind: "case-fold", resolvedAs: ci };
  const norm = id.toLowerCase().replace(/_/g, "");
  const wf = inputPortNames.find((n) => n.toLowerCase().replace(/_/g, "") === norm);
  if (wf && hasConnector(wf)) return { kind: "word-form", resolvedAs: wf };
  // The port might exist by name without an incoming connector — that's a
  // distinct failure mode (port declared but unwired) vs. port missing entirely.
  if (inputPortNames.includes(id)) return { kind: "port-exists-unwired", portName: id };
  return { kind: "no-port" };
}

type ShowMode = "unresolved" | "resolved" | "all";

export function UnresolvedDiagnostics({ session }: { session: ParsedSession }) {
  const [filter, setFilter] = useState("");
  const [limit, setLimit] = useState(50);
  const [showMode, setShowMode] = useState<ShowMode>("unresolved");
  // "all" = show rows for every target table; otherwise filter to one target.
  const [targetFilter, setTargetFilter] = useState<string>("all");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const { mapping, lineageByCol, incomingByInstance, txByName, allRows, unresolvedRows, resolvedRows } = useMemo(() => {
    const m = buildMappingJson(session);
    const lin = session.mapping ? buildLineage(session) : [];
    const byCol = new Map<string, LineageRow[]>();
    for (const l of lin) {
      const k = `${l.targetTable}::${l.targetColumn}`;
      const arr = byCol.get(k) ?? [];
      arr.push(l);
      byCol.set(k, arr);
    }
    const inc = new Map<string, { fromInstance: string; fromField: string; toField: string }[]>();
    for (const c of session.mapping?.connectors ?? []) {
      const arr = inc.get(c.toInstance) ?? [];
      arr.push({ fromInstance: c.fromInstance, fromField: c.fromField, toField: c.toField });
      inc.set(c.toInstance, arr);
    }
    const tx = new Map((session.mapping?.transformations ?? []).map((t) => [t.name, t]));
    const all = m.field_mappings;
    const unres = all.filter((r) => isFieldMappingUnresolved(r));
    const res = all.filter((r) => !isFieldMappingUnresolved(r));
    return {
      mapping: m,
      lineageByCol: byCol,
      incomingByInstance: inc,
      txByName: tx,
      allRows: all,
      unresolvedRows: unres,
      resolvedRows: res,
    };
  }, [session]);

  // Only real target tables — exclude B.1 unmapped-source rows whose
  // target_table is the "UNUSED" sentinel so the dropdown doesn't list a
  // phantom target. The dropdown is purely a UI nav filter.
  const targetTables = useMemo(
    () =>
      [
        ...new Set(allRows.filter((r) => r.is_used === "YES").map((r) => r.target_table)),
      ].sort(),
    [allRows],
  );

  const baseRows =
    showMode === "unresolved" ? unresolvedRows : showMode === "resolved" ? resolvedRows : allRows;

  const filtered = useMemo(() => {
    const f = filter.trim().toLowerCase();
    const scoped = targetFilter === "all" ? baseRows : baseRows.filter((r) => r.target_table === targetFilter);
    if (!f) return scoped;
    return scoped.filter(
      (r) =>
        (r.target_column || "").toLowerCase().includes(f) ||
        (r.target_table || "").toLowerCase().includes(f) ||
        (r.business_logic_expression || "").toLowerCase().includes(f) ||
        (r.source_table || "").toLowerCase().includes(f) ||
        (r.source_column || "").toLowerCase().includes(f),
    );
  }, [filter, baseRows, targetFilter]);

  const visible = filtered.slice(0, limit);
  const total = mapping.field_mappings.length;
  const unresolvedPct = total > 0 ? Math.round((unresolvedRows.length / total) * 100) : 0;
  const resolvedPct = total > 0 ? Math.round((resolvedRows.length / total) * 100) : 0;

  function toggle(key: string) {
    const next = new Set(expanded);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    setExpanded(next);
  }

  return (
    <div className="space-y-3">
      <Card
        title="Mapping Inspector"
        subtitle={`${total} rows total · ${resolvedRows.length} resolved (${resolvedPct}%) · ${unresolvedRows.length} unresolved (${unresolvedPct}%). Expand a row to see the walk path and either the success chain or the dead-end diagnosis.`}
        right={
          <div className="flex items-center gap-2">
            <Pill tone="ok">{resolvedRows.length} resolved</Pill>
            <Pill tone={unresolvedPct > 20 ? "warn" : "default"}>
              {unresolvedRows.length} unresolved
            </Pill>
          </div>
        }
      >
        <div className="flex flex-wrap items-center gap-2 border-b border-ink-200 px-4 py-2">
          <input
            type="text"
            placeholder="Filter by target/source column, table, or expression…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="flex-1 min-w-[200px] rounded border border-ink-300 px-2 py-1 text-sm"
          />
          <div className="flex items-center gap-1 text-xs text-ink-600">
            <span>Show:</span>
            {(["unresolved", "resolved", "all"] as ShowMode[]).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setShowMode(mode)}
                className={`rounded border px-2 py-0.5 ${
                  showMode === mode
                    ? "border-ink-900 bg-ink-900 text-white"
                    : "border-ink-300 bg-white text-ink-700 hover:bg-ink-50"
                }`}
              >
                {mode}
                <span className="ml-1 opacity-70">
                  ({mode === "unresolved" ? unresolvedRows.length : mode === "resolved" ? resolvedRows.length : total})
                </span>
              </button>
            ))}
          </div>
          {targetTables.length >= 2 ? (
            <label className="text-xs text-ink-600">
              Target table
              <select
                value={targetFilter}
                onChange={(e) => setTargetFilter(e.target.value)}
                className="ml-1 rounded border border-ink-300 px-1 py-0.5"
              >
                <option value="all">all ({targetTables.length})</option>
                {targetTables.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
          <label className="text-xs text-ink-600">
            Limit
            <select
              value={limit}
              onChange={(e) => setLimit(Number(e.target.value))}
              className="ml-1 rounded border border-ink-300 px-1 py-0.5"
            >
              <option value={20}>20</option>
              <option value={50}>50</option>
              <option value={200}>200</option>
              <option value={1000}>1000</option>
            </select>
          </label>
          <span className="text-xs text-ink-600">
            ({filtered.length} match{filtered.length === 1 ? "" : "es"}, showing {visible.length})
          </span>
        </div>

        {visible.length === 0 ? (
          <div className="px-4 py-6 text-sm text-ink-500">No rows match the filter.</div>
        ) : (
          <ul className="divide-y divide-ink-200">
            {visible.map((r, i) => {
              const key = `${r.target_table}::${r.target_column}::${r.load_type ?? ""}::${i}`;
              const open = expanded.has(key);
              const candidates =
                lineageByCol.get(`${r.target_table}::${r.target_column}`) ?? [];
              const trace =
                candidates.find(
                  (c) => (c.sourceTable || "") === (r.source_table || ""),
                ) ?? candidates[0];
              const rowUnresolved = isFieldMappingUnresolved(r);
              return (
                <li key={key} className="px-4 py-2 text-sm">
                  <button
                    type="button"
                    onClick={() => toggle(key)}
                    className="flex w-full items-start gap-3 text-left hover:bg-ink-50 rounded -mx-2 px-2 py-1"
                  >
                    <span className="text-ink-400 mt-0.5">{open ? "▾" : "▸"}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono font-semibold text-ink-900">
                          {r.target_table}.{r.target_column}
                        </span>
                        {r.load_type ? <Pill tone="default">{r.load_type}</Pill> : null}
                        <Pill tone={rowUnresolved ? "warn" : "ok"}>
                          {rowUnresolved
                            ? r.source_table || "null"
                            : `${r.source_table}${r.source_column ? `.${r.source_column}` : ""}`}
                        </Pill>
                        {r.expression_type ? (
                          <Pill tone="default">{r.expression_type}</Pill>
                        ) : null}
                      </div>
                      {r.business_logic_expression ? (
                        <div className="mt-1 font-mono text-xs text-ink-600 truncate">
                          {r.business_logic_expression}
                        </div>
                      ) : null}
                    </div>
                  </button>
                  {open ? (
                    rowUnresolved ? (
                      <DiagnosticDetail
                        row={r}
                        trace={trace}
                        incomingByInstance={incomingByInstance}
                        txByName={txByName}
                      />
                    ) : (
                      <ResolvedDetail row={r} trace={trace} txByName={txByName} />
                    )
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}

// Detail panel for rows whose walk SUCCEEDED — shows the full resolution
// chain: source side, walk path, captured expressions per hop, and any
// lookups / joiners / routers / aggregators the walk traversed. Mirrors the
// shape of DiagnosticDetail so users get a consistent reading experience
// regardless of whether the row resolved or not.
function ResolvedDetail({
  row,
  trace,
  txByName,
}: {
  row: ReturnType<typeof buildMappingJson>["field_mappings"][number];
  trace: LineageRow | undefined;
  txByName: Map<
    string,
    { name: string; fields: { name: string; portType?: string; expression?: string }[] }
  >;
}) {
  const pathInstances = (row.transformation_path || "").split(" → ").filter(Boolean);
  const expressionChain = (row.expression_chain || "").split(" || ").filter(Boolean);

  return (
    <div className="mt-2 ml-6 grid gap-3 rounded border border-emerald-200 bg-emerald-50/60 p-3 text-xs">
      <KV
        label="Source"
        value={`${row.source_table || "?"}${row.source_column ? `.${row.source_column}` : ""}${row.source_datatype ? `  (${row.source_datatype})` : ""}`}
        mono
      />
      <KV
        label="Target"
        value={`${row.target_table || "?"}.${row.target_column || "?"}${row.target_datatype ? `  (${row.target_datatype})` : ""}`}
        mono
      />
      {row.load_type ? <KV label="Load Type" value={row.load_type} mono /> : null}
      {row.business_logic_expression ? (
        <KV
          label="Business Logic"
          value={row.business_logic_expression}
          mono
          multiline
        />
      ) : null}
      {row.expression_type ? (
        <KV label="Expression Type" value={row.expression_type} mono />
      ) : null}
      {row.transformation_path ? (
        <KV
          label="Walk path (target → source)"
          value={`${row.target_table} → ${row.transformation_path}`}
          mono
        />
      ) : null}

      {expressionChain.length > 0 ? (
        <details open className="rounded border border-ink-200 bg-white">
          <summary className="cursor-pointer px-2 py-1 font-semibold">
            Expression chain per hop ({expressionChain.length})
          </summary>
          <ul className="px-2 py-1 font-mono">
            {expressionChain.map((step, i) => (
              <li key={i} className="border-b border-ink-100 py-0.5 break-all">
                {step}
              </li>
            ))}
          </ul>
        </details>
      ) : null}

      {pathInstances.length > 0 ? (
        <details className="rounded border border-ink-200 bg-white">
          <summary className="cursor-pointer px-2 py-1 font-semibold">
            Transformations traversed ({pathInstances.length})
          </summary>
          <ul className="max-h-64 overflow-auto px-2 py-1 font-mono">
            {pathInstances.map((inst, i) => {
              const tx = txByName.get(inst);
              return (
                <li key={i} className="border-b border-ink-100 py-0.5">
                  <span className="text-ink-900">{inst}</span>
                  {tx?.fields?.length ? (
                    <span className="ml-2 text-ink-500">
                      [{tx.fields.length} ports]
                    </span>
                  ) : (
                    <span className="ml-2 text-ink-500">[no tx def — likely SOURCE/TARGET/mapplet]</span>
                  )}
                </li>
              );
            })}
          </ul>
        </details>
      ) : null}

      <div className="grid gap-1">
        {row.lookups_used ? <KV label="Lookups used" value={row.lookups_used} mono /> : null}
        {row.joiners_used ? <KV label="Joiners used" value={row.joiners_used} mono /> : null}
        {row.routers_used ? <KV label="Routers used" value={row.routers_used} mono /> : null}
        {row.aggregators_used ? (
          <KV label="Aggregators used" value={row.aggregators_used} mono />
        ) : null}
        {row.source_qualifier ? (
          <KV label="Source Qualifier" value={row.source_qualifier} mono />
        ) : null}
        {row.sq_sql_query ? (
          <KV label="SQ SQL Override" value={row.sq_sql_query} mono multiline />
        ) : null}
        {row.router_condition ? (
          <KV label="Router condition" value={row.router_condition} mono multiline />
        ) : null}
        {row.notes ? <KV label="Notes" value={row.notes} mono multiline /> : null}
        {trace?.cdqDimension ? (
          <KV label="CDQ dimension" value={trace.cdqDimension} mono />
        ) : null}
        {trace?.cdqRule ? <KV label="CDQ rule" value={trace.cdqRule} mono /> : null}
      </div>
    </div>
  );
}

function DiagnosticDetail({
  row,
  trace,
  incomingByInstance,
  txByName,
}: {
  row: ReturnType<typeof buildMappingJson>["field_mappings"][number];
  trace: LineageRow | undefined;
  incomingByInstance: Map<
    string,
    { fromInstance: string; fromField: string; toField: string }[]
  >;
  txByName: Map<
    string,
    { name: string; fields: { name: string; portType?: string; expression?: string }[] }
  >;
}) {
  const lastInstance = trace?.lastInstance;
  const lastField = trace?.lastField;
  const lastTx = lastInstance ? txByName.get(lastInstance) : undefined;
  const incoming = lastInstance ? incomingByInstance.get(lastInstance) ?? [] : [];
  const expr = trace?.expression || "";
  const inputPortNames = (lastTx?.fields ?? [])
    .filter((f) => /INPUT/i.test(f.portType || ""))
    .map((f) => f.name);
  const identifiers = extractIdentifiers(expr).filter(
    (id) => !KNOWN_FUNCTIONS.has(id.toUpperCase()),
  );
  const connectorTargets = new Set(incoming.map((c) => c.toField));
  const hasConnector = (toField: string) => connectorTargets.has(toField);

  // Default filter for ports/connectors: prefill with lastField if present,
  // so the user lands on the row that matters in a 676-port transformation.
  const defaultFilter = lastField ?? "";
  const [portFilter, setPortFilter] = useState(defaultFilter);
  const [connFilter, setConnFilter] = useState(defaultFilter);

  const filteredPorts = useMemo(() => {
    if (!lastTx) return [];
    const f = portFilter.trim().toLowerCase();
    if (!f) return lastTx.fields;
    return lastTx.fields.filter(
      (p) => p.name.toLowerCase().includes(f) || (p.portType || "").toLowerCase().includes(f),
    );
  }, [lastTx, portFilter]);

  const filteredConns = useMemo(() => {
    const f = connFilter.trim().toLowerCase();
    if (!f) return incoming;
    return incoming.filter(
      (c) =>
        c.toField.toLowerCase().includes(f) ||
        c.fromField.toLowerCase().includes(f) ||
        c.fromInstance.toLowerCase().includes(f),
    );
  }, [incoming, connFilter]);

  return (
    <div className="mt-2 ml-6 grid gap-3 rounded border border-ink-200 bg-ink-50 p-3 text-xs">
      <KV label="Transformation Path" value={row.transformation_path || "(none)"} mono />
      <KV label="lastInstance" value={lastInstance ?? "(none — walk found no incoming connector at the target)"} mono />
      <KV label="lastField" value={lastField ?? "(none)"} mono />
      <KV label="captured expression" value={expr || "(none)"} mono multiline />

      {lastInstance && !lastTx ? (
        <div className="text-ink-600">
          Instance <span className="font-mono">{lastInstance}</span> isn&apos;t a transformation in
          this file. It&apos;s likely a SOURCE / TARGET definition or a mapplet — the walk dead-ended
          here because we couldn&apos;t recurse into its internals.
        </div>
      ) : null}

      {identifiers.length > 0 && lastTx ? (
        <details open className="rounded border border-ink-200 bg-white">
          <summary className="cursor-pointer px-2 py-1 font-semibold">
            Identifier ↔ input-port match (resolver simulation)
          </summary>
          <ul className="px-2 py-1 font-mono">
            {identifiers.map((id) => {
              const status = classifyIdentifier(id, inputPortNames, hasConnector);
              return (
                <li key={id} className="border-b border-ink-100 py-0.5">
                  <span className="text-ink-900">{id}</span>
                  <span className="ml-2 text-ink-500">→</span>{" "}
                  {status.kind === "exact-wired" ? (
                    <span className="text-emerald-700">
                      EXACT (port {status.portName} has incoming CONNECTOR — walk recurses here)
                    </span>
                  ) : status.kind === "prefix-add" ? (
                    <span className="text-emerald-700">prefix-add → {status.resolvedAs}</span>
                  ) : status.kind === "case-fold" ? (
                    <span className="text-emerald-700">case-fold → {status.resolvedAs}</span>
                  ) : status.kind === "word-form" ? (
                    <span className="text-emerald-700">word-form → {status.resolvedAs}</span>
                  ) : status.kind === "port-exists-unwired" ? (
                    <span className="text-amber-700">
                      PORT EXISTS, NO CONNECTOR — input port{" "}
                      <span className="font-semibold">{status.portName}</span> is declared but
                      nothing wires into it. Check upstream TX for a typo or a missing
                      CONNECTOR element.
                    </span>
                  ) : (
                    <span className="text-amber-700">
                      NO MATCHING PORT — input ports here:{" "}
                      {inputPortNames.length === 0
                        ? "(none)"
                        : inputPortNames.slice(0, 12).join(", ") +
                          (inputPortNames.length > 12 ? " …" : "")}
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        </details>
      ) : null}

      {lastTx ? (
        <details className="rounded border border-ink-200 bg-white">
          <summary className="cursor-pointer px-2 py-1 font-semibold">
            Ports on {lastTx.name} ({lastTx.fields.length}
            {portFilter ? `, ${filteredPorts.length} match` : ""})
          </summary>
          <div className="border-t border-ink-200 px-2 py-1">
            <input
              type="text"
              value={portFilter}
              onChange={(e) => setPortFilter(e.target.value)}
              placeholder="Filter ports by name or portType…"
              className="w-full rounded border border-ink-300 px-2 py-0.5 text-xs"
            />
          </div>
          <ul className="max-h-64 overflow-auto px-2 py-1 font-mono">
            {filteredPorts.slice(0, 200).map((f, i) => (
              <li key={i} className="border-b border-ink-100 py-0.5">
                <span className="text-ink-900">{f.name}</span>
                <span className="ml-2 text-ink-500">[{f.portType ?? "?"}]</span>
                {hasConnector(f.name) ? (
                  <span className="ml-2 text-emerald-700">[wired]</span>
                ) : null}
                {f.expression ? (
                  <span className="ml-2 text-ink-600">
                    EXPRESSION=&quot;{f.expression.slice(0, 80)}
                    {f.expression.length > 80 ? "…" : ""}&quot;
                  </span>
                ) : null}
              </li>
            ))}
            {filteredPorts.length > 200 ? (
              <li className="py-0.5 text-ink-500">
                … {filteredPorts.length - 200} more matches; narrow the filter
              </li>
            ) : null}
          </ul>
        </details>
      ) : null}

      {incoming.length > 0 ? (
        <details className="rounded border border-ink-200 bg-white">
          <summary className="cursor-pointer px-2 py-1 font-semibold">
            CONNECTORs targeting {lastInstance} ({incoming.length}
            {connFilter ? `, ${filteredConns.length} match` : ""})
          </summary>
          <div className="border-t border-ink-200 px-2 py-1">
            <input
              type="text"
              value={connFilter}
              onChange={(e) => setConnFilter(e.target.value)}
              placeholder="Filter by from/to field or from instance…"
              className="w-full rounded border border-ink-300 px-2 py-0.5 text-xs"
            />
          </div>
          <ul className="max-h-64 overflow-auto px-2 py-1 font-mono">
            {filteredConns.slice(0, 200).map((c, i) => (
              <li key={i} className="border-b border-ink-100 py-0.5">
                {c.fromInstance}.{c.fromField}
                <span className="text-ink-500"> → </span>
                {lastInstance}.<span className="text-ink-900 font-semibold">{c.toField}</span>
              </li>
            ))}
            {filteredConns.length > 200 ? (
              <li className="py-0.5 text-ink-500">
                … {filteredConns.length - 200} more matches; narrow the filter
              </li>
            ) : null}
          </ul>
        </details>
      ) : lastInstance ? (
        <div className="text-ink-600">
          No CONNECTORs target <span className="font-mono">{lastInstance}</span> in this XML.
        </div>
      ) : null}

      {trace?.transformationPath ? (
        <KV
          label="walk path (target → source)"
          value={`${row.target_table} → ${trace.transformationPath}`}
          mono
        />
      ) : null}
    </div>
  );
}

function KV({
  label,
  value,
  mono,
  multiline,
}: {
  label: string;
  value: string;
  mono?: boolean;
  multiline?: boolean;
}) {
  return (
    <div className="grid grid-cols-[160px_1fr] gap-2">
      <span className="text-ink-500">{label}</span>
      <span
        className={`${mono ? "font-mono" : ""} ${multiline ? "whitespace-pre-wrap break-all" : "truncate"} text-ink-900`}
      >
        {value}
      </span>
    </div>
  );
}
