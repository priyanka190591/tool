"use client";

import { useEffect, useRef, useState } from "react";
import { searchSessions, type SearchHit } from "@/lib/searchIndex";
import { pageHref, setHashParams, useHashParams } from "@/lib/href";

export function SearchClient() {
  const sp = useHashParams();
  const q = sp.get("q") ?? "";

  const inputRef = useRef<HTMLInputElement>(null);
  const [hits, setHits] = useState<SearchHit[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (!q) {
      setHits(null);
      setError(null);
      return;
    }
    let cancelled = false;
    setSearching(true);
    setError(null);
    searchSessions(q)
      .then((h) => {
        if (!cancelled) setHits(h);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (!cancelled) setSearching(false);
      });
    return () => {
      cancelled = true;
    };
  }, [q]);

  return (
    <div className="grid gap-6">
      <div className="rounded-lg border border-ink-200 bg-white px-5 py-4 shadow-sm">
        <form
          className="flex items-center gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            const value = inputRef.current?.value.trim() ?? "";
            setHashParams((sp) => {
              if (value) sp.set("q", value);
              else sp.delete("q");
            });
          }}
        >
          <label htmlFor="q" className="text-sm font-medium text-ink-700">
            Search
          </label>
          <input
            ref={inputRef}
            id="q"
            name="q"
            defaultValue={q}
            placeholder="Connection name, target table, parameter, expression, SQL keyword…"
            className="flex-1 rounded-md border border-ink-200 px-3 py-2 text-sm shadow-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
          />
          <button
            type="submit"
            className="rounded-md bg-ink-900 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-ink-800"
          >
            Search
          </button>
        </form>
        {q ? (
          <div className="mt-3 text-xs text-ink-500">
            {searching
              ? "Searching…"
              : `${(hits ?? []).length} match${(hits ?? []).length === 1 ? "" : "es"}`}{" "}
            for <code className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[11px]">{q}</code>
          </div>
        ) : null}
      </div>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-800">
          {error}
        </div>
      ) : !q ? (
        <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-10 text-center">
          <p className="text-sm text-ink-500">
            Search across every session in <code className="font-mono">sessions/</code> — by file name,
            session name, mapping, connection, source/target table, lookup, parameter, SQL/expression
            content, or session attribute value.
          </p>
        </div>
      ) : searching || hits === null ? (
        <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-10 text-center text-sm text-ink-500">
          Searching…
        </div>
      ) : hits.length === 0 ? (
        <div className="rounded-lg border border-dashed border-ink-300 bg-white px-6 py-10 text-center">
          <p className="text-sm text-ink-500">No matches.</p>
        </div>
      ) : (
        <div className="grid gap-3">
          {hits.map((hit) => {
            const href = pageHref("/", { file: hit.fileName, session: hit.sessionName });
            return (
              <a
                key={`${hit.fileName}-${hit.sessionIndex}`}
                href={href}
                className="block rounded-lg border border-ink-200 bg-white px-5 py-4 shadow-sm hover:border-ink-400 hover:shadow-md"
              >
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="text-sm font-semibold text-ink-900">{hit.sessionName}</h3>
                  <span className="text-xs text-ink-500">
                    {hit.fileName}
                    {hit.mappingName ? ` · ${hit.mappingName}` : ""}
                  </span>
                </div>
                {hit.matches.length > 0 ? (
                  <ul className="mt-2 space-y-1 text-xs text-ink-700">
                    {hit.matches.map((m, i) => (
                      <li key={i}>
                        <span className="inline-block w-24 rounded bg-ink-100 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-ink-700">
                          {m.category}
                        </span>{" "}
                        <span className="font-mono text-[12px]">{m.sample}</span>
                      </li>
                    ))}
                  </ul>
                ) : null}
              </a>
            );
          })}
        </div>
      )}
    </div>
  );
}
