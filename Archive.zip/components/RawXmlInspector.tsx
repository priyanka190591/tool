"use client";

import { useMemo, useState } from "react";

export function RawXmlInspector({ xml }: { xml: string }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() => {
    if (!query) return null;
    const q = query.toLowerCase();
    const lines = xml.split(/\r?\n/);
    return lines
      .map((line, i) => ({ line, i }))
      .filter((r) => r.line.toLowerCase().includes(q))
      .slice(0, 500);
  }, [xml, query]);

  const lineCount = useMemo(() => xml.split(/\r?\n/).length, [xml]);
  const bytes = useMemo(() => new Blob([xml]).size, [xml]);

  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-ink-500">
          <span>{lineCount.toLocaleString()} lines</span>
          <span aria-hidden>·</span>
          <span>{(bytes / 1024).toFixed(1)} KB</span>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter XML (e.g. CONNECTOR, Lookup condition)…"
            className="w-72 rounded-md border border-ink-200 bg-white px-3 py-1.5 text-sm shadow-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
          />
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="rounded-md border border-ink-200 bg-white px-3 py-1.5 text-xs font-medium text-ink-700 shadow-sm hover:bg-ink-50"
          >
            {open ? "Hide source" : "Show source"}
          </button>
        </div>
      </div>
      {query ? (
        <div className="rounded-md border border-ink-100 bg-ink-50/40 p-2">
          <div className="mb-1 text-xs text-ink-500">
            {filtered?.length ?? 0} match{(filtered?.length ?? 0) === 1 ? "" : "es"}
            {(filtered?.length ?? 0) === 500 ? " (capped at 500)" : ""}
          </div>
          <pre className="max-h-[420px] overflow-auto rounded bg-white p-3 font-mono text-[12px] leading-5 text-ink-900">
{filtered && filtered.length > 0
              ? filtered.map((r) => `${String(r.i + 1).padStart(5, " ")}  ${r.line}`).join("\n")
              : "No matches."}
          </pre>
        </div>
      ) : null}
      {open ? (
        <pre className="max-h-[600px] overflow-auto rounded-md border border-ink-100 bg-white p-3 font-mono text-[12px] leading-5 text-ink-900">
{xml}
        </pre>
      ) : null}
    </div>
  );
}
