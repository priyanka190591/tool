# Nested session folders + folder-scoped XLSX download — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Allow `public/sessions/` to be an arbitrarily-nested folder tree of session XMLs, render it as a collapsible tree in `SessionPicker`, and let the user download a ZIP of Clean-XLSXs for any selected folder (recursive, full path retained inside the ZIP).

**Architecture:** Tree shape is computed by a pure-logic module (`lib/folder-tree.ts`) from a flat `FileEntry[]` that carries a new `path` field. The static manifest (`public/sessions/index.json`) switches from `string[]` to `{path,name}[]`. `lib/downloads.ts` gains `downloadFolderXlsx(folder, files)`; the existing top-bar Download-all becomes a thin wrapper over the same function with the root node. URL hash deep-links migrate from `#file=` to `#path=` with a one-release legacy shim.

**Tech Stack:** Next.js 16 App Router, TypeScript, ExcelJS, JSZip, vitest. No new dependencies.

**Spec:** `docs/superpowers/specs/2026-06-05-nested-folders-design.md`.

**Invariant during the migration:** all 157 existing tests (`npm test`) and the 157 vanilla-port mirror tests (`npm run test:jsout`) MUST stay green after every task. Re-run both suites at every commit.

---

## Task 1: Recursive manifest generator + new schema

**Files:**
- Modify: `scripts/gen-sessions-manifest.mjs` (full rewrite — ~15 lines today)

The script today does a single-level `readdir`. We make it recursive and switch the emitted shape to `{path, name}[]`. The flat layout still works — every file simply has `path === name`.

- [ ] **Step 1: Rewrite `scripts/gen-sessions-manifest.mjs`**

Replace the entire file with:

```javascript
import { readdir, writeFile } from "node:fs/promises";
import { join, dirname, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const sessionsDir = join(here, "..", "public", "sessions");

async function walk(dir) {
  const out = [];
  const entries = await readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) {
      out.push(...(await walk(full)));
    } else if (e.isFile() && /\.xml$/i.test(e.name)) {
      // Always posix separators in the manifest, regardless of host OS.
      const rel = relative(sessionsDir, full).split(sep).join("/");
      out.push({ path: rel, name: e.name });
    }
  }
  return out;
}

const files = (await walk(sessionsDir)).sort((a, b) =>
  a.path.localeCompare(b.path),
);

const out = join(sessionsDir, "index.json");
await writeFile(out, JSON.stringify(files, null, 2) + "\n", "utf8");
console.log(`[manifest] ${files.length} entries -> ${out}`);
```

- [ ] **Step 2: Run the generator against the current flat layout**

Run: `node scripts/gen-sessions-manifest.mjs`
Expected output:
```
[manifest] 4 entries -> .../public/sessions/index.json
```

- [ ] **Step 3: Inspect the regenerated manifest**

Run: `cat public/sessions/index.json`
Expected (order may vary):
```json
[
  { "path": "COMPTIME.xml", "name": "COMPTIME.xml" },
  { "path": "Customers/s_CUSTOMER_LOAD.xml", "name": "s_CUSTOMER_LOAD.xml" }
  ...
]
```
Note: at this point the fixtures are still flat, so every `path` equals its `name`. That's fine.

- [ ] **Step 4: Commit**

```bash
git add scripts/gen-sessions-manifest.mjs public/sessions/index.json
git commit -m "feat(manifest): recursive walk and {path,name}[] shape"
```

---

## Task 2: Add `path` to `FileEntry` and read the new manifest shape

**Files:**
- Modify: `lib/sessions-types.ts` — `FileEntry` definition (around line 181)
- Modify: `lib/sessions-client.ts` — `discoverSessionFiles` (line 34), `tryDirectoryListing` (line 42), `loadFromManifest` (line 65), `listFileEntries` (line 113)

After this task, every consumer of `FileEntry` has a `.path` available. We keep `.fileName` as the leaf name for back-compat with TopBar / SessionPicker which haven't been updated yet.

- [ ] **Step 1: Read the existing `FileEntry` definition**

Run: `sed -n '180,195p' lib/sessions-types.ts`
Expected: a block declaring `export type FileEntry = { fileName: string; sessions: { index, name, mappingName? }[] }`. If the lines don't match, run `grep -n "FileEntry" lib/sessions-types.ts` and re-orient.

- [ ] **Step 2: Modify `FileEntry` to carry `path`**

Edit `lib/sessions-types.ts`, locate the existing `export type FileEntry = { ... }` block, and replace it with:

```typescript
export type FileEntry = {
  // Path relative to `public/sessions/`, posix separators. Carries the full
  // hierarchy: "Sales/2024/Q1/foo.xml". For root-level XMLs `path === fileName`.
  path: string;
  // Leaf filename — convenience, equals `path.split("/").pop()`.
  fileName: string;
  sessions: {
    index: number;
    name: string;
    mappingName?: string;
  }[];
};
```

- [ ] **Step 3: Update `lib/sessions-client.ts` — manifest reader**

Find the `loadFromManifest` function (around line 65). The current code parses a `string[]`. Replace the manifest-loading helper so it understands BOTH shapes (old `string[]` for safety during dev) and returns paths.

Locate this block:
```typescript
async function loadFromManifest(): Promise<string[]> {
  const res = await fetch(withBust(`${sessionsBase()}/index.json`), { cache: "no-store" });
  if (!res.ok) {
```

Replace the entire `loadFromManifest` function with:

```typescript
async function loadFromManifest(): Promise<string[]> {
  const res = await fetch(withBust(`${sessionsBase()}/index.json`), { cache: "no-store" });
  if (!res.ok) throw new Error(`Manifest fetch failed: ${res.status}`);
  const raw = await res.json();
  if (!Array.isArray(raw)) throw new Error("Manifest is not an array");
  // New shape: [{ path, name }]. Old shape: ["a.xml", ...] (kept for one release
  // in case a dev runs the app before regenerating the manifest).
  return raw.map((entry) => {
    if (typeof entry === "string") return entry;
    if (entry && typeof entry === "object" && typeof entry.path === "string") return entry.path;
    throw new Error(`Manifest entry has unexpected shape: ${JSON.stringify(entry)}`);
  });
}
```

- [ ] **Step 4: Drop the directory-listing fallback**

Directory listings don't recurse on real static servers (and disabling the fallback is part of the spec). In `discoverSessionFiles`, delete the `tryDirectoryListing()` branch so manifest is the sole source. Replace:

```typescript
async function discoverSessionFiles(): Promise<string[]> {
  const fromListing = await tryDirectoryListing();
  if (fromListing && fromListing.length > 0) {
    return fromListing;
  }
  return loadFromManifest();
}
```

with:

```typescript
async function discoverSessionFiles(): Promise<string[]> {
  return loadFromManifest();
}
```

Then delete the `tryDirectoryListing()` function entirely (it's the next function above `loadFromManifest`).

- [ ] **Step 5: Update `listFileEntries()` to populate `path`**

Locate the `listFileEntries` function (around line 113) and change the loop body so each `FileEntry` carries both `path` and `fileName`:

```typescript
export async function listFileEntries(): Promise<FileEntry[]> {
  if (entriesPromise) return entriesPromise;
  entriesPromise = (async () => {
    const paths = await listSessionFiles();
    const out: FileEntry[] = [];
    for (const path of paths) {
      const fileName = path.split("/").pop() ?? path;
      try {
        const all = await parseAllSessions(path);
        out.push({
          path,
          fileName,
          sessions: all.map((s, i) => ({
            index: i,
            name: s.name,
            mappingName: s.mappingName ?? s.mapping?.name,
          })),
        });
      } catch {
        out.push({ path, fileName, sessions: [{ index: 0, name: fileName }] });
      }
    }
    return out;
  })().catch((err) => {
    entriesPromise = null;
    throw err;
  });
  return entriesPromise;
}
```

- [ ] **Step 6: Run the full test suite to confirm nothing else broke**

Run: `npm test`
Expected: `Test Files  16 passed | 1 skipped (17)` and `Tests  157 passed | 1 skipped (158)`.

Also run: `npm run test:jsout`
Expected: same `157 passed | 1 skipped`.

If either suite drops a test, stop and diagnose before continuing.

- [ ] **Step 7: Commit**

```bash
git add lib/sessions-types.ts lib/sessions-client.ts
git commit -m "feat(sessions): FileEntry.path + manifest reads new {path,name}[] shape"
```

---

## Task 3: Folder tree module + tests (TDD)

**Files:**
- Create: `lib/folder-tree.ts`
- Test: `tests/folder-tree.test.ts`

Pure-logic module — full TDD pass.

- [ ] **Step 1: Write the test file**

Create `tests/folder-tree.test.ts` with:

```typescript
import { describe, it, expect } from "vitest";
import { buildFolderTree } from "@/lib/folder-tree";
import type { FileEntry } from "@/lib/sessions";

function f(path: string, sessions = 1): FileEntry {
  const name = path.split("/").pop() ?? path;
  return {
    path,
    fileName: name,
    sessions: Array.from({ length: sessions }, (_, i) => ({
      index: i,
      name: `${name}#${i}`,
    })),
  };
}

describe("buildFolderTree", () => {
  it("returns an empty root for empty input", () => {
    const root = buildFolderTree([]);
    expect(root.path).toBe("");
    expect(root.name).toBe("");
    expect(root.files).toEqual([]);
    expect(root.folders).toEqual([]);
    expect(root.totalFiles).toBe(0);
    expect(root.totalSessions).toBe(0);
  });

  it("places root-level files directly under root", () => {
    const root = buildFolderTree([f("a.xml"), f("b.xml", 2)]);
    expect(root.files.map((f) => f.fileName)).toEqual(["a.xml", "b.xml"]);
    expect(root.folders).toEqual([]);
    expect(root.totalFiles).toBe(2);
    expect(root.totalSessions).toBe(3); // 1 + 2
  });

  it("nests files into subfolders by path segments", () => {
    const root = buildFolderTree([
      f("Sales/2024/Q1/foo.xml"),
      f("Sales/bar.xml"),
      f("Customers/baz.xml", 3),
    ]);
    expect(root.totalFiles).toBe(3);
    expect(root.totalSessions).toBe(5);
    expect(root.folders.map((f) => f.name)).toEqual(["Customers", "Sales"]);

    const sales = root.folders.find((f) => f.name === "Sales")!;
    expect(sales.path).toBe("Sales");
    expect(sales.files.map((f) => f.fileName)).toEqual(["bar.xml"]);
    expect(sales.folders.map((f) => f.name)).toEqual(["2024"]);
    expect(sales.totalFiles).toBe(2);

    const q1 = sales.folders[0].folders[0];
    expect(q1.path).toBe("Sales/2024/Q1");
    expect(q1.name).toBe("Q1");
    expect(q1.files.map((f) => f.fileName)).toEqual(["foo.xml"]);
    expect(q1.totalFiles).toBe(1);
  });

  it("sorts folders before files at each level, both alpha", () => {
    const root = buildFolderTree([
      f("zeta.xml"),
      f("Beta/x.xml"),
      f("Alpha/y.xml"),
      f("apple.xml"),
    ]);
    expect(root.folders.map((f) => f.name)).toEqual(["Alpha", "Beta"]);
    expect(root.files.map((f) => f.fileName)).toEqual(["apple.xml", "zeta.xml"]);
  });

  it("rolls up totalFiles and totalSessions through every level", () => {
    const root = buildFolderTree([
      f("A/B/C/deep.xml", 4),
      f("A/B/wide.xml", 2),
      f("A/top.xml", 1),
    ]);
    expect(root.totalFiles).toBe(3);
    expect(root.totalSessions).toBe(7);
    const a = root.folders[0];
    expect(a.totalFiles).toBe(3);
    expect(a.totalSessions).toBe(7);
    const b = a.folders[0];
    expect(b.totalFiles).toBe(2);
    expect(b.totalSessions).toBe(6);
    const c = b.folders[0];
    expect(c.totalFiles).toBe(1);
    expect(c.totalSessions).toBe(4);
  });

  it("rejects paths containing '..' or empty segments", () => {
    expect(() => buildFolderTree([f("../escape.xml")])).toThrow();
    expect(() => buildFolderTree([f("Sales//foo.xml")])).toThrow();
    expect(() => buildFolderTree([f("/leading.xml")])).toThrow();
  });
});
```

- [ ] **Step 2: Run the tests to confirm they fail**

Run: `npx vitest run tests/folder-tree.test.ts`
Expected: All tests fail with `Cannot find module '@/lib/folder-tree'` (the module doesn't exist yet).

- [ ] **Step 3: Create `lib/folder-tree.ts`**

```typescript
import type { FileEntry } from "./sessions";

export type FolderNode = {
  // Leaf folder name (e.g. "Q1"). "" for the synthetic root.
  name: string;
  // Path relative to public/sessions/, without trailing slash. "" for root.
  path: string;
  // Files that live directly under this folder, sorted alpha by fileName.
  files: FileEntry[];
  // Subfolders, sorted alpha by name.
  folders: FolderNode[];
  // Rolled-up counts including everything under this node, recursive.
  totalFiles: number;
  totalSessions: number;
};

function makeNode(name: string, path: string): FolderNode {
  return { name, path, files: [], folders: [], totalFiles: 0, totalSessions: 0 };
}

function validatePath(path: string): void {
  if (path.startsWith("/")) throw new Error(`Path must not start with '/': ${path}`);
  if (path.includes("//")) throw new Error(`Path has empty segments: ${path}`);
  const segments = path.split("/");
  if (segments.some((s) => s === "" || s === "." || s === "..")) {
    throw new Error(`Path has illegal segment: ${path}`);
  }
}

export function buildFolderTree(files: FileEntry[]): FolderNode {
  const root = makeNode("", "");
  for (const file of files) {
    validatePath(file.path);
    const segments = file.path.split("/");
    const folderSegments = segments.slice(0, -1);
    let cursor = root;
    let cursorPath = "";
    for (const seg of folderSegments) {
      cursorPath = cursorPath ? `${cursorPath}/${seg}` : seg;
      let child = cursor.folders.find((c) => c.name === seg);
      if (!child) {
        child = makeNode(seg, cursorPath);
        cursor.folders.push(child);
      }
      cursor = child;
    }
    cursor.files.push(file);
  }
  sortNode(root);
  rollUp(root);
  return root;
}

function sortNode(node: FolderNode): void {
  node.folders.sort((a, b) => a.name.localeCompare(b.name));
  node.files.sort((a, b) => a.fileName.localeCompare(b.fileName));
  for (const child of node.folders) sortNode(child);
}

function rollUp(node: FolderNode): void {
  let files = node.files.length;
  let sessions = node.files.reduce((n, f) => n + f.sessions.length, 0);
  for (const child of node.folders) {
    rollUp(child);
    files += child.totalFiles;
    sessions += child.totalSessions;
  }
  node.totalFiles = files;
  node.totalSessions = sessions;
}

/**
 * Flatten a folder tree (or subtree) back into a depth-first list of
 * `FileEntry`s. Used by `downloadFolderXlsx` to walk the selected branch.
 */
export function filesUnder(node: FolderNode): FileEntry[] {
  const out: FileEntry[] = [];
  for (const f of node.files) out.push(f);
  for (const sub of node.folders) out.push(...filesUnder(sub));
  return out;
}
```

- [ ] **Step 4: Run the tests to confirm they pass**

Run: `npx vitest run tests/folder-tree.test.ts`
Expected: All 6 tests pass.

- [ ] **Step 5: Run the full suite to confirm no regressions**

Run: `npm test`
Expected: `Tests  163 passed | 1 skipped (164)` (the 6 new folder-tree tests on top of the existing 157).

Run: `npm run test:jsout`
Expected: `Tests  157 passed | 1 skipped (158)` (vanilla suite is unchanged).

- [ ] **Step 6: Commit**

```bash
git add lib/folder-tree.ts tests/folder-tree.test.ts
git commit -m "feat(folder-tree): build hierarchical tree from FileEntry[]"
```

---

## Task 4: Folder-scoped XLSX download

**Files:**
- Modify: `lib/downloads.ts` — add `downloadFolderXlsx`, refactor `downloadAllSessionsXlsx`

Today `downloadAllSessionsXlsx` takes pre-parsed `ParsedSession[]`. We add a new `downloadFolderXlsx(folder, files)` that walks a `FolderNode`, fetches + parses each XML, and writes one Clean-XLSX per session into a JSZip — entries keyed by the *full* path from `public/sessions/`. The old function becomes a thin wrapper for back-compat.

- [ ] **Step 1: Read the existing `downloadAllSessionsXlsx` block**

Run: `sed -n '50,90p' lib/downloads.ts`
Expected: see the existing JSZip-based bundler at lines 53–73.

- [ ] **Step 2: Add new imports and helpers in `lib/downloads.ts`**

At the top of the file (after the existing imports), add:

```typescript
import { parseAllSessions } from "./sessions-client";
import { filesUnder, type FolderNode } from "./folder-tree";
```

- [ ] **Step 3: Replace the existing `downloadAllSessionsXlsx` and add `downloadFolderXlsx`**

Locate the existing `export async function downloadAllSessionsXlsx(sessions: ParsedSession[]): Promise<void> { ... }` (and its companion `pickName`) and replace BOTH with:

```typescript
/**
 * Bundle every Clean-XLSX under `folder` (recursive) into a single ZIP.
 * Entries inside the ZIP retain their full path from `public/sessions/` so
 * re-extracting reconstructs the original tree.
 *
 * - Sessions that fail to parse are skipped and reported via the
 *   `failed` callback (caller renders a toast).
 * - If every file under `folder` fails to parse, throws so the caller
 *   surfaces an explicit error instead of emitting an empty ZIP.
 */
export async function downloadFolderXlsx(
  folder: FolderNode,
  options: { onFailure?: (path: string, error: unknown) => void } = {},
): Promise<{ bundled: number; failed: number }> {
  const [{ buildCleanWorkbook }, JSZipMod] = await Promise.all([
    import("./xlsx-clean"),
    import("jszip"),
  ]);
  const JSZip = JSZipMod.default;
  const zip = new JSZip();
  const used = new Map<string, number>();
  let bundled = 0;
  let failed = 0;
  for (const file of filesUnder(folder)) {
    try {
      const parsed = await parseAllSessions(file.path);
      for (const session of parsed) {
        const json = buildMappingJson(session);
        const buf = await buildCleanWorkbook(json);
        const entryName = entryNameFor(file.path, buildXlsxFilename(session), used);
        zip.file(entryName, buf);
        bundled++;
      }
    } catch (err) {
      failed++;
      options.onFailure?.(file.path, err);
    }
  }
  if (bundled === 0) {
    throw new Error(`No sessions could be bundled under "${folder.path || "all"}".`);
  }
  const blob = await zip.generateAsync({
    type: "blob",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
  downloadBlob(zipFilenameFor(folder), blob);
  return { bundled, failed };
}

// Build the ZIP entry path: `<parent folder of XML>/<xlsx filename>`, with
// `_N` suffix on collision so sibling sessions in the same XML stay
// individually addressable.
function entryNameFor(filePath: string, xlsxName: string, used: Map<string, number>): string {
  const parent = filePath.split("/").slice(0, -1).join("/");
  const base = parent ? `${parent}/${xlsxName}` : xlsxName;
  const count = (used.get(base) ?? 0) + 1;
  used.set(base, count);
  if (count === 1) return base;
  const stem = base.replace(/\.xlsx$/i, "");
  return `${stem}_${count}.xlsx`;
}

function zipFilenameFor(folder: FolderNode): string {
  if (folder.path === "") return "all_sessions_mappings.zip";
  // Convert "Sales/2024/Q1" → "Sales_2024_Q1_sessions.zip" so the archive
  // is self-describing on disk.
  const safe = folder.path.replace(/\//g, "_").replace(/[^A-Za-z0-9_-]+/g, "_");
  return `${safe}_sessions.zip`;
}

/**
 * Back-compat: bundle the entire tree. Today the TopBar still passes a
 * `ParsedSession[]` but we ignore that and just re-bundle from disk so the
 * code path stays single-implementation.
 *
 * @deprecated callers should switch to `downloadFolderXlsx(rootNode)`.
 */
export async function downloadAllSessionsXlsx(
  _sessionsIgnored: ParsedSession[],
): Promise<void> {
  const files = await listFileEntries();
  const { buildFolderTree } = await import("./folder-tree");
  const root = buildFolderTree(files);
  await downloadFolderXlsx(root);
}
```

- [ ] **Step 4: Add `listFileEntries` import**

At the top of `lib/downloads.ts`, add to the existing `./sessions-client` import (or create one if missing):

```typescript
import { listFileEntries, parseAllSessions } from "./sessions-client";
```

Make sure there is only one `import` line from `./sessions-client`.

- [ ] **Step 5: Manually verify by building and running the dev server**

Run: `npm run dev`
- Open `http://localhost:3000`
- Wait for sessions to load
- Click **Download all (.zip)** in the top bar
- Confirm a file named `all_sessions_mappings.zip` downloads
- Open the ZIP; expect entries with the `<xml_stem>_(<src>_TO_<tgt>).xlsx` naming we established earlier, at the root of the ZIP (since fixtures are still flat).

Stop the dev server (Ctrl+C).

- [ ] **Step 6: Run both test suites**

Run: `npm test`
Expected: 163 passing, 1 skipped (same as Task 3 end-state).

Run: `npm run test:jsout`
Expected: 157 passing, 1 skipped (unchanged).

- [ ] **Step 7: Commit**

```bash
git add lib/downloads.ts
git commit -m "feat(downloads): folder-scoped XLSX bundle, refactor Download-all"
```

---

## Task 5: SessionPicker — tree rendering + per-folder download button

**Files:**
- Modify: `components/SessionPicker.tsx` (full rewrite — ~150 lines)

Today the picker is a flat dropdown. We render a collapsible tree where folders show counts + a download button, and the search auto-expands matching subtrees.

- [ ] **Step 1: Replace the entire `components/SessionPicker.tsx`**

```tsx
"use client";

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import type { FileEntry } from "@/lib/sessions";
import { setHashParams } from "@/lib/href";
import { buildFolderTree, type FolderNode } from "@/lib/folder-tree";
import { downloadFolderXlsx } from "@/lib/downloads";

export function SessionPicker({
  entries,
  selectedPath,
  selectedSession,
}: {
  entries: FileEntry[];
  selectedPath?: string;
  selectedSession?: string;
}) {
  const [pending, startTransition] = useTransition();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [bundlingPath, setBundlingPath] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const root = useMemo(() => buildFolderTree(entries), [entries]);

  const selectedLabel = useMemo(() => {
    if (!selectedPath) return null;
    const entry = entries.find((e) => e.path === selectedPath);
    if (!entry) return null;
    if (!selectedSession || entry.sessions.length <= 1) return entry.fileName;
    return `${entry.fileName}  ›  ${selectedSession}`;
  }, [entries, selectedPath, selectedSession]);

  // When the user types in the search box, every ancestor of a match is
  // expanded; non-matching subtrees collapse.
  const expandedPaths = useMemo(() => {
    if (!query.trim()) return new Set<string>();
    const q = query.trim().toLowerCase();
    const set = new Set<string>();
    const walk = (n: FolderNode): boolean => {
      const fileMatch = n.files.some(
        (f) =>
          f.fileName.toLowerCase().includes(q) ||
          f.sessions.some(
            (s) =>
              s.name.toLowerCase().includes(q) ||
              (s.mappingName ?? "").toLowerCase().includes(q),
          ),
      );
      let childMatch = false;
      for (const child of n.folders) {
        if (walk(child)) childMatch = true;
      }
      if (fileMatch || childMatch) {
        if (n.path !== "") set.add(n.path);
        return true;
      }
      return false;
    };
    walk(root);
    return set;
  }, [root, query]);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function pickFile(file: FileEntry, sessionName?: string) {
    startTransition(() => {
      setHashParams((sp) => {
        sp.set("path", file.path);
        sp.delete("file"); // strip legacy hash param
        if (sessionName && file.sessions.length > 1) sp.set("session", sessionName);
        else sp.delete("session");
      });
      setOpen(false);
      setQuery("");
    });
  }

  async function downloadFolder(folder: FolderNode) {
    if (bundlingPath) return;
    setBundlingPath(folder.path);
    try {
      const { bundled, failed } = await downloadFolderXlsx(folder);
      if (failed > 0) {
        alert(`Bundled ${bundled} session${bundled === 1 ? "" : "s"}; ${failed} file${failed === 1 ? "" : "s"} failed to parse (see console).`);
      }
    } catch (e) {
      alert(`Download failed: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBundlingPath(null);
    }
  }

  return (
    <div className="flex items-center gap-3" ref={containerRef}>
      <label htmlFor="session-picker" className="text-sm font-medium text-ink-700">
        Session XML
      </label>
      <div className="relative w-[28rem]">
        <button
          type="button"
          id="session-picker"
          onClick={() => setOpen((v) => !v)}
          disabled={pending || root.totalFiles === 0}
          className="flex w-full items-center justify-between gap-2 rounded-md border border-ink-200 bg-white px-3 py-2 text-left text-sm text-ink-900 shadow-sm transition focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <span className="truncate">
            {selectedLabel
              ? selectedLabel
              : root.totalFiles === 0
                ? "No XML files found"
                : "Select a session…"}
          </span>
          <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor" className="text-ink-400" aria-hidden>
            <path
              fillRule="evenodd"
              d="M5.23 7.21a.75.75 0 0 1 1.06.02L10 11.06l3.71-3.83a.75.75 0 1 1 1.08 1.04l-4.24 4.38a.75.75 0 0 1-1.08 0L5.21 8.27a.75.75 0 0 1 .02-1.06Z"
              clipRule="evenodd"
            />
          </svg>
        </button>
        {open ? (
          <div className="absolute z-30 mt-1 w-full overflow-hidden rounded-md border border-ink-200 bg-white shadow-lg">
            <div className="border-b border-ink-100 p-2">
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by file, session, or mapping…"
                className="w-full rounded border border-ink-200 px-2 py-1 text-sm focus:border-ink-900 focus:outline-none focus:ring-2 focus:ring-ink-900/10"
              />
            </div>
            <div className="max-h-[28rem] overflow-y-auto">
              {root.totalFiles === 0 ? (
                <div className="px-3 py-2 text-sm text-ink-500">No XML files.</div>
              ) : (
                <TreeRows
                  node={root}
                  query={query.trim().toLowerCase()}
                  forceExpand={query.trim() !== ""}
                  expandedPaths={expandedPaths}
                  depth={0}
                  bundlingPath={bundlingPath}
                  onPickSession={pickFile}
                  onDownloadFolder={downloadFolder}
                  selectedPath={selectedPath}
                  selectedSession={selectedSession}
                />
              )}
            </div>
          </div>
        ) : null}
      </div>
      {pending ? <span className="text-xs text-ink-500">Loading…</span> : null}
    </div>
  );
}

function TreeRows({
  node,
  query,
  forceExpand,
  expandedPaths,
  depth,
  bundlingPath,
  onPickSession,
  onDownloadFolder,
  selectedPath,
  selectedSession,
}: {
  node: FolderNode;
  query: string;
  forceExpand: boolean;
  expandedPaths: Set<string>;
  depth: number;
  bundlingPath: string | null;
  onPickSession: (file: FileEntry, sessionName?: string) => void;
  onDownloadFolder: (folder: FolderNode) => void;
  selectedPath?: string;
  selectedSession?: string;
}) {
  return (
    <ul>
      {node.folders.map((sub) => (
        <FolderRow
          key={sub.path}
          folder={sub}
          query={query}
          forceExpand={forceExpand}
          expandedPaths={expandedPaths}
          depth={depth}
          bundlingPath={bundlingPath}
          onPickSession={onPickSession}
          onDownloadFolder={onDownloadFolder}
          selectedPath={selectedPath}
          selectedSession={selectedSession}
        />
      ))}
      {node.files.map((file) =>
        matchesQuery(file, query) ? (
          <FileRow
            key={file.path}
            file={file}
            depth={depth}
            onPickSession={onPickSession}
            selectedPath={selectedPath}
            selectedSession={selectedSession}
          />
        ) : null,
      )}
    </ul>
  );
}

function FolderRow({
  folder,
  query,
  forceExpand,
  expandedPaths,
  depth,
  bundlingPath,
  onPickSession,
  onDownloadFolder,
  selectedPath,
  selectedSession,
}: {
  folder: FolderNode;
  query: string;
  forceExpand: boolean;
  expandedPaths: Set<string>;
  depth: number;
  bundlingPath: string | null;
  onPickSession: (file: FileEntry, sessionName?: string) => void;
  onDownloadFolder: (folder: FolderNode) => void;
  selectedPath?: string;
  selectedSession?: string;
}) {
  const [openLocal, setOpenLocal] = useState(false);
  const expanded = forceExpand ? expandedPaths.has(folder.path) : openLocal;
  // If this folder has no descendants matching the query, drop it from the
  // rendered tree entirely (instead of showing an empty folder).
  if (forceExpand && !expandedPaths.has(folder.path)) return null;
  const bundling = bundlingPath === folder.path;
  return (
    <li>
      <div
        className="flex items-center gap-1 px-2 py-1 text-sm hover:bg-ink-50"
        style={{ paddingLeft: 8 + depth * 16 }}
      >
        <button
          type="button"
          onClick={() => setOpenLocal((v) => !v)}
          className="flex h-4 w-4 items-center justify-center text-ink-500"
          aria-label={expanded ? "Collapse folder" : "Expand folder"}
        >
          <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
            {expanded ? (
              <path d="M1 3.5h8L5 8z" />
            ) : (
              <path d="M3.5 1v8L8 5z" />
            )}
          </svg>
        </button>
        <span className="truncate font-medium text-ink-900">{folder.name}</span>
        <span className="text-[11px] text-ink-500">
          ({folder.totalFiles} file{folder.totalFiles === 1 ? "" : "s"}
          {" · "}
          {folder.totalSessions} session{folder.totalSessions === 1 ? "" : "s"})
        </span>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDownloadFolder(folder);
          }}
          disabled={bundlingPath !== null}
          title={`Download all sessions under ${folder.path} as a .zip`}
          className="ml-auto rounded border border-ink-200 bg-white px-1.5 py-0.5 text-[11px] text-ink-700 hover:bg-ink-50 disabled:opacity-50"
        >
          {bundling ? "…" : "⬇"}
        </button>
      </div>
      {expanded ? (
        <TreeRows
          node={folder}
          query={query}
          forceExpand={forceExpand}
          expandedPaths={expandedPaths}
          depth={depth + 1}
          bundlingPath={bundlingPath}
          onPickSession={onPickSession}
          onDownloadFolder={onDownloadFolder}
          selectedPath={selectedPath}
          selectedSession={selectedSession}
        />
      ) : null}
    </li>
  );
}

function FileRow({
  file,
  depth,
  onPickSession,
  selectedPath,
  selectedSession,
}: {
  file: FileEntry;
  depth: number;
  onPickSession: (file: FileEntry, sessionName?: string) => void;
  selectedPath?: string;
  selectedSession?: string;
}) {
  return (
    <li>
      {file.sessions.map((s) => {
        const active =
          selectedPath === file.path &&
          (file.sessions.length === 1 || selectedSession === s.name);
        return (
          <button
            key={`${file.path}|${s.index}`}
            type="button"
            onClick={() => onPickSession(file, s.name)}
            className={`flex w-full flex-col gap-0.5 py-1 text-left text-sm hover:bg-ink-50 ${active ? "bg-ink-100/60" : ""}`}
            style={{ paddingLeft: 8 + (depth + 1) * 16, paddingRight: 8 }}
          >
            <span className="font-medium text-ink-900">{s.name}</span>
            <span className="text-[11px] text-ink-500">
              {file.fileName}
              {s.mappingName ? ` · ${s.mappingName}` : ""}
            </span>
          </button>
        );
      })}
    </li>
  );
}

function matchesQuery(file: FileEntry, query: string): boolean {
  if (!query) return true;
  if (file.fileName.toLowerCase().includes(query)) return true;
  return file.sessions.some(
    (s) =>
      s.name.toLowerCase().includes(query) ||
      (s.mappingName ?? "").toLowerCase().includes(query),
  );
}
```

- [ ] **Step 2: Run `npm test` and `npm run test:jsout`**

Run: `npm test`
Expected: 163 passing.

Run: `npm run test:jsout`
Expected: 157 passing.

(The picker isn't covered by unit tests, but if our type changes accidentally broke a non-UI module a test will catch it.)

- [ ] **Step 3: Commit**

```bash
git add components/SessionPicker.tsx
git commit -m "feat(picker): tree rendering + per-folder download button"
```

---

## Task 6: Migrate URL hash from `#file=` to `#path=`

**Files:**
- Modify: `components/DashboardClient.tsx:17-18, 42, 51, 67`

The picker now writes `#path=`. The dashboard needs to read it. Keep a one-release shim that also accepts `#file=` so an old shared link still works.

- [ ] **Step 1: Read existing hash handling**

Run: `sed -n '15,20p' components/DashboardClient.tsx`
Expected: lines that read `hashParams.get("file")`.

- [ ] **Step 2: Update `DashboardClient.tsx`**

Replace lines 16–18:

```tsx
  const hashParams = useHashParams();
  const file = hashParams.get("file") ?? undefined;
  const sessionName = hashParams.get("session") ?? undefined;
```

with:

```tsx
  const hashParams = useHashParams();
  // Prefer the new `path=` key; fall back to legacy `file=` for one release
  // so old shared links still resolve. `file=` carried only a leaf name, so
  // when it matches a single `FileEntry.fileName` we resolve to that entry's
  // full path.
  const sessionName = hashParams.get("session") ?? undefined;
  const explicitPath = hashParams.get("path") ?? undefined;
  const legacyFile = hashParams.get("file") ?? undefined;
```

Then replace lines 42–47 (the `selected` derivation):

```tsx
    if (!entries) return;
    const selected = file && entries.some((e) => e.fileName === file) ? file : undefined;
    if (!selected) {
```

with:

```tsx
    if (!entries) return;
    const selected =
      explicitPath && entries.some((e) => e.path === explicitPath)
        ? explicitPath
        : legacyFile
          ? entries.find((e) => e.fileName === legacyFile)?.path
          : undefined;
    if (!selected) {
```

Then in the next `useEffect` deps array, change `[entries, file, sessionName]` to `[entries, explicitPath, legacyFile, sessionName]`.

Finally, replace the `selectedFile` line near the bottom and the SessionPicker invocation:

```tsx
  const selectedFile = file && entries?.some((e) => e.fileName === file) ? file : undefined;
```

becomes:

```tsx
  const selectedPath = (() => {
    if (!entries) return undefined;
    if (explicitPath && entries.some((e) => e.path === explicitPath)) return explicitPath;
    if (legacyFile) return entries.find((e) => e.fileName === legacyFile)?.path;
    return undefined;
  })();
```

and the JSX:

```tsx
        <SessionPicker
          entries={entries ?? []}
          selectedFile={selectedFile}
          selectedSession={sessionName}
        />
```

becomes:

```tsx
        <SessionPicker
          entries={entries ?? []}
          selectedPath={selectedPath}
          selectedSession={sessionName}
        />
```

- [ ] **Step 3: Confirm `parseSessionFile` accepts paths**

Run: `grep -n "parseSessionFile" lib/sessions-client.ts | head -5`
Expected: the function signature accepts a string. It already passes the value into `parseAllSessions(fileName)`, which fetches `${sessionsBase()}/${fileName}` — that URL works equally well for `foo.xml` and `Sales/2024/Q1/foo.xml`.

Confirm by reading lines ~99–111 (no change required; it just works).

- [ ] **Step 4: Run both test suites**

Run: `npm test`
Expected: 163 passing.

Run: `npm run test:jsout`
Expected: 157 passing.

- [ ] **Step 5: Commit**

```bash
git add components/DashboardClient.tsx
git commit -m "feat(routing): migrate #file= to #path= with one-release legacy shim"
```

---

## Task 7: Move fixtures + smoke-test the dashboard

**Files:**
- Move: `public/sessions/s_SALES_DIM_FULL.xml` → `public/sessions/Sales/s_SALES_DIM_FULL.xml`
- Move: `public/sessions/s_ORDERS_INCREMENTAL.xml` → `public/sessions/Sales/2024/Q1/s_ORDERS_INCREMENTAL.xml`
- Regenerate: `public/sessions/index.json`

Bring the new feature to life with a realistic nested layout. The other two fixtures (`COMPTIME.xml`, `s_CUSTOMER_LOAD.xml`) stay at the root so we still exercise the mixed root-files-and-folders case.

- [ ] **Step 1: Move fixtures**

```bash
mkdir -p public/sessions/Sales/2024/Q1
mv public/sessions/s_SALES_DIM_FULL.xml public/sessions/Sales/s_SALES_DIM_FULL.xml
mv public/sessions/s_ORDERS_INCREMENTAL.xml public/sessions/Sales/2024/Q1/s_ORDERS_INCREMENTAL.xml
```

- [ ] **Step 2: Regenerate manifest**

Run: `node scripts/gen-sessions-manifest.mjs`
Expected:
```
[manifest] 4 entries -> .../public/sessions/index.json
```

- [ ] **Step 3: Inspect the manifest**

Run: `cat public/sessions/index.json`
Expected (order alpha by path):
```json
[
  { "path": "COMPTIME.xml", "name": "COMPTIME.xml" },
  { "path": "Customers/s_CUSTOMER_LOAD.xml", "name": "s_CUSTOMER_LOAD.xml" }
  ...
]
```

Wait — `s_CUSTOMER_LOAD.xml` is still at root, not under `Customers/`. Re-read carefully: the manifest will be `COMPTIME.xml`, `s_CUSTOMER_LOAD.xml`, `Sales/2024/Q1/s_ORDERS_INCREMENTAL.xml`, `Sales/s_SALES_DIM_FULL.xml`. Confirm that's what you see.

- [ ] **Step 4: Run both test suites**

Run: `npm test`
Expected: 163 passing.

Run: `npm run test:jsout`
Expected: 157 passing.

- [ ] **Step 5: Smoke-test in a real browser**

Run: `npm run dev`

In a browser at `http://localhost:3000`:

1. The session picker dropdown shows a tree:
   ```
   ▸ Sales (2 files · 2 sessions) [⬇]
      ▸ 2024 (1 file · 1 session) [⬇]
         s_ORDERS_INCREMENTAL ...
      s_SALES_DIM_FULL ...
   COMPTIME.xml (3 sessions listed)
   s_CUSTOMER_LOAD.xml
   ```
2. Expand `Sales`, then `Sales/2024`. Click into `s_ORDERS_INCREMENTAL`. Confirm the URL hash becomes `#path=Sales%2F2024%2FQ1%2Fs_ORDERS_INCREMENTAL.xml&session=...` and the session view renders.
3. Click the `⬇` button next to `Sales`. A file named `Sales_sessions.zip` should download. Open it; expect entries:
   - `Sales/s_SALES_DIM_FULL_(STG_SALES_TO_FACT_SALES).xlsx`
   - `Sales/2024/Q1/s_ORDERS_INCREMENTAL_(STG_POLICY_RISK_TO_DW_RISK_LOCATION_FACT).xlsx`
4. Click **Download all (.zip)** in the top bar. Confirm `all_sessions_mappings.zip` includes all 4 entries, each at its full path.
5. Type a search query (e.g., `ORDERS`) in the picker input — confirm `Sales/2024/Q1` auto-expands and other folders dim/collapse.
6. Test the legacy shim: navigate to `http://localhost:3000/#file=COMPTIME.xml`. Confirm the session loads (legacy hash still works).

Stop the dev server.

- [ ] **Step 6: Commit**

```bash
git add public/sessions/
git commit -m "fixtures: move two sessions into nested folders for the new tree UI"
```

---

## Task 8: Final verification + documentation

**Files:**
- Modify: `README.md` (if it exists and documents the manifest format)

- [ ] **Step 1: Final test sweep**

Run: `npm test && npm run test:jsout`
Expected: 163 + 157 = 320 tests passing.

- [ ] **Step 2: Check README**

Run: `grep -n "index.json\|sessions/" README.md 2>/dev/null | head -10`

If the README documents the manifest schema or session loading, update it to describe the new `{path,name}[]` shape and the nested folder support. If no such documentation exists, skip this step.

- [ ] **Step 3: Final commit (if README updated)**

```bash
git add README.md
git commit -m "docs: README updated for nested folder support"
```

---

## Self-Review

**Spec coverage check (run after writing the plan):**

| Spec section | Covered in task |
|---|---|
| Storage layout (multi-level folders) | Task 1 (script) + Task 7 (fixture move) |
| Manifest schema `{path,name}[]` | Task 1 |
| `FileEntry.path` field | Task 2 |
| Posix path normalisation | Task 1 (split/join via `sep`) |
| Manifest reader handles legacy shape | Task 2 step 3 |
| Directory-listing fallback removed | Task 2 step 4 |
| `lib/folder-tree.ts` with `FolderNode` | Task 3 |
| Sort: folders alpha, then files alpha | Task 3 (`sortNode`) |
| `totalFiles` / `totalSessions` rollup | Task 3 (`rollUp`) |
| Path validation rejects `..`, `/leading`, `//` | Task 3 (`validatePath`) |
| `tests/folder-tree.test.ts` | Task 3 |
| `downloadFolderXlsx(folder, options)` | Task 4 |
| Recursive walk via `filesUnder(folder)` | Task 4 + Task 3 |
| ZIP entries retain full path from `public/sessions/` | Task 4 (`entryNameFor`) |
| ZIP filename `<safe_path>_sessions.zip` / `all_sessions_mappings.zip` for root | Task 4 (`zipFilenameFor`) |
| Collision suffixing `_2`, `_3` | Task 4 (`entryNameFor`) |
| Error handling: throw on zero bundled, callback on per-file failure | Task 4 (`downloadFolderXlsx`) |
| SessionPicker tree rendering | Task 5 |
| Per-folder `⬇` download button | Task 5 (`FolderRow`) |
| Search auto-expand of matching ancestors | Task 5 (`expandedPaths`) |
| `#file=` → `#path=` with legacy shim | Task 6 |
| Move fixtures into `Sales/`, `Sales/2024/Q1/` | Task 7 |
| Existing 157 tests stay green | Tasks 2, 3, 4, 5, 6, 7 all assert this |

No gaps detected.

**Placeholder scan:** No TBD/TODO markers. Each step has concrete commands and code.

**Type consistency:** `FolderNode` shape defined in Task 3; consumed identically in Tasks 4 and 5. `FileEntry.path` defined in Task 2; consumed in Tasks 3, 4, 5, 6. `downloadFolderXlsx` signature `(folder, options?)` defined in Task 4 and called the same way in Task 5.
