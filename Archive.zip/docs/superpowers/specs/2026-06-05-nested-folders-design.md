# Nested session folders + folder-scoped XLSX download

**Status:** Approved (2026-06-05)
**Scope:** Next.js app only (`lib/`, `components/`, `scripts/`, `public/sessions/`, `tests/`). Vanilla port under `js-out/` is untouched in this round.

## Goal

Let reviewers organise IDMC session XMLs in an arbitrarily-nested folder hierarchy under `public/sessions/`, browse them via a tree in the SessionPicker, and download a ZIP of Clean-XLSXs for any selected folder (recursively, with the folder hierarchy preserved inside the ZIP).

## User-visible behaviour

1. **Drop XMLs anywhere under `public/sessions/`** — folders nest as deep as the filesystem allows. Filenames need only be unique within their folder.
2. **`npm run dev` (or `build`)** regenerates `index.json` with full relative paths so the static client can discover the tree.
3. **SessionPicker dropdown** renders a collapsible tree (folders first, alpha; files next, alpha). Each folder header shows `(N files · M sessions)` rollup counts and a `⬇` download icon. Typing in the search box auto-expands every folder that is an ancestor of any file or session matching the query; folders with no matching descendant collapse and dim.
4. **Click `⬇` on a folder** → assembles a Clean-XLSX per session under that folder (recursively) and downloads them as `<safe_folder_path>_sessions.zip`. Inside the ZIP, each entry retains its folder path from `public/sessions/` (e.g. `Sales/2024/Q1/<xml>_(<src>_TO_<tgt>).xlsx`).
5. **TopBar "Download all (.zip)"** keeps its existing behaviour, now implemented as `downloadFolderXlsx(rootNode, files)` — same ZIP filename `all_sessions_mappings.zip`.
6. **Deep links** use `#path=<rel-path>&session=<name>`. The old `#file=<filename>&session=<name>` form is accepted for one release for backwards compatibility.

## Architecture

### Storage layout

```
public/sessions/
├── index.json                     (manifest, auto-generated)
├── COMPTIME.xml                   (root-level XMLs still allowed)
├── Sales/
│   ├── s_SALES_DIM_FULL.xml
│   └── 2024/
│       └── Q1/
│           └── s_ORDERS_INCREMENTAL.xml
└── Customers/
    └── s_CUSTOMER_LOAD.xml
```

### Manifest schema change

Old: `["a.xml", "b.xml"]` (flat strings)

New: array of `{ path, name }` objects, where `path` is relative to `public/sessions/` using forward slashes regardless of host OS:

```json
[
  { "path": "COMPTIME.xml",                            "name": "COMPTIME.xml" },
  { "path": "Customers/s_CUSTOMER_LOAD.xml",           "name": "s_CUSTOMER_LOAD.xml" },
  { "path": "Sales/2024/Q1/s_ORDERS_INCREMENTAL.xml",  "name": "s_ORDERS_INCREMENTAL.xml" },
  { "path": "Sales/s_SALES_DIM_FULL.xml",              "name": "s_SALES_DIM_FULL.xml" }
]
```

`name` is denormalised for convenience; it is always `path.split("/").pop()`.

### Module-level changes

| File | Change |
|---|---|
| `scripts/gen-sessions-manifest.mjs` | Recursive `readdir({ withFileTypes: true, recursive: true })` walk. Emits the new `{ path, name }[]` shape. Posix-normalises path separators. |
| `lib/sessions-types.ts` | Add `path: string` to `FileEntry`. |
| `lib/sessions-client.ts` | Parse the new manifest. Drop `tryDirectoryListing()` (directory listings don't recurse). Key sessions by `path`, not by `fileName` alone. |
| `lib/folder-tree.ts` *(new)* | Pure-logic builder: `buildFolderTree(files: FileEntry[]): FolderNode`. Sort order: folders first (alpha), files next (alpha). Compute `totalFiles` / `totalSessions` rollups via post-order DFS. |
| `lib/downloads.ts` | New `downloadFolderXlsx(folder, files)`. Refactor existing `downloadAllSessionsXlsx` to call it with the root node. |
| `components/SessionPicker.tsx` | Tree rendering. Per-folder header with chevron, count badge, and `⬇` download button. Search auto-expands matching subtrees. |
| `components/DashboardClient.tsx` | Read `#path=` (preferred) or `#file=` (legacy) from the URL hash. |
| `lib/href.ts` | Same hash param rename + legacy shim. |

### `FolderNode` shape

```ts
type FolderNode = {
  name: string;                // leaf folder name; "" for the root
  path: string;                // relative path with trailing "/"-less; "" for root
  files: FileEntry[];          // direct children only, alpha-sorted by name
  folders: FolderNode[];       // direct subfolders only, alpha-sorted by name
  totalFiles: number;          // includes all descendants
  totalSessions: number;       // includes all descendants
};
```

### `downloadFolderXlsx` behaviour

Pseudo-code:

```ts
async function downloadFolderXlsx(folder: FolderNode, files: FileEntry[]) {
  const zip = new JSZip();
  const used = new Map<string, number>();
  const failed: string[] = [];
  for (const file of filesUnder(folder, files)) {
    try {
      const parsed = await parseSessionFile(file.path); // parses all sessions in the XML
      for (const session of parsed) {
        const buf = await buildCleanWorkbook(buildMappingJson(session));
        const parentPath = file.path.split("/").slice(0, -1).join("/"); // "" for root files
        const entryName = parentPath
          ? `${parentPath}/${buildXlsxFilename(session)}`
          : buildXlsxFilename(session);
        zip.file(disambiguate(entryName, used), buf);
      }
    } catch (e) {
      failed.push(file.path);
    }
  }
  if (zip.files.length === 0) throw new Error(`No sessions parsed under ${folder.path}`);
  const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
  downloadBlob(zipFilenameFor(folder), blob);
}
```

- **`filesUnder`** does a DFS over `FolderNode` and returns a flat alpha-sorted list of `FileEntry` under it (descending into subfolders).
- **`disambiguate`** appends `_2`, `_3`, … to the stem if the same full ZIP-entry path collides (matches existing `pickName` logic).
- **`zipFilenameFor(folder)`** = `safeName(folder.path.replaceAll("/", "_")) + "_sessions.zip"` for any sub-folder (so selecting `Sales/2024/Q1` produces `Sales_2024_Q1_sessions.zip`, making the archive self-describing); `"all_sessions_mappings.zip"` for the root, preserving the existing top-bar contract.

**Path retention inside the ZIP:** entries always carry the *full* path from `public/sessions/`, never just the path relative to the selected folder. Selecting `Sales/2024` produces a ZIP whose entries start with `Sales/2024/Q1/...` — not `Q1/...`. This guarantees that re-extracting any ZIP into `public/sessions/` rebuilds the original tree exactly.

### Error handling

- A folder whose XMLs all fail to parse → throws with a per-file failure list logged to console; caller (SessionPicker / TopBar) surfaces a `toast(...)` error.
- A folder with mixed success → success toast notes the failed count: `"Bundled 12 of 13 sessions (1 failed: see console)"`.
- An XML that parses but has zero sessions → not an error; just contributes no entries.

### Testing

| Test file | Coverage |
|---|---|
| `tests/folder-tree.test.ts` *(new)* | Flat list → tree round-trip; `totalFiles` / `totalSessions` rollup correctness; sort order (folders before files, both alpha); path normalisation (leading `/` stripped, `..` / `.` rejected); single-root-only edge case; empty manifest. |
| `tests/sessions.test.ts` | Add an assertion that `parseSessionFile(pathWithFolders)` works identically to today. |

UI testing is out of scope for the automated suite; I will add temporary nested fixtures under `public/sessions/` (move `s_SALES_DIM_FULL.xml` into `Sales/` and `s_ORDERS_INCREMENTAL.xml` into `Sales/2024/Q1/`) and smoke-test the dashboard in a real browser.

## Non-goals

- No drag-and-drop or in-app folder management. The folder tree is read from disk only.
- No "combine all sessions into one workbook" mode. Only the per-session ZIP (chosen "A" + "B" in brainstorming).
- No change to per-session XLSX naming, FIELD_MAPPING columns, or any logic upstream of the picker. This is a strictly additive feature.
- No mirror to `js-out/` in this round.
- No server-side rendering or API routes added; the static-export contract is preserved.

## Rollout

- Single PR; backwards-compatible at the URL level (legacy `#file=` shim) and at the data level (the manifest generator runs in `predev`/`prebuild` so existing flat installs continue to work without manual intervention).
- After merge, the developer drops XMLs into nested folders and runs `npm run dev` once to regenerate the manifest; everything else is read from `index.json`.
