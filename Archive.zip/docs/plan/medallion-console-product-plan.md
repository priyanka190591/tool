# IDMC Medallion Console — Product Plan

## Context

The Session Dashboard (static-export refactor — shipped) gives engineers a read-only inspector for parsed IDMC session XML. A client engagement is pushing the tool in a new direction:

- Architects want to author a Source-to-Target (S2T) **design contract** before implementation.
- Tech leads want to audit existing IDMC projects against a **Medallion** layered architecture (Metal / Bronze / Silver / Gold / Platinum).
- Delivery wants a **refactor playbook** with prioritized actions to restructure brownfield IDMC code.

Goal: extend the existing static dashboard into a coherent product — the **IDMC Medallion Console** — that serves design, governance, and refactor workflows from a single deployable artifact, with no runtime Node.js dependency.

## Strategic decision: one product, multiple modes

One static-exported app with **four modes** surfaced in the nav:

| Mode | Audience | Primary job-to-be-done |
|---|---|---|
| **Inspect** | IDMC engineer | Drill into any session/mapping (today's dashboard) |
| **Architect** | Architect / tech lead | Author design contracts, define layer model, configure naming/DQ rules |
| **Reconcile** | Review meeting | See gaps: design coverage, layer leaks, DQ coverage, naming compliance |
| **Refactor** | Delivery lead | Prioritized backlog + clean S2T regeneration + handoff exports |

Not separate tools — splitting forces duplicated parsing/data models and breaks the cross-mode insight that's the actual value. Single zip, single URL, hostable on the existing PowerShell server.

### Positioning (what it is and isn't)

- **Is:** a review/governance/refactor lens on parsed IDMC artifacts, with an authored design contract on top.
- **Isn't:** an IDMC designer (Informatica has one), a metadata catalog (EDC does that), a SaaS (it's self-hosted, static).

## Default opinions (Medallion-first)

Ships pre-configured for 5-tier Medallion. Override by editing two JSON files.

```json
// public/contracts/layers.json   (default)
{
  "tiers": [
    { "id": "metal",    "rank": 0, "namePatterns": ["^mtl_", "^raw_", "^lnd_"] },
    { "id": "bronze",   "rank": 1, "namePatterns": ["^brz_", "^b_"] },
    { "id": "silver",   "rank": 2, "namePatterns": ["^slv_", "^s_"] },
    { "id": "gold",     "rank": 3, "namePatterns": ["^gld_", "^g_", "^fact_", "^dim_"] },
    { "id": "platinum", "rank": 4, "namePatterns": ["^plt_", "^pub_", "^dp_"] }
  ],
  "leakRule": "no-skip",
  "writeRules": {
    "metal":    { "writesAllowedFrom": [] },
    "bronze":   { "writesAllowedFrom": ["metal"] },
    "silver":   { "writesAllowedFrom": ["bronze"] },
    "gold":     { "writesAllowedFrom": ["silver"] },
    "platinum": { "writesAllowedFrom": ["gold"] }
  }
}
```

```json
// public/contracts/audit-columns.json   (default)
{
  "bronze":   ["INGEST_TS", "SOURCE_FILE", "BATCH_ID"],
  "silver":   ["DQ_STATUS", "LOAD_DT", "SOURCE_SYS"],
  "gold":     ["BUSINESS_AS_OF_DT", "EFFECTIVE_FROM_DT", "EFFECTIVE_TO_DT"],
  "platinum": ["PUBLISHED_AT", "OWNER", "SLA_TIER"]
}
```

DQ catalog and naming rules follow the same pattern (`dq-rules.json`, `naming-rules.json`).

## Architecture additions (on top of the existing static export)

```
public/contracts/                ← new client-editable inputs
  index.json                     ← manifest of contract files
  layers.json                    ← tier model + leak rules
  dq-rules.json                  ← DQ rule catalog
  naming-rules.json              ← per-tier naming regex
  audit-columns.json             ← required audit columns per tier
  *.s2t.csv                      ← per-target design contracts
  refresh-contracts.ps1          ← regenerates contracts/index.json

lib/
  contract.ts                    ← parse/type S2T CSVs
  layers.ts                      ← tier assignment (contract → naming fallback → unknown)
  dq.ts                          ← DQ rule catalog + IDMC CDQ mapplet detection
  reconcile.ts                   ← cross-session issue engine (pure)
  refactor.ts                    ← scoring + playbook generator (pure)
  reports.ts                     ← architecture/DQ/refactor XLSX builders

components/
  Nav.tsx                        ← 4-mode activity bar
  ArchitectClient.tsx
  ReconcileClient.tsx
  RefactorClient.tsx
  LayerBadge.tsx                 ← reusable tier chip
  LeakMatrix.tsx                 ← 5×5 tier transition heatmap
  GapList.tsx                    ← reconciliation issues with severity
  ScoreCard.tsx                  ← compliance / coverage scorecards

app/
  architecture/page.tsx          ← Reconcile mode overview
  contracts/page.tsx             ← Architect mode: list contracts
  contracts/[target]/page.tsx    ← per-target design vs impl
  refactor/page.tsx              ← Refactor mode: backlog + exports
```

`lib/reconcile.ts` emits a typed issue stream that every UI surface consumes:

```ts
type ArchIssue =
  | { kind: "layer-leak"; mapping: string; from: Tier; to: Tier; skipped: Tier[] }
  | { kind: "missing-in-impl"; designRow: ContractRow }
  | { kind: "extra-in-impl"; lineageRow: LineageRow }
  | { kind: "dq-coverage-gap"; target: string; column: string; expectedRule: string }
  | { kind: "naming-violation"; entity: string; expected: string }
  | { kind: "audit-column-missing"; target: string; tier: Tier; column: string }
  | { kind: "duplicate-logic"; signature: string; locations: string[] }
  | { kind: "unclassifiable-table"; table: string };
```

Severity (`high`/`med`/`low`) is derived deterministically from issue kind + tier (e.g. `layer-leak` skipping 2+ tiers is high; missing audit column on Platinum is high; on Bronze is medium).

## Phased build plan

Each phase ships standalone value. Stop after any phase and the previous artifact is still useful.

### Phase 1 — Medallion foundation (~3 days)

**Deliverables**
- `lib/layers.ts` with `layers.json` default
- Layer badge on every table reference in the existing session view
- Extend `lib/validation.ts` to emit `layer-leak`, `audit-column-missing`, `unclassifiable-table` issues from naming inference alone (no contract needed)
- Existing Validation panel shows new issues
- Tiny `Architecture` link in nav → leak matrix page (read-only)

**Why first:** delivers immediate value to brownfield clients with zero new inputs. Naming inference is enough to surface the worst leaks. Validates the layer model + UI affordances before we invest in contracts.

### Phase 2 — Design contract import + reconciliation engine (~5 days)

**Deliverables**
- `lib/contract.ts` parses `public/contracts/*.s2t.csv` (manifest pattern, same as sessions)
- `refresh-contracts.ps1` regenerates `contracts/index.json`
- `lib/reconcile.ts` produces `ArchIssue[]` from contracts × parsed sessions
- `/contracts` page lists all design contracts with coverage % per target
- `/contracts/[target]` page shows design vs implementation side-by-side with gap list
- "Architecture issues" panel added to session view, filtered to that session

**Why second:** this is the core differentiator. Everything downstream consumes `ArchIssue[]`. Get the data model right here; UI is mostly tabular.

### Phase 3 — Architecture overview + scorecards + main report export (~4 days)

**Deliverables**
- `/architecture` overview: leak matrix, scorecards (naming compliance %, DQ coverage %, audit completeness %, reusability %), top 10 high-severity issues
- `lib/reports.ts` → `architecture_report.xlsx` (sheets: Overview, Tier Matrix, Layer Leaks, DQ Coverage, Naming Compliance, Audit Coverage, Unclassified Tables)
- Layer-filtered search chip on existing `/search` page

**Why third:** the reconciliation engine produces the data; this is the executive-readable view. Sells the tool to the people writing the cheque.

### Phase 4 — Refactor playbook + clean S2T regeneration (~4 days)

**Deliverables**
- `lib/refactor.ts` — scoring (impact × effort), grouping (by tier, by mapping family), recommendation generator
- `/refactor` page: prioritized backlog with rationale per item, "expected after" preview
- `refactor_playbook.md` export (handed to delivery team)
- `clean_s2t.xlsx` export (design contract merged with implementation reality, ready to re-author)
- `dq_coverage.xlsx` export

**Why fourth:** depends on everything above. This is the "now what?" deliverable that turns the audit into action.

### Phase 5 — Templates, samples, onboarding (~2 days)

**Deliverables**
- `public/contracts/_samples/` with a 3-table Medallion example (one per tier transition)
- README addition: "Architect's quickstart" — how to author a contract from scratch
- Pre-populated `dq-rules.json` with the 10 most common IDMC CDQ patterns
- First-run experience: when `contracts/index.json` is missing, show a setup card with copy-pasteable templates
- README addition: how to override `layers.json` for non-Medallion shops

**Why last:** product polish. Nice to have for adoption, not blocking the value proposition.

**Total:** ~18 working days to a polished v1. Each phase is independently shippable.

## Critical files to create

(Beyond the directory map above.) Phase-by-phase the top-priority new files:

- **Phase 1:** `lib/layers.ts`, `components/LayerBadge.tsx`, `components/LeakMatrix.tsx`, `public/contracts/layers.json`, `public/contracts/audit-columns.json`, `app/architecture/page.tsx`
- **Phase 2:** `lib/contract.ts`, `lib/reconcile.ts`, `public/contracts/index.json`, `public/refresh-contracts.ps1`, `app/contracts/page.tsx`, `app/contracts/[target]/page.tsx`, `components/GapList.tsx`
- **Phase 3:** `lib/reports.ts` (extends `lib/xlsx.ts` patterns), `components/ScoreCard.tsx`, layer-filter on existing search
- **Phase 4:** `lib/refactor.ts`, `app/refactor/page.tsx`
- **Phase 5:** sample contracts, default `dq-rules.json`, README updates

## What we will not build

Bright lines worth being explicit about, because the client will ask:

- **No IDMC XML generation from contracts.** Authoring IDMC artifacts from design is a 6-month product; we'd compete with Informatica's own designer and lose. Stop at "rebuilt clean S2T" — the implementation team takes it from there.
- **No multi-tenant SaaS / auth / sharing.** The static-export, client-hosted model is part of the value proposition. Adding auth means losing the no-Node-on-target deployment story.
- **No DQ rule execution.** We *catalog* rules and detect their *application points* in mappings. Running them against data is a separate product (Informatica CDQ itself).
- **No live IDMC API connection.** XML import only. Adding "pull from IDMC" creates ops, auth, and version-skew problems for the static-hosting model.
- **No automatic XML refactoring.** Generate playbooks and clean S2Ts; let engineers apply changes in IDMC.

## Verification per phase

- **Phase 1:** load existing 4 sample XMLs, confirm each table gets a tier badge or "unclassifiable" tag; manually rename a target to violate the convention and confirm the issue appears.
- **Phase 2:** author a 5-row design CSV for one of the 4 sample mappings, confirm reconciliation surfaces the synthetic gaps; remove an entry from the design and confirm `extra-in-impl` fires.
- **Phase 3:** confirm `architecture_report.xlsx` opens in Excel, scorecards sum correctly across the sample set, leak matrix counts match a manual count.
- **Phase 4:** confirm refactor backlog is non-empty, top item has clear rationale, `refactor_playbook.md` reads as a sensible handoff doc.
- **Phase 5:** delete `contracts/index.json` and confirm first-run setup card appears with working templates.

At every phase, the build still produces a static `out/` and `session-dashboard-static.zip` (same packaging story). The PowerShell server keeps working unchanged.

## Open questions for the client (before Phase 2)

1. Is DQ a separate tier, or a mandatory step *between* Bronze and Silver? (Affects `layers.json` tier count.)
2. Where do RDM/MDM outputs land? Silver, or their own tier?
3. What's the canonical naming convention they want enforced — confirm or override the defaults above.
4. Do they have an existing DQ rules catalog (CSV/XLSX)? Import format we should support natively.
