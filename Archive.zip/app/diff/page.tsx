import { DiffClient } from "@/components/DiffClient";

export default function DiffPage() {
  return <DiffClient />;
}
