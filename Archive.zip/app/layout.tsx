import type { Metadata } from "next";
import { TopBar } from "@/components/TopBar";
import "./globals.css";

export const metadata: Metadata = {
  title: "IDMC Session Dashboard",
  description: "Visualize Informatica IDMC session XML files",
};

const HOME_HREF = process.env.NODE_ENV === "production" ? "/index.html" : "/";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen">
          <header className="border-b border-ink-200 bg-white">
            <div className="mx-auto flex max-w-7xl items-center gap-4 px-6 py-4">
              <a href={HOME_HREF} className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-ink-900 text-white">
                  <span className="text-xs font-semibold tracking-tight">SX</span>
                </div>
                <div>
                  <h1 className="text-base font-semibold tracking-tight text-ink-900">
                    IDMC Session XML Dashboard
                  </h1>
                  <p className="text-xs text-ink-500">
                    Browse, inspect, validate, and export Informatica IDMC sessions
                  </p>
                </div>
              </a>
              <div className="ml-auto">
                <TopBar />
              </div>
            </div>
          </header>
          <main className="mx-auto max-w-7xl px-6 py-8">{children}</main>
        </div>
      </body>
    </html>
  );
}
