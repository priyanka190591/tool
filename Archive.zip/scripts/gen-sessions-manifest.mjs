import { readdir, writeFile } from "node:fs/promises";
import { join, dirname, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const sessionsDir = join(here, "..", "public", "sessions");

async function walk(dir) {
  const out = [];
  const entries = await readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) {
      out.push(...(await walk(full)));
    } else if (e.isFile() && /\.xml$/i.test(e.name)) {
      // Always posix separators in the manifest, regardless of host OS.
      const rel = relative(sessionsDir, full).split(sep).join("/");
      out.push({ path: rel, name: e.name });
    }
  }
  return out;
}

const files = (await walk(sessionsDir)).sort((a, b) =>
  a.path.localeCompare(b.path),
);

const out = join(sessionsDir, "index.json");
await writeFile(out, JSON.stringify(files, null, 2) + "\n", "utf8");
console.log(`[manifest] ${files.length} entries -> ${out}`);
