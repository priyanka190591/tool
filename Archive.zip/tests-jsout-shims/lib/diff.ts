// @ts-nocheck
export type DiffStatus = any;
export type DiffPair = any;
export type DiffSection = any;
export type SessionDiff = any;
export { diffSessions } from "../../js-out/js/lib/diff.js";
