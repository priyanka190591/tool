// @ts-nocheck
// `@/lib/sessions` re-exported parsed-session + mapping types in Next.js.
// Tests use these as type-only imports. We pin them to `any` so TS doesn't
// complain when the shim is consumed by `import type { ... }`.
export type Connector = any;
export type ParsedSession = any;
export type TransformationDef = any;
export type SourceDef = any;
export type TargetDef = any;
export type MappingDef = any;
export type ConnectionRef = any;
export type WorkflowDef = any;
export type ConfigDef = any;
export type KV = any;

export { parseSessionsFromXml } from "../../js-out/js/lib/sessions-parser.js";
