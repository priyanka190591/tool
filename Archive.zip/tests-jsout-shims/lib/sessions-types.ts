// @ts-nocheck
export type ParsedSession = any;
export type Connector = any;
export type TransformationDef = any;
