// @ts-nocheck
export type MappingJson = any;
export type FieldMappingJson = any;
export type LookupJson = any;
export type SourceSqlJson = any;
export type ConnectionRowJson = any;
// Re-export runtime values from where vanilla actually defines them.
// Next.js puts `isFieldMappingUnresolved` in lib/mapping-schema.ts, but
// vanilla colocates it with build-mapping-json.js. Tests import it via
// `@/lib/mapping-schema`, so route through here.
export { isFieldMappingUnresolved } from "../../js-out/js/lib/build-mapping-json.js";
export { LOAD_TYPES, EXPRESSION_TYPES, NULL_LITERAL, GROUP_ORDER, groupAttributes } from "../../js-out/js/lib/mapping-schema.js";
