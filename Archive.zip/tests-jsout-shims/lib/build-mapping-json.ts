// @ts-nocheck
export { buildMappingJson, isFieldMappingUnresolved } from "../../js-out/js/lib/build-mapping-json.js";
