// Polyfills required by the vanilla js-out modules when run under Node.
//
//   - The vanilla XML parser (js-out/js/lib/xml-parser.js) calls
//     `new DOMParser()`; the browser supplies one, Node does not.
//     @xmldom/xmldom is a minimal pure-XML DOMParser that satisfies the
//     `parseFromString(xml, "application/xml")` + `querySelector("parsererror")`
//     usage the parser depends on.
//
//   - The vanilla XLSX writer (js-out/js/lib/exports-xlsx.js) reads ExcelJS
//     from `window.ExcelJS` (loaded as a UMD bundle in the browser). Under
//     Node we require the exceljs npm package and assign it to a synthetic
//     `globalThis.window`.
//
// @ts-nocheck

import { DOMParser } from "@xmldom/xmldom";
import ExcelJS from "exceljs";

if (typeof globalThis.DOMParser === "undefined") {
  globalThis.DOMParser = DOMParser as any;
}

if (typeof globalThis.window === "undefined") {
  (globalThis as any).window = globalThis;
}
(globalThis as any).window.ExcelJS = ExcelJS;
