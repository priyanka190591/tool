# refresh-sessions.ps1
#
# Regenerates sessions/index.json from the .xml files in the sessions folder.
# Run this from the same folder where this script lives (the deployed site root),
# after you add/remove XML files in .\sessions\.
#
# Usage:
#   .\refresh-sessions.ps1
#
# After running, hard-refresh your browser (Ctrl+F5).

$ErrorActionPreference = "Stop"

$here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$sessionDir = Join-Path $here "sessions"
$indexPath  = Join-Path $sessionDir "index.json"

if (-not (Test-Path $sessionDir)) {
    Write-Error "sessions folder not found at $sessionDir"
    exit 1
}

$files = Get-ChildItem -Path $sessionDir -Filter *.xml -File |
    Sort-Object Name |
    Select-Object -ExpandProperty Name

if ($null -eq $files) {
    $files = @()
} elseif ($files -isnot [array]) {
    $files = @($files)
}

# ConvertTo-Json renders a single-element array as a scalar, so guard with -AsArray
# when available (PS 7+). Otherwise fall back to manual JSON for arrays of <=1 item.
if ($PSVersionTable.PSVersion.Major -ge 7) {
    $json = ConvertTo-Json -InputObject $files -AsArray -Depth 1
} elseif ($files.Count -le 1) {
    $items = ($files | ForEach-Object { '"' + ($_ -replace '"','\"') + '"' }) -join ",`n  "
    $json = "[`n  $items`n]"
} else {
    $json = ConvertTo-Json -InputObject $files -Depth 1
}

Set-Content -Path $indexPath -Value $json -Encoding UTF8
Write-Host "Wrote $($files.Count) entries to $indexPath"
