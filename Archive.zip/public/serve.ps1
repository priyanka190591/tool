# serve.ps1
#
# Minimal static HTTP server for hosting the Session Dashboard build.
# Serves this folder as the document root. Maps directory requests to
# <dir>/index.html (so /search/ -> /search/index.html if anyone tries).
#
# Usage:
#   .\serve.ps1                  # http://localhost:8080
#   .\serve.ps1 -Port 9090       # custom port
#   .\serve.ps1 -Bind "0.0.0.0"  # listen on all interfaces (needs admin
#                                #   or a netsh URLACL reservation)
#
# Press Ctrl+C to stop.

[CmdletBinding()]
param(
    [int]$Port = 8080,
    [string]$Bind = "localhost"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$mime = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".mjs"  = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".xml"  = "application/xml; charset=utf-8"
    ".svg"  = "image/svg+xml"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".gif"  = "image/gif"
    ".ico"  = "image/x-icon"
    ".woff" = "font/woff"
    ".woff2" = "font/woff2"
    ".ttf"  = "font/ttf"
    ".otf"  = "font/otf"
    ".txt"  = "text/plain; charset=utf-8"
    ".map"  = "application/json; charset=utf-8"
}

function Resolve-RequestPath([string]$urlPath) {
    $clean = $urlPath.Split("?")[0]
    $decoded = [System.Uri]::UnescapeDataString($clean)

    $rel = $decoded.TrimStart("/")
    if ([string]::IsNullOrEmpty($rel)) {
        return @{ kind = "file"; path = (Join-Path $root "index.html") }
    }
    $candidate = Join-Path $root $rel

    if (Test-Path $candidate -PathType Container) {
        $indexInside = Join-Path $candidate "index.html"
        if (Test-Path $indexInside -PathType Leaf) {
            return @{ kind = "file"; path = $indexInside }
        }
        return @{ kind = "listing"; path = $candidate; urlPath = $decoded }
    }
    return @{ kind = "file"; path = $candidate }
}

function Send-DirectoryListing($context, [string]$dirPath, [string]$urlPath) {
    $files = Get-ChildItem -Path $dirPath -File | Sort-Object Name
    $dirs  = Get-ChildItem -Path $dirPath -Directory | Sort-Object Name

    $safeUrl = $urlPath
    $items = New-Object System.Text.StringBuilder
    foreach ($d in $dirs) {
        $name = $d.Name
        [void]$items.AppendLine("  <li><a href=`"$name/`">$name/</a></li>")
    }
    foreach ($f in $files) {
        $name = $f.Name
        [void]$items.AppendLine("  <li><a href=`"$name`">$name</a></li>")
    }

    $html = @"
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Index of $safeUrl</title></head>
<body>
<h1>Index of $safeUrl</h1>
<ul>
$($items.ToString())
</ul>
</body>
</html>
"@

    $context.Response.ContentType = "text/html; charset=utf-8"
    $context.Response.Headers.Add("Cache-Control", "no-store")
    $bytes = [Text.Encoding]::UTF8.GetBytes($html)
    $context.Response.ContentLength64 = $bytes.Length
    $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
}

function Send-File($context, [string]$path) {
    if (-not (Test-Path $path -PathType Leaf)) {
        $context.Response.StatusCode = 404
        $body = [Text.Encoding]::UTF8.GetBytes("404 Not Found: $($context.Request.Url.AbsolutePath)")
        $context.Response.ContentLength64 = $body.Length
        $context.Response.OutputStream.Write($body, 0, $body.Length)
        return
    }

    $ext = [IO.Path]::GetExtension($path).ToLower()
    $type = $mime[$ext]
    if (-not $type) { $type = "application/octet-stream" }

    $context.Response.ContentType = $type
    $bytes = [IO.File]::ReadAllBytes($path)
    $context.Response.ContentLength64 = $bytes.Length
    $context.Response.Headers.Add("Cache-Control", "no-store")
    $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
}

$prefix = "http://${Bind}:${Port}/"
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
} catch {
    Write-Error "Could not start HTTP listener at $prefix. $($_.Exception.Message)"
    if ($Bind -ne "localhost" -and $Bind -ne "127.0.0.1") {
        Write-Host ""
        Write-Host "Binding to '$Bind' usually requires admin or a netsh URLACL reservation:"
        Write-Host "  netsh http add urlacl url=$prefix user=Everyone"
    }
    exit 1
}

Write-Host "Session Dashboard serving on $prefix"
Write-Host "Document root: $root"
Write-Host "Open: ${prefix}index.html"
Write-Host "Press Ctrl+C to stop."

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        try {
            $resolved = Resolve-RequestPath $context.Request.Url.AbsolutePath
            if ($resolved.kind -eq "listing") {
                Send-DirectoryListing $context $resolved.path $resolved.urlPath
            } else {
                Send-File $context $resolved.path
            }
        } catch {
            Write-Warning "Error handling $($context.Request.Url): $($_.Exception.Message)"
            try {
                $context.Response.StatusCode = 500
            } catch {}
        } finally {
            try { $context.Response.OutputStream.Close() } catch {}
        }
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
