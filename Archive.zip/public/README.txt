Session Dashboard — static build
================================

This folder is a complete, self-contained static site. No Node.js required
at runtime. Any plain HTTP file server will host it.


1. Layout
---------

  index.html              entry page (the dashboard)
  search/index.html       search page
  diff/index.html         diff page
  _next/                  JS, CSS, fonts (do not move/edit individual files)
  sessions/               <-- drop your XML files here
    *.xml                 the parsed files
  serve.ps1               minimal PowerShell static server (recommended)
  refresh-sessions.ps1    fallback: creates sessions/index.json
  README.txt              this file


2. Adding / removing XML files
------------------------------

Just drop new .xml files into the `sessions\` folder. Hard-refresh
the browser (Ctrl+F5). The dashboard discovers files automatically
by asking the server for a directory listing.

No manifest. No rebuild. No script to run.


3. URL format
-------------

All URLs in this build include `index.html` explicitly:

  http://<host>/index.html                   <- dashboard
  http://<host>/search/index.html            <- search page
  http://<host>/diff/index.html              <- diff page

Selecting a session adds a hash fragment:

  http://<host>/index.html#file=foo.xml&session=s_FOO

Hash fragments are NEVER sent to the server -- they stay in the
browser -- so any plain HTTP file server can host this site without
URL rewriting. Refreshing the page works on every URL.


4. Serving the site
-------------------

The included `serve.ps1` is the recommended server. It supports the
directory-listing protocol the dashboard needs.

  PS> .\serve.ps1                 # listens on http://localhost:8080
  PS> .\serve.ps1 -Port 9090      # custom port

Then open  http://localhost:8080/index.html  in your browser.


5. Using a different server
---------------------------

The dashboard discovers XML files by fetching `/sessions/` and
parsing the directory listing the server returns.

Common servers that return listings out of the box:
  - The bundled serve.ps1
  - `python -m http.server`
  - Apache and nginx (default config)
  - Most static-site dev servers

If your server does NOT return directory listings (e.g. IIS with
DirectoryBrowse disabled, hardened production configs), you have
two options:

  Option A: enable directory listings in your server config.
  Option B: maintain `sessions\index.json` manually. The bundled
            refresh-sessions.ps1 script will generate it for you:

              PS> .\refresh-sessions.ps1

            Then re-run it whenever you add or remove XML files.


6. Troubleshooting
------------------

"Could not load sessions. The server did not return a directory
listing for /sessions/ and sessions/index.json is missing"
  -> Your server doesn't expose directory listings AND there's no
     fallback manifest. See section 5.

"This page could not be found. /index.html" (when running npm run dev)
  -> Dev mode uses clean URLs without `index.html`. Visit
     http://localhost:3000/ instead. The /index.html paths only
     exist in the production build (the contents of this folder).

Browser shows old data after I added new XMLs
  -> Hard refresh (Ctrl+F5) to bust the browser cache.

Static server returns the file but the page is blank
  -> Open browser DevTools -> Network tab and reload. Likely the
     server isn't returning the right MIME type for .js or .css.
     `serve.ps1` handles MIME types correctly; check yours.
