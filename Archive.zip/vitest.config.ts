import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: {
    alias: { "@": path.resolve(__dirname, ".") },
  },
  test: {
    globals: false,
    include: ["tests/**/*.test.ts"],
    environment: "node",
  },
});
