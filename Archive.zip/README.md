# IDMC Session XML Dashboard

A Next.js dashboard for browsing and inspecting Informatica IDMC session XML exports.

## How it works

- Drop session XML files into the `sessions/` folder at the project root.
- The dashboard's dropdown is populated by reading that folder server-side.
- When you select a file, the server parses it with `fast-xml-parser` and the page renders:
  - Session header (name, mapping, config, validity, reusable)
  - Grouped session attributes (general, performance, error handling, recovery, logging, partitioning)
  - Connection references (sources, targets, lookups)
  - Transformation instances with their per-instance overrides
  - Session extensions (Snowflake / S3 / etc. reader/writer config)
  - Parameters

## Getting started

```bash
npm install
npm run dev
# open http://localhost:3000
```

## Adding your own XML files

```bash
cp /path/to/your-export.xml sessions/
# refresh the page — the file appears in the dropdown
```

Files are matched by `*.xml` (case-insensitive). The parser looks for the first `<SESSION>` node anywhere in the document, so it works for full `POWERMART` exports and for session fragments.

## Nested folder support

XML files can be placed in arbitrary sub-folders under `sessions/`:

```
sessions/
  Sales/
    2024/
      Q1/
        s_ORDERS_INCREMENTAL.xml
    s_SALES_DIM_FULL.xml
  COMPTIME.xml
```

The build step scans the `sessions/` tree recursively and writes a `sessions/index.json` manifest. Each entry has a `path` (relative to `sessions/`, slash-separated) and a `name` (basename). The session picker in the dashboard assembles a folder-tree from these paths so nested sessions are grouped visually. The "Download all (.zip)" action and the diff/search pages all resolve files via the same path-based manifest. The legacy `#file=<name>` URL hash still works for flat root-level files.
