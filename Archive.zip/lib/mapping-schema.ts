// MappingJson — normalized intermediate representation used by the clean 3-sheet
// XLSX export, the JSON download, and (eventually) anything else that needs a
// schema-stable view of a session. Derived from ParsedSession + LineageRow[];
// see lib/build-mapping-json.ts. Schema is additive — bump schema_version on
// breaking changes.

export type SchemaVersion = "1";

export type FieldDef = {
  name: string;
  datatype: string;
  precision?: number;
  scale?: number;
  nullable?: boolean;
};

export type SourceJson = {
  name: string; // resolved clean name (BUSINESSNAME / REFERENCEDTABLE / cleaned wrapper)
  connection?: string;
  fields: FieldDef[];
};

export type TargetJson = {
  name: string;
  fields: FieldDef[];
};

export type LookupJson = {
  lookup_id: string; // instance/transformation name — referenced from field_mappings
  source_table: string; // cleaned (e.g. "dbo.policydetail")
  connection?: string;
  join_conditions: { left: string; right: string }[]; // parsed from "A = B AND C = D"
  return_fields: string[]; // OUTPUT / LOOKUP/OUTPUT / LOOKUP ports
  sql_override?: string; // stored once per lookup; never in field_mappings
  is_cached?: boolean;
  is_persistent?: boolean;
};

// Kind of expression on a TRANSFORMFIELD:
//   "Passthrough"    — IDMC auto-populated EXPRESSION="<port_name>" — no real logic
//   "Local Variable" — intra-transformation v_X port that holds reusable expression
//   "Computed"       — real transformation logic (arithmetic, IIF, function calls, etc.)
export type TransformationExpressionKind = "Passthrough" | "Local Variable" | "Computed";

export type TransformationJson = {
  name: string;
  type: string;
  expressions: {
    output_field: string;
    formula: string;
    kind: TransformationExpressionKind;
  }[];
};

export type LoadType =
  | "INSERT"
  | "UPDATE"
  | "DELETE"
  | "REJECT"
  | "DATA DRIVEN"
  | "UNSPECIFIED";

export type ExpressionType = "Direct" | "Derived" | "Lookup" | "Conditional";

// FieldMappingJson carries every column the FIELD_MAPPING sheet renders, plus
// derived fields used by downstream consumers (lineage, load_type, etc.).
// Null fields are rendered as the literal "NULL" in the XLSX per spec.
export type FieldMappingJson = {
  // Source side. `source_database` carries the connection NAME (not type)
  // from the session's CONNECTIONREFERENCE elements — what reviewers need
  // for impact analysis ("which connection does this read from?").
  source_table: string | null;
  source_database: string | null;
  source_column: string | null;
  source_datatype: string | null;
  source_precision: string | null;
  source_scale: string | null;
  source_nullable: string | null;
  source_key: string | null;

  // Expression / transformation logic
  business_logic_expression: string | null; // formerly final_expression
  expression_type: ExpressionType | null;   // Direct / Derived / Lookup / Conditional
  expression_chain: string | null;
  transformation_path: string | null;

  // Transformations involved
  lookups_used: string | null;
  joiners_used: string | null;
  routers_used: string | null;
  aggregators_used: string | null;

  // Source-qualifier context
  source_qualifier: string | null;
  sq_sql_query: string | null;

  // Data quality
  cdq_dimension: string | null;
  cdq_rule: string | null;

  // Target side
  target_table: string;
  target_database: string | null;
  target_column: string;
  target_datatype: string;
  target_precision: string | null;
  target_scale: string | null;
  target_nullable: string | null;
  target_key: string | null;

  // Context
  parameter_file: string | null;
  notes: string | null;

  // Derived fields. `load_type` is rendered as its own FIELD_MAPPING column;
  // the rest are kept for downstream consumers (JSON download, programmatic
  // access) and are not surfaced as separate columns in the sheet.
  lookup_used: string | null;
  datatype_conversion: string;
  lineage: string;
  load_type: LoadType;
  router_condition: string | null;
  default_logic: string | null;

  // ── Phase B additions ────────────────────────────────────────────────────
  // Used = "YES" when this row reflects a real mapping (target column wired
  // from a source); "NO" when the row is a synthetic placeholder for an
  // unconnected SOURCEFIELD (B.1).
  is_used: "YES" | "NO";

  // Lookup details surfaced per row (B.2). Only populated when the row's
  // source is a lookup.
  lookup_type: "Connected" | "Unconnected" | null;
  lookup_join_condition: string | null;
  lookup_return_column: string | null;
  lookup_keys_source_to_lookup: string | null;

  // Joiner + Aggregator details per row (B.3). Read from TX TABLEATTRIBUTEs
  // when joiners_used / aggregators_used is non-empty for the row.
  joiner_join_type: string | null;
  joiner_join_condition: string | null;
  aggregator_group_by: string | null;

  // ── Phase C additions ────────────────────────────────────────────────────
  // Raw XML expression preserved alongside the inlined business_logic_expression
  // (C.1). Same content the IDMC developer wrote in <TRANSFORMFIELD EXPRESSION="…">.
  raw_expression_xml: string | null;

  // Logical-step view of the transformation_path (C.2): labels each instance
  // with its transformation kind (Source Qualifier / Lookup / Expression /
  // Router / Target / etc.) so reviewers can parse the chain at a glance.
  logical_steps: string | null;

  // Error-handling logic (C.4) — ERROR('msg') calls, NVL-as-error patterns,
  // IIF(cond, ERROR('…'), …) etc.
  error_logic: string | null;
};

// Row shape shared by Overall Details and Session Details sheets. Both
// render as a flat (Section, Key, Value) table grouped visually by section.
export type KeyValueRow = {
  section: string;
  key: string;
  value: string;
};

// Source SQL — one row per transformation in the mapping that carries ANY
// SQL-bearing attribute. Covers Source Qualifiers (Sql Query / Sql Override /
// User Defined Join / Source Filter / Pre SQL / Post SQL), Lookups (Lookup
// Sql Override / Lookup Source Filter), and any other transformation that
// happens to expose SQL via its TABLEATTRIBUTEs.
//
// Per `sql_entries`: each detected SQL-like attribute on the transformation,
// preserving its label so reviewers can see which IDMC slot the SQL came
// from. `sql_text` is a combined `<Label>: <Value> | …` rendering for the
// flat XLSX cell and CSV; `sql_entries` exposes the structured form for the
// dashboard / programmatic consumers.
export type SqlEntry = {
  label: string; // e.g. "Sql Override", "Lookup Sql Override", "Pre SQL"
  value: string; // full SQL text — may be empty when only the label was present
};

export type SourceSqlJson = {
  transformation: string; // INSTANCE name
  transformation_type: string; // "Source Qualifier" / "Lookup Procedure" / etc.
  source_definition: string; // upstream SOURCE name (for SQs); blank for lookups
  connection: string;
  connection_type: string;
  sql_types: string; // comma-separated labels that carry a non-empty value
  source_tables: string; // FROM-clause tables across all SQL entries
  sql_text: string; // combined "<Label>: <Value> | …" for flat-cell rendering
  sql_entries: SqlEntry[]; // structured per-attribute view
  has_sql: boolean; // true if any sql_entries[i].value is non-empty

  // Back-compat aliases kept so the dashboard's existing render code keeps
  // working; mirror their counterparts above.
  source_qualifier: string; // === transformation
  has_sql_override: boolean; // === has_sql
  sql_query: string; // === sql_text (or a diagnostic when has_sql=false)
};

export type MappingJson = {
  schema_version: SchemaVersion;
  file_name: string;
  session_name: string;
  mapping_name: string;
  sources: SourceJson[];
  targets: TargetJson[];
  lookups: LookupJson[];
  transformations: TransformationJson[];
  field_mappings: FieldMappingJson[];
  // Summary / metadata sheets — added v1 (additive, no schema bump needed).
  overall_details: KeyValueRow[];
  source_sql: SourceSqlJson[];
  connections: ConnectionRowJson[];
  session_details: KeyValueRow[];
};

// One row per CONNECTIONREFERENCE in the session — surfaces the binding
// between an instance (SQ / Target / Lookup) and its connection. Renders
// as the "Connections" sheet in the Clean XLSX export.
export type ConnectionRowJson = {
  instance: string;
  instance_type: string;
  connection: string;
  connection_type: string;
  subtype: string;
  variable: string;
};

// ── Single source of truth for "is this row resolved or not?" ──────────────
// Used by the Mapping Inspector, the Overall Details counter, every export,
// and any future consumer. Keep this matched to the labels classifyComputedSource
// + classifyBlankSource can emit:
//
//   RESOLVED   → real table name, or one of (literal)/(system)/(aggregated)/(lookup …)
//   UNRESOLVED → blank / (computed) / (not wired) / (unresolved at …)
//
// The classified labels (literal/system/aggregated/lookup) MEAN the source
// was identified — just not as a single physical column. Counting them as
// "unresolved" would deflate resolution stats artificially.
export function isFieldMappingUnresolved(row: FieldMappingJson): boolean {
  const t = row.source_table || "";
  return !t || t === "(computed)" || t === "(not wired)" || t.startsWith("(unresolved");
}

export function isFieldMappingResolved(row: FieldMappingJson): boolean {
  return !isFieldMappingUnresolved(row);
}
