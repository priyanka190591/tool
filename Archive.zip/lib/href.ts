import { useEffect, useState } from "react";

type PagePath = "/" | "/search" | "/diff";

const IS_PROD = process.env.NODE_ENV === "production";

export function pageHref(
  path: PagePath,
  hashParams?: Record<string, string | undefined>,
): string {
  const base = IS_PROD
    ? path === "/" ? "/index.html" : `${path}/index.html`
    : path;
  if (!hashParams) return base;
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(hashParams)) {
    if (v !== undefined && v !== "") sp.set(k, v);
  }
  const qs = sp.toString();
  return qs ? `${base}#${qs}` : base;
}

const listeners = new Set<() => void>();

function notify() {
  for (const l of listeners) l();
}

function parseHash(): URLSearchParams {
  if (typeof window === "undefined") return new URLSearchParams();
  const raw = window.location.hash.startsWith("#")
    ? window.location.hash.slice(1)
    : window.location.hash;
  return new URLSearchParams(raw);
}

export function useHashParams(): URLSearchParams {
  const [params, setParams] = useState<URLSearchParams>(() => new URLSearchParams());
  useEffect(() => {
    setParams(parseHash());
    const listener = () => setParams(parseHash());
    listeners.add(listener);
    window.addEventListener("hashchange", listener);
    window.addEventListener("popstate", listener);
    return () => {
      listeners.delete(listener);
      window.removeEventListener("hashchange", listener);
      window.removeEventListener("popstate", listener);
    };
  }, []);
  return params;
}

export function setHashParams(
  updater: (sp: URLSearchParams) => void,
  options: { replace?: boolean } = {},
): void {
  if (typeof window === "undefined") return;
  const next = parseHash();
  updater(next);
  const newHash = next.toString();
  const url = `${window.location.pathname}${window.location.search}${newHash ? "#" + newHash : ""}`;
  if (options.replace) {
    window.history.replaceState({}, "", url);
  } else {
    window.history.pushState({}, "", url);
  }
  notify();
}

export function navigateTo(href: string): void {
  if (typeof window === "undefined") return;
  window.location.assign(href);
}
