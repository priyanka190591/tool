import type { FileEntry } from "./sessions";

export type FolderNode = {
  // Leaf folder name (e.g. "Q1"). "" for the synthetic root.
  name: string;
  // Path relative to public/sessions/, without trailing slash. "" for root.
  path: string;
  // Files that live directly under this folder, sorted alpha by fileName.
  files: FileEntry[];
  // Subfolders, sorted alpha by name.
  folders: FolderNode[];
  // Rolled-up counts including everything under this node, recursive.
  totalFiles: number;
  totalSessions: number;
};

function makeNode(name: string, path: string): FolderNode {
  return { name, path, files: [], folders: [], totalFiles: 0, totalSessions: 0 };
}

function validatePath(path: string): void {
  if (path.startsWith("/")) throw new Error(`Path must not start with '/': ${path}`);
  if (path.includes("//")) throw new Error(`Path has empty segments: ${path}`);
  const segments = path.split("/");
  if (segments.some((s) => s === "" || s === "." || s === "..")) {
    throw new Error(`Path has illegal segment: ${path}`);
  }
}

export function buildFolderTree(files: FileEntry[]): FolderNode {
  const root = makeNode("", "");
  for (const file of files) {
    validatePath(file.path);
    const segments = file.path.split("/");
    const folderSegments = segments.slice(0, -1);
    let cursor = root;
    let cursorPath = "";
    for (const seg of folderSegments) {
      cursorPath = cursorPath ? `${cursorPath}/${seg}` : seg;
      let child = cursor.folders.find((c) => c.name === seg);
      if (!child) {
        child = makeNode(seg, cursorPath);
        cursor.folders.push(child);
      }
      cursor = child;
    }
    cursor.files.push(file);
  }
  sortNode(root);
  rollUp(root);
  return root;
}

function sortNode(node: FolderNode): void {
  node.folders.sort((a, b) => a.name.localeCompare(b.name));
  node.files.sort((a, b) => a.fileName.localeCompare(b.fileName));
  for (const child of node.folders) sortNode(child);
}

function rollUp(node: FolderNode): void {
  let files = node.files.length;
  let sessions = node.files.reduce((n, f) => n + f.sessions.length, 0);
  for (const child of node.folders) {
    rollUp(child);
    files += child.totalFiles;
    sessions += child.totalSessions;
  }
  node.totalFiles = files;
  node.totalSessions = sessions;
}

/**
 * Flatten a folder tree (or subtree) back into a depth-first list of
 * `FileEntry`s. Used by `downloadFolderXlsx` to walk the selected branch.
 */
export function filesUnder(node: FolderNode): FileEntry[] {
  const out: FileEntry[] = [];
  for (const f of node.files) out.push(f);
  for (const sub of node.folders) out.push(...filesUnder(sub));
  return out;
}
