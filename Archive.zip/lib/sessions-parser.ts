import { XMLParser } from "fast-xml-parser";
import type {
  ConfigDef,
  ConnectionRef,
  MappingDef,
  MappletDef,
  ParsedSession,
  SessionExtension,
  SourceDef,
  TargetDef,
  TransformationDef,
  TransformationInstance,
  WorkflowDef,
  KV,
} from "./sessions-types";

const ARRAY_TAGS = new Set([
  "ATTRIBUTE",
  "TABLEATTRIBUTE",
  "METADATAEXTENSION",
  "TRANSFORMFIELD",
  "SOURCEFIELD",
  "TARGETFIELD",
  "TRANSFORMATION",
  "INSTANCE",
  "CONNECTOR",
  "SOURCE",
  "TARGET",
  "MAPPING",
  "MAPPLET",
  "SESSION",
  "SESSTRANSFORMATIONINST",
  "SESSIONEXTENSION",
  "CONNECTIONREFERENCE",
  "PARAMETER",
  "WORKFLOW",
  "TASKINSTANCE",
  "WORKFLOWLINK",
  "CONFIG",
  "FOLDER",
  "GROUP",
]);

const PARSER = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  parseAttributeValue: false,
  trimValues: true,
  allowBooleanAttributes: true,
  processEntities: true,
  isArray: (name) => ARRAY_TAGS.has(name),
});

export function parseSessionsFromXml(fileName: string, xml: string): ParsedSession[] {
  const tree = PARSER.parse(xml);
  const folder = findFirst(tree, "FOLDER");
  const repository = findFirst(tree, "REPOSITORY");
  const sessions = findAll(tree, "SESSION");
  const mappings = findAll(tree, "MAPPING");
  const workflows = findAll(tree, "WORKFLOW").map(parseWorkflow);
  const configs = findAll(tree, "CONFIG").map((c) => ({
    name: s(c["@_NAME"]) ?? "",
    description: s(c["@_DESCRIPTION"]),
    attributes: attrs(c),
  }));
  const sharedMeta = {
    folder: folder
      ? {
          name: s(folder["@_NAME"]),
          group: s(folder["@_GROUP"]),
          owner: s(folder["@_OWNER"]),
        }
      : undefined,
    repository: repository
      ? {
          name: s(repository["@_NAME"]),
          version: s(repository["@_VERSION"]),
          databaseType: s(repository["@_DATABASETYPE"]),
        }
      : undefined,
    workflows,
    configs,
    rawXml: xml,
  };

  if (sessions.length === 0) {
    return [buildParsed(fileName, 0, null, mappings, tree, sharedMeta)];
  }
  return sessions.map((sess, idx) =>
    buildParsed(fileName, idx, sess, mappings, tree, sharedMeta),
  );
}

function buildParsed(
  fileName: string,
  sessionIndex: number,
  session: any | null,
  mappings: any[],
  root: any,
  shared: {
    folder?: ParsedSession["folder"];
    repository?: ParsedSession["repository"];
    workflows: WorkflowDef[];
    configs: ConfigDef[];
    rawXml: string;
  },
): ParsedSession {
  const out: ParsedSession = {
    fileName,
    sessionIndex,
    hasSession: !!session,
    name: s(session?.["@_NAME"]) ?? fileName,
    description: s(session?.["@_DESCRIPTION"]),
    mappingName: s(session?.["@_MAPPINGNAME"]),
    reusable: s(session?.["@_REUSABLE"]),
    sortOrder: s(session?.["@_SORTORDER"]),
    isValid: s(session?.["@_ISVALID"]),
    versionNumber: s(session?.["@_VERSIONNUMBER"]),
    configReference: s(session?.["@_SESSIONCONFIGURATIONNAME"]),
    attributes: session ? attrs(session) : [],
    connectionRefs: collectConnectionRefs(session),
    transformationInstances: toArray<any>(session?.SESSTRANSFORMATIONINST).map(parseSessTxInst),
    extensions: toArray<any>(session?.SESSIONEXTENSION).map(parseExtension),
    parameters: toArray<any>(session?.PARAMETER).map((p) => ({
      name: String(p?.["@_NAME"] ?? ""),
      value: String(p?.["@_VALUE"] ?? ""),
    })),
    mapping: undefined,
    workflows: shared.workflows,
    configs: shared.configs,
    folder: shared.folder,
    repository: shared.repository,
    rawXml: shared.rawXml,
  };
  const matchedMapping =
    (out.mappingName && mappings.find((m) => s(m["@_NAME"]) === out.mappingName)) || mappings[0];
  if (matchedMapping) out.mapping = parseMapping(matchedMapping, root);
  return out;
}

function parseConnRef(c: any, fallbackInstanceName?: string, fallbackInstanceType?: string): ConnectionRef {
  // CNXREFNAME is the role label inside the parent SESSIONEXTENSION (e.g.
  // "DB Connection", "Connection"). CONNECTIONNAME is the actual connection
  // (e.g. "INFO_TARGET"). Real IDMC XMLs nearly always carry the connection
  // identifier in CONNECTIONNAME; CNXREFNAME is only useful as a fallback
  // when CONNECTIONNAME is empty (lookup transformations sometimes do this).
  const connectionName =
    s(c?.["@_CONNECTIONNAME"]) ||
    s(c?.["@_CNXREFNAME"]) ||
    "";
  // Instance name: prefer attributes on the CONNECTIONREFERENCE itself (some
  // XMLs have them), then fall back to the parent SESSIONEXTENSION's
  // SINSTANCENAME / NAME the caller threads through.
  const instanceName =
    s(c?.["@_SESSIONEXTENSIONNAME"]) ||
    s(c?.["@_INSTANCENAME"]) ||
    fallbackInstanceName ||
    "";
  const instanceType =
    s(c?.["@_REFOBJECTTYPE"]) ||
    s(c?.["@_INSTANCETYPE"]) ||
    fallbackInstanceType ||
    "";
  return {
    instanceType,
    instanceName,
    connectionName,
    connectionType: String(c?.["@_CONNECTIONTYPE"] ?? ""),
    connectionSubtype: s(c?.["@_CONNECTIONSUBTYPE"]),
    variable: s(c?.["@_VARIABLE"]),
  };
}

// Real IDMC XMLs put CONNECTIONREFERENCE elements INSIDE SESSIONEXTENSION,
// where the parent carries SINSTANCENAME (the instance the connection
// applies to). Collect from both direct-child position (older shapes) AND
// nested-in-SESSIONEXTENSION position, propagating the parent's
// SINSTANCENAME so connectionFor(instance) can match later.
function collectConnectionRefs(session: any): ConnectionRef[] {
  const out: ConnectionRef[] = [];
  // 1. Direct children of <SESSION> (legacy / minimal exports).
  for (const c of toArray<any>(session?.CONNECTIONREFERENCE)) {
    out.push(parseConnRef(c));
  }
  // 2. Nested inside each <SESSIONEXTENSION>. The extension's SINSTANCENAME
  //    is the instance the connection ref applies to.
  for (const ext of toArray<any>(session?.SESSIONEXTENSION)) {
    const sinst = s(ext?.["@_SINSTANCENAME"]);
    const ttype = s(ext?.["@_TRANSFORMATIONTYPE"]);
    for (const c of toArray<any>(ext?.CONNECTIONREFERENCE)) {
      out.push(parseConnRef(c, sinst, ttype));
    }
  }
  // De-dupe by (instanceName, connectionName) — some XMLs declare the same
  // ref in both positions.
  const seen = new Set<string>();
  return out.filter((r) => {
    const k = `${r.instanceName}::${r.connectionName}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function parseSessTxInst(t: any): TransformationInstance {
  return {
    name: String(t?.["@_SINSTANCENAME"] ?? ""),
    type: String(t?.["@_TRANSFORMATIONTYPE"] ?? ""),
    description: s(t?.["@_DESCRIPTION"]),
    attributes: attrs(t),
  };
}

function parseExtension(e: any): SessionExtension {
  return {
    name: String(e?.["@_SESSIONEXTENSIONNAME"] ?? ""),
    type: String(e?.["@_SESSIONEXTENSIONTYPE"] ?? ""),
    subtype: s(e?.["@_SUBTYPE"]),
    attributes: attrs(e),
  };
}

function parseMapping(m: any, root: any): MappingDef {
  // Transformations and connectors are mapping-scoped — multi-mapping XMLs
  // (like multi-session COMPTIME exports) have one set per MAPPING block.
  // Sources, targets, mapplets are folder-scoped — defined once and referenced
  // across mappings via INSTANCE entries.
  const fromMapping = findAll(m, "TRANSFORMATION").map(parseTransformation);
  const fromRoot = findAll(root, "TRANSFORMATION").map(parseTransformation);
  const instanceNames = new Set(
    toArray<any>(m.INSTANCE).map((i) => String(i?.["@_TRANSFORMATION_NAME"] ?? i?.["@_NAME"] ?? "")),
  );
  // Prefer mapping-scoped; fall back to folder-scoped only for instances actually
  // referenced by this mapping (catches reusable transformations).
  const usedFromRoot = fromRoot.filter(
    (t) => instanceNames.has(t.name) && !fromMapping.some((x) => x.name === t.name),
  );
  const allTransformations = [...fromMapping, ...usedFromRoot];
  const allSources = findAll(root, "SOURCE").map(parseSource);
  const allTargets = findAll(root, "TARGET").map(parseTarget);
  const mapplets = findAll(root, "MAPPLET").map(parseMapplet);

  return {
    name: s(m["@_NAME"]) ?? "",
    description: s(m["@_DESCRIPTION"]),
    isValid: s(m["@_ISVALID"]),
    versionNumber: s(m["@_VERSIONNUMBER"]),
    instances: toArray<any>(m.INSTANCE).map((i) => ({
      name: String(i?.["@_NAME"] ?? ""),
      type: String(i?.["@_TYPE"] ?? ""),
      transformationName: s(i?.["@_TRANSFORMATION_NAME"]),
      transformationType: s(i?.["@_TRANSFORMATION_TYPE"]),
      description: s(i?.["@_DESCRIPTION"]),
      reusable: s(i?.["@_REUSABLE"]),
    })),
    connectors: toArray<any>(m.CONNECTOR).map((c) => ({
      fromInstance: String(c?.["@_FROMINSTANCE"] ?? ""),
      fromInstanceType: String(c?.["@_FROMINSTANCETYPE"] ?? ""),
      fromField: String(c?.["@_FROMFIELD"] ?? ""),
      toInstance: String(c?.["@_TOINSTANCE"] ?? ""),
      toInstanceType: String(c?.["@_TOINSTANCETYPE"] ?? ""),
      toField: String(c?.["@_TOFIELD"] ?? ""),
    })),
    transformations: allTransformations,
    sources: allSources,
    targets: allTargets,
    mapplets,
  };
}

function parseTransformation(t: any): TransformationDef {
  const groups = toArray<any>(t.GROUP).map((g) => ({
    name: String(g?.["@_NAME"] ?? ""),
    condition: s(g?.["@_EXPRESSION"]) ?? s(g?.["@_CONDITION"]),
    order: s(g?.["@_ORDER"]),
  }));
  return {
    name: s(t["@_NAME"]) ?? "",
    type: s(t["@_TYPE"]) ?? "",
    description: s(t["@_DESCRIPTION"]),
    reusable: s(t["@_REUSABLE"]),
    objectVersion: s(t["@_OBJECTVERSION"]),
    versionNumber: s(t["@_VERSIONNUMBER"]),
    fields: toArray<any>(t.TRANSFORMFIELD).map((f) => ({
      name: String(f?.["@_NAME"] ?? ""),
      portType: String(f?.["@_PORTTYPE"] ?? ""),
      datatype: String(f?.["@_DATATYPE"] ?? ""),
      precision: s(f?.["@_PRECISION"]),
      scale: s(f?.["@_SCALE"]),
      defaultValue: s(f?.["@_DEFAULTVALUE"]),
      expression: s(f?.["@_EXPRESSION"]),
      expressionType: s(f?.["@_EXPRESSIONTYPE"]),
      pictureText: s(f?.["@_PICTURETEXT"]),
      group: s(f?.["@_GROUP"]),
    })),
    tableAttributes: tableAttrs(t),
    metadataExtensions: metaExts(t),
    groups,
  };
}

function parseMapplet(m: any): MappletDef {
  return {
    name: s(m["@_NAME"]) ?? "",
    description: s(m["@_DESCRIPTION"]),
    isValid: s(m["@_ISVALID"]),
    versionNumber: s(m["@_VERSIONNUMBER"]),
    instanceCount: toArray<any>(m.INSTANCE).length,
    transformationCount: toArray<any>(m.TRANSFORMATION).length,
  };
}

function parseSource(src: any): SourceDef {
  return {
    name: s(src["@_NAME"]) ?? "",
    databaseType: s(src["@_DATABASETYPE"]),
    databaseName: s(src["@_DBDNAME"]),
    ownerName: s(src["@_OWNERNAME"]),
    description: s(src["@_DESCRIPTION"]),
    // BUSINESSNAME, REFERENCEDTABLE, REFERENCEDDBD are IDMC's logical-source
    // pointers used when SOURCE itself is a wrapper. The lineage resolver
    // prefers these over the raw SOURCE name.
    businessName: s(src["@_BUSINESSNAME"]),
    referencedTable: s(src["@_REFERENCEDTABLE"]),
    referencedDatabase: s(src["@_REFERENCEDDBD"]) ?? s(src["@_REFERENCEDDBNAME"]),
    fields: toArray<any>(src.SOURCEFIELD).map((f) => ({
      name: String(f?.["@_NAME"] ?? ""),
      datatype: String(f?.["@_DATATYPE"] ?? ""),
      precision: s(f?.["@_PRECISION"]),
      scale: s(f?.["@_SCALE"]),
      nullable: s(f?.["@_NULLABLE"]),
      keyType: s(f?.["@_KEYTYPE"]),
      businessName: s(f?.["@_BUSINESSNAME"]),
      description: s(f?.["@_DESCRIPTION"]),
      fieldNumber: s(f?.["@_FIELDNUMBER"]),
    })),
  };
}

function parseTarget(tgt: any): TargetDef {
  return {
    name: s(tgt["@_NAME"]) ?? "",
    databaseType: s(tgt["@_DATABASETYPE"]),
    description: s(tgt["@_DESCRIPTION"]),
    constraint: s(tgt["@_CONSTRAINT"]),
    fields: toArray<any>(tgt.TARGETFIELD).map((f) => ({
      name: String(f?.["@_NAME"] ?? ""),
      datatype: String(f?.["@_DATATYPE"] ?? ""),
      precision: s(f?.["@_PRECISION"]),
      scale: s(f?.["@_SCALE"]),
      nullable: s(f?.["@_NULLABLE"]),
      keyType: s(f?.["@_KEYTYPE"]),
      businessName: s(f?.["@_BUSINESSNAME"]),
      description: s(f?.["@_DESCRIPTION"]),
      fieldNumber: s(f?.["@_FIELDNUMBER"]),
    })),
  };
}

function parseWorkflow(w: any): WorkflowDef {
  return {
    name: s(w["@_NAME"]) ?? "",
    description: s(w["@_DESCRIPTION"]),
    isValid: s(w["@_ISVALID"]),
    serverName: s(w["@_SERVERNAME"]),
    isEnabled: s(w["@_ISENABLED"]),
    schedulerName: s(w["@_SCHEDULERNAME"]),
    tasks: toArray<any>(w.TASKINSTANCE).map((t) => ({
      name: String(t?.["@_NAME"] ?? ""),
      taskName: s(t?.["@_TASKNAME"]),
      taskType: String(t?.["@_TASKTYPE"] ?? ""),
      reusable: s(t?.["@_REUSABLE"]),
      description: s(t?.["@_DESCRIPTION"]),
    })),
    links: toArray<any>(w.WORKFLOWLINK).map((l) => ({
      fromTask: String(l?.["@_FROMTASK"] ?? ""),
      toTask: String(l?.["@_TOTASK"] ?? ""),
      condition: s(l?.["@_CONDITION"]),
    })),
    attributes: attrs(w),
  };
}

function findFirst(node: any, tag: string): any | null {
  if (!node || typeof node !== "object") return null;
  if (node[tag]) return Array.isArray(node[tag]) ? node[tag][0] : node[tag];
  for (const k of Object.keys(node)) {
    const v = (node as Record<string, unknown>)[k];
    if (Array.isArray(v)) {
      for (const item of v) {
        const hit = findFirst(item, tag);
        if (hit) return hit;
      }
    } else if (typeof v === "object" && v !== null) {
      const hit = findFirst(v, tag);
      if (hit) return hit;
    }
  }
  return null;
}

function findAll(node: any, tag: string, acc: any[] = []): any[] {
  if (!node || typeof node !== "object") return acc;
  if (node[tag]) {
    if (Array.isArray(node[tag])) acc.push(...node[tag]);
    else acc.push(node[tag]);
  }
  for (const k of Object.keys(node)) {
    if (k === tag) continue;
    const v = (node as Record<string, unknown>)[k];
    if (Array.isArray(v)) {
      for (const item of v) findAll(item, tag, acc);
    } else if (typeof v === "object" && v !== null) {
      findAll(v, tag, acc);
    }
  }
  return acc;
}

function toArray<T>(value: T | T[] | undefined): T[] {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value : [value];
}

function attrs(node: any, key = "ATTRIBUTE"): KV[] {
  return toArray<any>(node?.[key]).map((a) => ({
    name: clean(String(a?.["@_NAME"] ?? "")),
    value: clean(String(a?.["@_VALUE"] ?? "")),
  }));
}

function tableAttrs(node: any): KV[] {
  return toArray<any>(node?.TABLEATTRIBUTE).map((a) => ({
    name: clean(String(a?.["@_NAME"] ?? "")),
    value: clean(String(a?.["@_VALUE"] ?? "")),
  }));
}

function metaExts(node: any): KV[] {
  return toArray<any>(node?.METADATAEXTENSION).map((a) => ({
    name: clean(`${a?.["@_DOMAINNAME"] ?? ""}.${a?.["@_NAME"] ?? ""}`.replace(/^\./, "")),
    value: clean(String(a?.["@_VALUE"] ?? "")),
  }));
}

function s(v: unknown): string | undefined {
  if (v === undefined || v === null) return undefined;
  const str = clean(String(v));
  return str.length === 0 ? undefined : str;
}

// IDMC XMLs frequently contain leftover numeric character references such as
// &#xD; / &#xA; / &#9; (CR / LF / TAB) inside attribute values, especially in
// expression text and SQL queries. fast-xml-parser doesn't expand numeric
// entities, so we do it here. Also trims surrounding whitespace.
function clean(str: string): string {
  if (!str) return str;
  return str
    .replace(/&#x([0-9A-Fa-f]+);/g, (_, hex) => safeCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => safeCodePoint(parseInt(dec, 10)))
    .replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, "")
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+$/gm, "")
    .replace(/^[ \t\n]+|[ \t\n]+$/g, "");
}

function safeCodePoint(code: number): string {
  if (!Number.isFinite(code) || code < 0) return "";
  if (code === 0x9 || code === 0xa || code === 0xd) return String.fromCodePoint(code);
  if (code < 0x20) return "";
  try {
    return String.fromCodePoint(code);
  } catch {
    return "";
  }
}
