import type {
  Connector,
  MappingInstance,
  ParsedSession,
  SourceDef,
  TargetDef,
  TransformationDef,
} from "./sessions";
import { inferCdqDimension, inferCdqRule } from "./cdq";

export type LineageRow = {
  mapping: string;
  targetTable: string;
  targetColumn: string;
  targetDataType: string;
  targetPrecision: string;
  targetScale: string;
  targetNullable: string;
  targetKey: string;
  targetDescription: string;

  sourceTable: string;
  sourceColumn: string;
  sourceDataType: string;
  sourcePrecision: string;
  sourceScale: string;
  sourceNullable: string;
  sourceKey: string;

  expression: string;
  expressionType: string;
  expressionChain: string;
  transformationPath: string;
  lookupsUsed: string;
  joinersUsed: string;
  routersUsed: string;
  aggregatorsUsed: string;
  sourceQualifier: string;
  sourceQualifierSql: string;
  sourceConnection: string;
  sourceConnectionType: string;
  targetConnection: string;
  targetConnectionType: string;
  cdqDimension: string;
  cdqRule: string;
  parameterFile: string;
  notes: string;
  // Walk-trace diagnostics — surfaced so the dashboard can explain WHY a
  // row's source dead-ended without forking the internal Trace type. Optional
  // so older fixtures and downstream consumers stay compatible.
  lastInstance?: string;
  lastField?: string;

  // ── Phase C additions ────────────────────────────────────────────────────
  // Raw XML expression — the unmodified <TRANSFORMFIELD EXPRESSION="…">
  // value before expandLocalVariables / inlineExpression rewrote it. Lets
  // build-mapping-json surface both raw + resolved forms.
  rawExpression?: string;

  // Which call style produced this row's lookup association? "unconnected"
  // when the :LKP.NAME(args) regex handler matched; "connected" (or absent)
  // for the port-CONNECTOR-based walk. Drives the Lookup Type column in B.2.
  lookupCallStyle?: "connected" | "unconnected";

  // Joined "<inst>.<port> DEFAULTVALUE: ERROR('msg')" entries the walk
  // collected. Empty when no port along the path used ERROR-as-default.
  errorHandlingFromXml?: string;
};

type Indices = {
  connectorByTo: Map<string, Connector>;
  txByName: Map<string, TransformationDef>;
  sourcesByName: Map<string, SourceDef>;
  // Same as sourcesByName but keyed by `name.toLowerCase()`. Lets Phase A.1's
  // lookup-table datatype recovery match SOURCE defs whose XML NAME differs
  // in case from the lookup TABLEATTRIBUTE (e.g., lookup table is `dbo.bldg`,
  // SOURCE is registered as `<SOURCE NAME="DBO.BLDG">`).
  sourcesByNameCi: Map<string, SourceDef>;
  // Instance name → MappingInstance (so we can resolve INSTANCE → underlying
  // SOURCE/TRANSFORMATION definition when the instance name differs from the
  // definition name, e.g., `<INSTANCE NAME="ISourceNode154" TRANSFORMATION_NAME="REAL_TABLE">`).
  instancesByName: Map<string, MappingInstance>;
};

type Trace = {
  sourceTable: string;
  sourceColumn: string;
  sourceDataType: string;
  sourcePrecision: string;
  sourceScale: string;
  sourceNullable: string;
  sourceKey: string;
  expression: string;
  expressionType: string;
  expressionAtInstance: string; // which transformation produced trace.expression
  expressionChain: { where: string; expr: string }[];
  path: string[];
  lookupsUsed: string[];
  joinersUsed: string[];
  routersUsed: string[];
  aggregatorsUsed: string[];
  sourceQualifier: string;
  sourceQualifierSql: string;
  cdqDimension: string;
  cdqRule: string;
  notes: string[];
  // Last (instance, field) the walk was looking at when it broke. Used by
  // classifyBlankSource to provide a useful hint for dead-end passthrough chains.
  lastInstance?: string;
  lastField?: string;
  // Phase C additions — mirrored onto LineageRow at row-build time.
  rawExpression?: string;
  lookupCallStyle?: "connected" | "unconnected";
  // Per-port error-handling values surfaced from <TRANSFORMFIELD DEFAULTVALUE>
  // when they contain ERROR() (the IDMC convention for "raise on null/error").
  // Captured as "<instance>.<port>: ERROR('msg')" strings so computeErrorLogic
  // can render them in the dedicated column.
  errorHandling: string[];
};

function blank(): Trace {
  return {
    sourceTable: "",
    sourceColumn: "",
    sourceDataType: "",
    sourcePrecision: "",
    sourceScale: "",
    sourceNullable: "",
    sourceKey: "",
    expression: "",
    expressionType: "",
    expressionChain: [],
    path: [],
    lookupsUsed: [],
    joinersUsed: [],
    routersUsed: [],
    aggregatorsUsed: [],
    sourceQualifier: "",
    sourceQualifierSql: "",
    cdqDimension: "",
    cdqRule: "",
    notes: [],
    expressionAtInstance: "",
    errorHandling: [],
  };
}

function getAttr(attrs: { name: string; value: string }[], name: string): string {
  const hit = attrs.find((a) => a.name.toLowerCase() === name.toLowerCase());
  return hit?.value ?? "";
}

// IDMC exports vary in WHICH TABLEATTRIBUTE holds a SQ's SQL. Try the
// canonical "Sql Query" first, then a handful of vendor-observed variants,
// then fuzzy-match any attribute whose name mentions SQL/Query/Override.
// Returns "" when nothing carries a non-empty value.
function findSqlAttr(attrs: { name: string; value: string }[]): string {
  const candidates = [
    "Sql Query",
    "SQL Query",
    "SqlQuery",
    "Sql Override",
    "SQL Override",
    "SqlOverride",
    "User Defined Join",
  ];
  for (const name of candidates) {
    const hit = attrs.find((a) => a.name.toLowerCase() === name.toLowerCase());
    if (hit?.value && hit.value.trim().length > 0) return hit.value;
  }
  const fuzzy = attrs.find(
    (a) => /sql|query|override/i.test(a.name) && a.value && a.value.trim().length > 0,
  );
  return fuzzy?.value ?? "";
}

function uniquePush(arr: string[], v: string) {
  if (v && !arr.includes(v)) arr.push(v);
}

// When the trace lands at a lookup output port, the port's datatype is often
// IDMC's defaulted `varchar(N)` rather than the underlying physical column's
// type (e.g. `int4`, `numeric`). If a SOURCE definition for the lookup's
// table is present in the same XML, return its SOURCEFIELD datatype instead
// so the FIELD_MAPPING surfaces the true source-of-truth type.
//
// Returns null if either:
//   - the lookup table isn't registered as a SOURCE in this XML, or
//   - the SOURCE doesn't carry a field whose name matches the lookup port.
type SourceDatatypeHit = {
  datatype: string;
  precision: string;
  scale: string;
  nullable: string;
  key: string;
};

function lookupTableSourceDatatype(
  lookupTableName: string,
  fieldName: string,
  idx: Indices,
): SourceDatatypeHit | null {
  if (!lookupTableName || !fieldName) return null;
  const candidates = [
    lookupTableName,
    cleanWrapperPrefix(lookupTableName),
    lookupTableName.split(".").pop() ?? "",
  ].filter(Boolean);
  for (const name of candidates) {
    // Try exact-case first (preserves predictable behavior); fall through to
    // the case-folded index so SOURCE defs like `<SOURCE NAME="DBO.BLDG">`
    // still match a lookup TABLE attribute of `dbo.bldg`.
    const src = idx.sourcesByName.get(name) ?? idx.sourcesByNameCi.get(name.toLowerCase());
    if (!src) continue;
    const sf = src.fields.find((f) => f.name.toLowerCase() === fieldName.toLowerCase());
    if (sf && sf.datatype) {
      return {
        datatype: sf.datatype,
        precision: sf.precision ?? "",
        scale: sf.scale ?? "",
        nullable: sf.nullable ?? "",
        key: sf.keyType ?? "",
      };
    }
  }
  return null;
}

function traceField(
  startInstance: string,
  startField: string,
  idx: Indices,
  depth = 0,
): Trace {
  const trace = blank();
  trace.path.push(startInstance);
  if (depth > 5) {
    trace.notes.push("Max expression-port recursion depth reached");
    return trace;
  }

  // If the trace is starting AT a lookup OUTPUT port (because expression-port
  // walking found a connector from a lookup output), resolve to the lookup table
  // immediately. Output ports of lookups have no incoming connector, so the loop
  // below would otherwise break with no source. INPUT ports of a lookup are
  // different — they have incoming connectors and must be walked normally so
  // their upstream source can be discovered.
  const startTx = idx.txByName.get(startInstance);
  if (depth > 0 && startTx && /lookup/i.test(startTx.type)) {
    const startPort = startTx.fields.find((f) => f.name === startField);
    const startPortType = (startPort?.portType || "").toUpperCase();
    const isLookupOutput = /LOOKUP|OUTPUT|RETURN/.test(startPortType) && !startPortType.includes("INPUT");
    if (isLookupOutput) {
      const lookupTable = getLookupTableName(startTx);
      const cleanedLookupTable = lookupTable ? cleanWrapperPrefix(lookupTable) : lookupTable;
      // If the lookup has no "Lookup table name" attribute we can read, fall
      // back to the (cleaned) lookup INSTANCE name rather than a verbose
      // "(lookup …)" placeholder — that name is what reviewers recognize.
      const lookupFallback = cleanWrapperPrefix(startInstance);
      trace.sourceTable =
        cleanedLookupTable ||
        (isSyntheticNodeName(lookupFallback) ? "" : lookupFallback);
      trace.sourceColumn = startField;
      // Prefer the physical SOURCEFIELD datatype over the lookup output port's
      // (often defaulted to varchar(N) by IDMC). Falls back to the port's
      // datatype when no matching SOURCE def is present in this XML.
      const trueType = lookupTableSourceDatatype(
        cleanedLookupTable || "",
        startField,
        idx,
      );
      if (trueType) {
        trace.sourceDataType = trueType.datatype;
        trace.sourcePrecision = trueType.precision;
        trace.sourceScale = trueType.scale;
        if (trueType.nullable) trace.sourceNullable = trueType.nullable;
        if (trueType.key) trace.sourceKey = trueType.key;
      } else if (startPort) {
        trace.sourceDataType = startPort.datatype;
        trace.sourcePrecision = startPort.precision ?? "";
        trace.sourceScale = startPort.scale ?? "";
        trace.notes.push(
          `Source datatype inherited from lookup output port ${startInstance}.${startField} — true physical type unavailable in this XML.`,
        );
      }
      uniquePush(trace.lookupsUsed, startInstance);
      return trace;
    }
  }

  let currentInstance = startInstance;
  let currentField = startField;
  trace.lastInstance = currentInstance;
  trace.lastField = currentField;
  const seen = new Set<string>();

  for (let hop = 0; hop < 500; hop++) {
    const key = `${currentInstance}::${currentField}`;
    if (seen.has(key)) {
      trace.notes.push(`Cycle detected at ${key}`);
      break;
    }
    seen.add(key);

    let incoming = idx.connectorByTo.get(key);
    if (!incoming) {
      // Try name variants on the current instance before giving up. Covers
      // Direct passthroughs where the output port name (e.g. "riskhashkey")
      // doesn't exactly match an upstream input port (e.g. "RiskHashKey").
      const variant = resolveConnectorPort(currentInstance, currentField, idx);
      if (variant && variant !== currentField) {
        currentField = variant;
        incoming = idx.connectorByTo.get(`${currentInstance}::${variant}`);
      }
    }
    if (!incoming) break;

    const fromInst = incoming.fromInstance;
    const fromField = incoming.fromField;
    const fromInstType = incoming.fromInstanceType;

    trace.path.unshift(fromInst);

    if (/source definition/i.test(fromInstType)) {
      // Resolve the SOURCE definition by direct name first, then by
      // INSTANCE→TRANSFORMATION_NAME indirection. IDMC often uses synthetic
      // instance names (`ISourceNode154`) whose underlying definition has a
      // different real-table name; without this fallback the SOURCEFIELDs
      // (datatype/precision/scale) and BUSINESSNAME/REFERENCEDTABLE
      // metadata get lost.
      let src = idx.sourcesByName.get(fromInst);
      const inst = idx.instancesByName.get(fromInst);
      if (!src && inst?.transformationName) {
        src = idx.sourcesByName.get(inst.transformationName);
      }
      // INSTANCE.TRANSFORMATION_NAME points to the real SOURCE def name even
      // when the INSTANCE NAME itself is synthetic (ISourceNode18). Prefer
      // that as the priority-5/6 fallback so we never leak the synthetic name.
      const fallbackName = inst?.transformationName?.trim() || fromInst;
      const resolved = resolveSourceTable(src, {
        sqSqlOverride: trace.sourceQualifierSql,
        fallbackName,
      });
      trace.sourceTable =
        resolved ||
        (isSyntheticNodeName(fallbackName) ? "" : cleanWrapperPrefix(fallbackName));
      trace.sourceColumn = fromField;
      // Case-insensitive SOURCEFIELD match: IDMC XMLs sometimes use a
      // different case in the SOURCEFIELD's NAME attribute than the
      // CONNECTOR's FROMFIELD references (e.g. `SYSTEMID` vs `systemid`).
      // Strict `===` would miss the field, leaving sourceDataType empty
      // (rendered as "NULL" in the XLSX). Mirrors the case-insensitive
      // pattern Phase A.1 uses for lookup-table field matching.
      const sf =
        src?.fields.find((f) => f.name === fromField) ??
        src?.fields.find((f) => f.name.toLowerCase() === fromField.toLowerCase());
      if (sf) {
        trace.sourceDataType = sf.datatype;
        trace.sourcePrecision = sf.precision ?? "";
        trace.sourceScale = sf.scale ?? "";
        trace.sourceNullable = sf.nullable ?? "";
        trace.sourceKey = sf.keyType ?? "";
      }
      break;
    }

    const txDef = idx.txByName.get(fromInst);
    if (txDef) {
      const port = txDef.fields.find((f) => f.name === fromField);
      // C.4: capture DEFAULTVALUE-as-error before evaluating the expression
      // logic. IDMC ports can carry a DEFAULTVALUE that fires when the main
      // expression returns null/errors — `ERROR('msg')` is the convention
      // for "raise instead of substitute". These values aren't part of the
      // expression chain so a separate capture is the only way to surface
      // them in the FIELD_MAPPING row.
      if (port?.defaultValue && /\bERROR\s*\(/i.test(port.defaultValue)) {
        const entry = `${fromInst}.${fromField} DEFAULTVALUE: ${port.defaultValue}`;
        if (!trace.errorHandling.includes(entry)) trace.errorHandling.push(entry);
      }
      if (port?.expression) {
        // IDMC auto-populates EXPRESSION on every output port. Most are trivial
        // pass-throughs ("EXPRESSION='SSN'" wiring port → input port of same name).
        // Those are not business logic — they're a renaming wire. Skip them so the
        // captured expression reflects the FIRST real transformation upstream.
        const isTrivial = isTrivialPassthrough(port.expression, fromInst, idx);
        if (!isTrivial) {
          trace.expressionChain.push({ where: `${fromInst}.${fromField}`, expr: port.expression });
          if (!trace.expression) {
            trace.expression = port.expression;
            trace.expressionType = port.expressionType ?? "";
            trace.expressionAtInstance = fromInst;
          }
        } else {
          // Trivial passthrough — this output port is internally wired to an
          // input port of the SAME transformation. The data flow is intra-
          // transformation (no CONNECTOR), so we redirect the walk to that input
          // port; the next hop will find its incoming CONNECTOR.
          // Resolve via the variant resolver so an expression like "X" pointed
          // at an upstream port named "in_X" jumps straight to the real port
          // name. Falls back to the normalized text if no variant resolves —
          // the next iteration's dead-end recovery will try variants again.
          //
          // Tag the tx category BEFORE redirecting — otherwise joiner /
          // aggregator detection (which runs further down per-hop) never fires
          // for hops whose output port was a trivial passthrough, leaving the
          // dedicated joiner/aggregator columns empty even though the walk
          // demonstrably passed through one.
          const txTypeForTag = (txDef.type || fromInstType || "").toLowerCase();
          if (txTypeForTag.includes("joiner")) uniquePush(trace.joinersUsed, fromInst);
          if (txTypeForTag.includes("aggregator")) uniquePush(trace.aggregatorsUsed, fromInst);
          if (txTypeForTag.includes("router")) uniquePush(trace.routersUsed, fromInst);
          if (txTypeForTag.includes("lookup")) uniquePush(trace.lookupsUsed, fromInst);
          const normalizedRef = normalizeExpressionToken(port.expression);
          currentInstance = fromInst;
          currentField = resolveConnectorPort(fromInst, normalizedRef, idx) ?? normalizedRef;
          trace.lastInstance = currentInstance;
          trace.lastField = currentField;
          continue;
        }
      }

      const txTypeLower = (txDef.type || fromInstType || "").toLowerCase();

      // Router / Update Strategy / Transaction Control: output ports do NOT
      // have direct incoming CONNECTORs — the wire flows through a sibling
      // INPUT port on the same transformation. The output port name is often
      // the input name with a group suffix (X → X1 for INSERT group, X → X2
      // for UPDATE group, or X → X_INSERT / X → X_UPDATE). If we land on such
      // an output port, redirect to the matching INPUT port so the next hop
      // finds the real upstream connector.
      if (
        port &&
        !port.expression &&
        /OUTPUT/i.test(port.portType || "") &&
        !/INPUT/i.test(port.portType || "") &&
        /router|update strategy|transaction control/i.test(txTypeLower)
      ) {
        const siblingInput = findSiblingInputPort(txDef, fromField);
        if (siblingInput && idx.connectorByTo.has(`${fromInst}::${siblingInput}`)) {
          if (txTypeLower.includes("router")) uniquePush(trace.routersUsed, fromInst);
          currentInstance = fromInst;
          currentField = siblingInput;
          trace.lastInstance = currentInstance;
          trace.lastField = currentField;
          continue;
        }
      }

      if (txTypeLower.includes("source qualifier")) {
        trace.sourceQualifier = fromInst;
        if (!trace.sourceQualifierSql) trace.sourceQualifierSql = findSqlAttr(txDef.tableAttributes);
      }

      if (txTypeLower.includes("aggregator")) {
        uniquePush(trace.aggregatorsUsed, fromInst);
        // Group-by ports pass through; aggregate ports have expressions (already captured).
        const groupBy = getAttr(txDef.tableAttributes, "Group By Ports");
        if (groupBy) trace.notes.push(`Aggregator ${fromInst} groups by: ${groupBy}`);
      }

      if (txTypeLower.includes("joiner")) {
        uniquePush(trace.joinersUsed, fromInst);
        const cond = getAttr(txDef.tableAttributes, "Join Condition");
        const type = getAttr(txDef.tableAttributes, "Join Type");
        if (cond || type) trace.notes.push(`Joiner ${fromInst}${type ? ` [${type}]` : ""}${cond ? ` ON ${cond}` : ""}`);
      }

      if (txTypeLower.includes("router")) {
        uniquePush(trace.routersUsed, fromInst);
        // Each group has a TABLEATTRIBUTE "Group Filter Condition" keyed by group name.
        // Try to surface relevant group condition.
        const groupFromPort = port?.group;
        if (groupFromPort) {
          const g = txDef.groups.find((gr) => gr.name === groupFromPort);
          if (g?.condition) trace.notes.push(`Router ${fromInst}, group ${groupFromPort}: ${g.condition}`);
        } else {
          // Fall back: any group filter condition with that field name reference
          for (const g of txDef.groups) {
            if (g.condition) trace.notes.push(`Router ${fromInst}, group ${g.name}: ${g.condition}`);
          }
        }
      }

      if (txTypeLower.includes("filter")) {
        const cond = getAttr(txDef.tableAttributes, "Filter Condition");
        if (cond) trace.notes.push(`Filter ${fromInst}: ${cond}`);
      }

      if (txTypeLower.includes("update strategy")) {
        const expr = getAttr(txDef.tableAttributes, "Update Strategy Expression");
        if (expr) trace.notes.push(`Update Strategy ${fromInst}: ${expr}`);
      }

      if (txTypeLower.includes("lookup")) {
        uniquePush(trace.lookupsUsed, fromInst);
        // C.4 / B.2: port-CONNECTOR-driven lookup → "Connected" call style.
        // Only set if we haven't already seen an unconnected :LKP call upstream
        // (which would have set "unconnected" first and is the more specific tag).
        if (!trace.lookupCallStyle) trace.lookupCallStyle = "connected";
        const lookupTable = getLookupTableName(txDef);
        const lookupCond = getAttr(txDef.tableAttributes, "Lookup condition");
        const lookupSql = getAttr(txDef.tableAttributes, "Lookup Sql Override");

        // Multi-source aggregation:
        //  (a) lookup table contributes ITS table + the output column being read
        //  (b) each lookup INPUT port with an incoming CONNECTOR contributes
        //      whatever upstream sources its wire resolves to.
        if (!trace.sourceTable) {
          const tableToColumns = new Map<string, Set<string>>();
          const cleanedLookupTable = lookupTable ? cleanWrapperPrefix(lookupTable) : "";
          // Fall back to the lookup INSTANCE name (cleaned) rather than a
          // verbose "(lookup …)" placeholder. Skip purely synthetic names —
          // they leak through to multi-source merges otherwise.
          const cleanedInst = cleanWrapperPrefix(fromInst);
          const lookupTableKey =
            cleanedLookupTable ||
            (isSyntheticNodeName(cleanedInst) ? "" : cleanedInst);
          if (lookupTableKey) tableToColumns.set(lookupTableKey, new Set([fromField]));

          for (const lkpPort of txDef.fields) {
            const pt = (lkpPort.portType || "").toUpperCase();
            if (!pt.includes("INPUT")) continue; // keys + filters only
            if (!idx.connectorByTo.has(`${fromInst}::${lkpPort.name}`)) continue;
            const sub = traceField(fromInst, lkpPort.name, idx, depth + 1);
            mergeSubIntoTableMap(sub, tableToColumns);
            for (const x of sub.lookupsUsed) uniquePush(trace.lookupsUsed, x);
            for (const x of sub.joinersUsed) uniquePush(trace.joinersUsed, x);
            for (const x of sub.routersUsed) uniquePush(trace.routersUsed, x);
            for (const x of sub.aggregatorsUsed) uniquePush(trace.aggregatorsUsed, x);
            if (!trace.sourceQualifier && sub.sourceQualifier) {
              trace.sourceQualifier = sub.sourceQualifier;
              if (!trace.sourceQualifierSql) trace.sourceQualifierSql = sub.sourceQualifierSql;
            }
          }
          assignSourcesFromMap(trace, tableToColumns);
          // Prefer the physical SOURCEFIELD datatype over the lookup port's
          // varchar default. Falls back to the port type when no SOURCE def
          // is registered for the lookup's table — in that case add a note
          // so reviewers don't trust the lookup port's varchar(N) as the
          // true physical datatype.
          const trueType = lookupTableSourceDatatype(cleanedLookupTable, fromField, idx);
          if (trueType) {
            trace.sourceDataType = trueType.datatype;
            trace.sourcePrecision = trueType.precision;
            trace.sourceScale = trueType.scale;
            if (trueType.nullable) trace.sourceNullable = trueType.nullable;
            if (trueType.key) trace.sourceKey = trueType.key;
          } else if (port) {
            trace.sourceDataType = port.datatype;
            trace.sourcePrecision = port.precision ?? "";
            trace.sourceScale = port.scale ?? "";
            trace.notes.push(
              `Source datatype inherited from lookup output port ${fromInst}.${fromField} — true physical type unavailable in this XML.`,
            );
          }
        }
        {
          const note = `Sourced from lookup ${fromInst} on ${lookupTable || "(table)"} via condition: ${lookupCond || "(none)"}${lookupSql ? ` | SQL override: ${lookupSql}` : ""}`;
          trace.notes.push(note);
          break;
        }
      }

      for (const ext of txDef.metadataExtensions) {
        if (/dimension/i.test(ext.name) && !trace.cdqDimension) trace.cdqDimension = ext.value;
        if (/(^|\W)rule(\W|$)/i.test(ext.name) && !trace.cdqRule) trace.cdqRule = ext.value;
      }
    } else {
      // Unknown upstream — could be mapplet output
      trace.notes.push(`Upstream ${fromInst} (${fromInstType}) has no transformation definition in this file.`);
    }

    currentInstance = fromInst;
    currentField = fromField;
    trace.lastInstance = currentInstance;
    trace.lastField = currentField;
  }

  if (!trace.sourceTable) {
    const upstreamTx = idx.txByName.get(currentInstance);
    const upstreamPort = upstreamTx?.fields.find((f) => f.name === currentField);
    const rawExpr = upstreamPort?.expression || trace.expression;
    if (rawExpr) {
      // Expand ONLY LOCAL VARIABLEs (intra-transformation), not connector-based
      // upstream substitutions. That way identifiers in the result still belong
      // to THIS instance and walkExpressionPorts can look up their CONNECTORs.
      // Inlining cross-transformation refs would move identifiers to upstream
      // instances where the connectorByTo lookups silently fail.
      const exprToWalk = expandLocalVariables(rawExpr, currentInstance, idx);
      walkExpressionPorts(currentInstance, exprToWalk, trace, idx, depth);
    }
  }

  return trace;
}

// Expand LOCAL VARIABLE references inside an expression, recursively, but ONLY
// for variables defined on the SAME transformation. INPUT-port references and
// other connector-based identifiers are deliberately left untouched so that
// walkExpressionPorts can resolve them via the connector graph (they belong to
// THIS instance, where lookups work; expanding them would move identifiers to
// upstream instances and break the lookup).
function expandLocalVariables(
  expr: string,
  instance: string,
  idx: Indices,
  depth = 0,
  seen: Set<string> = new Set(),
): string {
  if (depth > 5) return expr;
  const tx = idx.txByName.get(instance);
  if (!tx) return expr;
  return expr.replace(/[A-Za-z_][A-Za-z0-9_]*/g, (id) => {
    if (KNOWN_FUNCTIONS.has(id.toUpperCase())) return id;
    if (id.startsWith("$")) return id;
    const lv = tx.fields.find(
      (f) => f.name === id && /LOCAL VARIABLE/i.test(f.portType || ""),
    );
    if (!lv?.expression) return id;
    const key = `localvar:${instance}::${id}`;
    if (seen.has(key)) return id;
    seen.add(key);
    return `(${expandLocalVariables(lv.expression, instance, idx, depth + 1, seen)})`;
  });
}

// Matches IDMC unconnected-lookup invocation syntax inside an expression:
//   :LKP.LOOKUP_NAME(arg1, arg2, ...)
// Capture group 1 = lookup name, capture group 2 = raw arg list.
const LKP_CALL_RE = /:LKP\.([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)/g;

function walkExpressionPorts(instance: string, expression: string, trace: Trace, idx: Indices, depth: number) {
  const tableToColumns = new Map<string, Set<string>>();
  // Track the first resolved sub-trace so we can propagate its datatype/precision/
  // scale/nullable/key onto the parent. Better than leaving the cells blank when
  // the source resolves cleanly through expression-port walking.
  let firstResolved: Trace | null = null;

  // 1. Detect and consume :LKP.NAME(args) calls first.
  //    Two cases:
  //      (a) NAME is defined in this file → use its lookup table + output port
  //      (b) NAME is NOT defined here (shared/reusable/mapplet-internal lookup)
  //          → STILL record the lookup name + trace its arg sources. The keys
  //            passed to the lookup (e.g. SystemId, LineId) are real input
  //            ports on THIS instance with CONNECTORs we can walk back to the
  //            underlying Source Qualifier / source table. Without this, rows
  //            whose ONLY upstream is an unconnected lookup with an unknown
  //            definition look completely "(computed)" with no source side.
  const consumed: { start: number; end: number }[] = [];
  for (const match of expression.matchAll(LKP_CALL_RE)) {
    const whole = match[0];
    const lookupName = match[1];
    const argsStr = match[2];
    const start = match.index ?? 0;
    consumed.push({ start, end: start + whole.length });

    const lkpDef = idx.txByName.get(lookupName);
    const isKnown = !!lkpDef && /lookup/i.test(lkpDef.type);

    // ALWAYS record the lookup name — even when we can't find its definition,
    // the user should still see "Lookups Used: <name>" and Expression Type
    // should classify as "Lookup".
    uniquePush(trace.lookupsUsed, lookupName);
    // C.4 / B.2: tag this trace as using an unconnected-lookup call so the
    // FIELD_MAPPING row's Lookup Type column reads "Unconnected".
    if (!trace.lookupCallStyle) trace.lookupCallStyle = "unconnected";

    if (isKnown && lkpDef) {
      const rawLookupTable = getLookupTableName(lkpDef);
      const cleanedInst = cleanWrapperPrefix(lookupName);
      const lookupTable =
        (rawLookupTable ? cleanWrapperPrefix(rawLookupTable) : "") ||
        (isSyntheticNodeName(cleanedInst) ? "" : cleanedInst);
      const outPort =
        lkpDef.fields.find((f) => /LOOKUP\/OUTPUT|RETURN/.test((f.portType || "").toUpperCase())) ??
        lkpDef.fields.find((f) => /LOOKUP|OUTPUT/.test((f.portType || "").toUpperCase()));
      if (lookupTable) {
        const cols = tableToColumns.get(lookupTable) ?? new Set<string>();
        if (outPort) cols.add(outPort.name);
        tableToColumns.set(lookupTable, cols);
      }
      if (!firstResolved && outPort) {
        // Only claim firstResolved when we have the TRUE physical datatype
        // from a registered SOURCE def. When the helper returns null, the
        // lookup port's datatype is the IDMC `varchar(N)` default — claiming
        // it as the source datatype masks the real type of any other arg
        // (e.g. SystemId / LineId) that DOES trace back to a SOURCE.
        // Surface the limitation in notes so reviewers know why the lookup
        // didn't contribute to source-side resolution.
        const trueType = lookupTableSourceDatatype(lookupTable, outPort.name, idx);
        if (trueType) {
          firstResolved = {
            ...blank(),
            sourceDataType: trueType.datatype,
            sourcePrecision: trueType.precision,
            sourceScale: trueType.scale,
            sourceNullable: trueType.nullable,
            sourceKey: trueType.key,
          };
        } else {
          trace.notes.push(
            `Lookup ${lookupName}.${outPort.name} output datatype (${outPort.datatype || "?"}) not used as source — true physical type unavailable in this XML.`,
          );
        }
      }
    }

    // ALWAYS process args (both for known and unknown lookups). Each arg that's
    // a bare identifier is an input port at THIS instance; following its
    // CONNECTOR back recovers the upstream Source Qualifier + source table +
    // datatype. Critical for unknown lookups: this is the only path to a real
    // source. Also for known lookups: enriches the source aggregation.
    for (const raw of argsStr.split(",")) {
      const arg = raw.trim();
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(arg)) continue;
      if (KNOWN_FUNCTIONS.has(arg.toUpperCase())) continue;
      const resolved = resolveConnectorPort(instance, arg, idx);
      if (!resolved) continue;
      const sub = traceField(instance, resolved, idx, depth + 1);
      mergeSubIntoTableMap(sub, tableToColumns);
      if (!firstResolved && sub.sourceDataType) firstResolved = sub;
      // Propagate Source Qualifier context from sub-trace so unconnected-lookup
      // rows also pick up their upstream SQ + SQL override.
      if (!trace.sourceQualifier && sub.sourceQualifier) {
        trace.sourceQualifier = sub.sourceQualifier;
        if (!trace.sourceQualifierSql) trace.sourceQualifierSql = sub.sourceQualifierSql;
      }
      if (!trace.sourceTable && !sub.sourceTable && sub.lastInstance) {
        trace.lastInstance = sub.lastInstance;
        trace.lastField = sub.lastField;
      }
    }
  }
  let stripped = expression;
  for (const r of consumed.sort((a, b) => b.start - a.start)) {
    stripped = stripped.slice(0, r.start) + " ".repeat(r.end - r.start) + stripped.slice(r.end);
  }

  // 2. Existing bare-identifier scan over the stripped expression.
  for (const ref of extractIdentifiers(stripped)) {
    if (KNOWN_FUNCTIONS.has(ref.toUpperCase())) continue;
    const resolved = resolveConnectorPort(instance, ref, idx);
    if (!resolved) continue;
    const sub = traceField(instance, resolved, idx, depth + 1);
    mergeSubIntoTableMap(sub, tableToColumns);
    if (!firstResolved && sub.sourceDataType) firstResolved = sub;
    for (const x of sub.lookupsUsed) uniquePush(trace.lookupsUsed, x);
    for (const x of sub.joinersUsed) uniquePush(trace.joinersUsed, x);
    for (const x of sub.routersUsed) uniquePush(trace.routersUsed, x);
    for (const x of sub.aggregatorsUsed) uniquePush(trace.aggregatorsUsed, x);
    if (!trace.sourceQualifier && sub.sourceQualifier) {
      trace.sourceQualifier = sub.sourceQualifier;
      if (!trace.sourceQualifierSql) trace.sourceQualifierSql = sub.sourceQualifierSql;
    }
    // Propagate the deepest dead-end point upward. If the outer trace itself
    // has no resolved source and the sub-trace also dead-ended without one,
    // surface the sub's lastInstance/lastField so reviewers (and the
    // diagnostic UI) can see WHERE upstream the resolution broke — not just
    // the outer walk's stopping point at this expression.
    if (!trace.sourceTable && !sub.sourceTable && sub.lastInstance) {
      trace.lastInstance = sub.lastInstance;
      trace.lastField = sub.lastField;
    }
  }
  assignSourcesFromMap(trace, tableToColumns);
  if (firstResolved && !trace.sourceDataType) {
    trace.sourceDataType = firstResolved.sourceDataType;
    trace.sourcePrecision = firstResolved.sourcePrecision;
    trace.sourceScale = firstResolved.sourceScale;
    trace.sourceNullable = firstResolved.sourceNullable;
    trace.sourceKey = firstResolved.sourceKey;
  }
}

// Merge one sub-trace's resolved source into a tableToColumns aggregation.
// Handles both single-source ("TBL"/"COL") and pre-aggregated ("T1, T2"/"A/B; C")
// shapes by splitting on the established separators.
function mergeSubIntoTableMap(sub: Trace, tableToColumns: Map<string, Set<string>>) {
  const subTable = sub.sourceTable;
  if (!subTable) return;
  if (subTable.startsWith("(") && !subTable.startsWith("(lookup ")) return; // (not wired)/(computed)
  const tables = subTable.split(", ");
  const groups = (sub.sourceColumn || "").split("; ");
  for (let i = 0; i < tables.length; i++) {
    const t = tables[i];
    // Drop synthetic INSTANCE names (ISourceNode18, …). When a sibling
    // sub-trace already carries the real upstream table, including the
    // synthetic one would render as "real_table, ISourceNode18" in the
    // merged cell. When NO sibling has a real name, the row's resolution
    // already failed upstream — surfacing the synthetic name here adds
    // noise rather than information.
    if (isSyntheticNodeName(t)) continue;
    const cols = tableToColumns.get(t) ?? new Set<string>();
    const colGroup = groups[i] ?? "";
    for (const c of colGroup.split("/")) if (c) cols.add(c);
    tableToColumns.set(t, cols);
  }
}

// Apply the agreed separator convention to set trace.sourceTable /
// trace.sourceColumn from a tableToColumns aggregation.
function assignSourcesFromMap(trace: Trace, tableToColumns: Map<string, Set<string>>) {
  if (tableToColumns.size === 0) return;
  const sortedEntries = [...tableToColumns.entries()].sort(([a], [b]) => a.localeCompare(b));
  trace.sourceTable = sortedEntries.map(([t]) => t).join(", ");
  trace.sourceColumn = sortedEntries
    .map(([, cols]) => [...cols].sort().join("/"))
    .filter(Boolean)
    .join("; ");
}

// Trivial passthrough: a single bare identifier whose name matches an input port
// of the SAME transformation (verified via an incoming CONNECTOR). IDMC emits
// these on every output port that just wires through — they are noise, not logic.
// For a Router / Update Strategy / Transaction Control output port (e.g. "X2",
// "X_INSERT", "X_UPD"), find the corresponding INPUT port on the same
// transformation (e.g. "X"). Tries (in order):
//   1. Exact name match with INPUT or INPUT/OUTPUT portType
//   2. Strip a trailing numeric suffix and re-check  ("X2" → "X")
//   3. Strip a known branch suffix (_INSERT/_UPDATE/_INS/_UPD/_DEL/_REJECT/_OUTPUT)
//      and re-check  ("X_INSERT" → "X")
// Returns null if no candidate found.
function findSiblingInputPort(
  txDef: TransformationDef,
  outputName: string,
): string | null {
  const isInput = (p: { portType?: string }) => /INPUT/i.test(p.portType || "");
  // 1. Exact name match (same name in two groups)
  const exact = txDef.fields.find((p) => p.name === outputName && isInput(p));
  if (exact) return exact.name;
  // 2. Strip trailing digits ONE AT A TIME, longest prefix first. IDMC
  //    Routers form group-output names by appending a group index to the
  //    input name; the input name itself may already contain digits. So
  //    output "SqFtArea13" can mean group-3 of input "SqFtArea1", not group-13
  //    of input "SqFtArea". Trying progressively shorter prefixes catches
  //    both shapes ("X2" → "X" and "SqFtArea13" → "SqFtArea1").
  {
    let candidate = outputName;
    while (/\d$/.test(candidate)) {
      candidate = candidate.slice(0, -1);
      if (candidate.length === 0) break;
      const m = txDef.fields.find((p) => p.name === candidate && isInput(p));
      if (m) return m.name;
    }
  }
  // 3. Strip common branch suffix: "X_INSERT" → "X"
  const suffix = outputName.match(
    /^(.+?)_(?:INSERT|UPDATE|DELETE|INS|UPD|DEL|REJECT|OUT|OUTPUT|DEFAULT)$/i,
  );
  if (suffix) {
    const m = txDef.fields.find((p) => p.name === suffix[1] && isInput(p));
    if (m) return m.name;
  }
  // 4. Add common input prefix: "X" → "in_X" / "i_X" / "input_X" / "IN_X"
  //    Real IDMC Routers commonly use this pattern: inputs prefixed with `in_`,
  //    outputs bare per group.
  for (const prefix of ["in_", "IN_", "i_", "input_", "INPUT_"]) {
    const candidate = `${prefix}${outputName}`;
    const m = txDef.fields.find((p) => p.name === candidate && isInput(p));
    if (m) return m.name;
  }
  // 5. Combine: branch-suffix strip + prefix add ("X_INSERT" → "in_X")
  if (suffix) {
    for (const prefix of ["in_", "IN_", "i_", "input_", "INPUT_"]) {
      const candidate = `${prefix}${suffix[1]}`;
      const m = txDef.fields.find((p) => p.name === candidate && isInput(p));
      if (m) return m.name;
    }
  }
  // 6. Case-fold + word-form normalization. Real IDMC mappings sometimes mix
  //    CamelCase / snake_case / lowercase between output and input ports
  //    (e.g. output "risksystemid", input "RiskSystemId"). Collapsing both
  //    sides to lowercase-no-underscores recovers the match.
  const targetNorm = outputName.toLowerCase().replace(/_/g, "");
  for (const p of txDef.fields) {
    if (!isInput(p)) continue;
    if (p.name.toLowerCase().replace(/_/g, "") === targetNorm) return p.name;
  }
  return null;
}

// Resolve a bare identifier (`ref`) appearing in an expression on `instance`
// to the actual input-port name on that instance that has an incoming
// CONNECTOR. Returns the port name on success, or null if no variant matches.
//
// Variants tried, in this order:
//   1. exact:       ref
//   2. prefix-add:  in_ref, IN_ref, i_ref, input_ref, INPUT_ref
//   3. case-fold:   any input port whose lowercase name == ref.toLowerCase()
//   4. word-form:   lowercase-no-underscore equality
//                   (risksystemid ↔ RiskSystemId ↔ risk_system_id ↔ RISK_SYSTEM_ID)
//
// Used by walkExpressionPorts' bare-identifier scan, the :LKP.NAME(args)
// arg loop, and the traceField main-loop dead-end recovery. Without this
// helper, identifiers in expressions like `TO_CHAR(SystemId)` silently fail
// to resolve whenever the actual input port uses a naming convention that
// differs from the text in the expression.
function resolveConnectorPort(
  instance: string,
  ref: string,
  idx: Indices,
): string | null {
  // 1. exact
  if (idx.connectorByTo.has(`${instance}::${ref}`)) return ref;
  // 2. prefix-add
  for (const prefix of ["in_", "IN_", "i_", "input_", "INPUT_"]) {
    const variant = `${prefix}${ref}`;
    if (idx.connectorByTo.has(`${instance}::${variant}`)) return variant;
  }
  // Steps 3 + 4: candidate input-port names. Prefer enumerating the
  // transformation def's input ports; if `instance` isn't a transformation
  // (e.g. it's a TARGET instance — targets don't live in txByName), fall
  // back to scanning connectorByTo keys for any port name on this instance.
  const refLc = ref.toLowerCase();
  const refNorm = refLc.replace(/_/g, "");
  const tx = idx.txByName.get(instance);
  let candidates: string[];
  if (tx) {
    candidates = tx.fields
      .filter((f) => /INPUT/i.test(f.portType || ""))
      .map((f) => f.name);
  } else {
    const prefix = `${instance}::`;
    candidates = [];
    for (const k of idx.connectorByTo.keys()) {
      if (k.startsWith(prefix)) candidates.push(k.slice(prefix.length));
    }
  }
  // 3. case-fold
  for (const name of candidates) {
    if (name.toLowerCase() === refLc && idx.connectorByTo.has(`${instance}::${name}`)) {
      return name;
    }
  }
  // 4. word-form (collapse underscores + case)
  for (const name of candidates) {
    if (
      name.toLowerCase().replace(/_/g, "") === refNorm &&
      idx.connectorByTo.has(`${instance}::${name}`)
    ) {
      return name;
    }
  }
  return null;
}

// Normalize an expression by stripping SQL line/block comments and folding
// non-ASCII whitespace (NBSP, zero-width, etc.) so downstream checks aren't
// fooled by benign noise like "X /* legacy */" or trailing NBSP.
function normalizeExpressionToken(expr: string): string {
  return expr
    .replace(/--[^\n\r]*/g, "")
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/[\s\u00A0\u200B\u2028\u2029\uFEFF]+/g, " ")
    .trim();
}

function isTrivialPassthrough(expr: string, instance: string, idx: Indices): boolean {
  const normalized = normalizeExpressionToken(expr);
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(normalized)) return false;
  // A function name (SYSDATE, SYSTIMESTAMP, etc.) won't have an incoming
  // CONNECTOR to instance.<name>, so the check below filters those out
  // naturally. We deliberately do NOT exclude by KNOWN_FUNCTIONS - that set
  // contains SQL keywords like "IN" and "BETWEEN" which are also valid port
  // names in real IDMC mappings. Use resolveConnectorPort so that renaming
  // wires like `EXPRESSION="X"` whose actual input port is `in_X` (or any
  // case/word-form variant) are still recognized as trivial — otherwise
  // they'd be captured as fake "business logic".
  return resolveConnectorPort(instance, normalized, idx) !== null;
}

// Inline upstream non-trivial expressions in place of port references so the cell
// shows the FULL resolved business logic instead of a chain of intermediate names.
// Depth-limited to keep the result readable and to avoid blow-ups on wide DAGs.
export function inlineExpression(
  expr: string,
  instance: string,
  idx: Indices,
  depth = 0,
  seen: Set<string> = new Set(),
): string {
  if (depth > 3) return expr;

  // Protect :LKP.NAME(args) calls from identifier substitution — they're already
  // meaningful as-is and `NAME` is a transformation name, not a port. Mask, run
  // the substitution, then restore the original LKP calls.
  const placeholders: string[] = [];
  const masked = expr.replace(LKP_CALL_RE, (whole) => {
    placeholders.push(whole);
    return `LKP${placeholders.length - 1}`;
  });

  const currentTx = idx.txByName.get(instance);

  const substituted = masked.replace(/[A-Za-z_][A-Za-z0-9_]*/g, (id) => {
    if (KNOWN_FUNCTIONS.has(id.toUpperCase())) return id;
    if (id.startsWith("$")) return id; // params / built-ins

    // First, try LOCAL VARIABLE inlining within the SAME transformation.
    // LOCAL VARIABLEs don't have inter-transformation CONNECTORs — they're
    // defined inline. Common pattern: an OUTPUT port's expression references
    // v_FOO, which itself has EXPRESSION="something complex".
    const localVar = currentTx?.fields.find(
      (f) => f.name === id && /LOCAL VARIABLE/i.test(f.portType || ""),
    );
    if (localVar?.expression) {
      const key = `localvar:${instance}::${id}`;
      if (seen.has(key)) return id;
      seen.add(key);
      const inner = inlineExpression(localVar.expression, instance, idx, depth + 1, seen);
      return `(${inner})`;
    }

    // Fall through to CONNECTOR-based inlining (cross-transformation).
    const inc = idx.connectorByTo.get(`${instance}::${id}`);
    if (!inc) return id;
    const upTx = idx.txByName.get(inc.fromInstance);
    if (!upTx) return id;
    const upPort = upTx.fields.find((f) => f.name === inc.fromField);
    if (!upPort?.expression) return id;
    if (isTrivialPassthrough(upPort.expression, inc.fromInstance, idx)) {
      // Skip pass-through, continue inlining at the upstream instance with the same id.
      const key = `${inc.fromInstance}::${inc.fromField}::${id}`;
      if (seen.has(key)) return id;
      seen.add(key);
      return inlineExpression(inc.fromField, inc.fromInstance, idx, depth, seen);
    }
    const key = `${inc.fromInstance}::${inc.fromField}`;
    if (seen.has(key)) return id;
    seen.add(key);
    const inner = inlineExpression(upPort.expression, inc.fromInstance, idx, depth + 1, seen);
    return `(${inner})`;
  });

  // Restore the protected LKP calls.
  return substituted.replace(/LKP(\d+)/g, (_, idStr) => placeholders[Number(idStr)] ?? "");
}

function extractIdentifiers(expr: string): string[] {
  const ids = new Set<string>();
  const re = /[A-Za-z_][A-Za-z0-9_]*/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(expr))) ids.add(m[0]);
  return [...ids];
}

// IDMC/PowerCenter built-in functions and reserved tokens to exclude when
// scanning expressions for port references.
const KNOWN_FUNCTIONS = new Set([
  // string
  "UPPER", "LOWER", "INITCAP", "LTRIM", "RTRIM", "TRIM", "LENGTH", "INSTR", "SUBSTR",
  "REPLACECHR", "REPLACESTR", "CHR", "ASCII", "CONCAT", "REVERSE", "LPAD", "RPAD",
  "SOUNDEX", "METAPHONE", "INDEXOF",
  // numeric
  "ABS", "CEIL", "FLOOR", "MOD", "POWER", "SQRT", "EXP", "LN", "LOG", "ROUND", "TRUNC",
  "SIGN", "RAND", "RANDOM",
  // date
  "SYSDATE", "SYSTIMESTAMP", "CURRENT_DATE", "CURRENT_TIMESTAMP",
  "ADD_TO_DATE", "DATE_DIFF", "GET_DATE_PART", "LAST_DAY",
  "MAKE_DATE_TIME", "SET_DATE_PART", "DATE_COMPARE",
  // conversion
  "TO_CHAR", "TO_DATE", "TO_NUMBER", "TO_INTEGER", "TO_DECIMAL", "TO_FLOAT", "TO_BIGINT",
  // tests / null handling
  "IIF", "DECODE", "NVL", "ISNULL", "IS_NULL", "IS_NUMBER", "IS_DATE", "IS_SPACES",
  "GREATEST", "LEAST", "CHOOSE", "ERROR", "ABORT", "MAX", "MIN",
  // aggregators
  "SUM", "AVG", "COUNT", "FIRST", "LAST", "MEDIAN", "STDDEV", "VARIANCE", "PERCENTILE",
  // logical operators / literals
  "AND", "OR", "NOT", "TRUE", "FALSE", "NULL",
  "IN", "BETWEEN", "LIKE",
  // update strategy constants
  "DD_INSERT", "DD_UPDATE", "DD_DELETE", "DD_REJECT",
]);

// When the trace can't pin down a real source table, return a 2-tuple
// describing how to fill the Source Table / Source Column cells:
//   - "(not wired)"  → target column has no incoming connector at all (data bug)
//   - "(computed)"   → anything else; sourceColumn is filled with the literal
//                       default, the system-function call, or the short expression.
//                       The reviewer can read the expression off the row instead
//                       of having to look up the column elsewhere.
function classifyBlankSource(tr: Trace): { table: string; column: string } {
  if (!tr.expression && tr.path.length <= 1) {
    return { table: "(not wired)", column: "" };
  }
  // Prefer the MOST UPSTREAM expression in the chain — that's where the value
  // is actually produced. The first-captured trace.expression is usually a
  // passthrough port near the target that hides the real default.
  const upstream =
    tr.expressionChain.length > 0
      ? tr.expressionChain[tr.expressionChain.length - 1].expr
      : tr.expression;
  const e = (upstream || "").trim();
  if (!e) {
    // Dead-end passthrough chain — the trace walked through trivial-passthrough
    // Expressions and ran out of connectors. Surface the topmost-upstream port
    // and instance so reviewers can jump straight to where the chain broke,
    // rather than showing a useless blank cell.
    const where = tr.lastInstance ? `(unresolved at ${tr.lastInstance})` : "(unresolved)";
    return { table: where, column: tr.lastField ?? "" };
  }
  return { table: "(computed)", column: e.length > 120 ? e.slice(0, 117) + "..." : e };
}

// IDMC technical wrapper prefixes that should be cleaned away from
// instance/source names when no better metadata is available.
// Order matters: DUMMY_SQ_ before DUMMY_ before SQ_SHORTCUT_ before SQ_.
const WRAPPER_PREFIX_RE = /^(DUMMY_SQ_|DUMMY_|SQ_SHORTCUT_|SQ_)/i;

function isWrapperName(name: string | undefined | null): boolean {
  if (!name) return false;
  return WRAPPER_PREFIX_RE.test(name.trim());
}

// IDMC auto-generates synthetic INSTANCE NAMEs (ISourceNode18, ITargetNode42,
// ILookupNode5, IGroupNode3, IStageNode7) that point to the real definition
// via the INSTANCE TRANSFORMATION_NAME attribute. These names are never the
// real table — when we see one we resolve through the indirection (or skip it
// during multi-source merge) rather than surface the bare synthetic name.
const SYNTHETIC_NODE_RE = /^I(?:Source|Target|Lookup|Group|Stage)Node\d+$/i;

function isSyntheticNodeName(name: string | undefined | null): boolean {
  if (!name) return false;
  return SYNTHETIC_NODE_RE.test(name.trim());
}

// Strip surrounding quotes (Oracle-style "Name" / MySQL-style `Name`) and a
// known wrapper prefix, but only when the remainder is a valid identifier
// (or qualified identifier like SCHEMA.TABLE). Returns the original name if
// stripping would produce an empty or malformed value.
function cleanWrapperPrefix(name: string): string {
  if (!name) return name;
  let work = name.trim();
  // Strip one surrounding layer of double quotes, single quotes, or backticks.
  if (
    (work.startsWith('"') && work.endsWith('"')) ||
    (work.startsWith("'") && work.endsWith("'")) ||
    (work.startsWith("`") && work.endsWith("`"))
  ) {
    work = work.slice(1, -1).trim();
  }
  const stripped = work.replace(WRAPPER_PREFIX_RE, "");
  if (!stripped) return name;
  if (!/^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*$/.test(stripped)) {
    // If the unquoted form (no prefix stripping) is a valid identifier, return that.
    if (/^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*$/.test(work)) return work;
    return name;
  }
  return stripped;
}

// Lightweight extraction of FROM / JOIN table names from a SQL Override.
// Captures one- to three-part qualified identifiers (db.schema.table). Skips
// subqueries (parens after FROM/JOIN never match the identifier regex) and
// stops at keywords. Returns deduplicated tables in first-seen order.
function extractFromTables(sql: string): string[] {
  if (!sql) return [];
  const out: string[] = [];
  const seen = new Set<string>();
  const pattern = /\b(?:FROM|JOIN)\s+([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*){0,2})/gi;
  for (const m of sql.matchAll(pattern)) {
    const t = m[1];
    if (!seen.has(t)) {
      seen.add(t);
      out.push(t);
    }
  }
  return out;
}

// Resolve the best Source Table name for a SOURCE definition per the spec's
// 6-step priority:
//   1. SQ SQL Override FROM/JOIN tables (when present in context)
//   2. SOURCE BUSINESSNAME
//   3. REFERENCEDTABLE [+ REFERENCEDDBD]
//   4. (session-level attributes — reserved, not implemented yet)
//   5. SOURCE NAME when not a technical wrapper
//   6. Cleaned wrapper prefix as last resort
// Returns "" only when the source is completely unidentifiable.
function resolveSourceTable(
  srcDef: SourceDef | undefined,
  context: { sqSqlOverride?: string; fallbackName?: string } = {},
): string {
  if (context.sqSqlOverride) {
    const tables = extractFromTables(context.sqSqlOverride);
    if (tables.length > 0) {
      // Even SQL-Override-extracted names can carry IDMC wrappers (e.g.
      // FROM DUMMY_SQ_risk_stg). Apply the same cleaning we'd apply to
      // SOURCE NAME so the Hard Rule holds everywhere.
      return tables.map(cleanWrapperPrefix).join(", ");
    }
  }
  const biz = srcDef?.businessName?.trim();
  if (biz && !isWrapperName(biz) && !isSyntheticNodeName(biz)) return biz;
  const refTable = srcDef?.referencedTable?.trim();
  if (refTable && !isWrapperName(refTable) && !isSyntheticNodeName(refTable)) {
    const refDb = srcDef?.referencedDatabase?.trim();
    return refDb ? `${refDb}.${refTable}` : refTable;
  }
  const srcName = (srcDef?.name ?? context.fallbackName ?? "").trim();
  if (!srcName) return "";
  // Refuse to surface a synthetic IDMC instance name (ISourceNode18, …) as the
  // Source Table — caller decides what to do with the empty result.
  if (isSyntheticNodeName(srcName)) return "";
  // Always run through cleanWrapperPrefix — handles both the priority-5 case
  // (SOURCE NAME is a real table but might be quoted, e.g. Oracle "adv_prod_dw")
  // and priority 6 (wrapper-prefix strip). cleanWrapperPrefix is a no-op for
  // names that are already clean.
  return cleanWrapperPrefix(srcName);
}

// IDMC exports vary in how the lookup-table-name attribute is spelled. Try the
// most common variants in priority order.
function getLookupTableName(t: TransformationDef): string {
  const candidates = [
    "Lookup table name",
    "Lookup Table Name",
    "Lookup table",
    "Lookup Table",
    "Lookuptablename",
    "Table Name",
    "Source Table",
  ];
  for (const name of candidates) {
    const v = getAttr(t.tableAttributes, name);
    if (v) return v;
  }
  return "";
}

export function buildLineage(session: ParsedSession): LineageRow[] {
  if (!session.mapping) return [];
  const m = session.mapping;

  const connectorByTo = new Map<string, Connector>();
  for (const c of m.connectors) connectorByTo.set(`${c.toInstance}::${c.toField}`, c);

  const txByName = new Map<string, TransformationDef>();
  for (const t of m.transformations) txByName.set(t.name, t);

  const sourcesByName = new Map<string, SourceDef>();
  const sourcesByNameCi = new Map<string, SourceDef>();
  for (const src of m.sources) {
    sourcesByName.set(src.name, src);
    // First-wins on case collisions — real IDMC mappings never declare two
    // <SOURCE> defs that differ only by case, so collision is theoretical.
    if (!sourcesByNameCi.has(src.name.toLowerCase())) {
      sourcesByNameCi.set(src.name.toLowerCase(), src);
    }
  }

  const targetsByName = new Map<string, TargetDef>();
  for (const t of m.targets) targetsByName.set(t.name, t);

  const instancesByName = new Map<string, MappingInstance>();
  for (const i of m.instances) instancesByName.set(i.name, i);

  const idx: Indices = { connectorByTo, txByName, sourcesByName, sourcesByNameCi, instancesByName };

  const connByInstance = new Map<string, { name: string; type: string }>();
  for (const c of session.connectionRefs) {
    connByInstance.set(c.instanceName, { name: c.connectionName, type: c.connectionType });
  }
  function connectionFor(instance: string): { name: string; type: string } {
    return connByInstance.get(instance) ?? { name: "", type: "" };
  }

  // Parameter file extraction — vendors spell this several ways in the XML:
  //   - "Parameter Filename"           (canonical IDMC)
  //   - "Parameter File Name"          (with space)
  //   - "Param Filename" / "PARAM_FILE_NAME"
  //   - sometimes stored as a session-level parameter rather than attribute
  // Anchor on the word `\b(param(?:eter)?)\s*file\b` so we never match
  // unrelated names like "Parameter Default" or "Source Filename".
  const PARAM_FILE_RE = /\b(?:param(?:eter)?)[\s_-]*file(?:[\s_-]*name)?\b/i;
  const parameterFile =
    session.attributes.find((a) => PARAM_FILE_RE.test(a.name))?.value ??
    session.parameters.find((p) => PARAM_FILE_RE.test(p.name))?.value ??
    "";

  const mappingName = session.mappingName ?? m.name ?? "";

  const targetInstances = m.instances.filter((i) => /target/i.test(i.type));
  const targetPairs: { instanceName: string; def: TargetDef }[] = [];
  if (targetInstances.length > 0) {
    for (const ti of targetInstances) {
      const def = targetsByName.get(ti.transformationName ?? ti.name);
      if (def) targetPairs.push({ instanceName: ti.name, def });
    }
  } else {
    for (const tgt of m.targets) targetPairs.push({ instanceName: tgt.name, def: tgt });
  }

  const rows: LineageRow[] = [];
  for (const { instanceName, def } of targetPairs) {
    for (const f of def.fields) {
      const tr = traceField(instanceName, f.name, idx);
      // C.1: snapshot the raw XML expression BEFORE inlineExpression rewrites
      // it. Lets build-mapping-json surface both raw + resolved forms.
      if (tr.expression && !tr.rawExpression) tr.rawExpression = tr.expression;
      // Inline upstream non-trivial expressions so the cell shows the FULL business
      // logic, not a chain of intermediate port names.
      if (tr.expression && tr.expressionAtInstance) {
        tr.expression = inlineExpression(tr.expression, tr.expressionAtInstance, idx);
      }
      let sourceTable = tr.sourceTable;
      let sourceColumn = tr.sourceColumn;
      if (!sourceTable) {
        const cls = classifyBlankSource(tr);
        sourceTable = cls.table;
        if (!sourceColumn) sourceColumn = cls.column;
      }
      const tgtConn = connectionFor(instanceName);
      // For lookup-sourced rows the lookup table is the primary value source,
      // so its connection takes priority over the SQ connection (the SQ is on
      // the lookup-KEY pipeline, not the value pipeline). Fall back to SQ when
      // no lookup is involved.
      let srcConn: { name: string; type: string } = { name: "", type: "" };
      if (tr.lookupsUsed.length > 0) {
        srcConn = connectionFor(tr.lookupsUsed[0]);
      }
      if (!srcConn.name && tr.sourceQualifier) {
        srcConn = connectionFor(tr.sourceQualifier);
      }
      // Final fallback — the topmost upstream instance the walk reached may
      // have a <CONNECTIONREFERENCE> of its own (common for direct-source
      // wrappers like DUMMY_SQ_* that bypass an SQ entirely).
      if (!srcConn.name && tr.lastInstance) {
        srcConn = connectionFor(tr.lastInstance);
      }
      const partial: LineageRow = {
        mapping: mappingName,
        targetTable: def.name,
        targetColumn: f.name,
        targetDataType: f.datatype,
        targetPrecision: f.precision ?? "",
        targetScale: f.scale ?? "",
        targetNullable: f.nullable ?? "",
        targetKey: f.keyType ?? "",
        targetDescription: f.description ?? "",
        sourceTable,
        sourceColumn,
        sourceDataType: tr.sourceDataType,
        sourcePrecision: tr.sourcePrecision,
        sourceScale: tr.sourceScale,
        sourceNullable: tr.sourceNullable,
        sourceKey: tr.sourceKey,
        expression: tr.expression,
        expressionType: tr.expressionType,
        expressionChain: tr.expressionChain.map((e) => `${e.where}: ${e.expr}`).join(" || "),
        transformationPath: tr.path.join(" → "),
        lookupsUsed: tr.lookupsUsed.join(", "),
        joinersUsed: tr.joinersUsed.join(", "),
        routersUsed: tr.routersUsed.join(", "),
        aggregatorsUsed: tr.aggregatorsUsed.join(", "),
        sourceQualifier: tr.sourceQualifier,
        sourceQualifierSql: tr.sourceQualifierSql,
        sourceConnection: srcConn.name,
        sourceConnectionType: srcConn.type,
        targetConnection: tgtConn.name,
        targetConnectionType: tgtConn.type,
        cdqDimension: tr.cdqDimension,
        cdqRule: tr.cdqRule,
        parameterFile,
        notes: tr.notes.join(" | "),
        lastInstance: tr.lastInstance,
        lastField: tr.lastField,
        rawExpression: tr.rawExpression,
        lookupCallStyle: tr.lookupCallStyle,
        errorHandlingFromXml: tr.errorHandling.length > 0 ? tr.errorHandling.join(" | ") : undefined,
      };
      if (!partial.cdqDimension) {
        partial.cdqDimension = inferCdqDimension(partial, session);
      }
      if (!partial.cdqRule) {
        partial.cdqRule = inferCdqRule(partial, session);
      }
      rows.push(partial);
    }
  }
  return rows;
}
