export type KV = { name: string; value: string };

export type ConnectionRef = {
  instanceType: string;
  instanceName: string;
  connectionName: string;
  connectionType: string;
  connectionSubtype?: string;
  variable?: string;
};

export type TransformationInstance = {
  name: string;
  type: string;
  description?: string;
  attributes: KV[];
};

export type SessionExtension = {
  name: string;
  type: string;
  subtype?: string;
  attributes: KV[];
};

export type TransformField = {
  name: string;
  portType: string;
  datatype: string;
  precision?: string;
  scale?: string;
  defaultValue?: string;
  expression?: string;
  expressionType?: string;
  pictureText?: string;
  group?: string;
};

export type TransformationDef = {
  name: string;
  type: string;
  description?: string;
  reusable?: string;
  objectVersion?: string;
  versionNumber?: string;
  fields: TransformField[];
  tableAttributes: KV[];
  metadataExtensions: KV[];
  groups: { name: string; condition?: string; order?: string }[];
};

export type SourceField = {
  name: string;
  datatype: string;
  precision?: string;
  scale?: string;
  nullable?: string;
  keyType?: string;
  businessName?: string;
  description?: string;
  fieldNumber?: string;
};

export type SourceDef = {
  name: string;
  databaseType?: string;
  databaseName?: string;
  ownerName?: string;
  description?: string;
  businessName?: string;
  referencedTable?: string;
  referencedDatabase?: string;
  fields: SourceField[];
};

export type TargetDef = {
  name: string;
  databaseType?: string;
  description?: string;
  constraint?: string;
  fields: SourceField[];
};

export type MappingInstance = {
  name: string;
  type: string;
  transformationName?: string;
  transformationType?: string;
  description?: string;
  reusable?: string;
};

export type Connector = {
  fromInstance: string;
  fromInstanceType: string;
  fromField: string;
  toInstance: string;
  toInstanceType: string;
  toField: string;
};

export type MappletDef = {
  name: string;
  description?: string;
  isValid?: string;
  versionNumber?: string;
  instanceCount: number;
  transformationCount: number;
};

export type MappingDef = {
  name: string;
  description?: string;
  isValid?: string;
  versionNumber?: string;
  instances: MappingInstance[];
  connectors: Connector[];
  transformations: TransformationDef[];
  sources: SourceDef[];
  targets: TargetDef[];
  mapplets: MappletDef[];
};

export type TaskInstance = {
  name: string;
  taskName?: string;
  taskType: string;
  reusable?: string;
  description?: string;
};

export type WorkflowLink = {
  fromTask: string;
  toTask: string;
  condition?: string;
};

export type WorkflowDef = {
  name: string;
  description?: string;
  isValid?: string;
  serverName?: string;
  isEnabled?: string;
  schedulerName?: string;
  tasks: TaskInstance[];
  links: WorkflowLink[];
  attributes: KV[];
};

export type ConfigDef = {
  name: string;
  description?: string;
  attributes: KV[];
};

export type ParsedSession = {
  fileName: string;
  sessionIndex: number;
  hasSession: boolean;
  name: string;
  description?: string;
  mappingName?: string;
  reusable?: string;
  sortOrder?: string;
  isValid?: string;
  versionNumber?: string;
  configReference?: string;
  attributes: KV[];
  connectionRefs: ConnectionRef[];
  transformationInstances: TransformationInstance[];
  extensions: SessionExtension[];
  parameters: KV[];
  mapping?: MappingDef;
  workflows: WorkflowDef[];
  configs: ConfigDef[];
  folder?: { name?: string; group?: string; owner?: string };
  repository?: { name?: string; version?: string; databaseType?: string };
  rawXml: string;
};

export type FileEntry = {
  // Path relative to `public/sessions/`, posix separators. Carries the full
  // hierarchy: "Sales/2024/Q1/foo.xml". For root-level XMLs `path === fileName`.
  path: string;
  // Leaf filename — convenience, equals `path.split("/").pop()`.
  fileName: string;
  sessions: {
    index: number;
    name: string;
    mappingName?: string;
  }[];
};

const ATTRIBUTE_GROUPS: { label: string; match: (name: string) => boolean }[] = [
  { label: "General", match: (n) => /^(general|session log|workflow log|parameter|treat source rows|enable test)/i.test(n) },
  { label: "Performance", match: (n) => /(buffer|cache|commit|throughput|dtm|memory|pushdown|incremental|high precision)/i.test(n) },
  { label: "Error handling", match: (n) => /(error|reject|stop on)/i.test(n) },
  { label: "Recovery", match: (n) => /(recovery|resume|retry|deadlock)/i.test(n) },
  { label: "Logging", match: (n) => /(log|trace)/i.test(n) },
  { label: "Partitioning", match: (n) => /(partition)/i.test(n) },
];

export function groupAttributes(rows: KV[]): Record<string, KV[]> {
  const groups: Record<string, KV[]> = {};
  for (const a of rows) {
    const g = ATTRIBUTE_GROUPS.find((x) => x.match(a.name));
    const key = g ? g.label : "Other";
    (groups[key] ??= []).push(a);
  }
  return groups;
}

export const GROUP_ORDER = [
  "General",
  "Performance",
  "Error handling",
  "Recovery",
  "Logging",
  "Partitioning",
  "Other",
];
