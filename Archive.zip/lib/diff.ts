import type { KV, ParsedSession } from "./sessions";

export type DiffStatus = "added" | "removed" | "changed" | "same";

export type DiffPair = {
  key: string;
  left?: string;
  right?: string;
  status: DiffStatus;
};

export type DiffSection = {
  title: string;
  pairs: DiffPair[];
  summary: { added: number; removed: number; changed: number; same: number };
};

export type SessionDiff = {
  leftLabel: string;
  rightLabel: string;
  sections: DiffSection[];
  totals: { added: number; removed: number; changed: number; same: number };
};

function kvMap(rows: KV[]): Map<string, string> {
  const m = new Map<string, string>();
  for (const r of rows) m.set(r.name, r.value);
  return m;
}

function diffMaps(left: Map<string, string>, right: Map<string, string>): DiffPair[] {
  const keys = new Set<string>([...left.keys(), ...right.keys()]);
  const pairs: DiffPair[] = [];
  for (const key of Array.from(keys).sort((a, b) => a.localeCompare(b))) {
    const l = left.get(key);
    const r = right.get(key);
    let status: DiffStatus;
    if (l === undefined) status = "added";
    else if (r === undefined) status = "removed";
    else if (l !== r) status = "changed";
    else status = "same";
    pairs.push({ key, left: l, right: r, status });
  }
  return pairs;
}

function summarize(pairs: DiffPair[]) {
  const s = { added: 0, removed: 0, changed: 0, same: 0 };
  for (const p of pairs) s[p.status]++;
  return s;
}

function section(title: string, pairs: DiffPair[]): DiffSection {
  return { title, pairs, summary: summarize(pairs) };
}

export function diffSessions(left: ParsedSession, right: ParsedSession): SessionDiff {
  const sections: DiffSection[] = [];

  sections.push(section("Session attributes", diffMaps(kvMap(left.attributes), kvMap(right.attributes))));
  sections.push(section("Parameters", diffMaps(kvMap(left.parameters), kvMap(right.parameters))));

  // Connections (key: instanceName)
  const lConn = new Map(left.connectionRefs.map((c) => [c.instanceName, summarizeConn(c)]));
  const rConn = new Map(right.connectionRefs.map((c) => [c.instanceName, summarizeConn(c)]));
  sections.push(section("Connections", diffMaps(lConn, rConn)));

  // Transformation expressions per port
  const lExpr = collectExpressions(left);
  const rExpr = collectExpressions(right);
  sections.push(section("Expressions", diffMaps(lExpr, rExpr)));

  // Lookup settings
  const lLkp = collectLookupSettings(left);
  const rLkp = collectLookupSettings(right);
  sections.push(section("Lookups", diffMaps(lLkp, rLkp)));

  // Source qualifier SQL
  const lSql = collectSqOverrides(left);
  const rSql = collectSqOverrides(right);
  sections.push(section("Source SQL", diffMaps(lSql, rSql)));

  // Source / target columns
  sections.push(section("Source columns", diffMaps(collectSourceCols(left), collectSourceCols(right))));
  sections.push(section("Target columns", diffMaps(collectTargetCols(left), collectTargetCols(right))));

  // Connectors (lineage edges)
  sections.push(section("Connectors", diffMaps(collectConnectors(left), collectConnectors(right))));

  const totals = { added: 0, removed: 0, changed: 0, same: 0 };
  for (const s of sections) {
    totals.added += s.summary.added;
    totals.removed += s.summary.removed;
    totals.changed += s.summary.changed;
    totals.same += s.summary.same;
  }

  return {
    leftLabel: `${left.fileName} :: ${left.name}`,
    rightLabel: `${right.fileName} :: ${right.name}`,
    sections,
    totals,
  };
}

function summarizeConn(c: ParsedSession["connectionRefs"][number]): string {
  return `${c.connectionName} | ${c.connectionType}${c.connectionSubtype ? ` / ${c.connectionSubtype}` : ""}${c.variable ? ` (${c.variable})` : ""}`;
}

function collectExpressions(p: ParsedSession): Map<string, string> {
  const out = new Map<string, string>();
  for (const t of p.mapping?.transformations ?? []) {
    for (const f of t.fields) {
      if (!f.expression) continue;
      out.set(`${t.name}.${f.name}`, f.expression);
    }
  }
  return out;
}

function collectLookupSettings(p: ParsedSession): Map<string, string> {
  const out = new Map<string, string>();
  for (const t of p.mapping?.transformations ?? []) {
    if (!/lookup/i.test(t.type)) continue;
    for (const a of t.tableAttributes) out.set(`${t.name}.${a.name}`, a.value);
  }
  return out;
}

function collectSqOverrides(p: ParsedSession): Map<string, string> {
  const out = new Map<string, string>();
  for (const t of p.mapping?.transformations ?? []) {
    if (!/source qualifier/i.test(t.type)) continue;
    for (const a of t.tableAttributes) out.set(`${t.name}.${a.name}`, a.value);
  }
  for (const inst of p.transformationInstances) {
    if (!/source qualifier/i.test(inst.type)) continue;
    for (const a of inst.attributes) out.set(`${inst.name}.${a.name} (session)`, a.value);
  }
  return out;
}

function collectSourceCols(p: ParsedSession): Map<string, string> {
  const out = new Map<string, string>();
  for (const s of p.mapping?.sources ?? [])
    for (const f of s.fields)
      out.set(`${s.name}.${f.name}`, `${f.datatype}${f.precision ? `(${f.precision}${f.scale && f.scale !== "0" ? `,${f.scale}` : ""})` : ""}${f.nullable ? ` ${f.nullable}` : ""}`);
  return out;
}

function collectTargetCols(p: ParsedSession): Map<string, string> {
  const out = new Map<string, string>();
  for (const t of p.mapping?.targets ?? [])
    for (const f of t.fields)
      out.set(`${t.name}.${f.name}`, `${f.datatype}${f.precision ? `(${f.precision}${f.scale && f.scale !== "0" ? `,${f.scale}` : ""})` : ""}${f.nullable ? ` ${f.nullable}` : ""}`);
  return out;
}

function collectConnectors(p: ParsedSession): Map<string, string> {
  const out = new Map<string, string>();
  for (const c of p.mapping?.connectors ?? []) {
    out.set(`${c.fromInstance}.${c.fromField} → ${c.toInstance}.${c.toField}`, "wired");
  }
  return out;
}
