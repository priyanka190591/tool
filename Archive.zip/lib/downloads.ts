import type { ParsedSession } from "./sessions-types";
import { sessionToCsv, sessionToJson, sessionToMarkdown } from "./exports";
import { buildMappingJson } from "./build-mapping-json";
import { listFileEntries, parseAllSessions } from "./sessions-client";
import { filesUnder, type FolderNode } from "./folder-tree";

export function downloadBlob(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

function safeName(s: string): string {
  return s.replace(/[^A-Za-z0-9_-]+/g, "_");
}

function stemOf(fileName: string): string {
  return fileName.replace(/\.xml$/i, "");
}

// IDMC technical wrapper prefixes that should be cleaned away from
// source/target candidates before they appear in user-facing filenames.
// Mirrors WRAPPER_PREFIX_RE in lib/lineage.ts — kept inline to avoid a
// cross-module dependency just for one regex.
const WRAPPER_PREFIX_RE = /^(DUMMY_SQ_|DUMMY_|SQ_SHORTCUT_|SQ_)/i;

function stripWrapperPrefix(name: string): string {
  const stripped = name.replace(WRAPPER_PREFIX_RE, "");
  return stripped || name;
}

// Clean 3-sheet workbook (FIELD_MAPPING + LOOKUPS + TRANSFORMATIONS) driven
// by the normalized MappingJson intermediate. This is the canonical export
// surface — all reviewer-facing artefacts (XLSX, CSV, JSON, Markdown) read
// from the same MappingJson so column semantics never drift between them.
export async function downloadSessionCleanXlsx(session: ParsedSession): Promise<void> {
  const { buildCleanWorkbook } = await import("./xlsx-clean");
  const json = buildMappingJson(session);
  const buf = await buildCleanWorkbook(json);
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  downloadBlob(buildXlsxFilename(session), blob);
}

// Back-compat alias — older callers / docs may still reference the original
// "XLSX" download. Always emits the Clean workbook now.
export const downloadSessionXlsx = downloadSessionCleanXlsx;

/**
 * Bundle every Clean-XLSX under `folder` (recursive) into a single ZIP.
 * Entries inside the ZIP retain their full path from `public/sessions/` so
 * re-extracting reconstructs the original tree.
 *
 * - Sessions that fail to parse are skipped and reported via the
 *   `onFailure` callback (caller renders a toast).
 * - If every file under `folder` fails to parse, throws so the caller
 *   surfaces an explicit error instead of emitting an empty ZIP.
 */
export async function downloadFolderXlsx(
  folder: FolderNode,
  options: { onFailure?: (path: string, error: unknown) => void } = {},
): Promise<{ bundled: number; failed: number }> {
  const [{ buildCleanWorkbook }, JSZipMod] = await Promise.all([
    import("./xlsx-clean"),
    import("jszip"),
  ]);
  const JSZip = JSZipMod.default;
  const zip = new JSZip();
  const used = new Map<string, number>();
  let bundled = 0;
  let failed = 0;
  for (const file of filesUnder(folder)) {
    try {
      const parsed = await parseAllSessions(file.path);
      for (const session of parsed) {
        const json = buildMappingJson(session);
        const buf = await buildCleanWorkbook(json);
        const entryName = entryNameFor(file.path, buildXlsxFilename(session), used);
        zip.file(entryName, buf);
        bundled++;
      }
    } catch (err) {
      failed++;
      options.onFailure?.(file.path, err);
    }
  }
  if (bundled === 0) {
    throw new Error(`No sessions could be bundled under "${folder.path || "all"}".`);
  }
  const blob = await zip.generateAsync({
    type: "blob",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
  downloadBlob(zipFilenameFor(folder), blob);
  return { bundled, failed };
}

// Build the ZIP entry path: `<parent folder of XML>/<xlsx filename>`, with
// `_N` suffix on collision so sibling sessions in the same XML stay
// individually addressable.
function entryNameFor(filePath: string, xlsxName: string, used: Map<string, number>): string {
  const parent = filePath.split("/").slice(0, -1).join("/");
  const base = parent ? `${parent}/${xlsxName}` : xlsxName;
  const count = (used.get(base) ?? 0) + 1;
  used.set(base, count);
  if (count === 1) return base;
  const stem = base.replace(/\.xlsx$/i, "");
  return `${stem}_${count}.xlsx`;
}

function zipFilenameFor(folder: FolderNode): string {
  if (folder.path === "") return "all_sessions_mappings.zip";
  // Convert "Sales/2024/Q1" → "Sales_2024_Q1_sessions.zip" so the archive
  // is self-describing on disk.
  const safe = folder.path.replace(/\//g, "_").replace(/[^A-Za-z0-9_-]+/g, "_");
  return `${safe}_sessions.zip`;
}

/**
 * Back-compat: bundle the entire tree. The TopBar still passes a
 * `ParsedSession[]` but we ignore it and re-bundle from disk so the
 * code path stays single-implementation.
 *
 * @deprecated callers should switch to `downloadFolderXlsx(rootNode)`.
 */
export async function downloadAllSessionsXlsx(
  _sessionsIgnored: ParsedSession[],
): Promise<void> {
  const files = await listFileEntries();
  const { buildFolderTree } = await import("./folder-tree");
  const root = buildFolderTree(files);
  await downloadFolderXlsx(root);
}

// Pattern: <session_name>_(<source>_TO_<target>).xlsx
// session_name = XML basename (per spec — same as XML name).
// source / target = most-referenced source and target tables for this session.
export function buildXlsxFilename(session: ParsedSession): string {
  const stem = safeName(stemOf(session.fileName));
  const src = primaryTable(session, "source");
  const tgt = primaryTable(session, "target");
  return `${stem}_(${src}_TO_${tgt}).xlsx`;
}

function primaryTable(session: ParsedSession, kind: "source" | "target"): string {
  // Prefer the most-cited table from MappingJson rows when available. Use the
  // canonical pipeline so the filename matches what's INSIDE the workbook
  // (e.g. lookup_id-rewritten source names rather than raw lookup tables).
  if (session.mapping && (session.mapping.targets.length > 0 || session.mapping.sources.length > 0)) {
    const json = buildMappingJson(session);
    if (json.field_mappings.length > 0) {
      const counts = new Map<string, number>();
      for (const r of json.field_mappings) {
        const raw = kind === "source" ? r.source_table : r.target_table;
        if (!raw || raw.startsWith("(")) continue;
        // "UNUSED" is a sentinel written by build-mapping-json for orphan
        // source fields. It should never become the user-facing table name.
        if (raw === "UNUSED") continue;
        for (const t of raw.split(",").map((x) => x.trim()).filter(Boolean)) {
          if (t === "UNUSED") continue;
          const cleaned = stripWrapperPrefix(t);
          counts.set(cleaned, (counts.get(cleaned) ?? 0) + 1);
        }
      }
      if (counts.size > 0) {
        const top = [...counts.entries()].sort((a, b) => b[1] - a[1])[0][0];
        return safeName(top);
      }
    }
  }
  // Fallback: first mapping def, then first session-level instance, then "SRC"/"TGT".
  if (kind === "source") {
    if (session.mapping?.sources.length) return safeName(stripWrapperPrefix(session.mapping.sources[0].name));
    const sq = session.transformationInstances.find((i) => /source qualifier/i.test(i.type));
    if (sq) return safeName(stripWrapperPrefix(sq.name));
    return "SRC";
  }
  if (session.mapping?.targets.length) return safeName(stripWrapperPrefix(session.mapping.targets[0].name));
  const tgt = session.transformationInstances.find((i) => /target/i.test(i.type));
  if (tgt) return safeName(stripWrapperPrefix(tgt.name));
  return "TGT";
}

export function downloadSessionJson(session: ParsedSession): void {
  const body = sessionToJson(session);
  const blob = new Blob([body], { type: "application/json;charset=utf-8" });
  downloadBlob(`${stemOf(session.fileName)}_mapping.json`, blob);
}

export function downloadSessionCsv(session: ParsedSession): void {
  const body = sessionToCsv(session);
  const blob = new Blob([body], { type: "text/csv;charset=utf-8" });
  downloadBlob(`${stemOf(session.fileName)}_field_mapping.csv`, blob);
}

export function downloadSessionMarkdown(session: ParsedSession): void {
  const body = sessionToMarkdown(session);
  const blob = new Blob([body], { type: "text/markdown;charset=utf-8" });
  downloadBlob(`${stemOf(session.fileName)}_mapping.md`, blob);
}
