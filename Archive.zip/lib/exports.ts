// Reviewer-facing export formats (CSV, JSON, Markdown). All three derive
// from the same MappingJson intermediate that powers the Clean 3-sheet XLSX
// so column semantics stay 1:1 across surfaces.

import { buildMappingJson } from "./build-mapping-json";
import type { FieldMappingJson, MappingJson } from "./mapping-schema";
import type { ParsedSession } from "./sessions";

// The columns shipped in the Clean XLSX FIELD_MAPPING sheet, in the same
// order. Keeping CSV and XLSX header-identical means a reviewer can paste
// CSV into the XLSX (or vice versa) without re-mapping columns.
const FIELD_MAPPING_HEADERS: { csv: string; field: keyof FieldMappingJson }[] = [
  { csv: "Used", field: "is_used" },
  { csv: "Source Table", field: "source_table" },
  { csv: "Source Database", field: "source_database" },
  { csv: "Source Column", field: "source_column" },
  { csv: "Source Datatype", field: "source_datatype" },
  { csv: "Src Precision", field: "source_precision" },
  { csv: "Src Scale", field: "source_scale" },
  { csv: "Src Nullable", field: "source_nullable" },
  { csv: "Src Key", field: "source_key" },
  { csv: "Business Logic / Expression", field: "business_logic_expression" },
  { csv: "Expression Type", field: "expression_type" },
  { csv: "Expression Chain", field: "expression_chain" },
  { csv: "Transformation Path", field: "transformation_path" },
  { csv: "Logical Steps", field: "logical_steps" },
  { csv: "Lookups Used", field: "lookups_used" },
  { csv: "Lookup Type", field: "lookup_type" },
  { csv: "Lookup Join Condition", field: "lookup_join_condition" },
  { csv: "Lookup Return Column", field: "lookup_return_column" },
  { csv: "Lookup Keys (Source → Lookup)", field: "lookup_keys_source_to_lookup" },
  { csv: "Joiners Used", field: "joiners_used" },
  { csv: "Joiner Join Type", field: "joiner_join_type" },
  { csv: "Joiner Join Condition", field: "joiner_join_condition" },
  { csv: "Routers Used", field: "routers_used" },
  { csv: "Aggregators Used", field: "aggregators_used" },
  { csv: "Aggregator Group By", field: "aggregator_group_by" },
  { csv: "Source Qualifier", field: "source_qualifier" },
  { csv: "CDQ Dimension (heuristic)", field: "cdq_dimension" },
  { csv: "CDQ Rule (heuristic)", field: "cdq_rule" },
  { csv: "Error Handling Logic", field: "error_logic" },
  { csv: "Load Type", field: "load_type" },
  { csv: "Target Table", field: "target_table" },
  { csv: "Target Database", field: "target_database" },
  { csv: "Target Column", field: "target_column" },
  { csv: "Target Datatype", field: "target_datatype" },
  { csv: "Tgt Precision", field: "target_precision" },
  { csv: "Tgt Scale", field: "target_scale" },
  { csv: "Tgt Nullable", field: "target_nullable" },
  { csv: "Tgt Key", field: "target_key" },
  { csv: "Parameter File", field: "parameter_file" },
  { csv: "Notes", field: "notes" },
];

export function fieldMappingsToCsv(rows: FieldMappingJson[]): string {
  if (rows.length === 0) return "";
  const head = FIELD_MAPPING_HEADERS.map((h) => csvEscape(h.csv)).join(",");
  const body = rows
    .map((r) =>
      FIELD_MAPPING_HEADERS.map((h) => {
        const v = r[h.field];
        // Match the XLSX convention: empty cells render as literal "NULL"
        // so downstream consumers can distinguish "no data" from "blank string".
        return csvEscape(v == null || v === "" ? "NULL" : String(v));
      }).join(","),
    )
    .join("\n");
  return `${head}\n${body}\n`;
}

export function sessionToCsv(session: ParsedSession): string {
  const json = buildMappingJson(session);
  return fieldMappingsToCsv(json.field_mappings);
}

export function sessionToJson(session: ParsedSession): string {
  const json = buildMappingJson(session);
  // Wrap MappingJson with the original session metadata (minus rawXml) so
  // downstream programmatic consumers retain access to attributes /
  // connection refs / parameters without re-parsing.
  const sessionMeta = {
    file_name: session.fileName,
    session_name: session.name,
    description: session.description,
    is_valid: session.isValid,
    reusable: session.reusable,
    version_number: session.versionNumber,
    config_reference: session.configReference,
    parameters: session.parameters,
    connection_refs: session.connectionRefs,
    transformation_instances: session.transformationInstances,
    extensions: session.extensions,
    attributes: session.attributes,
  };
  return JSON.stringify({ session: sessionMeta, mapping: json }, null, 2);
}

export function sessionToMarkdown(session: ParsedSession): string {
  const json = buildMappingJson(session);
  const lines: string[] = [];
  const md = (s: string) => s.replace(/\|/g, "\\|");
  const cell = (s: string | null | undefined) => md(s == null || s === "" ? "—" : s);

  lines.push(`# Session: ${session.name}`);
  if (session.description) lines.push(`\n${session.description}`);
  lines.push("");
  lines.push(`- **File**: \`${session.fileName}\``);
  lines.push(`- **Mapping**: ${json.mapping_name || "—"}`);
  lines.push(`- **Reusable**: ${session.reusable ?? "—"}`);
  lines.push(`- **Valid**: ${session.isValid ?? "—"}`);
  lines.push(`- **Version**: ${session.versionNumber ?? "—"}`);
  lines.push(`- **Config**: ${session.configReference ?? "—"}`);
  const paramFile = session.attributes.find((a) =>
    /parameter.*file.?name/i.test(a.name),
  )?.value;
  if (paramFile) lines.push(`- **Parameter file**: \`${paramFile}\``);

  lines.push("");
  lines.push(
    `- **Field mappings**: ${json.field_mappings.length}` +
      ` (${json.lookups.length} lookups, ${json.transformations.length} transformations)`,
  );

  lines.push("");
  lines.push("## Field mappings (FIELD_MAPPING)");
  lines.push("");
  if (json.field_mappings.length === 0) {
    lines.push("_No field mappings resolved._");
  } else {
    lines.push(
      "| Target | Target Type | Source | Source Type | Load Type | Expression | Path |",
    );
    lines.push("|---|---|---|---|---|---|---|");
    for (const r of json.field_mappings) {
      const tgt = `${r.target_table}.${r.target_column}`;
      const tgtType = typeStr(r.target_datatype, r.target_precision, r.target_scale);
      const srcName = r.source_column
        ? `${r.source_table}.${r.source_column}`
        : (r.source_table || "—");
      const srcType = typeStr(r.source_datatype, r.source_precision, r.source_scale);
      lines.push(
        `| ${cell(tgt)} | ${cell(tgtType)} | ${cell(srcName)} | ${cell(srcType)} | ${cell(r.load_type)} | ${cell(r.business_logic_expression)} | ${cell(r.transformation_path)} |`,
      );
    }
  }

  if (json.lookups.length > 0) {
    lines.push("");
    lines.push("## Lookups (LOOKUPS)");
    for (const lkp of json.lookups) {
      lines.push("");
      lines.push(`### ${lkp.lookup_id}`);
      lines.push(`- **Source table**: \`${lkp.source_table}\``);
      if (lkp.connection) lines.push(`- **Connection**: ${lkp.connection}`);
      if (lkp.is_cached != null) lines.push(`- **Cached**: ${lkp.is_cached}`);
      if (lkp.is_persistent != null) lines.push(`- **Persistent**: ${lkp.is_persistent}`);
      if (lkp.return_fields.length > 0) {
        lines.push(`- **Return fields**: \`${lkp.return_fields.join("`, `")}\``);
      }
      if (lkp.join_conditions.length > 0) {
        lines.push(`- **Join condition**: \`${lkp.join_conditions.map((j) => `${j.left} = ${j.right}`).join(" AND ")}\``);
      }
      if (lkp.sql_override) {
        lines.push("");
        lines.push("```sql");
        lines.push(lkp.sql_override);
        lines.push("```");
      }
    }
  }

  if (json.transformations.length > 0) {
    lines.push("");
    lines.push("## Transformations (TRANSFORMATIONS)");
    lines.push("");
    lines.push("| Name | Type | Output field | Formula |");
    lines.push("|---|---|---|---|");
    for (const tx of json.transformations) {
      if (tx.expressions.length === 0) {
        lines.push(`| ${md(tx.name)} | ${md(tx.type)} | — | — |`);
      } else {
        for (const e of tx.expressions) {
          lines.push(`| ${md(tx.name)} | ${md(tx.type)} | ${md(e.output_field)} | ${md(e.formula)} |`);
        }
      }
    }
  }

  if (session.connectionRefs.length > 0) {
    lines.push("");
    lines.push("## Connections");
    lines.push("");
    lines.push("| Instance | Type | Connection | Conn. type | Subtype |");
    lines.push("|---|---|---|---|---|");
    for (const c of session.connectionRefs) {
      lines.push(
        `| ${md(c.instanceName)} | ${md(c.instanceType)} | ${md(c.connectionName)} | ${md(c.connectionType)} | ${md(c.connectionSubtype ?? "")} |`,
      );
    }
  }

  if (session.parameters.length > 0) {
    lines.push("");
    lines.push("## Parameters");
    for (const p of session.parameters) lines.push(`- \`${p.name}\` = \`${p.value}\``);
  }

  if (session.extensions.length > 0) {
    lines.push("");
    lines.push("## Session Extensions");
    for (const ext of session.extensions) {
      lines.push("");
      lines.push(
        `### ${ext.name} — ${ext.type}${ext.subtype ? ` / ${ext.subtype}` : ""}`,
      );
      if (ext.attributes.length === 0) lines.push("_No attributes._");
      for (const a of ext.attributes) lines.push(`- **${a.name}**: \`${a.value}\``);
    }
  }

  return lines.join("\n") + "\n";
}

function typeStr(
  dt: string | null | undefined,
  prec: string | null | undefined,
  scale: string | null | undefined,
): string {
  if (!dt) return "";
  if (prec) {
    if (scale && scale !== "0") return `${dt}(${prec},${scale})`;
    return `${dt}(${prec})`;
  }
  return dt;
}

function csvEscape(s: string): string {
  const needs = /[",\n\r]/.test(s);
  const escaped = s.replace(/"/g, '""');
  return needs ? `"${escaped}"` : escaped;
}

// Back-compat re-exports for any callers that imported the old helpers.
// CSV is the only one that changed shape (LineageRow → FieldMappingJson);
// callers passing raw LineageRow arrays now get an explicit error rather
// than schema-drifted output.
export type { MappingJson };
