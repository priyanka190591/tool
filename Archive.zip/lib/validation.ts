import type { ParsedSession, Connector, TransformationDef } from "./sessions";

export type ValidationIssue = {
  severity: "error" | "warning" | "info";
  code: string;
  message: string;
  location?: string;
};

export function validateSession(session: ParsedSession): ValidationIssue[] {
  const out: ValidationIssue[] = [];
  if (!session.hasSession) {
    out.push({ severity: "info", code: "MAPPING_ONLY", message: "No SESSION node; rendering mapping-only." });
  }
  if (session.isValid && session.isValid !== "YES") {
    out.push({ severity: "warning", code: "SESSION_INVALID", message: `Session marked ISVALID="${session.isValid}".` });
  }

  const m = session.mapping;
  if (!m) {
    out.push({ severity: "warning", code: "NO_MAPPING", message: "Session references a mapping but no MAPPING node was found in the file." });
    return out;
  }

  // Unmapped target columns
  const connectorByTo = new Map<string, Connector>();
  for (const c of m.connectors) connectorByTo.set(`${c.toInstance}::${c.toField}`, c);
  const targetInstances = m.instances.filter((i) => /target/i.test(i.type));
  const targetsByName = new Map(m.targets.map((t) => [t.name, t] as const));
  type Pair = { instanceName: string; def: NonNullable<ReturnType<typeof targetsByName.get>> };
  const targetPairs: Pair[] =
    targetInstances.length > 0
      ? (targetInstances
          .map((i) => {
            const def = targetsByName.get(i.transformationName ?? i.name);
            return def ? { instanceName: i.name, def } : null;
          })
          .filter((x): x is Pair => !!x))
      : m.targets.map((t) => ({ instanceName: t.name, def: t }));
  for (const { instanceName, def } of targetPairs) {
    for (const f of def.fields) {
      if (!connectorByTo.has(`${instanceName}::${f.name}`)) {
        out.push({
          severity: "error",
          code: "TARGET_UNMAPPED",
          message: `Target column ${def.name}.${f.name} has no incoming CONNECTOR.`,
          location: `${instanceName}.${f.name}`,
        });
      }
    }
  }

  // Unused source columns
  const sourceTouched = new Set<string>();
  for (const c of m.connectors) {
    if (/source definition/i.test(c.fromInstanceType)) sourceTouched.add(`${c.fromInstance}::${c.fromField}`);
  }
  const sourceInstances = m.instances.filter((i) => /source/i.test(i.type) && !/qualifier/i.test(i.type));
  const sourcesByName = new Map(m.sources.map((src) => [src.name, src] as const));
  for (const inst of sourceInstances) {
    const def = sourcesByName.get(inst.transformationName ?? inst.name);
    if (!def) continue;
    for (const f of def.fields) {
      if (!sourceTouched.has(`${inst.name}::${f.name}`)) {
        out.push({
          severity: "info",
          code: "SOURCE_UNUSED",
          message: `Source column ${def.name}.${f.name} is not consumed by any downstream instance.`,
          location: `${inst.name}.${f.name}`,
        });
      }
    }
  }

  // Expression transformations with empty output expressions
  for (const t of m.transformations) {
    if (!/expression/i.test(t.type)) continue;
    for (const f of t.fields) {
      const pt = (f.portType || "").toLowerCase();
      if (pt === "output" && !f.expression) {
        out.push({
          severity: "warning",
          code: "EMPTY_EXPRESSION",
          message: `Expression ${t.name}.${f.name} is an OUTPUT port with no expression.`,
          location: `${t.name}.${f.name}`,
        });
      }
    }
  }

  // Lookup hygiene
  for (const t of m.transformations) {
    if (!/lookup/i.test(t.type)) continue;
    const lookupTable = pick(t, "Lookup table name");
    const condition = pick(t, "Lookup condition");
    const cacheEnabled = pick(t, "Lookup cache enabled");
    const cachePersistent = pick(t, "Lookup cache persistent");
    const cachePrefix = pick(t, "Cache File Name Prefix") || pick(t, "Lookup cache file name prefix");
    if (!lookupTable) {
      out.push({ severity: "warning", code: "LOOKUP_NO_TABLE", message: `Lookup ${t.name} has no "Lookup table name".`, location: t.name });
    }
    if (!condition) {
      out.push({ severity: "warning", code: "LOOKUP_NO_CONDITION", message: `Lookup ${t.name} has no "Lookup condition".`, location: t.name });
    }
    if (cachePersistent === "YES" && !cachePrefix) {
      out.push({ severity: "warning", code: "LOOKUP_PERSISTENT_NO_PREFIX", message: `Lookup ${t.name} is persistent-cached but has no cache file name prefix; concurrent runs may collide.`, location: t.name });
    }
    if (cacheEnabled === "NO" && pick(t, "Re-cache from lookup source") === "YES") {
      out.push({ severity: "info", code: "LOOKUP_RECACHE_WITHOUT_CACHE", message: `Lookup ${t.name} has Re-cache=YES but cache is disabled.`, location: t.name });
    }
  }

  // Orphan instances (no in, no out)
  if (m.instances.length > 0) {
    const inDeg = new Map<string, number>();
    const outDeg = new Map<string, number>();
    for (const c of m.connectors) {
      inDeg.set(c.toInstance, (inDeg.get(c.toInstance) ?? 0) + 1);
      outDeg.set(c.fromInstance, (outDeg.get(c.fromInstance) ?? 0) + 1);
    }
    for (const inst of m.instances) {
      const i = inDeg.get(inst.name) ?? 0;
      const o = outDeg.get(inst.name) ?? 0;
      const isSource = /source/i.test(inst.type) && !/qualifier/i.test(inst.type);
      const isTarget = /target/i.test(inst.type);
      if (i + o === 0) {
        out.push({ severity: "warning", code: "ORPHAN_INSTANCE", message: `Instance ${inst.name} is not connected to anything.`, location: inst.name });
      } else if (!isSource && i === 0) {
        out.push({ severity: "warning", code: "NO_INPUTS", message: `Non-source instance ${inst.name} has no incoming connectors.`, location: inst.name });
      } else if (!isTarget && o === 0) {
        out.push({ severity: "info", code: "NO_OUTPUTS", message: `Non-target instance ${inst.name} has no outgoing connectors.`, location: inst.name });
      }
    }
  }

  // Cycle detection in connector graph
  const adj = new Map<string, Set<string>>();
  for (const c of m.connectors) {
    if (!adj.has(c.fromInstance)) adj.set(c.fromInstance, new Set());
    adj.get(c.fromInstance)!.add(c.toInstance);
  }
  const visited = new Set<string>();
  const onPath = new Set<string>();
  const cycleNodes = new Set<string>();
  function dfs(node: string) {
    if (cycleNodes.has(node)) return;
    if (onPath.has(node)) {
      cycleNodes.add(node);
      return;
    }
    if (visited.has(node)) return;
    visited.add(node);
    onPath.add(node);
    for (const next of adj.get(node) ?? []) dfs(next);
    onPath.delete(node);
  }
  for (const n of adj.keys()) dfs(n);
  if (cycleNodes.size > 0) {
    out.push({
      severity: "error",
      code: "CYCLE_DETECTED",
      message: `Cycle in connector graph involving: ${Array.from(cycleNodes).join(", ")}.`,
    });
  }

  // Connection references missing for lookups / source qualifiers
  for (const tx of m.transformations) {
    if (!/source qualifier|lookup/i.test(tx.type)) continue;
    const refByInstance = session.connectionRefs.find((c) => c.instanceName === tx.name);
    if (!refByInstance) {
      out.push({
        severity: "info",
        code: "NO_CONNECTION_REF",
        message: `Instance ${tx.name} (${tx.type}) has no CONNECTIONREFERENCE entry.`,
        location: tx.name,
      });
    }
  }

  // Parameter references in attributes/SQL not declared
  const declared = new Set(session.parameters.map((p) => p.name));
  const referenced = new Set<string>();
  for (const a of session.attributes) collectParams(a.value, referenced);
  for (const inst of session.transformationInstances)
    for (const a of inst.attributes) collectParams(a.value, referenced);
  for (const tx of m.transformations) for (const a of tx.tableAttributes) collectParams(a.value, referenced);
  for (const p of referenced) {
    if (!declared.has(p) && !/^\$(PM|Source|Target|Input|Output|Sess|Folder)/i.test(p)) {
      out.push({
        severity: "info",
        code: "PARAM_NOT_DECLARED",
        message: `Parameter ${p} referenced but not declared in <PARAMETER>.`,
      });
    }
  }

  // Parameter file declared anywhere? If $$VAR references exist but the session
  // has no "Parameter Filename" attribute, runtime values won't be loaded.
  const paramFile = session.attributes.find((a) => /parameter.*file.?name/i.test(a.name))?.value;
  if (referenced.size > 0 && !paramFile) {
    out.push({
      severity: "warning",
      code: "PARAM_FILE_MISSING",
      message: `Session references ${referenced.size} parameter(s) but has no "Parameter Filename" attribute — runtime values will not be loaded.`,
    });
  }

  // Source qualifier with neither SQL Query nor any connected output port — likely dead.
  const fromInstanceCount = new Map<string, number>();
  for (const c of m.connectors) fromInstanceCount.set(c.fromInstance, (fromInstanceCount.get(c.fromInstance) ?? 0) + 1);
  for (const tx of m.transformations) {
    if (!/source qualifier/i.test(tx.type)) continue;
    const sql = pick(tx, "Sql Query");
    if (!sql && (fromInstanceCount.get(tx.name) ?? 0) === 0) {
      out.push({
        severity: "warning",
        code: "SQ_NO_SQL_NO_PORTS",
        message: `Source Qualifier ${tx.name} has no SQL Query and no outgoing connectors.`,
        location: tx.name,
      });
    }
  }

  // Target instance without "Target load type" override
  for (const inst of session.transformationInstances) {
    if (!/target/i.test(inst.type)) continue;
    const loadType = inst.attributes.find((a) => a.name.toLowerCase() === "target load type")?.value;
    if (!loadType) {
      out.push({
        severity: "info",
        code: "TARGET_NO_LOAD_TYPE",
        message: `Target ${inst.name} has no "Target load type" override (defaults to "Normal").`,
        location: inst.name,
      });
    }
  }

  // Duplicate instance names
  const instanceNames = new Map<string, number>();
  for (const inst of m.instances) {
    instanceNames.set(inst.name, (instanceNames.get(inst.name) ?? 0) + 1);
  }
  for (const [name, count] of instanceNames) {
    if (count > 1) {
      out.push({
        severity: "error",
        code: "DUPLICATE_INSTANCE_NAME",
        message: `Instance name "${name}" appears ${count} times in this mapping.`,
        location: name,
      });
    }
  }

  // Connection variable references without matching connection ref
  for (const a of session.attributes) {
    const m2 = a.name.match(/^\$(Source|Target)\s+connection\s+value$/i);
    if (!m2) continue;
    if (!a.value) continue;
    const refDir = m2[1].toLowerCase();
    const hasMatching = session.connectionRefs.some((c) =>
      (refDir === "source" ? /source|lookup/i.test(c.instanceType) : /target/i.test(c.instanceType)) &&
      c.connectionName === a.value,
    );
    if (!hasMatching) {
      out.push({
        severity: "warning",
        code: "CONNECTION_VAR_UNRESOLVED",
        message: `Session attribute "${a.name}=${a.value}" has no matching ${refDir} CONNECTIONREFERENCE.`,
        location: a.name,
      });
    }
  }

  // Audit-column hint: write targets in a Bronze/Silver/Gold layer typically include
  // load-tracking columns (LOAD_DT/LOAD_TS/BATCH_ID/SOURCE_FILE/INGEST_TS).
  const AUDIT_PATTERNS = [/load.?(dt|ts|date|time)/i, /ingest.?(dt|ts|time)/i, /batch.?id/i, /source.?(sys|file|system)/i];
  for (const tgt of m.targets) {
    const hasAudit = tgt.fields.some((f) => AUDIT_PATTERNS.some((re) => re.test(f.name)));
    if (!hasAudit && tgt.fields.length > 0) {
      out.push({
        severity: "info",
        code: "AUDIT_COL_MISSING",
        message: `Target ${tgt.name} has no audit column (LOAD_DT/INGEST_TS/BATCH_ID/SOURCE_SYS). Recommended for downstream lineage.`,
        location: tgt.name,
      });
    }
  }

  // Empty transformation definition
  for (const tx of m.transformations) {
    if (tx.fields.length === 0 && tx.tableAttributes.length === 0) {
      out.push({
        severity: "warning",
        code: "EMPTY_TRANSFORMATION",
        message: `Transformation ${tx.name} (${tx.type}) has no ports and no attributes.`,
        location: tx.name,
      });
    }
  }

  return out;
}

function pick(t: TransformationDef, name: string): string {
  return t.tableAttributes.find((a) => a.name.toLowerCase() === name.toLowerCase())?.value ?? "";
}

function collectParams(text: string, into: Set<string>) {
  const matches = text.matchAll(/\$\$[A-Za-z_][A-Za-z0-9_]*/g);
  for (const m of matches) into.add(m[0]);
}
