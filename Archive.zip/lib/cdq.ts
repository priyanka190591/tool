import type { LineageRow } from "./lineage";
import type { ParsedSession } from "./sessions-types";

const REFERENCE_TABLE_PREFIX = /^(DIM_|REF_|M_|MD_|LKP_|MASTER_|MD_|CODES_)/i;
const TIMELINESS_COLUMN_PATTERNS = [
  /^(LOAD|INGEST|BATCH)_(DT|TS|DATE|TIME|ID)$/i,
  /^(CREATED|MODIFIED|UPDATED|INSERTED)_(BY|AT|DT|TS|DATE|TIME)$/i,
  /_(AS_?OF|EFFECTIVE)_?(DT|TS|DATE|TIME)$/i,
  /(LOAD_TS|INGEST_TS|BATCH_ID|ETL_DT|RUN_DATE|SESSION_START)/i,
];

// Words that look like an identifier of an IDMC built-in function we'd not
// treat as a port reference. Used by the format-mask check.
const FORMAT_FUNCTIONS = /\b(TO_CHAR|TO_DATE|TO_NUMBER|TO_DECIMAL|TO_BIGINT|TO_FLOAT)\s*\(/;

export function inferCdqDimension(row: LineageRow, session: ParsedSession): string {
  // Only infer when there's real lineage. Unresolved labels carry no signal.
  // Only skip truly disconnected rows. "(computed)" rows still have an
  // expression worth classifying.
  if (!row.sourceTable || row.sourceTable === "(not wired)") return "";

  const found = new Set<string>();
  const expr = row.expression || "";
  const expressionChain = row.expressionChain || "";
  const fullExpression = `${expr} ${expressionChain}`;

  // 1. Lookup-derived value → Accuracy
  if (row.lookupsUsed) {
    const lkpNames = row.lookupsUsed.split(",").map((s) => s.trim()).filter(Boolean);
    const lookupTables = collectLookupTables(lkpNames, session);
    if (lookupTables.some((t) => REFERENCE_TABLE_PREFIX.test(t)) || lookupTables.length > 0) {
      found.add("Accuracy");
    }
  }

  // 2. Joiner → Integrity (cross-table consistency check)
  if (row.joinersUsed) found.add("Integrity");

  // 3. Aggregator → Consistency
  if (row.aggregatorsUsed) found.add("Consistency");

  // 4. Conformity from explicit type / format checks
  if (/\b(IS_NUMBER|IS_DATE|IS_NOT_NULL|IS_SPACES)\b/.test(fullExpression)) {
    found.add("Conformity");
  }
  // Format mask (second arg to TO_CHAR/TO_DATE/etc.)
  if (FORMAT_FUNCTIONS.test(fullExpression) && /['"]\s*[A-Za-z0-9:/.\- _]+\s*['"]/.test(fullExpression)) {
    found.add("Conformity");
  }

  // 5. Completeness from defaulting / null handling
  if (/\b(NVL|ISNULL)\s*\(/.test(fullExpression)) {
    found.add("Completeness");
  }

  // 6. Timeliness from target column naming
  if (TIMELINESS_COLUMN_PATTERNS.some((re) => re.test(row.targetColumn))) {
    found.add("Timeliness");
  }

  // 7. Uniqueness — primary key target whose path includes an Aggregator
  //    (the IDMC dedup pattern: Aggregator with GROUP BY and no aggregate funcs).
  if ((row.targetKey || "").toUpperCase() === "PRIMARY" && row.aggregatorsUsed) {
    found.add("Uniqueness");
  }

  // 8. Default — direct source-to-target column is "Accuracy" by convention
  //    (source treated as authoritative). Only fire when nothing else matched.
  if (found.size === 0) {
    found.add("Accuracy");
  }

  // Cap at three to keep cells readable. The "(heuristic)" disclaimer lives
  // in the column header now, so we don't repeat "[heuristic] " per cell.
  const ordered = [...found].slice(0, 3);
  return ordered.join(", ");
}

export function inferCdqRule(row: LineageRow, session: ParsedSession): string {
  // Same gate as dimension inference: don't classify unresolved rows.
  // Only skip truly disconnected rows. "(computed)" rows still have an
  // expression worth classifying.
  if (!row.sourceTable || row.sourceTable === "(not wired)") return "";

  const rules: string[] = [];
  const expr = row.expression || "";
  const chain = row.expressionChain || "";
  const all = `${expr} ${chain}`;

  // ── Null handling / defaulting ──
  if (/\bNVL\s*\(/i.test(all)) rules.push("NULL_DEFAULT");
  if (/\bISNULL\s*\(/i.test(all)) rules.push("NULL_CHECK");
  if (/\bIS_NOT_NULL\s*\(/i.test(all)) rules.push("NOT_NULL_CHECK");
  if (/\bIS_SPACES\s*\(/i.test(all)) rules.push("NON_BLANK_CHECK");

  // ── Type / format checks ──
  // IS_DATE(value, 'YYYYMMDD') style — capture the mask.
  const isDateMask = /\bIS_DATE\s*\(\s*[^,)]+,\s*['"]([^'"]+)['"]/i.exec(all);
  if (isDateMask) rules.push(`DATE_PARSE_CHECK[${isDateMask[1]}]`);
  else if (/\bIS_DATE\s*\(/i.test(all)) rules.push("DATE_PARSE_CHECK");
  if (/\bIS_NUMBER\s*\(/i.test(all)) rules.push("NUMERIC_CHECK");

  // TO_DATE / TO_CHAR with format mask are normalization rules.
  const toDateMask = /\bTO_DATE\s*\(\s*[^,)]+,\s*['"]([^'"]+)['"]/i.exec(all);
  if (toDateMask) rules.push(`DATE_PARSE[${toDateMask[1]}]`);
  const toCharMask = /\bTO_CHAR\s*\(\s*[^,)]+,\s*['"]([^'"]+)['"]/i.exec(all);
  if (toCharMask) rules.push(`FORMAT_NORMALIZE[${toCharMask[1]}]`);

  // ── String normalization ──
  if (/\bUPPER\s*\(/i.test(all)) rules.push("CASE_UPPER");
  if (/\bLOWER\s*\(/i.test(all)) rules.push("CASE_LOWER");
  if (/\bINITCAP\s*\(/i.test(all)) rules.push("CASE_INITCAP");
  if (/\b(?:L|R)?TRIM\s*\(/i.test(all)) rules.push("WHITESPACE_TRIM");
  if (/\bREPLACE(?:CHR|STR)\s*\(/i.test(all)) rules.push("STRING_REPLACE");
  if (/\bLPAD\s*\(/i.test(all)) rules.push("LEFT_PAD");
  if (/\bRPAD\s*\(/i.test(all)) rules.push("RIGHT_PAD");

  // ── Aggregation ──
  if (/\bCOUNT\s*\(/i.test(all)) rules.push("RECORD_COUNT");
  if (/\bSUM\s*\(/i.test(all)) rules.push("AGGREGATE_SUM");
  if (/\bAVG\s*\(/i.test(all)) rules.push("AGGREGATE_AVG");
  if (/\b(?:MAX|MIN)\s*\(/i.test(all)) rules.push("AGGREGATE_BOUND");
  if (/\bMEDIAN\s*\(/i.test(all)) rules.push("AGGREGATE_MEDIAN");

  // ── Reference / integrity ──
  if (row.lookupsUsed) rules.push("REFERENCE_LOOKUP");
  if (row.joinersUsed) rules.push("RELATIONAL_JOIN");
  if (row.routersUsed) rules.push("CONDITIONAL_ROUTE");

  // ── Update strategy / change detection ──
  if (/\bDD_(?:INSERT|UPDATE|DELETE|REJECT)\b/i.test(all)) rules.push("CHANGE_DETECTION");

  // ── System / context tagging ──
  if (/\b(?:SYSTIMESTAMP|SYSDATE|CURRENT_TIMESTAMP|CURRENT_DATE|SESSSTARTTIME)\b/i.test(all)) {
    rules.push("LOAD_TIMESTAMP");
  }
  if (/\$\$?PM(?:RepositoryServiceName|MappingName|SessionName|FolderName|WorkflowName)\b/i.test(all)) {
    rules.push("CONTEXT_TAG");
  }

  // ── Numeric / rounding ──
  if (/\bROUND\s*\(/i.test(all)) rules.push("ROUND");
  if (/\bTRUNC\s*\(\s*[^,)]+,\s*['"][A-Z]+['"]/i.test(all)) rules.push("DATE_TRUNCATE");
  else if (/\bTRUNC\s*\(/i.test(all)) rules.push("PRECISION_TRUNCATE");

  // Direct passthrough with no rules detected → leave empty
  if (rules.length === 0) return "";

  const unique = [...new Set(rules)].slice(0, 6);
  return unique.join(", ");
}

function collectLookupTables(lookupInstances: string[], session: ParsedSession): string[] {
  const tables: string[] = [];
  for (const inst of lookupInstances) {
    const txDef = session.mapping?.transformations.find((t) => t.name === inst);
    if (txDef) {
      const t = txDef.tableAttributes.find((a) => /lookup table name/i.test(a.name))?.value;
      if (t) {
        tables.push(t);
        continue;
      }
    }
    const sessInst = session.transformationInstances.find((x) => x.name === inst);
    if (sessInst) {
      const t = sessInst.attributes.find((a) => /lookup table name/i.test(a.name))?.value;
      if (t) tables.push(t);
    }
  }
  return tables;
}
