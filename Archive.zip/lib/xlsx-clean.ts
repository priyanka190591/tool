import ExcelJS from "exceljs";
import type { MappingJson } from "./mapping-schema";

// Clean 6-sheet workbook generated from MappingJson. Sheet order:
//   1. Overall details   — cover page (identity + resolution stats + counts)
//   2. FIELD_MAPPING     — canonical mapping table (the main artefact)
//   3. LOOKUPS           — one row per lookup transformation (SQL lives here)
//   4. TRANSFORMATIONS   — non-lookup TX expressions
//   5. Source SQL        — one row per Source Qualifier + its SQL query
//   6. Session Details   — session-level metadata (attrs/params/conns/etc.)
//
// Optimized for business reviewers: SQL appears only on dedicated sheets,
// never per FIELD_MAPPING row; verbose transformation paths are out of view;
// each row has a single resolved business_logic_expression + readable lineage.

const HEADER_BG = "FF1F2230";
const ALT_FILL = "FFF6F7F9";

export async function buildCleanWorkbook(json: MappingJson): Promise<ArrayBuffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "IDMC Session Dashboard (clean)";
  wb.created = new Date();

  buildOverallDetailsSheet(wb, json);
  buildFieldMappingSheet(wb, json);
  buildLookupsSheet(wb, json);
  buildTransformationsSheet(wb, json);
  buildSourceSqlSheet(wb, json);
  buildConnectionsSheet(wb, json);
  buildSessionDetailsSheet(wb, json);

  const buf = await wb.xlsx.writeBuffer();
  return toArrayBuffer(buf);
}

// Cover-page summary as a Section / Key / Value table.
function buildOverallDetailsSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("Overall details", {
    properties: { tabColor: { argb: "FFEAB308" } }, // amber — easy to spot
  });
  ws.columns = [
    { header: "Section", key: "section", width: 18 },
    { header: "Field", key: "key", width: 32 },
    { header: "Value", key: "value", width: 80 },
  ];
  for (const r of json.overall_details) {
    ws.addRow({ section: r.section, key: r.key, value: r.value });
  }
  finalizeSheet(ws, { freezeCols: 2, wrap: true });
}

// One row per transformation that exposes ANY SQL-bearing TABLEATTRIBUTE.
// Covers SQs (Sql Query / Sql Override / Source Filter / Pre SQL / Post SQL)
// AND Lookups (Lookup Sql Override / Lookup Source Filter). For each row the
// "SQL Text" column concatenates all detected SQL entries as
// `<Label>: <Value> | <Label>: <Value>` (empty values render as just the
// label) — mirrors the reference tool's layout.
function buildSourceSqlSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("Source SQL", {
    properties: { tabColor: { argb: "FF059669" } }, // emerald
  });
  ws.columns = [
    { header: "SQL / Query Name", key: "transformation", width: 28 },
    { header: "Type", key: "transformation_type", width: 22 },
    { header: "Source Definition", key: "source_definition", width: 26 },
    { header: "Connection", key: "connection", width: 22 },
    { header: "Connection Type", key: "connection_type", width: 16 },
    { header: "SQL Types Present", key: "sql_types", width: 30 },
    { header: "Source Tables (from SQL)", key: "source_tables", width: 36 },
    { header: "SQL Text", key: "sql_text", width: 100 },
  ];
  for (const r of json.source_sql) {
    ws.addRow({
      transformation: r.transformation,
      transformation_type: r.transformation_type || "—",
      source_definition: r.source_definition || "—",
      connection: r.connection || "—",
      connection_type: r.connection_type || "—",
      sql_types: r.sql_types || "—",
      source_tables: r.source_tables || "—",
      sql_text: r.sql_text || "—",
    });
  }
  finalizeSheet(ws, { freezeCols: 1, wrap: true });
}

// One row per CONNECTIONREFERENCE — surfaces the binding between an
// instance (Source Qualifier / Target / Lookup) and the connection it uses
// at runtime. Same data also informs the Source Database / Target Database
// columns in FIELD_MAPPING.
function buildConnectionsSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("Connections", {
    properties: { tabColor: { argb: "FF0EA5E9" } }, // sky blue
  });
  ws.columns = [
    { header: "Instance", key: "instance", width: 28 },
    { header: "Instance Type", key: "instance_type", width: 22 },
    { header: "Connection", key: "connection", width: 26 },
    { header: "Connection Type", key: "connection_type", width: 18 },
    { header: "Subtype", key: "subtype", width: 16 },
    { header: "Variable", key: "variable", width: 22 },
  ];
  for (const c of json.connections) {
    ws.addRow({
      instance: c.instance || "—",
      instance_type: c.instance_type || "—",
      connection: c.connection || "—",
      connection_type: c.connection_type || "—",
      subtype: c.subtype || "—",
      variable: c.variable || "—",
    });
  }
  finalizeSheet(ws, { freezeCols: 1, wrap: true });
}

// Session-level metadata (attrs / params / conns / instance overrides / extensions).
function buildSessionDetailsSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("Session Details", {
    properties: { tabColor: { argb: "FF6B7280" } }, // slate
  });
  ws.columns = [
    { header: "Section", key: "section", width: 22 },
    { header: "Key", key: "key", width: 42 },
    { header: "Value", key: "value", width: 80 },
  ];
  for (const r of json.session_details) {
    ws.addRow({ section: r.section, key: r.key, value: r.value });
  }
  finalizeSheet(ws, { freezeCols: 2, wrap: true });
}

// FIELD_MAPPING structure — strict order per spec. Empty cells use the literal
// string "NULL" so reviewers can distinguish "data not available" from a parser
// bug. Source side first, then expression context, then target side, then
// context cells (Parameter File, Notes).
function buildFieldMappingSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("FIELD_MAPPING", {
    properties: { tabColor: { argb: "FF2563EB" } },
  });
  ws.columns = [
    // Used flag (1) — Phase B.1. "YES" for real mappings, "NO" for synthetic
    // rows representing unconnected source fields.
    { header: "Used", key: "is_used", width: 8 },
    // Source side (8) — Source Database is the CONNECTION NAME from the
    // session's CONNECTIONREFERENCE for whichever instance fed this row.
    { header: "Source Table", key: "source_table", width: 26 },
    { header: "Source Database", key: "source_database", width: 22 },
    { header: "Source Column", key: "source_column", width: 24 },
    { header: "Source Datatype", key: "source_datatype", width: 16 },
    { header: "Src Precision", key: "source_precision", width: 12 },
    { header: "Src Scale", key: "source_scale", width: 10 },
    { header: "Src Nullable", key: "source_nullable", width: 12 },
    { header: "Src Key", key: "source_key", width: 14 },
    // Expression / transformation context (4).
    { header: "Business Logic / Expression", key: "business_logic_expression", width: 50 },
    { header: "Expression Type", key: "expression_type", width: 14 },
    { header: "Expression Chain", key: "expression_chain", width: 50 },
    { header: "Transformation Path", key: "transformation_path", width: 44 },
    { header: "Logical Steps", key: "logical_steps", width: 50 },
    // Transformations involved (4) + per-row detail columns (B.2, B.3).
    { header: "Lookups Used", key: "lookups_used", width: 22 },
    { header: "Lookup Type", key: "lookup_type", width: 14 },
    { header: "Lookup Join Condition", key: "lookup_join_condition", width: 40 },
    { header: "Lookup Return Column", key: "lookup_return_column", width: 22 },
    { header: "Lookup Keys (Source → Lookup)", key: "lookup_keys_source_to_lookup", width: 32 },
    { header: "Joiners Used", key: "joiners_used", width: 18 },
    { header: "Joiner Join Type", key: "joiner_join_type", width: 20 },
    { header: "Joiner Join Condition", key: "joiner_join_condition", width: 36 },
    { header: "Routers Used", key: "routers_used", width: 18 },
    { header: "Aggregators Used", key: "aggregators_used", width: 18 },
    { header: "Aggregator Group By", key: "aggregator_group_by", width: 30 },
    // Source-qualifier context (1) — SQ SQL Query lives on the dedicated
    // "Source SQL" sheet to avoid duplicating long multi-line text per row.
    { header: "Source Qualifier", key: "source_qualifier", width: 22 },
    // Data quality (2) — tool-inferred, hence the "(heuristic)" disclaimer
    // in the header. Values are derived from transformation kinds + expression
    // patterns; not present in the source XML.
    { header: "CDQ Dimension (heuristic)", key: "cdq_dimension", width: 22 },
    { header: "CDQ Rule (heuristic)", key: "cdq_rule", width: 26 },
    // Error-handling (1) — Phase C.4.
    { header: "Error Handling Logic", key: "error_logic", width: 36 },
    // Load Type (1) — INSERT / UPDATE / DELETE / REJECT / DATA DRIVEN / UNSPECIFIED.
    // Derived from Update Strategy expressions and target load options.
    { header: "Load Type", key: "load_type", width: 16 },
    // Target side (8) — Target Database is the CONNECTION NAME of the
    // target instance's binding.
    { header: "Target Table", key: "target_table", width: 22 },
    { header: "Target Database", key: "target_database", width: 22 },
    { header: "Target Column", key: "target_column", width: 24 },
    { header: "Target Datatype", key: "target_datatype", width: 16 },
    { header: "Tgt Precision", key: "target_precision", width: 12 },
    { header: "Tgt Scale", key: "target_scale", width: 10 },
    { header: "Tgt Nullable", key: "target_nullable", width: 12 },
    { header: "Tgt Key", key: "target_key", width: 14 },
    // Context (2)
    { header: "Parameter File", key: "parameter_file", width: 30 },
    { header: "Notes", key: "notes", width: 40 },
  ];
  const NULL_LITERAL = "NULL";
  const fill = (v: string | null | undefined): string =>
    v === null || v === undefined || v === "" ? NULL_LITERAL : v;
  for (const r of json.field_mappings) {
    ws.addRow({
      is_used: r.is_used,
      source_table: fill(r.source_table),
      source_database: fill(r.source_database),
      source_column: fill(r.source_column),
      source_datatype: fill(r.source_datatype),
      source_precision: fill(r.source_precision),
      source_scale: fill(r.source_scale),
      source_nullable: fill(r.source_nullable),
      source_key: fill(r.source_key),
      business_logic_expression: fill(r.business_logic_expression),
      expression_type: fill(r.expression_type),
      expression_chain: fill(r.expression_chain),
      transformation_path: fill(r.transformation_path),
      logical_steps: fill(r.logical_steps),
      lookups_used: fill(r.lookups_used),
      lookup_type: fill(r.lookup_type),
      lookup_join_condition: fill(r.lookup_join_condition),
      lookup_return_column: fill(r.lookup_return_column),
      lookup_keys_source_to_lookup: fill(r.lookup_keys_source_to_lookup),
      joiners_used: fill(r.joiners_used),
      joiner_join_type: fill(r.joiner_join_type),
      joiner_join_condition: fill(r.joiner_join_condition),
      routers_used: fill(r.routers_used),
      aggregators_used: fill(r.aggregators_used),
      aggregator_group_by: fill(r.aggregator_group_by),
      source_qualifier: fill(r.source_qualifier),
      cdq_dimension: fill(r.cdq_dimension),
      cdq_rule: fill(r.cdq_rule),
      error_logic: fill(r.error_logic),
      load_type: fill(r.load_type),
      target_table: r.target_table,
      target_database: fill(r.target_database),
      target_column: r.target_column,
      target_datatype: r.target_datatype,
      target_precision: fill(r.target_precision),
      target_scale: fill(r.target_scale),
      target_nullable: fill(r.target_nullable),
      target_key: fill(r.target_key),
      parameter_file: fill(r.parameter_file),
      notes: fill(r.notes),
    });
  }
  finalizeSheet(ws, { freezeCols: 2, wrap: true });
}

function buildLookupsSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("LOOKUPS", { properties: { tabColor: { argb: "FF7C3AED" } } });
  ws.columns = [
    { header: "Lookup ID", key: "lookup_id", width: 24 },
    { header: "Source Table", key: "source_table", width: 26 },
    { header: "Connection", key: "connection", width: 22 },
    { header: "Join Condition", key: "join_condition", width: 40 },
    { header: "Return Fields", key: "return_fields", width: 36 },
    { header: "Cached", key: "is_cached", width: 10 },
    { header: "Persistent", key: "is_persistent", width: 12 },
    { header: "SQL Override", key: "sql_override", width: 80 },
  ];
  for (const lkp of json.lookups) {
    ws.addRow({
      lookup_id: lkp.lookup_id,
      source_table: lkp.source_table,
      connection: lkp.connection ?? "",
      join_condition: lkp.join_conditions.map((c) => `${c.left} = ${c.right}`).join(" AND "),
      return_fields: lkp.return_fields.join(", "),
      is_cached: lkp.is_cached === undefined ? "" : lkp.is_cached ? "YES" : "NO",
      is_persistent: lkp.is_persistent === undefined ? "" : lkp.is_persistent ? "YES" : "NO",
      sql_override: lkp.sql_override ?? "",
    });
  }
  finalizeSheet(ws, { freezeCols: 1, wrap: true });
}

function buildTransformationsSheet(wb: ExcelJS.Workbook, json: MappingJson) {
  const ws = wb.addWorksheet("TRANSFORMATIONS", {
    properties: { tabColor: { argb: "FF0D9488" } },
  });
  ws.columns = [
    { header: "Transformation", key: "name", width: 28 },
    { header: "Type", key: "type", width: 22 },
    { header: "Output Field", key: "output_field", width: 24 },
    { header: "Kind", key: "kind", width: 14 },
    { header: "Expression", key: "formula", width: 80 },
  ];
  for (const t of json.transformations) {
    if (t.expressions.length === 0) {
      ws.addRow({ name: t.name, type: t.type, output_field: "", kind: "", formula: "" });
      continue;
    }
    for (const e of t.expressions) {
      ws.addRow({
        name: t.name,
        type: t.type,
        output_field: e.output_field,
        kind: e.kind,
        formula: e.formula,
      });
    }
  }
  finalizeSheet(ws, { freezeCols: 2, wrap: true });
}

function finalizeSheet(
  ws: ExcelJS.Worksheet,
  opts: { freezeCols?: number; wrap?: boolean } = {},
) {
  const headerRow = ws.getRow(1);
  headerRow.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 11 };
  headerRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: HEADER_BG } };
  headerRow.alignment = { vertical: "middle", horizontal: "left", wrapText: true };
  headerRow.height = 26;
  headerRow.border = { bottom: { style: "thin", color: { argb: "FF1F2230" } } };

  const lastRow = ws.lastRow?.number ?? 1;
  const lastCol = ws.columnCount;
  if (lastRow > 1 && lastCol > 0) {
    for (let r = 2; r <= lastRow; r++) {
      const row = ws.getRow(r);
      row.alignment = { vertical: "top", wrapText: !!opts.wrap };
      if (r % 2 === 0) {
        for (let c = 1; c <= lastCol; c++) {
          row.getCell(c).fill = { type: "pattern", pattern: "solid", fgColor: { argb: ALT_FILL } };
        }
      }
    }
  }

  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: lastCol } };
  ws.views = [{ state: "frozen", ySplit: 1, xSplit: opts.freezeCols ?? 0 }];
}

function toArrayBuffer(buf: ExcelJS.Buffer): ArrayBuffer {
  if (buf instanceof ArrayBuffer) return buf;
  const view = buf as unknown as { buffer: ArrayBufferLike; byteOffset: number; byteLength: number };
  if (view && view.buffer instanceof ArrayBuffer) {
    return view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength);
  }
  const copy = new Uint8Array(new ArrayBuffer((buf as unknown as Uint8Array).byteLength));
  copy.set(buf as unknown as Uint8Array);
  return copy.buffer;
}
