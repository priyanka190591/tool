import { listSessionFiles, parseAllSessions, type ParsedSession } from "./sessions";

export type SearchHit = {
  fileName: string;
  sessionIndex: number;
  sessionName: string;
  mappingName?: string;
  matches: { category: string; sample: string }[];
};

export type SessionFacts = {
  fileName: string;
  sessionIndex: number;
  sessionName: string;
  mappingName?: string;
  description?: string;
  isValid?: string;
  sources: string[];
  targets: string[];
  connections: string[];
  lookups: string[];
  parameters: string[];
  transformations: string[];
  searchable: string;
};

function factsOf(p: ParsedSession): SessionFacts {
  const sources = (p.mapping?.sources ?? []).map((s) => s.name);
  const targets = (p.mapping?.targets ?? []).map((t) => t.name);
  const connections = p.connectionRefs.map((c) => c.connectionName).filter(Boolean);
  const lookups = (p.mapping?.transformations ?? []).filter((t) => /lookup/i.test(t.type)).map((t) => t.name);
  const transformations = (p.mapping?.transformations ?? []).map((t) => `${t.type}:${t.name}`);
  const parameters = p.parameters.map((x) => x.name);
  const sqlBits = (p.mapping?.transformations ?? []).flatMap((t) =>
    t.tableAttributes.filter((a) => /sql|condition|filter/i.test(a.name)).map((a) => a.value),
  );
  const expressionBits = (p.mapping?.transformations ?? []).flatMap((t) =>
    t.fields.filter((f) => !!f.expression).map((f) => `${t.name}.${f.name}=${f.expression}`),
  );
  const attrBits = p.attributes.map((a) => `${a.name}=${a.value}`);
  const searchable = [
    p.name,
    p.description ?? "",
    p.mappingName ?? "",
    sources.join(" "),
    targets.join(" "),
    connections.join(" "),
    lookups.join(" "),
    transformations.join(" "),
    parameters.join(" "),
    sqlBits.join("\n"),
    expressionBits.join("\n"),
    attrBits.join("\n"),
    p.fileName,
  ]
    .join("\n")
    .toLowerCase();
  return {
    fileName: p.fileName,
    sessionIndex: p.sessionIndex,
    sessionName: p.name,
    mappingName: p.mappingName ?? p.mapping?.name,
    description: p.description,
    isValid: p.isValid,
    sources,
    targets,
    connections,
    lookups,
    parameters,
    transformations,
    searchable,
  };
}

let cachedFacts: { mtime: number; facts: SessionFacts[] } | null = null;

async function buildFacts(): Promise<SessionFacts[]> {
  const files = await listSessionFiles();
  const acc: SessionFacts[] = [];
  for (const f of files) {
    try {
      const all = await parseAllSessions(f);
      for (const p of all) acc.push(factsOf(p));
    } catch {
      // skip unparseable files
    }
  }
  cachedFacts = { mtime: Date.now(), facts: acc };
  return acc;
}

export async function getFacts(force = false): Promise<SessionFacts[]> {
  if (!force && cachedFacts && Date.now() - cachedFacts.mtime < 5_000) {
    return cachedFacts.facts;
  }
  return buildFacts();
}

export function invalidateFacts() {
  cachedFacts = null;
}

export async function searchSessions(query: string): Promise<SearchHit[]> {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const facts = await getFacts();
  const hits: SearchHit[] = [];
  for (const f of facts) {
    if (!f.searchable.includes(q)) continue;
    const matches: SearchHit["matches"] = [];
    pushMatch(matches, "Session name", f.sessionName, q);
    pushMatch(matches, "Mapping", f.mappingName, q);
    pushMatch(matches, "Description", f.description, q);
    for (const src of f.sources) pushMatch(matches, "Source", src, q);
    for (const tgt of f.targets) pushMatch(matches, "Target", tgt, q);
    for (const conn of f.connections) pushMatch(matches, "Connection", conn, q);
    for (const lkp of f.lookups) pushMatch(matches, "Lookup", lkp, q);
    for (const p of f.parameters) pushMatch(matches, "Parameter", p, q);
    if (matches.length === 0) {
      // It matched in SQL or expressions; surface a snippet
      const snip = snippet(f.searchable, q);
      if (snip) matches.push({ category: "Content", sample: snip });
    }
    hits.push({
      fileName: f.fileName,
      sessionIndex: f.sessionIndex,
      sessionName: f.sessionName,
      mappingName: f.mappingName,
      matches: matches.slice(0, 8),
    });
  }
  return hits;
}

function pushMatch(into: SearchHit["matches"], category: string, value: string | undefined, q: string) {
  if (!value) return;
  if (value.toLowerCase().includes(q)) into.push({ category, sample: value });
}

function snippet(text: string, q: string): string {
  const i = text.indexOf(q);
  if (i < 0) return "";
  const start = Math.max(0, i - 40);
  const end = Math.min(text.length, i + q.length + 40);
  return (start > 0 ? "…" : "") + text.slice(start, end).replace(/\s+/g, " ") + (end < text.length ? "…" : "");
}
