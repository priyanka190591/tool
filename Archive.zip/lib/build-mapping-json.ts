import type {
  KV,
  MappingDef,
  ParsedSession,
  SourceDef,
  TargetDef,
  TransformationDef,
} from "./sessions";
import { buildLineage, type LineageRow } from "./lineage";
import {
  isFieldMappingUnresolved,
  type FieldDef,
  type FieldMappingJson,
  type KeyValueRow,
  type LoadType,
  type LookupJson,
  type MappingJson,
  type SourceJson,
  type SourceSqlJson,
  type SqlEntry,
  type TargetJson,
  type TransformationJson,
} from "./mapping-schema";

const CONVERSION_FN_RE = /\b(TO_CHAR|TO_DATE|TO_NUMBER|TO_INTEGER|TO_DECIMAL|TO_FLOAT|TO_BIGINT|CAST|CONVERT)\b/i;

export function buildMappingJson(session: ParsedSession): MappingJson {
  const m = session.mapping;
  const lineageRows = buildLineage(session);

  // ── connection-by-instance index, mirrors lineage.ts logic
  const connByInstance = new Map<string, string>();
  for (const c of session.connectionRefs) connByInstance.set(c.instanceName, c.connectionName);

  // ── sources/targets
  const sources: SourceJson[] = (m?.sources ?? []).map((src) => ({
    name: src.name, // The lineage tracer already does name resolution; this is the parsed name.
    connection: lookupConnectionForSourceDef(src, session),
    fields: src.fields.map(toFieldDef),
  }));

  const targets: TargetJson[] = (m?.targets ?? []).map((t) => ({
    name: t.name,
    fields: t.fields.map(toFieldDef),
  }));

  // ── lookups (deduped — one entry per Lookup transformation)
  const lookups: LookupJson[] = (m?.transformations ?? [])
    .filter((t) => /lookup/i.test(t.type))
    .map((t) => buildLookupJson(t, connByInstance));

  // ── non-lookup transformations
  // Every TRANSFORMFIELD with an EXPRESSION is included, classified by kind
  // so reviewers can see ALL the wires (Output Field / Expression cells will
  // match for "Passthrough" rows — that's the IDMC default — but distinct
  // for "Computed" / "Local Variable" rows). Excel users can filter by Kind
  // column to focus on real logic.
  const transformations: TransformationJson[] = (m?.transformations ?? [])
    .filter((t) => !/lookup/i.test(t.type))
    .map((t) => ({
      name: t.name,
      type: t.type,
      expressions: t.fields
        .filter((f) => !!f.expression)
        .map((f) => ({
          output_field: f.name,
          formula: f.expression!,
          kind: classifyExpressionKind(f.name, f.expression!, f.portType),
        })),
    }));

  // ── field_mappings (one per target column, including unmapped)
  const targetIndex = new Map<string, FieldDef>();
  for (const t of targets) for (const f of t.fields) targetIndex.set(`${t.name}::${f.name}`, f);

  const seenTargetCols = new Set<string>();
  const fieldMappings: FieldMappingJson[] = [];

  // Pre-build the SQ-name → SQL map so every row can surface its source-
  // qualifier SQL even when the backward walk doesn't land on the SQ (e.g.,
  // lookup-fed rows, computed rows). Reuses `extractSqlEntries` so any SQL-
  // bearing TABLEATTRIBUTE — Sql Query, Sql Override, User Defined Join,
  // Source Filter, Pre/Post SQL — counts.
  const sqSqlByName = new Map<string, string>();
  for (const t of m?.transformations ?? []) {
    if (!/source qualifier/i.test(t.type)) continue;
    const filled = extractSqlEntries(t.tableAttributes).filter(
      (e) => e.value.trim().length > 0,
    );
    if (filled.length === 0) continue;
    // Keep one composite string per SQ — Sql Query / Sql Override are the
    // primary slots; others appear after, labeled, separated by `\n\n`.
    const text = filled
      .map((e) => (filled.length === 1 ? e.value : `-- ${e.label}\n${e.value}`))
      .join("\n\n");
    sqSqlByName.set(t.name, text);
  }

  for (const r of lineageRows) {
    const key = `${r.targetTable}::${r.targetColumn}`;
    seenTargetCols.add(key);
    const tgtField = targetIndex.get(key);
    fieldMappings.push(buildFieldMapping(r, tgtField, lookups, m, session, sqSqlByName));
  }

  // Backfill any target column not produced by buildLineage (defensive — should be 0 in practice)
  for (const tgt of targets) {
    for (const f of tgt.fields) {
      const key = `${tgt.name}::${f.name}`;
      if (seenTargetCols.has(key)) continue;
      fieldMappings.push({
        ...emptyFieldMapping(),
        target_table: tgt.name,
        target_column: f.name,
        target_datatype: formatDatatype(f),
        target_precision: f.precision ? String(f.precision) : null,
        target_scale: f.scale ? String(f.scale) : null,
        target_nullable: f.nullable === undefined ? null : f.nullable ? "NULL" : "NOTNULL",
        notes: "Unmapped / Not derived",
        lineage: `(unmapped) → ${tgt.name}.${f.name}`,
        is_used: "YES", // a target column exists; just not wired — still counts as mapping intent
      });
    }
  }

  // B.1 — Unmapped SOURCE fields: every SOURCEFIELD that doesn't appear as
  // the source_column of any field_mapping row is silently dropped today.
  // Emit a synthetic row per unused source field so reviewers can see the
  // gap. These rows go AFTER all real mappings in the sheet.
  const usedSourcePairs = new Set<string>();
  for (const r of fieldMappings) {
    const tbl = r.source_table || "";
    const col = r.source_column || "";
    if (!tbl || !col || tbl.startsWith("(")) continue;
    // Multi-source rows: split on the established separator conventions.
    const tables = tbl.split(",").map((s) => s.trim());
    const colGroups = col.split("; ");
    for (let i = 0; i < tables.length; i++) {
      const cols = (colGroups[i] ?? colGroups.join("/")).split("/");
      for (const c of cols) {
        if (c.trim()) usedSourcePairs.add(`${tables[i]}::${c.trim()}`);
      }
    }
  }
  for (const src of sources) {
    for (const f of src.fields) {
      if (usedSourcePairs.has(`${src.name}::${f.name}`)) continue;
      fieldMappings.push({
        ...emptyFieldMapping(),
        source_table: src.name,
        source_column: f.name,
        source_datatype: formatDatatype(f),
        source_precision: f.precision ? String(f.precision) : null,
        source_scale: f.scale ? String(f.scale) : null,
        source_nullable: f.nullable === undefined ? null : f.nullable ? "NULL" : "NOTNULL",
        target_table: "UNUSED",
        target_column: "UNUSED",
        target_datatype: "UNUSED",
        notes: "Source field not connected to any target column",
        lineage: `${src.name}.${f.name} → (unused)`,
        is_used: "NO",
      });
    }
  }

  const orderedFieldMappings = orderTargetRows(fieldMappings);
  const sourceSql = buildSourceSql(m, session, connByInstance);

  return {
    schema_version: "1",
    file_name: session.fileName,
    session_name: session.name,
    mapping_name: session.mappingName ?? m?.name ?? "",
    sources,
    targets,
    lookups,
    transformations,
    field_mappings: orderedFieldMappings,
    overall_details: buildOverallDetails(session, m, orderedFieldMappings, sources, targets, lookups, transformations, sourceSql),
    source_sql: sourceSql,
    connections: session.connectionRefs.map((c) => ({
      instance: c.instanceName || "",
      instance_type: c.instanceType || "",
      connection: c.connectionName || "",
      connection_type: c.connectionType || "",
      subtype: c.connectionSubtype ?? "",
      variable: c.variable ?? "",
    })),
    session_details: buildSessionDetails(session),
  };
}

// ── Source SQL sheet builder ────────────────────────────────────────────────
//
// One row per Source Qualifier transformation. Each row carries the SQL
// query (override if present, otherwise IDMC-generated default), the
// upstream SOURCE definition wired into it, the resolved connection, and
// FROM-clause table extraction so reviewers can see exactly which physical
// tables the SQ reads from.
function buildSourceSql(
  m: MappingDef | undefined,
  session: ParsedSession,
  connByInstance: Map<string, string>,
): SourceSqlJson[] {
  if (!m) return [];
  const out: SourceSqlJson[] = [];
  // Build a quick lookup of upstream source-def names per SQ instance.
  const upstreamByInstance = new Map<string, string>();
  for (const c of m.connectors) {
    if (/source definition/i.test(c.fromInstanceType) && !upstreamByInstance.has(c.toInstance)) {
      upstreamByInstance.set(c.toInstance, c.fromInstance);
    }
  }
  const connTypeByInstance = new Map<string, string>();
  for (const c of session.connectionRefs) connTypeByInstance.set(c.instanceName, c.connectionType);

  for (const t of m.transformations) {
    const entries = extractSqlEntries(t.tableAttributes);
    if (entries.length === 0) continue;

    const filled = entries.filter((e) => e.value.trim().length > 0);
    const allTables = new Set<string>();
    for (const e of filled) {
      for (const tbl of extractFromTables(e.value)) allTables.add(tbl);
    }
    // Combined cell text: "<Label>: <Value> | <Label>: <Value>". When the
    // value is empty (the attribute existed but had no SQL), include just
    // the label so reviewers see "Lookup Source Filter" without ": ".
    const combinedText = entries
      .map((e) => (e.value.trim().length > 0 ? `${e.label}: ${e.value}` : e.label))
      .join(" | ");

    out.push({
      transformation: t.name,
      transformation_type: t.type,
      source_definition: upstreamByInstance.get(t.name) ?? "",
      connection: connByInstance.get(t.name) ?? "",
      connection_type: connTypeByInstance.get(t.name) ?? "",
      sql_types: filled.map((e) => e.label).join(", "),
      source_tables: [...allTables].join(", "),
      sql_text: combinedText,
      sql_entries: entries,
      has_sql: filled.length > 0,
      // Back-compat aliases for older dashboard render code.
      source_qualifier: t.name,
      has_sql_override: filled.length > 0,
      sql_query: combinedText,
    });
  }
  return out;
}

// Comprehensive catalog of IDMC TABLEATTRIBUTE names that can carry SQL.
// Covers Source Qualifier attributes (Sql Query / Sql Override / User Defined
// Join / Source Filter / Pre SQL / Post SQL), Lookup attributes (Lookup Sql
// Override / Lookup Source Filter), and several name variants vendors use.
// Match is case-insensitive AND whitespace/hyphen-insensitive so "Pre-Sql",
// "Pre SQL", and "PreSqlStatements" all collapse to the same slot.
const SQL_ATTR_CATALOG: { label: string; aliases: string[] }[] = [
  {
    label: "Sql Query",
    aliases: ["sql query", "sqlquery"],
  },
  {
    label: "Sql Override",
    aliases: ["sql override", "sqloverride", "user defined join", "userdefinedjoin"],
  },
  {
    label: "Source Filter",
    aliases: ["source filter", "sourcefilter"],
  },
  {
    label: "Pre SQL",
    aliases: ["pre sql", "pre-sql", "presql", "pre sql statements", "presqlstatements"],
  },
  {
    label: "Post SQL",
    aliases: ["post sql", "post-sql", "postsql", "post sql statements", "postsqlstatements"],
  },
  {
    label: "Lookup Sql Override",
    aliases: ["lookup sql override", "lookupsqloverride"],
  },
  {
    label: "Lookup Source Filter",
    aliases: ["lookup source filter", "lookupsourcefilter"],
  },
];

function normalizeAttrName(name: string): string {
  return name.toLowerCase().replace(/[\s_-]+/g, " ").trim();
}

// Scan a transformation's TABLEATTRIBUTEs for any SQL-bearing slot. Returns
// an entry per matching attribute, including ones with empty values (so the
// XLSX can show "Lookup Source Filter" as a label even when the slot exists
// but has no value — matches reference-tool behavior).
function extractSqlEntries(attrs: KV[]): SqlEntry[] {
  const seen = new Set<string>();
  const out: SqlEntry[] = [];
  for (const a of attrs) {
    const norm = normalizeAttrName(a.name);
    const slot = SQL_ATTR_CATALOG.find((c) => c.aliases.includes(norm));
    if (slot) {
      if (seen.has(slot.label)) continue;
      seen.add(slot.label);
      out.push({ label: slot.label, value: a.value ?? "" });
      continue;
    }
    // Fuzzy fallback — any attribute whose name explicitly contains SQL/Query/Override.
    if (/\b(sql|query|override)\b/i.test(a.name)) {
      const label = a.name; // preserve original label
      if (seen.has(label)) continue;
      seen.add(label);
      out.push({ label, value: a.value ?? "" });
    }
  }
  return out;
}

// ── Overall Details sheet builder ──────────────────────────────────────────
//
// Cover-page summary surfaced as a (Section, Key, Value) table. Includes
// session identity, resolution-rate stats, and counts of every major entity
// in the mapping. Designed so a reviewer can answer "is this export sane?"
// in 30 seconds without leafing through other sheets.
function buildOverallDetails(
  session: ParsedSession,
  m: MappingDef | undefined,
  fieldMappings: FieldMappingJson[],
  sources: SourceJson[],
  targets: TargetJson[],
  lookups: LookupJson[],
  transformations: TransformationJson[],
  sourceSql: SourceSqlJson[],
): KeyValueRow[] {
  const rows: KeyValueRow[] = [];
  const add = (section: string, key: string, value: unknown) => {
    if (value === undefined || value === null || value === "") return;
    rows.push({ section, key, value: String(value) });
  };
  // Use the canonical resolved/unresolved definition from mapping-schema so
  // the Overall details sheet, Mapping Inspector, and every other surface
  // report the same number. Counting (literal)/(system)/(aggregated)/(lookup)
  // as "unresolved" would deflate the stats — those rows ARE resolved, just
  // not to a single physical column.
  const unresolved = fieldMappings.filter(isFieldMappingUnresolved).length;
  const resolved = fieldMappings.length - unresolved;
  const pct = fieldMappings.length > 0 ? Math.round((resolved / fieldMappings.length) * 100) : 0;

  add("Identity", "File", session.fileName);
  add("Identity", "Session", session.name);
  add("Identity", "Mapping", session.mappingName ?? m?.name ?? "");
  add("Identity", "Description", session.description);
  add("Identity", "Reusable", session.reusable);
  add("Identity", "Valid", session.isValid);
  add("Identity", "Version", session.versionNumber);
  add("Identity", "Configuration", session.configReference);
  // Match the broadened regex in lib/lineage.ts so the Overall details sheet
  // and the per-row "Parameter File" column agree.
  const PARAM_FILE_RE = /\b(?:param(?:eter)?)[\s_-]*file(?:[\s_-]*name)?\b/i;
  const paramFile =
    session.attributes.find((a) => PARAM_FILE_RE.test(a.name))?.value ??
    session.parameters.find((p) => PARAM_FILE_RE.test(p.name))?.value;
  add("Identity", "Parameter File", paramFile);

  add("Resolution", "Total field mappings", fieldMappings.length);
  add("Resolution", "Resolved", `${resolved} (${pct}%)`);
  add("Resolution", "Unresolved", `${unresolved} (${100 - pct}%)`);

  add("Counts", "Sources", sources.length);
  add("Counts", "Targets", targets.length);
  add("Counts", "Lookups", lookups.length);
  add("Counts", "Transformations (non-lookup)", transformations.length);
  add("Counts", "Source Qualifiers", sourceSql.length);
  add("Counts", "Connections", session.connectionRefs.length);
  add("Counts", "Parameters", session.parameters.length);
  add("Counts", "Session extensions", session.extensions.length);

  if (sources.length > 0) add("Tables", "Source tables", sources.map((s) => s.name).join(", "));
  if (targets.length > 0) add("Tables", "Target tables", targets.map((t) => t.name).join(", "));

  // Disclaimer for columns that are tool-inferred rather than XML-derived.
  add(
    "Notes",
    "Heuristic columns",
    "CDQ Dimension (heuristic) and CDQ Rule (heuristic) are inferred from transformation kinds + expression patterns. They are NOT extracted from the source XML and should be treated as suggestions, not facts.",
  );

  return rows;
}

// ── Session Details sheet builder ──────────────────────────────────────────
//
// All session-level metadata in a single (Section, Key, Value) table:
// session attributes, parameters, connection bindings, instance overrides,
// session extensions. Mirrors what the dashboard's individual Session-group
// sections show — exists in the XLSX so reviewers don't need the dashboard
// for context.
function buildSessionDetails(session: ParsedSession): KeyValueRow[] {
  const rows: KeyValueRow[] = [];
  for (const a of session.attributes) {
    rows.push({ section: "Attributes", key: a.name, value: a.value });
  }
  for (const p of session.parameters) {
    rows.push({ section: "Parameters", key: p.name, value: p.value });
  }
  for (const c of session.connectionRefs) {
    const valueParts = [c.connectionName, c.connectionType, c.connectionSubtype].filter(Boolean);
    rows.push({
      section: "Connections",
      key: `${c.instanceName} (${c.instanceType})`,
      value: valueParts.join(" · "),
    });
  }
  for (const inst of session.transformationInstances) {
    for (const a of inst.attributes ?? []) {
      rows.push({
        section: "Instance Overrides",
        key: `${inst.name}: ${a.name}`,
        value: a.value,
      });
    }
  }
  for (const ext of session.extensions) {
    rows.push({
      section: "Session Extensions",
      key: `${ext.name} (${ext.type}${ext.subtype ? `/${ext.subtype}` : ""})`,
      value: ext.attributes.map((a) => `${a.name}=${a.value}`).join("; "),
    });
  }
  return rows;
}

// ── Local helpers (kept here to avoid coupling lineage.ts internals) ───────
function getAttr(attrs: KV[], name: string): string {
  const hit = attrs.find((a) => a.name.toLowerCase() === name.toLowerCase());
  return hit?.value ?? "";
}

// Tiny FROM/JOIN parser — same shape as lib/lineage.ts:extractFromTables,
// duplicated to avoid widening lineage's export surface for one consumer.
function extractFromTables(sql: string): string[] {
  const pattern = /\b(?:FROM|JOIN)\s+([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*){0,2})/gi;
  const out = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = pattern.exec(sql))) out.add(m[1]);
  return [...out];
}

// When a Router splits the load into INSERT and UPDATE branches, IDMC emits
// two target INSTANCES for the same TARGET DEFINITION. We emit BOTH rows
// (one per branch) per the user-confirmed spec, so reviewers can see each
// branch's source-side and condition independently. This function only
// reorders the rows so duplicates (same target column from different
// branches) sit adjacent — by (target_table, original_target_field_order,
// load_type) for stable, scannable order.
function orderTargetRows(rows: FieldMappingJson[]): FieldMappingJson[] {
  const firstIndex = new Map<string, number>();
  rows.forEach((r, i) => {
    const key = `${r.target_table}::${r.target_column}`;
    if (!firstIndex.has(key)) firstIndex.set(key, i);
  });
  const loadOrder: Record<string, number> = {
    INSERT: 0,
    UPDATE: 1,
    DELETE: 2,
    REJECT: 3,
    "DATA DRIVEN": 4,
    UNSPECIFIED: 5,
  };
  return [...rows].sort((a, b) => {
    const ak = `${a.target_table}::${a.target_column}`;
    const bk = `${b.target_table}::${b.target_column}`;
    const ai = firstIndex.get(ak) ?? 0;
    const bi = firstIndex.get(bk) ?? 0;
    if (ai !== bi) return ai - bi;
    return (loadOrder[a.load_type] ?? 99) - (loadOrder[b.load_type] ?? 99);
  });
}

// ────────────────────────────────────────────────────────────────────
// Lookups
// ────────────────────────────────────────────────────────────────────

function buildLookupJson(
  t: TransformationDef,
  connByInstance: Map<string, string>,
): LookupJson {
  const get = (n: string) =>
    t.tableAttributes.find((a) => a.name.toLowerCase() === n.toLowerCase())?.value ?? "";
  const sourceTable = get("Lookup table name") || get("Lookup Table Name") || get("Lookup table") || "";
  const conditionRaw = get("Lookup condition");
  const sqlOverride = get("Lookup Sql Override");
  const cacheEnabled = get("Lookup cache enabled");
  const cachePersistent = get("Lookup cache persistent");

  return {
    lookup_id: t.name,
    source_table: sourceTable || `(unknown for ${t.name})`,
    connection: connByInstance.get(t.name),
    join_conditions: parseJoinConditions(conditionRaw),
    return_fields: t.fields
      .filter((f) => /LOOKUP\/OUTPUT|LOOKUP|RETURN|OUTPUT/i.test(f.portType || ""))
      .filter((f) => !/INPUT/i.test(f.portType || ""))
      .map((f) => f.name),
    sql_override: sqlOverride || undefined,
    is_cached: cacheEnabled === "YES" ? true : cacheEnabled === "NO" ? false : undefined,
    is_persistent:
      cachePersistent === "YES" ? true : cachePersistent === "NO" ? false : undefined,
  };
}

// Parses "A = B" or "A = B AND C = D" into [{left:"A",right:"B"},{left:"C",right:"D"}].
// Permissive about whitespace; ignores operators other than '=' (which are uncommon in lookup conditions).
function parseJoinConditions(raw: string): { left: string; right: string }[] {
  if (!raw) return [];
  const parts = raw.split(/\s+AND\s+/i);
  const out: { left: string; right: string }[] = [];
  for (const p of parts) {
    const m = p.match(/^\s*([^=\s][^=]*?)\s*=\s*([^=\s].*?)\s*$/);
    if (m) out.push({ left: m[1].trim(), right: m[2].trim() });
  }
  return out;
}

// ────────────────────────────────────────────────────────────────────
// Field mappings
// ────────────────────────────────────────────────────────────────────

function buildFieldMapping(
  r: LineageRow,
  tgtField: FieldDef | undefined,
  lookups: LookupJson[],
  m: MappingDef | undefined,
  session: ParsedSession,
  sqSqlByName: Map<string, string>,
): FieldMappingJson {
  // Lookup-derived rows: source_table collapses to the lookup_id (per user-confirmed
  // schema). The aggregated key-source info already lives in lookups[].join_conditions.
  const lookupId = primaryLookupForRow(r, lookups);
  const sourceTableRaw = r.sourceTable;
  const isUnmapped = sourceTableRaw === "(not wired)" || sourceTableRaw === "";
  const isComputedOnly = sourceTableRaw === "(computed)" || sourceTableRaw.startsWith("(unresolved");

  let source_table: string | null;
  let source_column: string | null;
  if (lookupId) {
    // Show the underlying PHYSICAL table name (e.g. "dbo.bldg") rather than
    // the lookup instance ID (e.g. "lkp_BLDG"). The lookup_id is still
    // available in `lookups_used` and the LOOKUPS sheet pairs Lookup ID ↔
    // Source Table side-by-side, so cross-reference is preserved and the
    // FIELD_MAPPING cell stays SQL-readable.
    source_table = sourceTableRaw || null;
    source_column = r.sourceColumn || null;
    if (!source_table) source_table = lookupId;
    if (!source_column) source_column = pickLookupReturnColumn(r, lookupId, lookups);
  } else if (isUnmapped) {
    source_table = null;
    source_column = null;
  } else if (isComputedOnly) {
    // Classify the kind of computation so the cell isn't a bare NULL:
    //   (system)     — IDMC built-in session/runtime variables (SESSSTARTTIME, $PM…)
    //   (literal)    — hardcoded constant ('Y', '9999-12-31', 0, NULL)
    //   (aggregated) — output of an Aggregator (SUM/COUNT/AVG/MAX/MIN)
    //   (derived)    — anything else computed but without a single source column
    source_table = classifyComputedSource(r.expression);
    source_column = null;
  } else {
    source_table = sourceTableRaw || null;
    source_column = r.sourceColumn || null;
  }

  const finalExpression = computeFinalExpression(r);

  const targetDatatype = tgtField ? formatDatatype(tgtField) : r.targetDataType;
  const sourceDatatype = r.sourceDataType || null;

  const loadType = computeLoadType(r);
  const routerCondition = computeRouterCondition(r, m);
  const dtConversion = computeDatatypeConversion(sourceDatatype, targetDatatype, finalExpression);
  const defaultLogic = computeDefaultLogic(finalExpression ?? "");

  const lineage = formatLineage(source_table, source_column, finalExpression, r);

  let notes: string | null = null;
  if (isUnmapped) {
    notes = finalExpression ? "Derived" : "Unmapped / Not derived";
  } else if (isComputedOnly && finalExpression) {
    notes = "Derived";
  } else if (isComputedOnly && !finalExpression) {
    // The trace reached intermediate transformations but never resolved a
    // source AND no expression was captured. Stays unmapped from the
    // reviewer's standpoint — make notes match what lineage already shows.
    notes = "Unmapped / Not derived";
  } else if (!source_table && !finalExpression && !lookupId) {
    // Belt-and-suspenders: any row without source, expression, OR lookup is
    // effectively unmapped — flag it consistently with the lineage cell.
    notes = "Unmapped / Not derived";
  } else if (r.notes) {
    // Strip "| SQL override: …" segment — SQL lives once in lookups[].sql_override
    // and must not be embedded per row (Prompt 5 de-dup contract).
    const cleaned = r.notes
      .split("|")
      .map((p) => p.trim())
      .filter((p) => p && !/^SQL override:/i.test(p))
      .join(" | ");
    notes = cleaned || null;
  }

  void session; // reserved for future use

  const expressionType = computeExpressionType(finalExpression, lookupId, source_table);

  return {
    // Source side
    source_table,
    source_database: r.sourceConnection || null,
    source_column,
    source_datatype: sourceDatatype,
    source_precision: r.sourcePrecision || null,
    source_scale: r.sourceScale || null,
    source_nullable: r.sourceNullable || null,
    source_key: r.sourceKey || null,

    // Expression / transformation logic
    business_logic_expression: finalExpression,
    expression_type: expressionType,
    expression_chain: r.expressionChain || null,
    transformation_path: r.transformationPath || null,

    // Transformations
    lookups_used: r.lookupsUsed || null,
    joiners_used: r.joinersUsed || null,
    routers_used: r.routersUsed || null,
    aggregators_used: r.aggregatorsUsed || null,

    // Source qualifier
    source_qualifier: r.sourceQualifier || null,
    sq_sql_query: resolveSqSql(r, source_table, sqSqlByName),

    // Data quality
    cdq_dimension: r.cdqDimension || null,
    cdq_rule: r.cdqRule || null,

    // Target side
    target_table: r.targetTable,
    target_database: r.targetConnection || null,
    target_column: r.targetColumn,
    target_datatype: targetDatatype,
    target_precision: r.targetPrecision || (tgtField?.precision ? String(tgtField.precision) : null),
    target_scale: r.targetScale || (tgtField?.scale ? String(tgtField.scale) : null),
    target_nullable: r.targetNullable || (tgtField?.nullable === undefined ? null : tgtField.nullable ? "NULL" : "NOTNULL"),
    target_key: r.targetKey || null,

    // Context
    parameter_file: r.parameterFile || null,
    notes,

    // Derived (kept in JSON for programmatic consumers)
    lookup_used: lookupId,
    datatype_conversion: dtConversion,
    lineage,
    load_type: loadType,
    router_condition: routerCondition,
    default_logic: defaultLogic,

    // ── Phase B + C field population ──
    is_used: "YES",
    ...computeLookupDetailColumns(r, lookupId, lookups),
    ...computeTxDetailColumns(r, m),
    raw_expression_xml: r.rawExpression || null,
    logical_steps: computeLogicalSteps(r.transformationPath, m),
    error_logic: computeErrorLogic(finalExpression ?? "", r.errorHandlingFromXml ?? ""),
  };
}

// emptyFieldMapping returns a FieldMappingJson with all-null/safe defaults
// for the Phase B unmapped-source and target-backfill rows that don't go
// through buildFieldMapping. Centralizing the shape here keeps schema
// additions in one place.
function emptyFieldMapping(): FieldMappingJson {
  return {
    source_table: null,
    source_database: null,
    source_column: null,
    source_datatype: null,
    source_precision: null,
    source_scale: null,
    source_nullable: null,
    source_key: null,
    business_logic_expression: null,
    expression_type: null,
    expression_chain: null,
    transformation_path: null,
    lookups_used: null,
    joiners_used: null,
    routers_used: null,
    aggregators_used: null,
    source_qualifier: null,
    sq_sql_query: null,
    cdq_dimension: null,
    cdq_rule: null,
    target_table: "",
    target_database: null,
    target_column: "",
    target_datatype: "",
    target_precision: null,
    target_scale: null,
    target_nullable: null,
    target_key: null,
    parameter_file: null,
    notes: null,
    lookup_used: null,
    datatype_conversion: "NONE",
    lineage: "",
    load_type: "UNSPECIFIED",
    router_condition: null,
    default_logic: null,
    is_used: "NO",
    lookup_type: null,
    lookup_join_condition: null,
    lookup_return_column: null,
    lookup_keys_source_to_lookup: null,
    joiner_join_type: null,
    joiner_join_condition: null,
    aggregator_group_by: null,
    raw_expression_xml: null,
    logical_steps: null,
    error_logic: null,
  };
}

// ── B.2: Lookup-detail columns ──────────────────────────────────────────────
// When the row's source is a lookup, surface its join condition + return
// column + connected/unconnected type as dedicated columns. Reads from the
// already-built LookupJson[] aggregation.
function computeLookupDetailColumns(
  r: LineageRow,
  lookupId: string | null,
  lookups: LookupJson[],
): Pick<
  FieldMappingJson,
  | "lookup_type"
  | "lookup_join_condition"
  | "lookup_return_column"
  | "lookup_keys_source_to_lookup"
> {
  if (!lookupId) {
    return {
      lookup_type: null,
      lookup_join_condition: null,
      lookup_return_column: null,
      lookup_keys_source_to_lookup: null,
    };
  }
  const lkp = lookups.find((l) => l.lookup_id === lookupId);
  if (!lkp) {
    return {
      lookup_type: null,
      lookup_join_condition: null,
      lookup_return_column: null,
      lookup_keys_source_to_lookup: null,
    };
  }
  // The lineage row records lookupCallStyle when set by the :LKP regex
  // handler in walkExpressionPorts. When absent, default to "Connected"
  // (port-based — the most common shape).
  const type = r.lookupCallStyle === "unconnected" ? "Unconnected" : "Connected";
  const joinCond = lkp.join_conditions
    .map((c) => `${c.left} = ${c.right}`)
    .join(" AND ");
  const returnCol = pickLookupReturnColumn(r, lookupId, lookups);
  const keys = lkp.join_conditions
    .map((c) => `${c.right} → ${c.left}`) // source side → lookup side
    .join(", ");
  return {
    lookup_type: type,
    lookup_join_condition: joinCond || null,
    lookup_return_column: returnCol || null,
    lookup_keys_source_to_lookup: keys || null,
  };
}

// ── B.3: Joiner + Aggregator detail columns ─────────────────────────────────
// Pull Joiner Join Type + Join Condition + Aggregator Group By Ports straight
// from the TX's TABLEATTRIBUTEs. Only fires when the row's joiners_used /
// aggregators_used names a TX we can find in the mapping.
function computeTxDetailColumns(
  r: LineageRow,
  m: MappingDef | undefined,
): Pick<
  FieldMappingJson,
  "joiner_join_type" | "joiner_join_condition" | "aggregator_group_by"
> {
  if (!m) {
    return { joiner_join_type: null, joiner_join_condition: null, aggregator_group_by: null };
  }
  const txByName = new Map(m.transformations.map((t) => [t.name, t]));
  const readAttr = (instName: string, attrName: string): string => {
    const tx = txByName.get(instName);
    if (!tx) return "";
    const hit = tx.tableAttributes.find((a) => a.name.toLowerCase() === attrName.toLowerCase());
    return hit?.value ?? "";
  };
  const joinerInsts = (r.joinersUsed || "").split(",").map((s) => s.trim()).filter(Boolean);
  const aggInsts = (r.aggregatorsUsed || "").split(",").map((s) => s.trim()).filter(Boolean);

  const joinTypes: string[] = [];
  const joinConds: string[] = [];
  for (const inst of joinerInsts) {
    const t = readAttr(inst, "Join Type");
    const c = readAttr(inst, "Join Condition");
    if (t) joinTypes.push(`${inst}: ${t}`);
    if (c) joinConds.push(`${inst}: ${c}`);
  }
  const groupBys: string[] = [];
  for (const inst of aggInsts) {
    const gb = readAttr(inst, "Group By Ports");
    if (gb) groupBys.push(`${inst}: ${gb}`);
  }

  return {
    joiner_join_type: joinTypes.join(" | ") || null,
    joiner_join_condition: joinConds.join(" | ") || null,
    aggregator_group_by: groupBys.join(" | ") || null,
  };
}

// ── C.2: Logical steps labelling ────────────────────────────────────────────
// Turn the raw "→"-joined instance path into "Step 1: <Kind> (<inst>) → …"
// by looking up each instance's transformation type. Source/Target instances
// get their canonical labels even though they're not Transformations.
function computeLogicalSteps(
  path: string | null | undefined,
  m: MappingDef | undefined,
): string | null {
  if (!path) return null;
  const instances = path.split(" → ").map((s) => s.trim()).filter(Boolean);
  if (instances.length === 0) return null;
  const txByName = m
    ? new Map(m.transformations.map((t) => [t.name, t]))
    : new Map<string, TransformationDef>();
  const instByName = m
    ? new Map(m.instances.map((i) => [i.name, i]))
    : new Map<string, (typeof m extends NonNullable<typeof m> ? typeof m["instances"][number] : never)>();
  const labelFor = (inst: string): string => {
    const tx = txByName.get(inst);
    if (tx) return prettifyTxKind(tx.type);
    const i = instByName.get(inst);
    if (i) {
      if (/source/i.test(i.type) && !/qualifier/i.test(i.type)) return "Source";
      if (/target/i.test(i.type)) return "Target";
      return prettifyTxKind(i.type || "");
    }
    return "Instance";
  };
  return instances
    .map((inst, i) => `Step ${i + 1}: ${labelFor(inst)} (${inst})`)
    .join(" → ");
}

function prettifyTxKind(rawType: string): string {
  if (!rawType) return "Transformation";
  // Common normalizations: "Source Qualifier" → "Source Qualifier",
  // "Lookup Procedure" → "Lookup", "Expression" → "Expression", etc.
  if (/source\s*qualifier/i.test(rawType)) return "Source Qualifier";
  if (/lookup/i.test(rawType)) return "Lookup";
  if (/router/i.test(rawType)) return "Router";
  if (/joiner/i.test(rawType)) return "Joiner";
  if (/aggregator/i.test(rawType)) return "Aggregator";
  if (/expression/i.test(rawType)) return "Expression";
  if (/update\s*strategy/i.test(rawType)) return "Update Strategy";
  if (/filter/i.test(rawType)) return "Filter";
  if (/transaction\s*control/i.test(rawType)) return "Transaction Control";
  if (/sorter/i.test(rawType)) return "Sorter";
  if (/rank/i.test(rawType)) return "Rank";
  if (/union/i.test(rawType)) return "Union";
  if (/normalizer/i.test(rawType)) return "Normalizer";
  if (/sequence/i.test(rawType)) return "Sequence Generator";
  if (/source/i.test(rawType)) return "Source";
  if (/target/i.test(rawType)) return "Target";
  return rawType;
}

// ── C.4: Error-handling logic capture ───────────────────────────────────────
// Recognize ERROR('msg') calls and IIF(cond, ERROR('msg'), …) patterns IN
// the expression itself, plus DEFAULTVALUE-based ERROR entries the trace
// collected from upstream ports (the IDMC convention for "raise on null").
// Returns null when no error-raising logic is present.
function computeErrorLogic(expr: string, errorHandlingFromXml: string): string | null {
  const out: string[] = [];
  if (expr) {
    // Plain ERROR('msg') — possibly multiple in the same expression.
    const errMatches = expr.match(/ERROR\s*\(\s*['"][^'"]*['"]\s*\)/gi);
    if (errMatches) {
      for (const m of errMatches) out.push(`Raises: ${m.trim()}`);
    }
    // IIF(condition, ERROR('msg'), value) — surface the trigger condition.
    const iifErr = expr.match(/IIF\s*\(\s*([^,]+),\s*ERROR\s*\(\s*['"]([^'"]*)['"]\s*\)/i);
    if (iifErr) {
      out.push(`Raises error when: ${iifErr[1].trim()} → '${iifErr[2]}'`);
    }
  }
  if (errorHandlingFromXml) {
    for (const entry of errorHandlingFromXml.split(" | ")) {
      if (entry.trim()) out.push(entry.trim());
    }
  }
  return out.length > 0 ? [...new Set(out)].join(" | ") : null;
}

// When the trace dead-ends in a computed value, classify the kind of origin
// so Source Table is informative (vs bare NULL). Recognized buckets:
//   (system)     — SESSSTARTTIME, SYSTIMESTAMP, SYSDATE, $PM…, $$VAR, CURRENT_*
//   (aggregated) — SUM/COUNT/AVG/MAX/MIN/MEDIAN/FIRST/LAST/PERCENTILE
//   (literal)    — single quoted string, number, NULL keyword, TO_DATE on a literal
// Classify a TRANSFORMFIELD's EXPRESSION for the TRANSFORMATIONS sheet's
// Kind column. Lets reviewers filter out IDMC's auto-generated passthrough
// noise without losing visibility — every wire is still in the sheet, but
// only "Computed" rows carry real logic.
function classifyExpressionKind(
  fieldName: string,
  expression: string,
  portType?: string,
): "Passthrough" | "Local Variable" | "Computed" {
  if (/LOCAL\s+VARIABLE/i.test(portType ?? "")) return "Local Variable";
  // Trim AND case-fold so EXPRESSION="x" with port "X" still counts as
  // passthrough (IDMC sometimes emits case-mismatched defaults).
  if (expression.trim().toLowerCase() === fieldName.toLowerCase()) return "Passthrough";
  return "Computed";
}

//   (computed)   — anything else (fallback)
function classifyComputedSource(expr: string | undefined | null): string {
  const e = (expr || "").trim();
  if (!e) return "(computed)";
  if (/\b(SESSSTARTTIME|SYSTIMESTAMP|SYSDATE|CURRENT_DATE|CURRENT_TIMESTAMP|\$PM[A-Za-z_]+|\$\$[A-Za-z_][A-Za-z0-9_]*|\$Source|\$Target)\b/i.test(e)) {
    return "(system)";
  }
  if (/^(SUM|COUNT|AVG|MAX|MIN|MEDIAN|FIRST|LAST|PERCENTILE|STDDEV|VARIANCE)\s*\(/i.test(e)) {
    return "(aggregated)";
  }
  // Literal: a bare quoted string, a number, NULL, or TO_DATE/TO_NUMBER on a literal
  if (/^'[^']*'$/.test(e) || /^[+-]?\d+(\.\d+)?$/.test(e) || /^NULL$/i.test(e)) {
    return "(literal)";
  }
  if (/^TO_DATE\(\s*'[^']*'/i.test(e) || /^TO_NUMBER\(\s*['\d]/i.test(e)) {
    return "(literal)";
  }
  return "(computed)";
}

// Classify the kind of mapping for the Expression Type column:
//   Direct      — pure passthrough; no expression, source resolved
//   Lookup      — value flows from a lookup (lookup_used populated)
//   Conditional — expression contains IIF/DECODE/CASE/WHEN
//   Derived     — anything else with a non-null business logic expression
//   null        — no source AND no expression (unmapped)
function computeExpressionType(
  expr: string | null,
  lookupId: string | null,
  source: string | null,
): import("./mapping-schema").ExpressionType | null {
  if (lookupId) return "Lookup";
  if (expr) {
    if (/\b(IIF|DECODE|CASE|WHEN)\b/i.test(expr)) return "Conditional";
    return "Derived";
  }
  if (source) return "Direct";
  return null;
}

// Resolve the SQ SQL Query column for a row, in priority order:
//   1. Walk found an SQ explicitly (sourceQualifier) → use that SQ's SQL.
//   2. Otherwise scan transformation_path for any known SQ instance.
//   3. If the mapping has EXACTLY one SQ, rows whose source actually depends
//      on data inherit it as session-wide context. Pure literal / system /
//      not-wired / unresolved rows are skipped — the SQL has no relevance
//      to a hardcoded value.
//   4. Otherwise null — multi-SQ mappings where the row doesn't visit any SQ
//      stay null to avoid attributing the wrong SQL.
//
// `resolvedSourceTable` is the post-classifyComputedSource value (e.g.
// "(literal)", "(system)", "(computed)"), NOT the raw lineage trace value —
// the caller passes it in so we can distinguish a literal-cell from a
// data-cell that just happens to have an empty trace.
function resolveSqSql(
  r: LineageRow,
  resolvedSourceTable: string | null,
  sqSqlByName: Map<string, string>,
): string | null {
  if (sqSqlByName.size === 0) return null;
  // 1. Walk found an SQ explicitly.
  if (r.sourceQualifier && sqSqlByName.has(r.sourceQualifier)) {
    return sqSqlByName.get(r.sourceQualifier) ?? null;
  }
  // 2. Scan transformation_path for any known SQ instance.
  if (r.transformationPath) {
    for (const inst of r.transformationPath.split(" → ")) {
      const trimmed = inst.trim();
      if (sqSqlByName.has(trimmed)) return sqSqlByName.get(trimmed) ?? null;
    }
  }
  // 3. Sole-SQ-in-mapping fallback. Skip when the row's resolved source is a
  //    pure literal/system/not-wired/unresolved/computed classifier — those
  //    don't draw data from the SQ, so attaching its SQL would mislead.
  const t = resolvedSourceTable || "";
  const purelyComputed =
    !t ||
    t === "(literal)" ||
    t === "(system)" ||
    t === "(computed)" ||
    t === "(not wired)" ||
    t === "(aggregated)" ||
    t.startsWith("(unresolved");
  if (sqSqlByName.size === 1 && !purelyComputed) {
    return [...sqSqlByName.values()][0];
  }
  return null;
}

function primaryLookupForRow(r: LineageRow, lookups: LookupJson[]): string | null {
  if (!r.lookupsUsed) return null;
  const ids = r.lookupsUsed.split(",").map((s) => s.trim()).filter(Boolean);
  if (ids.length === 0) return null;
  // Prefer one whose lookup definition we have
  const known = ids.find((id) => lookups.some((l) => l.lookup_id === id));
  return known ?? ids[0];
}

function pickLookupReturnColumn(
  r: LineageRow,
  lookupId: string,
  lookups: LookupJson[],
): string | null {
  const lkp = lookups.find((l) => l.lookup_id === lookupId);
  if (!lkp) return r.sourceColumn || null;
  // The row's sourceColumn might be an aggregated list "X; Y". Pick the entry that
  // matches one of the lookup's return_fields; fall back to the first piece.
  const candidates = (r.sourceColumn || "")
    .split(/[;,]/)
    .map((s) => s.trim().split("/").map((x) => x.trim()))
    .flat()
    .filter(Boolean);
  for (const c of candidates) if (lkp.return_fields.includes(c)) return c;
  return candidates[0] ?? lkp.return_fields[0] ?? null;
}

function computeFinalExpression(r: LineageRow): string | null {
  const expr = (r.expression || "").trim();
  return expr || null;
  // No more "bare identifier filter" — the tracer's trivial-passthrough skip
  // already prevents "EXPRESSION=<portName>" from leaking as business logic.
  // The bare identifiers that DO reach here are system functions / constants
  // (SYSTIMESTAMP, SYSDATE, $PMMappingName, etc.) which ARE the business logic
  // and must be preserved for Derived classification + lineage clarity.
}

function computeLoadType(r: LineageRow): LoadType {
  const notes = r.notes || "";
  // Update Strategy expression detection — most reliable signal.
  const usMatch = notes.match(/Update Strategy [^:]+:\s*(.+?)(?:\s*\|\s*|$)/i);
  if (usMatch) {
    const usExpr = usMatch[1].toUpperCase();
    const hasInsert = usExpr.includes("DD_INSERT");
    const hasUpdate = usExpr.includes("DD_UPDATE");
    const hasDelete = usExpr.includes("DD_DELETE");
    const hasReject = usExpr.includes("DD_REJECT");
    const flags = [hasInsert, hasUpdate, hasDelete, hasReject].filter(Boolean).length;
    if (flags > 1) return "DATA DRIVEN";
    if (hasInsert) return "INSERT";
    if (hasUpdate) return "UPDATE";
    if (hasDelete) return "DELETE";
    if (hasReject) return "REJECT";
  }
  // Router group keyword heuristic. Require an explicit underscore-bounded token
  // (e.g. _INS, INS_GRP, _UPD_OUT) to avoid false positives like "ROUTER_DEL"
  // (the substring "DEL" in "DELIVERY" etc.).
  const path = r.transformationPath;
  if (/(?:^|_)(INSERT|INS)(?:_|$|\b)/i.test(path)) return "INSERT";
  if (/(?:^|_)(UPDATE|UPD)(?:_|$|\b)/i.test(path)) return "UPDATE";
  if (/(?:^|_)(DELETE|DEL)(?:_|$|\b)/i.test(path)) return "DELETE";
  if (/(?:^|_)REJECT(?:_|$|\b)/i.test(path)) return "REJECT";
  return "UNSPECIFIED";
}

function computeRouterCondition(r: LineageRow, m: MappingDef | undefined): string | null {
  if (!r.routersUsed || !m) return null;
  const routerIds = r.routersUsed.split(",").map((s) => s.trim()).filter(Boolean);
  for (const id of routerIds) {
    const rtr = m.transformations.find((t) => t.name === id && /router/i.test(t.type));
    if (!rtr) continue;
    // Prefer a group whose name appears in the transformation path; else join all.
    const path = r.transformationPath.toUpperCase();
    const matching = rtr.groups.find((g) => g.name && path.includes(g.name.toUpperCase()));
    if (matching?.condition) return `${id}.${matching.name}: ${matching.condition}`;
    const allConditions = rtr.groups
      .filter((g) => g.condition)
      .map((g) => `${g.name}: ${g.condition}`)
      .join(" | ");
    if (allConditions) return `${id} → ${allConditions}`;
  }
  return null;
}

function computeDatatypeConversion(
  source: string | null,
  target: string,
  expr: string | null,
): string {
  if (!source) return "NONE";
  const srcBase = baseDatatype(source);
  const tgtBase = baseDatatype(target);
  if (!srcBase || !tgtBase) return "NONE";
  const same = srcBase.toLowerCase() === tgtBase.toLowerCase();
  let label = same ? "NONE" : `${srcBase} → ${tgtBase}`;
  if (expr) {
    const m = expr.match(CONVERSION_FN_RE);
    if (m && label !== "NONE") label = `${label} (${m[1].toUpperCase()})`;
    else if (m && label === "NONE") label = `${m[1].toUpperCase()} applied`;
  }
  return label;
}

function baseDatatype(s: string): string {
  // Strip "(p,s)" suffixes and any IDMC-specific parametric form like "number(p,s)"
  return s.replace(/\([^)]*\)/g, "").trim();
}

// Standardized default-logic format: "NULL → <value>" where <value> is the
// literal default the expression substitutes when the input is NULL. Returns
// null when no recognizable NULL-handling pattern is present.
function computeDefaultLogic(expr: string): string | null {
  if (!expr) return null;
  // NVL(X, default)
  const nvl = expr.match(/NVL\(\s*([^,()]+?)\s*,\s*([^)]+?)\s*\)/i);
  if (nvl) return `NULL → ${normalizeDefaultValue(nvl[2])}`;
  // COALESCE(X, default[, ...])
  const coalesce = expr.match(/COALESCE\(\s*([^,()]+?)\s*,\s*([^,)]+?)\s*[,)]/i);
  if (coalesce) return `NULL → ${normalizeDefaultValue(coalesce[2])}`;
  // IIF(ISNULL(X), default, X) — the literal substituted when input IS null
  const iif = expr.match(/IIF\(\s*ISNULL\([^)]+\)\s*,\s*([^,)]+?)\s*,/i);
  if (iif) return `NULL → ${normalizeDefaultValue(iif[1])}`;
  // Bare ISNULL(X) check — the expression checks for NULL but doesn't substitute
  const isnull = expr.match(/\bISNULL\(\s*([^)]+?)\s*\)/i);
  if (isnull) return `NULL → NULL`;
  return null;
}

// Normalize a default value to the canonical form. Keep quotes for strings,
// strip whitespace, and uppercase NULL/true/false literals so the column reads
// consistently across rows.
function normalizeDefaultValue(v: string): string {
  const t = v.trim();
  if (/^null$/i.test(t)) return "NULL";
  if (/^'.*'$/.test(t)) return t;
  if (/^".*"$/.test(t)) return t;
  return t;
}

// Business-friendly lineage. Format: source.col → target.col. Expressions are
// NOT included — they live in their own column (final_expression). This keeps
// the lineage column scannable and consistent across thousands of rows.
function formatLineage(
  src: string | null,
  srcCol: string | null,
  _expr: string | null,
  r: LineageRow,
): string {
  const target = `${r.targetTable}.${r.targetColumn}`;
  if (!src && !srcCol) return `(unmapped) → ${target}`;
  const sourceSide = src && srcCol ? `${src}.${srcCol}` : (src ?? srcCol ?? "(unknown)");
  return `${sourceSide} → ${target}`;
}

// ────────────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────────────

function toFieldDef(f: SourceDef["fields"][number] | TargetDef["fields"][number]): FieldDef {
  return {
    name: f.name,
    datatype: f.datatype,
    precision: f.precision ? Number(f.precision) : undefined,
    scale: f.scale ? Number(f.scale) : undefined,
    nullable: f.nullable === "NULL" ? true : f.nullable === "NOTNULL" ? false : undefined,
  };
}

function formatDatatype(f: FieldDef): string {
  if (!f.precision) return f.datatype;
  if (f.scale && f.scale !== 0) return `${f.datatype}(${f.precision},${f.scale})`;
  return `${f.datatype}(${f.precision})`;
}

function lookupConnectionForSourceDef(
  src: SourceDef,
  session: ParsedSession,
): string | undefined {
  // Try matching by instance name first (rare), then fall back to nothing.
  const ref = session.connectionRefs.find((c) => c.instanceName === src.name);
  return ref?.connectionName;
}

// Used to satisfy TS — KV is referenced in re-exported types; keeps the import live.
void (null as unknown as KV);
