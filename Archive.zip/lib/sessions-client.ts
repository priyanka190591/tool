import { parseSessionsFromXml } from "./sessions-parser";
import type { FileEntry, ParsedSession } from "./sessions-types";

function sessionsBase(): string {
  if (typeof window === "undefined") return "/sessions";
  const basePath = (window as unknown as { __NEXT_DATA__?: { assetPrefix?: string } })?.__NEXT_DATA__?.assetPrefix ?? "";
  return `${basePath.replace(/\/$/, "")}/sessions`;
}

const xmlCache = new Map<string, Promise<ParsedSession[]>>();
let manifestPromise: Promise<string[]> | null = null;
let entriesPromise: Promise<FileEntry[]> | null = null;

function withBust(url: string): string {
  return url;
}

// Percent-encode each path segment individually, leaving "/" separators
// literal. Required when paths contain folder components — the default
// encodeURIComponent would turn "/" into "%2F" and break static fetches.
function encodePath(path: string): string {
  return path.split("/").map(encodeURIComponent).join("/");
}

export function invalidateClientCache() {
  xmlCache.clear();
  manifestPromise = null;
  entriesPromise = null;
}

export async function listSessionFiles(): Promise<string[]> {
  if (!manifestPromise) {
    manifestPromise = discoverSessionFiles().catch((err) => {
      manifestPromise = null;
      throw err;
    });
  }
  return manifestPromise;
}

async function discoverSessionFiles(): Promise<string[]> {
  return loadFromManifest();
}

async function loadFromManifest(): Promise<string[]> {
  const res = await fetch(withBust(`${sessionsBase()}/index.json`), { cache: "no-store" });
  if (!res.ok) throw new Error(`Manifest fetch failed: ${res.status}`);
  const raw = await res.json();
  if (!Array.isArray(raw)) throw new Error("Manifest is not an array");
  // New shape: [{ path, name }]. Old shape: ["a.xml", ...] (kept for one release
  // in case a dev runs the app before regenerating the manifest).
  return raw.map((entry) => {
    if (typeof entry === "string") return entry;
    if (entry && typeof entry === "object" && typeof entry.path === "string") return entry.path;
    throw new Error(`Manifest entry has unexpected shape: ${JSON.stringify(entry)}`);
  });
}

export async function parseAllSessions(fileName: string): Promise<ParsedSession[]> {
  const key = fileName;
  const hit = xmlCache.get(key);
  if (hit) return hit;
  const p = (async () => {
    const res = await fetch(withBust(`${sessionsBase()}/${encodePath(fileName)}`), {
      cache: "no-store",
    });
    if (!res.ok) throw new Error(`Failed to fetch ${fileName} (HTTP ${res.status})`);
    const xml = await res.text();
    return parseSessionsFromXml(fileName, xml);
  })().catch((err) => {
    xmlCache.delete(key);
    throw err;
  });
  xmlCache.set(key, p);
  return p;
}

export async function parseSessionFile(
  fileName: string,
  sessionIndexOrName?: number | string,
): Promise<ParsedSession> {
  const all = await parseAllSessions(fileName);
  if (all.length === 0) throw new Error(`No content parsed from ${fileName}`);
  if (sessionIndexOrName === undefined || sessionIndexOrName === "") return all[0];
  if (typeof sessionIndexOrName === "number") {
    return all[Math.min(Math.max(0, sessionIndexOrName), all.length - 1)];
  }
  const byName = all.find((p) => p.name === sessionIndexOrName);
  return byName ?? all[0];
}

export async function listFileEntries(): Promise<FileEntry[]> {
  if (entriesPromise) return entriesPromise;
  entriesPromise = (async () => {
    const paths = await listSessionFiles();
    const out: FileEntry[] = [];
    for (const path of paths) {
      const fileName = path.split("/").pop() ?? path;
      try {
        const all = await parseAllSessions(path);
        out.push({
          path,
          fileName,
          sessions: all.map((s, i) => ({
            index: i,
            name: s.name,
            mappingName: s.mappingName ?? s.mapping?.name,
          })),
        });
      } catch {
        out.push({ path, fileName, sessions: [{ index: 0, name: fileName }] });
      }
    }
    return out;
  })().catch((err) => {
    entriesPromise = null;
    throw err;
  });
  return entriesPromise;
}
